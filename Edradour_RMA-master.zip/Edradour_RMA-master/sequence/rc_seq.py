from gen.libs import lib
from ..rc import RC


p = RC()


def pre_sequence_definition():
    pre = lib.get_sequence_definition('Edradour RC Pre Sequence')
    pre.add_step(p.first_step_of_pre_seq, name='First Step of Pre Sequence')
    pre.add_step(p.scan_uut_info, name='Scan UUT Label')
    # pre.add_step(p.check_mes_event, name='Check MES Event')
    # pre.add_step(p.query_mes_mac, name='Query MES MAC')
    pre.add_step(p.read_config, name='Read Config')
    pre.add_step(p.upload_test_records, name='Upload Start Records')
    #
    return pre


def main_sequence_definition():
    main = lib.get_sequence_definition('Edradour RC Main Sequence')
    main.add_step(p.first_step_of_main_seq, name='First Step of Main Sequence')
    main.add_step(p.init_connections, name='Init Connections')
    main.add_step(p.get_uut_console, name='Get UUT Console')
    main.add_step(p.power_cycle_u_boot, name='Power Cycle U Boot')
    # main.add_step(p.uboot_version_check, name='U Boot Version Check')
    # main.add_step(p.enter_diag_mode, name='Enter DIAG Mode')
    # main.add_step(p.check_diag_version, name='Check Diag Version')
    # main.add_step(p.check_cpld_version, name='Check CPLD Version')
    # main.add_step(p.program_ideeprom, name='Program IDEEPROM')
    # main.add_step(p.check_ideeprom, name='Check IDEEPROM')
    # main.add_step(p.check_clock, name='Check clock')
    # main.add_step(p.tpm_test_physical, name='TPM Test Physical')
    # main.add_step(p.chassis_temp_check, name='Chassis Temp Check')
    # main.add_step(p.hardware_inventory_check, name='Hardware Inventory Check')
    main.add_step(p.power_off, name='Power off')
    #
    final = main.add_sequence('Final Main Sequence', finalization=True)
    final.add_step(p.close_all_connections, name='Close All Connections')
    final.add_step(p.upload_test_records, name='Upload Test Records')
    final.add_step(p.finalization, name='Finalization')
    return main
