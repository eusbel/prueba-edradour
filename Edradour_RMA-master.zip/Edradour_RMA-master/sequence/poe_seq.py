from gen.libs import lib
from ..bft import POE


p = POE()


def pre_sequence_definition():
    pre = lib.get_sequence_definition('Edradour Pre Sequence')
    pre.add_step(p.first_step_of_pre_seq, name='First Step of Pre Sequence')
    pre.add_step(p.check_program_version, name='Check Program Version')
    pre.add_step(p.scan_uut_info, name='Check Scan SN PN')
    pre.add_step(p.check_all_led_off, name='Check All LED Off')
    pre.add_step(p.check_power_console, name='Check Power and Console Connection')
    pre.add_step(p.check_mes_event, name='Check MES Event')
    pre.add_step(p.query_mes_mac, name='Query MES MAC')
    pre.add_step(p.init_connections, name='Init Connections')
    pre.add_step(p.read_config, name='Read Config')
    pre.add_step(p.get_uut_console, name='Get UUT Console')
    pre.add_step(p.power_cycle_u_boot, name='Check U-Boot Up')
    pre.add_step(p.upload_test_records, name='Upload Start Records')
    #
    return pre


def main_sequence_definition():
    main = lib.get_sequence_definition('Edradour Main Sequence')
    main.add_step(p.first_step_of_main_seq, name='First Step of Main Sequence')
    main.add_step(p.bootloader_version_check, name='Bootloader Version Check')
    main.add_step(p.enter_diag_mode, name='Enter DIAG')
    main.add_step(p.check_diag_version, name='Check Diag Version')
    main.add_step(p.check_ideeprom, name='Check IDEEPROM')
    main.add_step(p.poe_and_traffic_test, name='POE Test')
    main.add_step(p.power_off, name='Power off')
    #
    final = main.add_sequence('Final Main Sequence', finalization=True)
    final.add_step(p.close_all_connections, name='Close All Connections')
    final.add_step(p.upload_test_records, name='Upload Test Records')
    final.add_step(p.print_test_summary, name='Test Summary')
    final.add_step(p.finalization, name='Finalization')
    return main
