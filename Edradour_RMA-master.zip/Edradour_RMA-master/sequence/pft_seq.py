from gen.libs import lib
from ..pft import PFT as P


p = P()


def pre_sequence_definition():
    pre = lib.get_sequence_definition('PFT Pre Sequence')
    pre.add_step(p.first_step_of_pre_seq, name='First Step of Pre Sequence')
    pre.add_step(p.scan_uut_sn, name='Scan UUT Label')
    pre.add_step(p.check_mes_event, name='Check MES Event')

    pre.add_step(p.init_config, name='Init Config')
    pre.add_step(p.upload_test_records, name='Upload Start Records')
    #
    return pre


def main_sequence_definition():
    main = lib.get_sequence_definition('PFT Main Sequence')
    main.add_step(p.first_step_of_main_seq, name='First Step of Main Sequence')
    main.add_step(p.init_connections, name='Init Connections')
    main.add_step(p.get_equipment_console, name='Get Equipment Console')
    main.add_step(p.get_uut_console, name='Get UUT Console')
    main.add_step(p.read_to_test, name='Ready to Test')

    #
    final = main.add_sequence('Final Main Sequence', finalization=True)
    final.add_step(p.close_connections, name='Close Connections')
    final.add_step(p.upload_test_records, name='Upload Test Records')
    final.add_step(p.finalization, name='Finalization')
    return main
