from gen.libs import lib
from ..bft import BFT


p = BFT()


def pre_sequence_definition():
    pre = lib.get_sequence_definition('Edradour Pre Sequence')
    pre.add_step(p.first_step_of_pre_seq, name='First Step of Pre Sequence')
    pre.add_step(p.check_program_version, name='Check Program Version')
    pre.add_step(p.scan_uut_info, name='Check Scan SN PN')
    # pre.add_step(p.check_all_led_off, name='Check All LED Off')
    # pre.add_step(p.check_power_console, name='Check Power and Console Connection')
    # pre.add_step(p.check_mes_event, name='Check MES Event')
    # pre.add_step(p.query_mes_mac, name='Query MES MAC')
    pre.add_step(p.init_connections, name='Init Connections')
    pre.add_step(p.read_config, name='Read Config')
    pre.add_step(p.get_uut_console, name='Get UUT Console')
    # pre.add_step(p.power_cycle_u_boot, name='Check U-Boot Up')
    pre.add_step(p.upload_test_records, name='Upload Start Records')
    #
    return pre


def main_sequence_definition():
    main = lib.get_sequence_definition('Edradour Main Sequence')
    main.add_step(p.first_step_of_main_seq, name='First Step of Main Sequence')
    main.add_step(p.check_u_boot_version, name='Check U Boot Version')
    main.add_step(p.bootloader_mem_test, name='Bootloader Memory Test')
    main.add_step(p.bootloader_version_check, name='Bootloader Version Check')
    main.add_step(p.load_diag, name='Load DIAG')
    main.add_step(p.boot_diag, name='Boot Up DIAG')
    main.add_step(p.create_vfat_paration, name='Create vfat paration')
    main.add_step(p.check_cpld_golden_image, name='Check CPLD Golden Image')
    main.add_step(p.push_button, name='Push Button')
    main.add_step(p.reset_reason, name='Reset Reason')
    main.add_step(p.check_diag_version, name='Check Diag Version')
    main.add_step(p.check_pfe_fw, name='Check PFE FW')
    main.add_step(p.check_emmc_fw_version, name='Check eMMC FW Version')
    main.add_step(p.update_emmc_fw, name='Update eMMC FW')
    main.add_step(p.check_ideeprom, name='Check IDEEPROM')
    main.add_step(p.check_system_status, name='Check System Status', continue_on_error=True)
    main.add_step(p.memory_test, name='Memory Test')
    main.add_step(p.cpu_full_load, name='CPU Full Load')
    main.add_step(p.set_clock, name='Set Clock')
    main.add_step(p.check_clock, name='Check clock')
    main.add_step(p.led_test, name='LED Test')
    main.add_step(p.transceiver_port_pinchk, name='Transceiver Port Pinchk')
    main.add_step(p.i2c_test, name='I2C TEST')
    main.add_step(p.sfp_check, name='SFP PN REV Check')
    main.add_step(p.dump_sfp_info, name='Dump SFP Information')
    main.add_step(p.poe_traffic_test, name='PoE Traffic Test')
    main.add_step(p.traffic_test, name='Full Speed Traffic Test')
    main.add_step(p.low_speed_traffic_test, name='Low Speed Traffic Test')
    main.add_step(p.mgmt_test, name='MGMT Test')
    main.add_step(p.usb_speed_test, name='USB Speed Test')
    main.add_step(p.emmc_test, name='eMMC Test')
    main.add_step(p.tpm_test_physical, name='TPM Test Physical')
    main.add_step(p.fan_speed_direction_test, name='Fan Speed Direction Test')
    main.add_step(p.chassis_temp_check, name='Chassis Temp Check')
    main.add_step(p.hardware_inventory_check, name='Hardware Inventory Check')
    main.add_step(p.ecc_errors_check, name='ECC Errors Check')
    main.add_step(p.memory_size_check, name='Memory Size Check')
    main.add_step(p.check_cpu_cores, name='Check CPU Cores')
    main.add_step(p.reset_test, name='Reset test')
    main.add_step(p.power_off, name='Power off')
    #
    final = main.add_sequence('Final Main Sequence', finalization=True)
    final.add_step(p.close_all_connections, name='Close All Connections')
    final.add_step(p.upload_test_records, name='Upload Test Records')
    final.add_step(p.print_test_summary, name='Test Summary')
    final.add_step(p.finalization, name='Finalization')
    return main
