from gen.libs import lib
from ..mac import MAC as P


p = P()


def pre_sequence_definition():
    pre = lib.get_sequence_definition('Pre Sequence')
    pre.add_step(p.first_step_of_pre_seq, name='First Step of Pre Sequence')
    pre.add_step(p.scan_uut_sn, name='Scan UUT Label')
    pre.add_step(p.check_mes_event, name='Check MES Event')
    pre.add_step(p.query_mes_mac, name='Query MES MAC')
    pre.add_step(p.check_mac_from_sys, name='Check MAC From Sys')
    pre.add_step(p.read_config, name='Read Config')
    pre.add_step(p.upload_test_records, name='Upload Start Records')
    #
    return pre


def main_sequence_definition():
    main = lib.get_sequence_definition('Main Sequence')
    main.add_step(p.first_step_of_main_seq, name='First Step of Main Sequence')
    main.add_step(p.distribute_mb_mac_address, name='Generate MB MAC')
    main.add_step(p.verify_mb_mac, name='Verify MB MAC')
    main.add_step(p.verify_mac_with_jnp, name='Verify MAC With JNP')
    main.add_step(p.update_mac_address_to_mes, name='Upload MAC to MES')
    #
    final = main.add_sequence('Final Main Sequence', finalization=True)
    final.add_step(p.upload_test_records, name='Upload Test Records')
    final.add_step(p.finalization, name='Finalization')
    return main
