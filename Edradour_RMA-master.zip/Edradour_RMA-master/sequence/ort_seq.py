from gen.libs import lib
from ..rit import ORT


p = ORT()


def pre_sequence_definition():
    pre = lib.get_sequence_definition('Edradour Pre Sequence')
    pre.add_step(p.first_step_of_pre_seq, name='First Step of Pre Sequence')
    pre.add_step(p.init_connections, name='Init Connections')
    pre.add_step(p.get_uut_console, name='Get UUT Console')
    pre.add_step(p.get_uut_diag, name='Get UUT DIAG')
    pre.add_step(p.read_diag_info, name='Read DIAG info')
    pre.add_step(p.check_uut_sn_pn, name='Check UUT SN PN')
    pre.add_step(p.check_mes_event, name='Check MES Event')
    pre.add_step(p.query_mes_mac, name='Query MES MAC')
    pre.add_step(p.read_config, name='Read Config')
    # check ports
    pre.add_step(p.check_ports, name='Check Ports')
    # pre.add_step(p.check_temperature, name='Check Temperature')
    pre.add_step(p.upload_test_records, name='Upload Start Records')
    #
    return pre


def main_sequence_definition():
    main = lib.get_sequence_definition('Edradour Main Sequence')
    main.add_step(p.first_step_of_main_seq, name='First Step of Main Sequence')

    main.add_step(p.ort_iterations_test, name='ORT Iterations')

    #
    final = main.add_sequence('Final Main Sequence', finalization=True)
    final.add_step(p.close_all_connections, name='Close All Connections')
    final.add_step(p.upload_test_records, name='Upload Test Records')
    final.add_step(p.print_test_summary, name='Test Summary')
    final.add_step(p.finalization, name='Finalization')
    return main
