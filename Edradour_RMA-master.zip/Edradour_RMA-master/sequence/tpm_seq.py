from gen.libs import lib
from ..tpm import TPM


p = TPM()


def pre_sequence_definition():
    pre = lib.get_sequence_definition('Edradour TPM Pre Sequence')
    pre.add_step(p.first_step_of_pre_seq, name='First Step of Pre Sequence')
    pre.add_step(p.check_program_version, name='Check Program Version')
    pre.add_step(p.scan_uut_info, name='Check Scan SN PN')
    pre.add_step(p.check_power_console, name='Check Power and Console Connection')
    pre.add_step(p.check_mes_event, name='Check MES Event')
    pre.add_step(p.query_mes_mac, name='Query MES MAC')
    pre.add_step(p.init_connections, name='Init Connections')
    pre.add_step(p.read_config, name='Read Config')
    pre.add_step(p.get_uut_console, name='Get UUT Console')
    pre.add_step(p.power_cycle_u_boot, name='Check U-Boot Up')
    pre.add_step(p.upload_test_records, name='Upload Start Records')
    #
    return pre


def main_sequence_definition():
    main = lib.get_sequence_definition('Edradour TPM Main Sequence')
    main.add_step(p.first_step_of_main_seq, name='First Step of Main Sequence')
    main.add_step(p.check_u_boot_version, name='Check U Boot Version')
    main.add_step(p.boot_diag, name='Boot DIAG')
    main.add_step(p.create_vfat_paration, name='Create vfat paration')
    main.add_step(p.enter_diag_mode, name='Enter DIAG Mode')
    main.add_step(p.check_diag_version, name='Check Diag Version')
    main.add_step(p.check_ideeprom, name='Check IDEEPROM')
    main.add_step(p.enter_bcm_mode, name='Enter BCM Mode')
    main.add_step(p.delete_old_tpm2_dir, name='Delete Old TPM2 Dir')
    main.add_step(p.download_tpm2_tar_file, name='Download TPM2 Tar File')
    main.add_step(p.extract_tpm2_tar_file, name='Extract TPM2 Tar File')
    main.add_step(p.setup_tpm2_env, name='Setup TPM2 Env')
    main.add_step(p.check_tpm2_programmed_status, name='Check TPM2 Programmed Status')
    main.add_step(p.cleanup_tpm2_certs, name='Cleanup TPM2')
    main.add_step(p.validate_hdls_pre, name='Validate HDLS Pre')
    main.add_step(p.retrieve_tpm_fw_version, name='Retrieve TPM2 FW Version')
    main.add_step(p.run_basic_program_phase, name='Run Basic Program Phase')
    main.add_step(p.run_advanced_program_phase, name='Run Advanced Program Phase')
    main.add_step(p.request_csr_file, name='Request CSR File')
    main.add_step(p.get_device_cert, name='Get Device Cert')
    main.add_step(p.forward_csr_to_dlm, name='Forward CSR to DLM')
    main.add_step(p.upload_cert_file_to_datacenter, name='Upload Cert File to Datacenter')
    main.add_step(p.program_csr_into_tpm2_device, name='Program CSR into Device')
    main.add_step(p.verify_program_csr_into_tpm2_device, name='Verify TPM2')
    main.add_step(p.check_version, name='Check Version')
    main.add_step(p.check_key_handlers_after_programing, name='Check Key Handlers after Programming')
    main.add_step(p.show_idevid_details, name='Show idevid Details')
    main.add_step(p.finalize_cert, name='Finalize Cert')
    main.add_step(p.lookup_session, name='Lookup Session')
    main.add_step(p.check_version, name='Check Version Final')
    main.add_step(p.power_off, name='Power off')
    #
    final = main.add_sequence('Final Main Sequence', finalization=True)
    final.add_step(p.close_all_connections, name='Close All Connections')
    final.add_step(p.upload_test_records, name='Upload Test Records')
    final.add_step(p.print_test_summary, name='Test Summary')
    final.add_step(p.finalization, name='Finalization')
    return main
