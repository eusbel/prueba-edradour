from gen.libs import lib
from ..junos_check import JUNOS_CHECK


p = JUNOS_CHECK()


def pre_sequence_definition():
    pre = lib.get_sequence_definition('Edradour Pre Sequence')
    pre.add_step(p.first_step_of_pre_seq, name='First Step of Pre Sequence')
    pre.add_step(p.check_program_version, name='Check Program Version')
    # pre.add_step(p.check_power_console, name='Check Power and Console Connection')
    pre.add_step(p.scan_uut_info, name='Check Scan SN PN')
    pre.add_step(p.check_mes_event, name='Check MES Event')
    pre.add_step(p.query_mes_mac, name='Query MES MAC')
    pre.add_step(p.init_connections, name='Init Connections')
    pre.add_step(p.read_config, name='Read Config')
    pre.add_step(p.get_uut_console, name='Get UUT Console')
    pre.add_step(p.power_cycle_check_junos_boot, name='JUNOS Boot Up')
    pre.add_step(p.upload_test_records, name='Upload Start Records')
    #
    return pre


def main_sequence_definition():
    main = lib.get_sequence_definition('Edradour Main Sequence')
    main.add_step(p.first_step_of_main_seq, name='First Step of Main Sequence')
    main.add_step(p.enter_cli, name='Enter Cli')
    main.add_step(p.check_junos_version, name='Check JUNOS Version')
    main.add_step(p.check_chassis_hardware, name='Check Chassis Hardware')
    main.add_step(p.check_chassis_mac_address, name='Check Chassis MAC')
    main.add_step(p.check_chassis_hardware_extensive, name='Check Chassis Hardware Extensive')
    main.add_step(p.check_system_firmware, name='Check System Firmware')
    main.add_step(p.check_chassis_firmware_detail, name='Check Chassis Firmware Detail')
    main.add_step(p.request_system_halt, name='Request System Halt')
    main.add_step(p.power_off, name='Power off')
    #
    final = main.add_sequence('Final Main Sequence', finalization=True)
    final.add_step(p.close_all_connections, name='Close All Connections')
    final.add_step(p.upload_test_records, name='Upload Test Records')
    final.add_step(p.print_test_summary, name='Test Summary')
    final.add_step(p.finalization, name='Finalization')
    return main
