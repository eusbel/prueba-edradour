import re
import time
from time import sleep

from .common.dcn import TimerMeta
from .common.quantum import Quantum
from .common.utils import helper
from .common.fields import StrField, Field
from .common import sfchelper
from .define.define import EX4K, cookie_mapping
from .define import define as df
from .common import machelper
from .common.uut import UUT
from .common.pdu import PDU
from .common import scanner
from .common.logger import log


class JUNOS_CHECK(Quantum, metaclass=TimerMeta):
    product_name = 'Edradour'
    sernum = StrField()
    area = 'JUNOS_CHECK'

    mapping = Field()  # type: EX4K

    uut = None
    pdu = None

    u_boot_prompt = 'u-boot>'
    root_prompt = 'root@:RE:0%'
    cli_prompt = 'root>'
    poe_version = None

    def scan_uut_info(self):
        # 扫描 SN
        ans = scanner.ask_question(question='Please scan label. 请扫描标签。 Quét thẻ SN', image='Edradour/images/scan_sn.png')
        self.sernum = ans

        self.check_fail_record(sn=self.sernum, station=self.area)

        # check label 所有信息
        self.check_label(sn=self.sernum)

        # 查询 MES LABEL PN
        pn = sfchelper.get_label_part_number_from_mes(sn=self.sernum)
        # 2nd source NPI
        if 'A' in pn:
            pn = pn[:-1]
        if pn not in cookie_mapping.keys():
            raise Exception(f'Part Number: {pn} is not supported! acceptable list: {list(cookie_mapping.keys())}')
        self.uuttype = pn

        # 读取预定义数据
        self.mapping = cookie_mapping[pn]

        # if self.mapping.group != 'G1':
        #     raise Exception(f'Only Support G1 Test !')

        log.debug(f'SN: {self.sernum}, Label PN:{pn}, uuttype: {self.uuttype}')
        # Double Check mapping APN
        if self.uuttype != self.mapping.apn.r_val:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn r value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn r val: {self.mapping.apn.r_val}. PASS')

        if self.uuttype != self.mapping.apn.w_val:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn w value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn w val: {self.mapping.apn.w_val}. PASS')

        # 记得添加测试记录
        helper.add_record(sn=self.sernum, pn=self.uuttype, area=self.area)

    def check_mes_event(self):
        self.mes_check_event(sn=self.sernum, area='JUNOS_CHECK')
        # 检查genius测试工站
        self.genius_check_event(sn=self.sernum, current_station="FT")
        # 非正常流程检查 TPM 工站的测试记录
        # if helper.mode == helper.DEBUG:
        #     return helper.SKIP
        # self.area_check_mes(self.sernum, area='TPM')

    def query_mes_mac(self):
        mac, size = sfchelper.get_mac_address_from_mes(wsn=self.sernum)
        mac_helper = machelper.MacAddressHelper()
        mac = mac_helper.convert(mac, lower=True, delimiter=':')
        size = int(size)
        self.mac_address, self.mac_block_size = mac, size
        log.debug(f'MAC from MES: {mac}, Size: {size} >> {self.mac_address}, {self.mac_block_size}')
        if mac.replace(":", '').upper() != self.mac_label.upper():
            log.error(f"MAC label:{self.mac_label.upper()} not match MES system:{mac.replace(':', '').upper()}")
        log.debug(f"MAC label:{self.mac_label.upper()} match MES system:{mac.replace(':', '').upper()}")

    def read_config(self):
        self.mapping.uut_ip = helper.config['uut_ip']
        self.mapping.serverip = helper.config['serverip']
        self.mapping.netmask = helper.config['netmask']
        self.mapping.gateway = helper.config['gateway']

        # mac 写入的时候是小写的，读取的时候是大写的！
        self.mapping.mac.set(w_val=self.mac_address, r_val=self.mac_address.upper())
        self.mapping.asn.set(w_val=self.sernum, r_val=self.sernum)
        self.mapping.chas_sn.set(w_val=self.sernum, r_val=self.sernum)

    def get_uut_console(self):
        self.uut.do_connect(close_before_open=True)

    def login_junos(self):
        self.uut.send_wise('', ['login:', 'DIAG>'], timeout=600)
        if 'DIAG>' in self.uut.buffer:
            raise Exception('uut not in JUNOS mode!')
        self.uut.send_wise('root', [self.root_prompt, 'Password:'])
        if 'Password:' in self.uut.buffer:
            self.uut.send_wise(self.mapping.junos_root_password, [self.root_prompt, 'login:'])
            if 'Login incorrect' in self.uut.buffer:
                raise Exception('incorrect root password!')
        self.uut.send_wise('', self.root_prompt)

    def enter_cli(self):
        # if self.mapping.group in [df.GROUP_2, df.GROUP_3]:
        #     return helper.SKIP

        # self.uut.send_wise('root', self.root_re_pmt)
        self.sleep_time(3)
        self.uut.send_wise('cli', self.cli_prompt)
        self.sleep_time(60)

    def check_junos_version(self):
        if self.mapping.group == 'G1':
            self.check_junos_version_g1()
            return
        self.uut.send_wise('show version | no-more', self.cli_prompt)
        # 检查 Model
        captured_model = re.search(r'Model: ([^\r\n]+)', self.uut.buffer)
        if captured_model is None:
            raise Exception('not found Model!!')
        captured_model = captured_model.group(1).strip()
        if captured_model != self.mapping.platform.lower():
            log.error('model mismatch!!!')
            log.debug(f'Expected model: {self.mapping.platform.lower()}, Captured model: {captured_model}, FAIL')
            raise Exception('model mismatch!!!')
        log.debug('model match!!!')
        log.debug(f'Expected model: {self.mapping.platform.lower()}, Captured model: {captured_model}, PASS')

        # 检查JUNOS version
        captured_junos_ver = re.search(r'Junos: ([^\r\n]+)', self.uut.buffer)
        if captured_junos_ver is None:
            raise Exception('not found JUNOS version!!!')
        captured_junos_ver = captured_junos_ver.group(1)
        if captured_junos_ver != self.mapping.junos_version:
            log.error('JUNOS version mismatch!!')
            log.debug(
                f'Expected JUNOS version: {self.mapping.junos_version}, Captured JUNOS version: {captured_junos_ver}, FAIL')
            raise Exception('JUNOS version mismatch!!')
        log.debug('JUNOS version match!!')
        log.debug(
            f'Expected JUNOS version: {self.mapping.junos_version}, Captured JUNOS version: {captured_junos_ver}, PASS')

    def check_junos_version_g1(self):
        self.uut.send_wise('show version | no-more', self.cli_prompt)
        # 检查 Model
        captured_model = re.search(r'Model: ([^\r\n]+)', self.uut.buffer)
        if captured_model is None:
            raise Exception('not found Model!!')
        captured_model = captured_model.group(1).strip()
        if captured_model != self.mapping.platform.lower():
            log.error('model mismatch!!!')
            log.debug(f'Expected model: {self.mapping.platform.lower()}, Captured model: {captured_model}, FAIL')
            raise Exception('model mismatch!!!')
        log.debug('model match!!!')
        log.debug(f'Expected model: {self.mapping.platform.lower()}, Captured model: {captured_model}, PASS')

        # 检查JUNOS version
        captured_junos_ver = re.search(r'Junos: ([^\r\n]+)', self.uut.buffer)
        if captured_junos_ver is None:
            raise Exception('not found JUNOS version!!!')
        captured_junos_ver = captured_junos_ver.group(1)
        if captured_junos_ver not in ['24.4R1.12', '24.4R1-S2.15']:
            log.error('JUNOS version mismatch!!')
            log.debug(
                f"Expected JUNOS version: {['24.4R1.12', '24.4R1-S2.15']}, Captured JUNOS version: {captured_junos_ver}, FAIL")
            raise Exception('JUNOS version mismatch!!')
        log.debug('JUNOS version match!!')
        log.debug(
            f"Expected JUNOS version: {['24.4R1.12', '24.4R1-S2.15']}, Captured JUNOS version: {captured_junos_ver}, PASS")

    def check_chassis_hardware(self):
        self.uut.send_wise('show chassis hardware | no-more', self.cli_prompt)
        chassis_sn = re.search(r'Chassis\s+(\S+)', self.uut.buffer)
        if chassis_sn is None:
            raise Exception('not found chassis SN!!')
        chassis_sn = chassis_sn.group(1).strip()
        if chassis_sn != self.sernum:
            log.error('Chassis SN mismatch!!')
            log.debug(f'Expected Chassis SN: {self.sernum}, Captured Chassis SN: {chassis_sn}, FAIL')
            raise Exception('Chassis SN mismatch!!')
        log.debug('Chassis SN match!!')
        log.debug(f'Expected Chassis SN: {self.sernum}, Captured Chassis SN: {chassis_sn}, PASS')

        # check PN rev
        pn_rev = re.search(r'FPC 0\s+REV (\S+)\s+(\S+)', self.uut.buffer)
        if pn_rev is None:
            raise Exception('not found chassis PN&REV!!')
        chassis_pn = pn_rev.group(2).strip()
        if chassis_pn != self.pn_label.split()[0].strip():
            log.error('Chassis PN mismatch!!')
            log.debug(
                f'Expected Chassis PN: {self.pn_label.split()[0].strip()}, Captured Chassis PN: {chassis_pn}, FAIL')
            raise Exception('Chassis PN mismatch!!')
        log.debug('Chassis PN match!!')
        log.debug(f'Expected Chassis PN: {self.pn_label.split()[0].strip()}, Captured Chassis PN: {chassis_pn}, PASS')

        chassis_pn_rev = pn_rev.group(1).strip()
        if chassis_pn_rev != self.pn_label.split()[2].strip():
            log.error('Chassis PN REV mismatch!!')
            log.debug(
                f'Expected Chassis PN REV: {self.pn_label.split()[2].strip()}, Captured Chassis PN REV: {chassis_pn_rev}, FAIL')
            raise Exception('Chassis PN REV mismatch!!')
        log.debug('Chassis PN REV match!!')
        log.debug(f'Expected Chassis PN REV: {self.pn_label.split()[2].strip()}, Captured Chassis PN REV: {chassis_pn_rev}, PASS')

    def check_chassis_mac_address(self):
        self.uut.send_wise('show chassis mac-addresses', self.cli_prompt)
        helper.check_item('Base address', self.mac_address.lower(), r'Base address\s+(\S+)', self.uut.buffer)
        helper.check_item('Count', str(self.mac_block_size), r'Count\s+(\d+)', self.uut.buffer)

    def check_chassis_hardware_extensive(self):
        self.uut.send_wise('show chassis hardware extensive |no-more', self.cli_prompt)

        # check SKU & SN
        sku_sn = re.search(r'Chassis\s+(\S+)\s+(\S+)', self.uut.buffer)
        if sku_sn is None:
            raise Exception('not found chassis SKU&SN!!')
        chassis_sku = sku_sn.group(2).strip()
        if chassis_sku != self.sku_label.split()[0].strip():
            log.error('Chassis SKU mismatch!!')
            log.error(
                f'Expected Chassis PN: {self.sku_label.split()[0].strip()}, Captured Chassis PN: {chassis_sku}, FAIL')
            raise Exception('Chassis SKU mismatch!!')
        log.debug('Chassis SKU match!!')
        log.debug(f'Expected Chassis PN: {self.sku_label.split()[0].strip()}, Captured Chassis PN: {chassis_sku}, PASS')

        chassis_sn = sku_sn.group(1).strip()
        if chassis_sn != self.sernum:
            log.error('Chassis SN mismatch!!')
            log.error(f'Expected Chassis SN: {self.sernum}, Captured Chassis SN: {chassis_sn}, FAIL')
            raise Exception('Chassis SN mismatch!!')
        log.debug('Chassis SN match!!')
        log.debug(f'Expected Chassis SN: {self.sernum}, Captured Chassis SN: {chassis_sn}, PASS')

        # check sku_rev
        check_value = hex(ord(self.sku_label.split()[-1][-1]))[-2:]
        log.debug(f"Check Address 0x60 7th value is:{check_value}")
        address_str = re.findall(r'Address 0x60: 00 00 00 00 00 00 (\d+) 00 00 ff ff ff ff ff ff ff', self.uut.buffer)
        if not address_str:
            raise Exception('not found Address 0x60')
        # 检查第7位是否有不正确的值
        wrong_value = list(filter(lambda x: x != check_value, address_str))
        if wrong_value:
            log.error(f"Catch wrong value:{wrong_value}")
            raise Exception(f"Catch wrong value:{wrong_value}")
        log.debug(f'Found all Address 0x60 7th is {check_value}, PASS')

    def check_chassis_firmware_detail(self):
        # todo
        if self.mapping.group == 'G1':
            self.check_chassis_firmware_detail_g1()
            return
        self.uut.send_wise('show chassis firmware detail', self.cli_prompt)
        # check POE ver
        if 'P' in self.mapping.platform:
            poe_ver = re.search(r'PoE firmware\s+(\S+)', self.uut.buffer)
            if poe_ver is None:
                raise Exception('not found FPC 0 POE version!!')
            poe_ver = poe_ver.group(1).strip()
            if poe_ver != self.poe_version:
                log.error('FPC 0 POE version mismatch!!')
                log.error(
                    f'Expected FPC 0 POE version: {self.poe_version}, Captured FPC 0 POE version: {poe_ver}, FAIL')
                raise Exception('FPC 0 POE version mismatch!!')
            log.debug('FPC 0 POE version match!!')
            log.debug(f'Expected FPC 0 POE version: {self.poe_version}, Captured FPC 0 POE version: {poe_ver}, PASS')

        # check u_boot
        u_boot_ver = re.search(r'U-Boot\s+(\S+)',  self.uut.buffer)
        if u_boot_ver is None:
            raise Exception('not found FPC 0 U-Boot version!!')
        u_boot_ver = u_boot_ver.group(1).strip()
        if u_boot_ver != self.mapping.u_boot:
            log.error('FPC 0 U-Boot version mismatch!!')
            log.error(
                f'Expected FPC 0 U-Boot version: {self.mapping.u_boot}, Captured FPC 0 U-Boot version: {u_boot_ver}, FAIL')
            raise Exception('FPC 0 U-Boot version mismatch!!')
        log.debug('FPC 0 U-Boot version match!!')
        log.debug(f'Expected FPC 0 U-Boot version: {self.mapping.u_boot}, Captured FPC 0 U-Boot version: {u_boot_ver}, PASS')

    def check_chassis_firmware_detail_g1(self):
        self.uut.send_wise('show chassis firmware detail', self.cli_prompt)
        # check POE ver
        if 'P' in self.mapping.platform:
            poe_ver = re.search(r'PoE firmware\s+(\S+)', self.uut.buffer)
            if poe_ver is None:
                raise Exception('not found FPC 0 POE version!!')
            poe_ver = poe_ver.group(1).strip()
            if poe_ver != self.poe_version:
                log.error('FPC 0 POE version mismatch!!')
                log.error(
                    f'Expected FPC 0 POE version: {self.poe_version}, Captured FPC 0 POE version: {poe_ver}, FAIL')
                raise Exception('FPC 0 POE version mismatch!!')
            log.debug('FPC 0 POE version match!!')
            log.debug(f'Expected FPC 0 POE version: {self.poe_version}, Captured FPC 0 POE version: {poe_ver}, PASS')

        # check u_boot
        u_boot_ver = re.search(r'U-Boot\s+(\S+)',  self.uut.buffer)
        if u_boot_ver is None:
            raise Exception('not found FPC 0 U-Boot version!!')
        u_boot_ver = u_boot_ver.group(1).strip()
        if u_boot_ver not in ['2.12', '2.13', '2.14']:
            log.error('FPC 0 U-Boot version mismatch!!')
            log.error(
                f"Expected FPC 0 U-Boot version: {['2.12', '2.13', '2.14']}, Captured FPC 0 U-Boot version: {u_boot_ver}, FAIL")
            raise Exception('FPC 0 U-Boot version mismatch!!')
        log.debug('FPC 0 U-Boot version match!!')
        log.debug(f"Expected FPC 0 U-Boot version: {['2.12', '2.13', '2.14']}, Captured FPC 0 U-Boot version: {u_boot_ver}, PASS")

    def check_system_firmware(self):
        # todo
        if self.mapping.group == 'G1':
            self.check_system_firmware_g1()
            return
        self.uut.send_wise('show system firmware', self.cli_prompt)
        # check POE ver
        if 'P' in self.mapping.platform:
            poe_ver = re.search(r'FPC 0\s+POE\s+(\S+)\s+(\S+)',  self.uut.buffer)
            if poe_ver is None:
                raise Exception('not found FPC 0 POE version!!')
            current_poe_ver = poe_ver.group(1).strip()
            available_poe_ver = poe_ver.group(2).strip()
            log.debug(f'Current POE version is: {current_poe_ver}')
            log.debug(f'Available POE version is: {available_poe_ver}')
            if current_poe_ver != available_poe_ver:
                log.debug(f'Current POE version not match Available POE version, FAIL')
                raise Exception('Current POE version not match Available POE version')
            else:
                log.debug(f'Current POE version match Available POE version, PASS')
                self.poe_version = available_poe_ver

        # check u_boot
        u_boot_ver = re.search(r'FPC 0\s+U-Boot\s+(\S+)',  self.uut.buffer)
        if u_boot_ver is None:
            raise Exception('not found FPC 0 U-Boot version!!')
        u_boot_ver = u_boot_ver.group(1).strip()
        if u_boot_ver != self.mapping.u_boot:
            log.error('FPC 0 U-Boot version mismatch!!')
            log.error(
                f'Expected FPC 0 U-Boot version: {self.mapping.u_boot}, Captured FPC 0 U-Boot version: {u_boot_ver}, FAIL')
            raise Exception('FPC 0 U-Boot version mismatch!!')
        log.debug('FPC 0 U-Boot version match!!')
        log.debug(f'Expected FPC 0 U-Boot version: {self.mapping.u_boot}, Captured FPC 0 U-Boot version: {u_boot_ver}, PASS')
        # check CPLD
        cpld_ver = re.search(r'FPC 0\s+CPLD\s+(\S+)',  self.uut.buffer)
        if cpld_ver is None:
            raise Exception('not found FPC 0 CPLD version!!')
        cpld_ver = cpld_ver.group(1).strip()
        log.debug(f'Captured FPC 0 CPLD version: {cpld_ver}')
        log.debug(f'Expected FPC 0 CPLD version: {self.mapping.cpld}')
        if cpld_ver not in [self.mapping.cpld, self.mapping.cpld_old]:
            log.error(
                f'Expected CPLD version version: {self.mapping.cpld}, Captured CPLD version : {cpld_ver}, FAIL')
            raise Exception('FPC 0 CPLD version mismatch!!')
        log.debug('FPC 0 CPLD version match!!')
        log.debug(
            f'Expected CPLD version version: {[self.mapping.cpld, self.mapping.cpld_old]}, Captured CPLD version : {cpld_ver}, PASS')

    def check_system_firmware_g1(self):
        self.uut.send_wise('show system firmware', self.cli_prompt)
        # check POE ver
        if 'P' in self.mapping.platform:
            poe_ver = re.search(r'FPC 0\s+POE\s+(\S+)\s+(\S+)',  self.uut.buffer)
            if poe_ver is None:
                raise Exception('not found FPC 0 POE version!!')
            current_poe_ver = poe_ver.group(1).strip()
            available_poe_ver = poe_ver.group(2).strip()
            log.debug(f'Current POE version is: {current_poe_ver}')
            log.debug(f'Available POE version is: {available_poe_ver}')
            if current_poe_ver != available_poe_ver:
                log.debug(f'Current POE version not match Available POE version, FAIL')
                raise Exception('Current POE version not match Available POE version')
            else:
                log.debug(f'Current POE version match Available POE version, PASS')
                self.poe_version = available_poe_ver

        # check u_boot
        u_boot_ver = re.search(r'FPC 0\s+U-Boot\s+(\S+)',  self.uut.buffer)
        if u_boot_ver is None:
            raise Exception('not found FPC 0 U-Boot version!!')
        u_boot_ver = u_boot_ver.group(1).strip()
        if u_boot_ver not in ['2.12', '2.13', '2.14']:
            log.error('FPC 0 U-Boot version mismatch!!')
            log.error(
                f"Expected FPC 0 U-Boot version: {['2.12', '2.13', '2.14']}, Captured FPC 0 U-Boot version: {u_boot_ver}, FAIL")
            raise Exception('FPC 0 U-Boot version mismatch!!')
        log.debug('FPC 0 U-Boot version match!!')
        log.debug(f"Expected FPC 0 U-Boot version: {['2.12', '2.13', '2.14']}, Captured FPC 0 U-Boot version: {u_boot_ver}, PASS")
        # check CPLD
        cpld_ver = re.search(r'FPC 0\s+CPLD\s+(\S+)',  self.uut.buffer)
        if cpld_ver is None:
            raise Exception('not found FPC 0 CPLD version!!')
        cpld_ver = cpld_ver.group(1).strip()
        log.debug(f'Captured FPC 0 CPLD version: {cpld_ver}')
        log.debug(f'Expected FPC 0 CPLD version: {self.mapping.cpld}')
        if cpld_ver not in ['1.22', '1.24', '1.26']:
            log.error(
                f"Expected CPLD version version: {['1.22', '1.24']}, Captured CPLD version : {cpld_ver}, FAIL")
            raise Exception('FPC 0 CPLD version mismatch!!')
        log.debug('FPC 0 CPLD version match!!')
        log.debug(
            f"Expected CPLD version version: {['1.22', '1.24']}, Captured CPLD version : {cpld_ver}, PASS")

    def request_system_halt(self):
        # if self.mapping.group in [df.GROUP_2, df.GROUP_3]:
        #     return helper.SKIP

        self.uut.send_wise('request system halt', '[yes,no] (no)')
        self.uut.send_wise('yes', '')
        self.uut.waitfor('System going down in 30 seconds', 120)
        self.uut.waitfor('Please press any key to reboot', 120)
        log.debug('system is down!')

    def power_cycle_check_junos_boot(self):
        # msg = '[U BOOT] Please power cycle UUT. 请拔下电源然后重新上电'
        # if scanner.yes_or_enter_to_continue(question=msg) is False:
        #     raise Exception('power cycle UUT failed! operator!')
        while True:
            try:
                self.pdu.power_cycle(helper.config['pdu_port'])
                self.uut.send_wise('', 'U-Boot', 30)
                self.login_junos()
                break
            except Exception as e:
                if scanner.yes_or_enter_to_continue(
                        question='(Pre Check Step 2)\n'
                                'Vui lòng kiểm tra lại nguồn điện và cáp đã được kết nối tốt chưa\n'
                                 'Please check the power supply and cables are connected well again',
                        image='Edradour/images/check_power_console.png',
                ) is False:
                    raise Exception('OP Stop Test!')

    def power_off(self):
        self.pdu.power_off(helper.config['pdu_port'])

    def init_connections(self):
        self.uut = UUT(conn_str=helper.config['uut_conn_str'])
        self.pdu = PDU(conn_str=helper.config['pdu_conn_str'])

    def close_all_connections(self):
        self.uut.do_disconnect()

    def first_step_of_pre_seq(self):
        self.check_latest_repo_version(self.product_name)
        super().first_step_of_pre_seq()

    def upload_test_records(self):
        self.update_test_status()
        helper.quick_set('Upload to Genius')
        super().add_genius_records(
            str1name='BASE_MAC',
            str1=self.mac_address,
            str3name='JUNOS_Version',
            str3=self.mapping.junos_version,
            str4name='JUNOS_POE_Firmware_Version',
            str4=self.poe_version,
            str6name='Script_Version',
            str6=self.current_version,
        )
        helper.quick_set('Upload to MES')
        self.add_mes_records()



