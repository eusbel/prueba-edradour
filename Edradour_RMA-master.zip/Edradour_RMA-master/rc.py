import re
import time

from .common.quantum import Quantum
from .common.utils import helper
from .common.fields import Field
from .common import sfchelper
from .define import define as df
from .define.define import cookie_mapping, EX4K
from .common import machelper
from .common.uut import UUT
from .common.pdu import PDU
from .common import scanner
from .common.logger import log
import datetime as dt


class RC(Quantum):

    area = 'RC'
    product_name = 'Edradour'

    mapping = Field()  # type: EX4K

    uut = None

    pdu = None

    u_boot_prompt = 'u-boot>'
    diag_prompt = 'DIAG>'

    def scan_uut_info(self):
        # 扫描 SN
        ans = scanner.ask_question(question='Please scan label. 请扫描标签。 Quét thẻ SN')
        self.sernum = ans

        # 查询 MES LABEL PN
        pn = sfchelper.get_label_part_number_from_mes(sn=self.sernum)
        # 2nd source NPI
        if 'A' in pn:
            pn = pn[:-1]
        if pn not in cookie_mapping.keys():
            raise Exception(f'Part Number: {pn} is not supported! acceptable list: {list(cookie_mapping.keys())}')
        self.uuttype = pn

        # 读取预定义数据
        self.mapping = cookie_mapping[pn]
        # 打印初始化的参数
        log.debug(f'SN: {self.sernum}, Label PN:{pn}, UUTType: {self.uuttype}, Model: {self.mapping.platform}')

        # Double Check mapping APN
        if self.uuttype != self.mapping.apn.r_val:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn r value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn r val: {self.mapping.apn.r_val}. PASS')

        if self.uuttype != self.mapping.apn.w_val:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn w value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn w val: {self.mapping.apn.w_val}. PASS')

        # 记得添加测试记录
        helper.add_record(sn=self.sernum, pn=self.uuttype, area=self.area)

    def check_mes_event(self):
        self.mes_check_event(sn=self.sernum, area=self.area)

    def query_mes_mac(self):
        mac, size = sfchelper.get_mac_address_from_mes(wsn=self.sernum)
        if mac is None:
            helper.quick_set('NO MAC FROM MES')
            raise Exception('no MAC from MES!!!')

        if size != self.mapping.mac_block_size:
            helper.quick_set('MAC Block Size Incorrect')
            raise Exception(f'MAC Block Size Incorrect, expected: {self.mapping.mac_block_size}, got: {size}, FAIL!!!')

        mac_helper = machelper.MacAddressHelper()
        mac = mac_helper.convert(mac, lower=True, delimiter=':')
        size = int(size)
        self.mac_address, self.mac_block_size = mac, size

    def read_config(self):

        self.mapping.uut_ip = helper.config['uut_ip']
        self.mapping.serverip = helper.config['serverip']
        self.mapping.netmask = helper.config['netmask']

        self.mapping.mac.set(w_val=self.mac_address, r_val=self.mac_address.upper())
        self.mapping.asn.set(w_val=self.sernum, r_val=self.sernum)
        self.mapping.chas_sn.set(w_val=self.sernum, r_val=self.sernum)

        # UTC
        now = dt.datetime.now(dt.timezone.utc)
        hex_year = f'{now.year:04X}'
        self.mapping.asy.set(w_val=hex_year, r_val=f'{hex_year[0:2]} {hex_year[2:4]}')
        self.mapping.asm.set(w_val=f'{now.month:02X}', r_val=f'{now.month:02X}')
        self.mapping.asd.set(w_val=f'{now.day:02X}', r_val=f'{now.day:02X}')

        # MES
        rev = sfchelper.get_label_aver_min_from_mes(self.sernum)
        self.mapping.aver_min.set(w_val=rev, r_val=rev)
        self.mapping.arev.set(w_val=rev, r_val=rev)
        model_maj_rev = sfchelper.get_label_model_maj_rev_from_mes(self.sernum)
        self.mapping.mrev_maj.set(w_val=model_maj_rev, r_val=model_maj_rev)

    def get_uut_console(self):
        self.uut.do_connect(close_before_open=True)

    def erase_shmoo_register(self):
        if self.mapping.erase_shmoo is not True:
            self.debug(f'{self.mapping.platform} NO to erase shmoo...SKIP...')
            return helper.SKIP

        self.debug(f'{self.mapping.platform} need to erase shmoo.')
        self.uut.send_wise('sf probe; sf erase 0x100000 0x10000', self.u_boot_prompt)
        if 'Erased: OK' not in self.uut.buffer:
            raise Exception('erase failed!')
        self.uut.send_wise('sf probe; sf erase 0x110000 0x10000', self.u_boot_prompt)
        if 'Erased: OK' not in self.uut.buffer:
            raise Exception('erase failed!')
        self.uut.send_wise('reset', '')
        #
        # 设置一次就好了
        if not self.mapping.ddr_mode_speed:
            log.warning(f'DDR Mode and speed are not set!! -> {self.mapping.platform}')
            raise Exception('please set ddr mode and speed!')

        log.debug(f'{self.mapping.platform} DDR Mode and Speed -> {self.mapping.ddr_mode_speed}')
        ddr_mode, ddr_speed = self.mapping.ddr_mode_speed
        # 只有48T P MP 需要按3 1, 其他都是 4 1
        self.uut.waitfor('Please select DDR mode -')
        time.sleep(0.2)
        self.uut.send_wise(ddr_mode, 'Please select DDR speed -', suffix='')
        time.sleep(0.2)
        self.uut.send_wise(ddr_speed, '', suffix='')

        self.wait_for_u_boot()

    def u_boot_tftp_download(self):
        while True:
            # tftpboot 0x6a000000 192.168.11.20:Edradour_UBOOT_1.0.3_sb_u-boot.img
            self.uut.send_wise(f'tftpboot 0x6a000000 {self.mapping.serverip}:edradour/{self.mapping.u_boot_file}',
                               self.u_boot_prompt)
            if 'Bytes transferred =' not in self.uut.buffer:
                log.error(f'download u boot: {self.mapping.u_boot_file} failed!')
                if scanner.yes_or_enter_to_continue(
                        question=f'Download u boot: {self.mapping.u_boot_file} failed, retry?\n下载u boot 文件失败，重试？') is False:
                    raise Exception('download u boot failed!')
                # retry
                continue

            break

    def update_u_boot_version(self, boot_bank):
        log.debug(f'update u boot bank: {boot_bank}')

        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version in self.uut.buffer:
            log.debug(f'{boot_bank} u boot version is the latest! {self.mapping.u_boot_version}')
            return

        log.warning(f'u boot bank: {boot_bank}, need upgrade to version: {self.mapping.u_boot_version}')
        self.setup_u_boot_env()
        # download
        self.u_boot_tftp_download()

        self.uut.send_wise('sf probe; sf erase 0x0 0x800000; sf write 0x6a000000 0x0 0x800000', self.u_boot_prompt)
        if 'Erased: OK' not in self.uut.buffer:
            raise Exception('erase failed!')
        if 'Written: OK' not in self.uut.buf:
            raise Exception('write failed!')

        self.sleep_time(3)
        # Reset之后新版本才会生效
        self.uut.send_wise('reset', '')
        current_boot_bank = self.wait_for_u_boot()
        if current_boot_bank != '1':
            raise Exception(f'current boot bank should be {boot_bank}, but now is: {current_boot_bank}')

        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            raise Exception(f'upgrade u boot failed!')

        log.debug(f'boot bank: {boot_bank}\' u boot version is the latest. {self.mapping.u_boot_version}')

    def switch_to_primary_u_boot(self):
        log.debug('switch to primary u boot bank(1)')
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x39 0x2', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x8 0x1a', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x9 0x1', '')
        boot_bank = self.wait_for_u_boot()
        if boot_bank != '1':
            log.error(f'switch to primary u boot failed! expected boot bank: 1, but now is: {boot_bank}')
            raise Exception(f'switch to primary u boot failed! expected boot bank: 1, but now is: {boot_bank}')
        log.debug(f'switch to u boot bank: {boot_bank} OK')
        return boot_bank

    def switch_to_secondary_u_boot(self):
        log.debug('switch to secondary u boot bank(2)')
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x39 0x3', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x8 0x1a', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x9 0x1', '')
        boot_bank = self.wait_for_u_boot()
        if boot_bank != '2':
            log.error(f'switch to primary u boot failed! expected boot bank: 2, but now is: {boot_bank}')
            raise Exception(f'switch to primary u boot failed! expected boot bank: 2, but now is: {boot_bank}')
        log.debug(f'switch to u boot bank: {boot_bank} OK')
        return boot_bank

    def check_u_boot_version(self):
        # change to 1
        self.switch_to_primary_u_boot()
        self.update_u_boot_version('1')

        # change to 2
        self.switch_to_secondary_u_boot()
        # update
        self.update_u_boot_version('2')

        # change back to 1
        self.switch_to_primary_u_boot()

    def uboot_version_check(self):
        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(f'not found expected u boot version: {self.mapping.u_boot_version}')
            raise Exception('check u boot version failed!')
        log.debug(f'found expected u boot version: {self.mapping.u_boot_version}')

    def setup_u_boot_env(self):
        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)

        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)

    def enter_diag_mode(self):
        self.setup_u_boot_env()
        self.uut.send_wise('run bootcmd', self.diag_prompt, 360)

        # Check Platform & Part Number
        self.quick_set('Check DIAG Platform')

        diag_platform = re.search(r'\*\s+Platform:\s+(.+)', self.uut.buffer)
        if diag_platform is None:
            raise Exception(f'not found platform: {self.mapping.platform} in DIAG')
        diag_platform = diag_platform.group(1).strip()
        if diag_platform != self.mapping.platform:
            raise Exception(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, FAIL')
        log.debug(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, PASS')

        self.quick_set('Check DIAG Part Number')
        diag_pn = re.search(r'\*\s+Part Number:\s+(.+)', self.uut.buffer)
        if diag_pn is None:
            raise Exception(f'not found part numer: {self.mapping.platform} in DIAG')
        diag_pn = diag_pn.group(1).strip()
        if diag_pn != self.mapping.apn.r_val:
            raise Exception(f'diag platform, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, FAIL')
        log.debug(f'diag part number, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, PASS')

        # config network
        self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.uut_ip} netmask {self.mapping.netmask} up',
                           self.diag_prompt)
        self.sleep_time(5)

        # diag version
        self.uut.send_wise('version', self.diag_prompt)
        if self.mapping.diag_version not in self.uut.buffer:
            raise Exception('not found DIAG version')
        log.debug(f'found expected diag version: {self.mapping.diag_version}')

    def wait_for_u_boot(self):
        self.uut.waitfor(['Hit any key to stop autoboot', 'Do you want to run the Shmoo? [y/N]',
                          '*** U-Boot Boot Menu ***', self.u_boot_prompt],
                         150)
        log.debug(f'found -> {self.uut.foundphrase}')
        # Current Boot Bank: 	1
        current_boot_bank = re.search(r'Current Boot Bank:\s+(\d+)', self.uut.buffer)
        if current_boot_bank is not None:
            current_boot_bank = current_boot_bank.group(1)
        log.debug(f'current boot bank: {current_boot_bank}')

        # JNPR U BOOT
        if '*** U-Boot Boot Menu ***' in self.uut.buffer:
            time.sleep(0.5)
            self.uut.send_esc(['Hit any key to stop autoboot', self.u_boot_prompt])
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Do you want to run the Shmoo? [y/N]' in self.uut.buffer:
            self.uut.send_wise('N', ['Hit any key to stop autoboot', self.u_boot_prompt], 150, suffix='')
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Hit any key to stop autoboot' in self.uut.buffer:
            self.uut.send_esc(self.u_boot_prompt)
            log.debug(f'found -> {self.uut.foundphrase}')

        time.sleep(1)
        self.uut.send_ctrl_c(self.u_boot_prompt)
        return current_boot_bank


    def power_cycle_u_boot(self):
        # msg = '[U BOOT] Please power cycle UUT. 请拔下电源然后重新上电'
        # if scanner.yes_or_enter_to_continue(question=msg) is False:
        #     raise Exception('power cycle UUT failed! operator!')
        self.pdu.power_cycle(helper.config['pdu_port'])
        self.sleep_time(5)
        scanner.get_right_answer(
            question='请选择MGMT LED的状态. \n'
                     'Please select MGMT LED status. \n'
                     'Vui lòng chọn trạng thái đèn LED MGMT. ',
            answers=['PASS', 'FAIL'],
            retry=1,
            right_answer='PASS',
            image=f'Edradour/images/rc_led2.png'
        )

    def power_cycle_diag(self):
        # msg = '[DIAG] Please power cycle UUT. 请拔下电源然后重新上电'
        # if scanner.yes_or_enter_to_continue(question=msg) is False:
        #     raise Exception('power cycle UUT failed! operator!')
        self.pdu.power_cycle(helper.config['pdu_port'])
        self.wait_for_u_boot()
        self.enter_diag_mode()

    def check_diag_version(self):
        self.uut.send_wise('version', self.diag_prompt)
        if self.mapping.diag_version not in self.uut.buffer:
            raise Exception(f'not found expected DIAG version: {self.mapping.diag_version}')
        self.uut.send_wise('cpuinfo', self.diag_prompt)

    def check_cpld_version(self):
        self.uut.send_wise('version', self.diag_prompt)
        if self.mapping.cpld_version not in self.uut.buffer:
            raise Exception(f'not found expected cpld version: {self.mapping.diag_version}')

    def program_ideeprom(self):
        # Disable the IDEEPROM WP
        self.uut.send_wise('cpldwrite 0 0x1f 0x0', self.diag_prompt)

        for i in range(10):
            self.uut.send_wise('ideeprom clear_to_ff CPU_EEPROM 0 0x80', self.diag_prompt)
            if re.search('error|fail', self.uut.buffer, re.I):
                if scanner.yes_or_enter_to_continue('clear id eeprom failed, retry? 清理ID EEPROM失败，重测？') is False:
                    raise Exception('clear id eeprom failed 1!')
                continue
            self.uut.send_wise('ideeprom default CPU_EEPROM', self.diag_prompt)
            if re.search('error|fail', self.uut.buffer, re.I):
                if scanner.yes_or_enter_to_continue(
                        'default id eeprom failed, retry? default ID EEPROM失败，重测？') is False:
                    raise Exception('default id eeprom failed 1!')
                continue
            break
        else:
            raise Exception('clear id eeprom failed 2!')

        targets = [
            self.mapping.jedec,
            self.mapping.eeprom_ver,
            self.mapping.bit_field,
            self.mapping.aver_maj,
            self.mapping.aver_min,

            self.mapping.arev,
            self.mapping.afg,
            self.mapping.mac_mc,
            self.mapping.mac_fv,
            self.mapping.mac_ent,
            self.mapping.msi,
            self.mapping.clei,
            self.mapping.mrev_maj,
            self.mapping.mrev_min,

            # year month day
            self.mapping.asd,
            self.mapping.asm,
            self.mapping.asy,
            #
            self.mapping.aid,
            self.mapping.apn,
            self.mapping.mn,
            #
            self.mapping.mac,
            self.mapping.asn,
            self.mapping.chas_sn,
        ]
        for tg in targets:
            log.debug(f'program: {tg}')
            self.uut.send_wise(f'ideeprom edit CPU_EEPROM {tg.w_name} {tg.w_val}', self.diag_prompt)
            if re.search('error|fail', self.uut.buffer, re.I):
                raise Exception('found error or fail in buffer!')
            if 'Verify the write content - pass' not in self.uut.buffer:
                raise Exception(f'program {tg.w_name} failed!!')
            log.debug(f'program {tg.w_name}: {tg.w_val} PASS.')

        # 这个值会自动写进去，只是做个别项目的CheckSum好像每个SKU都是固定的值
        self.uut.send_wise('ideeprom cksum CPU_EEPROM', self.diag_prompt)
        if re.search('error|fail', self.uut.buffer, re.I):
            raise Exception('check sum failed, found error or fail in buffer!')

    def check_ideeprom(self):
        # 注意此处的检查项目要和上面写的项目保持一致
        self.uut.send_wise('ideeprom show CPU_EEPROM', self.diag_prompt)
        targets = [
            self.mapping.jedec,
            self.mapping.eeprom_ver,
            self.mapping.bit_field,
            self.mapping.aver_maj,
            self.mapping.aver_min,

            self.mapping.arev,
            self.mapping.afg,
            self.mapping.mac_mc,
            self.mapping.mac_fv,
            self.mapping.mac_ent,
            self.mapping.msi,
            self.mapping.clei,
            self.mapping.mrev_maj,
            self.mapping.mrev_min,

            # year month day
            self.mapping.asd,
            self.mapping.asm,
            self.mapping.asy,
            #
            self.mapping.aid,
            self.mapping.apn,
            self.mapping.mn,
            #
            self.mapping.mac,
            self.mapping.asn,
            self.mapping.chas_sn,
        ]
        for tg in targets:
            log.debug(f'verify: {tg}')
            captured = re.search(f'{re.escape(tg.r_name)}: ([^\r\n]*)', self.uut.buffer)
            if captured is None:
                raise Exception(f'not found {tg.r_name}!!!')
            captured = captured.group(1).strip()
            if captured != tg.r_val:
                log.error(f'{tg.r_name}, expected: {tg.r_val}, captured: {captured}, FAIL')
                raise Exception(f'{tg.r_name} mismatch!')
            log.debug(f'{tg.r_name}, expected: {tg.r_val}, captured: {captured}, PASS')

    def check_clock(self):
        self.uut.send_wise('rtctest', self.diag_prompt)
        if 'Rtc test - PASS' not in self.uut.buffer:
            raise Exception('check rtc clock failed!')
        self.uut.send_wise('rtcread', self.diag_prompt)

    def tpm_test_physical(self):
        # tpm_tis_spi spi1.0: 2.0 TPM (device-id 0x1D, rev-id 54)
        # tpm tpm0: A TPM error (256) occurred attempting the self test
        # tpm tpm0: starting up the TPM manually
        # 第一次测试的时候会出现上述Error，是正常的
        self.uut.send_wise('syscall modprobe tpm_tis_spi', self.diag_prompt)
        self.uut.send_wise('tpm -t', self.diag_prompt)
        if 'TPM test PASS' not in self.uut.buffer:
            raise Exception('TPM test failed!')

        self.uut.send_wise('tpm -g', self.diag_prompt)
        if 'TPM test PASS' not in self.uut.buffer:
            raise Exception('TPM -g test failed!')

        # TPM_PT_MANUFACTURER:            IFX�
        manufacturer = re.search(r'TPM_PT_MANUFACTURER:\s+(\w+)', self.uut.buffer)
        if manufacturer is None:
            raise Exception('not found TPM_PT_MANUFACTURER!')
        manufacturer = manufacturer.group(1)
        if manufacturer != self.mapping.tpm_manufacturer:
            log.error(
                f'TPM Manufacturer, expected: {self.mapping.tpm_manufacturer}, captured: {manufacturer}. FAIL')
            raise Exception(
                f'TPM Manufacturer, expected: {self.mapping.tpm_manufacturer}, captured: {manufacturer}. FAIL')
        log.debug(f'TPM Manufacturer, expected: {self.mapping.tpm_manufacturer}, captured: {manufacturer}. PASS')

        # TPM_PT_VENDOR_STRING:           SLB9672���������
        vendor = re.search(r'TPM_PT_VENDOR_STRING:\s+(\w+)', self.uut.buffer)
        if vendor is None:
            raise Exception('not found: TPM_PT_VENDOR_STRING')
        vendor = vendor.group(1)
        if vendor != self.mapping.tpm_vendor:
            log.error(f'TPM Vendor, expected: {self.mapping.tpm_vendor}, captured: {vendor}. FAIL')
            raise Exception(f'TPM Vendor, expected: {self.mapping.tpm_vendor}, captured: {vendor}. FAIL')
        log.debug(f'TPM Vendor, expected: {self.mapping.tpm_vendor}, captured: {vendor}. PASS')

        # TPM_PT_FIRMWARE_VERSION:        16.13.17733.0
        fw_ver = re.search(r'TPM_PT_FIRMWARE_VERSION:\s+([\w.]+)', self.uut.buffer)
        if fw_ver is None:
            raise Exception('not found: TPM_PT_FIRMWARE_VERSION')
        fw_ver = fw_ver.group(1)
        if fw_ver != self.mapping.tpm_fw_ver:
            log.error(f'TPM FW Version, expected: {self.mapping.tpm_fw_ver}, captured: {fw_ver}. FAIL')
            raise Exception(f'TPM FW Version, expected: {self.mapping.tpm_fw_ver}, captured: {fw_ver}. FAIL')
        log.debug(f'TPM FW Version, expected: {self.mapping.tpm_fw_ver}, captured: {fw_ver}. PASS')

        self.uut.send_wise('syscall ./eltt2 -g', self.diag_prompt)

    def chassis_temp_check(self):
        """
        tempread all
        Temperature#1 : [TMP75#1] : +39.50 oC
        Temperature#2 : [TMP75#2] : +23.50 oC
        Temperature#3 : [TMP75#3] : +23.0 oC
        Temperature#4 : [MAC0_Internal] : +61.8 oC
        Temperature#5 : [MAC1_Internal] : +61.8 oC
        DIAG>
        """

        self.uut.send_wise('tempread all', self.diag_prompt)
        temp = re.findall(r':\s+([+-](?:\d+)?\.\d+)\s+oC', self.uut.buffer)
        if len(temp) == 0:
            raise Exception('not found temperatures!')

        for t in temp:
            float_t = float(t)
            if not (self.mapping.low_temp <= float_t <= self.mapping.high_temp):
                msg = f'temp: {float_t} out of range, [{self.mapping.low_temp}, {self.mapping.high_temp}]'
                log.error(msg)
                raise Exception(f'temperature out of range!')
            else:
                log.debug(f'temp: {float_t} is in range: [{self.mapping.low_temp}, {self.mapping.high_temp}]')

    def hardware_inventory_check(self):
        log.debug(f'this SKU has {self.mapping.fan_count} fan(s).')
        if self.mapping.fan_count != 0:
            self.uut.send_wise('fanlist', self.diag_prompt)
            if re.search('error|fail|absent', self.uut.buffer, flags=re.I):
                raise Exception('found error in fanlist')
            fans = re.findall(r'FAN#\d+ :', self.uut.buffer)
            log.debug(f'fan count: {len(fans)}, -> {fans}')
            if len(fans) != self.mapping.fan_count:
                log.error(f'fan count mismatch! expected: {self.mapping.fan_count}, got: {len(fans)}')
                raise Exception(f'fan count mismatch! expected: {self.mapping.fan_count}, got: {len(fans)}')
            log.debug(f'fan count match! expected: {self.mapping.fan_count}, got: {len(fans)}')
        else:
            log.debug('no need to check fan...SKIP')

        self.uut.send_wise('rtcbattery', self.diag_prompt)
        if re.search('error|fail', self.uut.buffer, flags=re.I):
            raise Exception('rtcbattery failed!')
        if 'RTC Battery - PASS' not in self.uut.buffer:
            raise Exception('not found pass criteria: RTC Battery - PASS')
        log.debug('found pass criteria: RTC Battery - PASS')

    def power_off(self):
        self.pdu.power_off(helper.config['pdu_port'])

    def init_connections(self):
        self.uut = UUT(conn_str=helper.config['uut_conn_str'])
        self.pdu = PDU(conn_str=helper.config['pdu_conn_str'])

    def first_step_of_pre_seq(self):
        self.check_latest_repo_version(self.product_name)
        super().first_step_of_pre_seq()

    def first_step_of_main_seq(self):
        log.debug(self.mapping)

    def close_all_connections(self):
        self.uut.do_disconnect()
