import platform

from .common.quantum import Quantum
from .common.utils import helper
from .common.fields import StrField, Field
from .common import sfchelper
from .common import scanner
from .common.logger import log
from .define.mac_define import cookie_mapping
from .define import mac_define
from .common import machelper


class MAC(Quantum):
    sernum = StrField()
    uuttype = StrField()
    sku_ver = StrField()
    sku_mac = StrField()
    assign_flag = True
    verify_jnp = True
    #
    mapping = Field()   # type: mac_define.JNP

    area = 'MAC-A'

    def scan_uut_sn(self):
        # 扫描 SN
        ans = scanner.ask_question(question='Please scan label. 请扫描标签。 Quét thẻ SN')
        self.sernum = ans

        data = sfchelper.get_sn_detail_from_mes(self.sernum)
        sku_ver = data.get('SKU_VER', None)
        if not sku_ver:
            raise Exception('not found SKU_VER from mes')
        log.debug(f"SN {self.sernum} MES sku ver is {sku_ver}")
        self.sku_ver = sku_ver

        # 查询 MES LABEL PN
        pn = sfchelper.get_skuno_from_mes(sn=self.sernum)
        if pn not in cookie_mapping.keys():
            raise Exception(f'Part Number: {pn} is not supported! acceptable list: {list(cookie_mapping.keys())}')
        self.uuttype = pn

        # 读取预定义数据
        self.mapping = cookie_mapping[pn]
        # 打印初始化的参数
        log.debug(f'SN: {self.sernum}, Label PN: {pn}, UUTType: {self.uuttype}')

        # 记得添加测试记录
        helper.add_record(sn=self.sernum, pn=self.uuttype, area=self.area)

    def check_mes_event(self):
        self.mes_check_event(sn=self.sernum, area=self.area)

    def query_mes_mac(self):
        mac, size, sku= sfchelper.get_mac_data_from_mes(wsn=self.sernum)
        log.debug(f"SN {self.sernum} MES MAC is {mac}, Size is {size}, Sku is {sku}")
        self.sku_mac = sku

        if mac:
            mac_helper = machelper.MacAddressHelper()
            mac = mac_helper.convert(mac, lower=True, delimiter=':')
            self.verify_jnp = False

    def read_config(self):
        self.machine = platform.node()
        self.container = helper.get_container_name()

    def distribute_mb_mac_address(self):
        if not self.assign_flag:
            return helper.SKIP

        if not all([self.sernum, self.uuttype]):
            raise Exception(f'distribute mac address failed -> {[self.sernum, self.uuttype]}')

        # MB
        mb_mac, mb_block_size = self.generate_mac(
            bu=self.mapping.bu, project=self.mapping.mb_project, product=self.mapping.product,
            sernum=self.sernum, uuttype=self.uuttype, block_size=self.mapping.mb_block_size
        )
        log.debug(f'MB MAC: {mb_mac}, {mb_block_size}')
        if mb_block_size != self.mapping.mb_block_size:
            raise Exception(
                f'check mb block size failed! expected: {self.mapping.mb_block_size}, from db: {mb_block_size}')

        # Juniper does not require this field must be C
        # if mb_mac[6].upper() != 'C':
        #     raise Exception(f'the MAC: {mb_mac} is not C block!')
        self.mapping.mb_mac = mb_mac

    def verify_mb_mac(self):
        if not self.assign_flag:
            return helper.SKIP
        # check MAC again!
        log.debug(f'checking MB MAC...{self.mapping.mb_mac}, {self.mapping.mb_block_size}')
        self.verify_mac(self.sernum, mac_address=self.mapping.mb_mac, mac_block_size=self.mapping.mb_block_size)
        log.debug('checking MB MAC... OK')

    def verify_mac_with_jnp(self):
        if not self.verify_jnp:
            log.debug(f"{self.sernum} already assign in MES, skip verify JNP")
            return helper.SKIP
        # mac = "087671000000"
        # mac_size = 128
        # 转为整数
        mac = self.mapping.mb_mac
        mac_start = int(mac, 16)
        # 计算结束地址
        mac_end_int = mac_start + self.mapping.mb_block_size - 1
        # 转为12位十六进制字符串，大写
        mac_end_hex = format(mac_end_int, '012x').upper()
        # 转换为标准 MAC 地址格式
        mac_end_fmt = '-'.join(mac_end_hex[i:i + 2] for i in range(0, 12, 2))
        # 起始 MAC 格式化
        mac_start_fmt = '-'.join(mac[i:i + 2] for i in range(0, 12, 2))
        # 打印结果
        log.debug(f"Start MAC : {mac_start_fmt}")
        log.debug(f"End MAC   : {mac_end_fmt}", )
        log.debug(f"mac_end_hex (raw) : {mac_end_hex}")

        res = sfchelper.verify_mac_jnp(
            sn=self.sernum, pn=self.uuttype, ver_sku=self.sku_ver,
            mac_start=mac_start_fmt, mac_end=mac_end_fmt, mac_size=self.mapping.mb_block_size)
        self.debug(res)
        log.debug('checking MB MAC with JNP... OK')

    def check_mac_from_sys(self):
        sys_mac, sys_mac_size = sfchelper.select_mac_address(self.sernum)
        if sys_mac == "" or sys_mac_size == "0":
            log.debug("Not found mac address from mac 254 address assignment system, Can start assign genius MAC")
        else:
            log.debug(f"Get mac data from 254 assignment system: {sys_mac}, {sys_mac_size}")
            self.assign_flag = False
            self.verify_jnp = False
            self.mapping.mb_mac = sys_mac
            self.mapping.mb_block_size = int(sys_mac_size)

    def update_mac_address_to_mes(self):
        self.debug(f'SN: {self.sernum}, PN: {self.sku_mac}, '
                   f'MB MAC: {self.mapping.mb_mac}, MB Block Size: {self.mapping.mb_block_size}')

        if not all([self.sernum, self.sku_mac, self.mapping.mb_mac, self.mapping.mb_block_size]):
            raise Exception(
                f'please ensure all fields are valid! -> '
                f'{[self.sernum, self.sku_mac, self.mapping.mb_mac, self.mapping.mb_block_size]}')

        self.verify_mb_mac()

        log.debug('Uploading to MES...')
        res = sfchelper.update_mac_address_to_mes(
            sn=self.sernum, pn=self.sku_mac,
            mb_mac=self.mapping.mb_mac, mb_block_size=self.mapping.mb_block_size,
            )
        self.debug(res)
        log.debug('Uploading to MES... OK')

    def first_step_of_main_seq(self):
        log.debug(f'machine: {self.machine}')
        log.debug(f'container: {self.container}')

    def upload_test_records(self):
        self.update_test_status()
        helper.quick_set('Upload to Genius')
        super().add_genius_records(
            str1name='Serial Number',
            str1=self.sernum,
            str2name='Part Number',
            str2=self.uuttype,
            str3name='BASE MAC',
            str3=self.mapping.mb_mac,
            str4name='MAC Block Size',
            str4=self.mapping.mb_block_size,
            str6name='Script_Version',
            str6=self.current_version,
        )
        helper.quick_set('Upload to MES')
        self.add_mes_records()
