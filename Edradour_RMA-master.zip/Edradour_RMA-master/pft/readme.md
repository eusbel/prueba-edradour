Python 3.11
使用cx-freeze代替pyinstaller

步骤：
python setup.py build_exe