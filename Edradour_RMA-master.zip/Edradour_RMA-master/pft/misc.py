from serial.tools import list_ports

__all__ = ['get_com_ports']


def get_com_ports():
    return [
        p.device for p in list_ports.comports()
    ]
