import io
import os.path
import traceback
import datetime as dt
import platform

from xmodem import XMODEM
import serial
import re

from logger import LogHelper
from settings import settings


PRE_CONFIG_TOOL_VERSION = 'Pre-config tool ver. 1.0'
PUBLIC_KEY = 'fe7ac8210ea4d8b57dca4b5856980d5fbe9858427b9e292e02ce7b248854465b'
PUBLIC_KEY_CRC_32 = '0x2e57daef'
DEVICE_ID = '88853650'


class XMODEMUtil:

    def __init__(self, console):
        self.conn = console

    def upload(self, filename, mode='xmodem'):
        """
        xmodem or xmodem1k
        :param filename:
        :param mode:
        :return:
        """

        def get(size, timeout=1):
            data = self.conn.read(size) or None
            return data

        def put(data, timeout=1):
            return self.conn.write(data)

        modem = XMODEM(get, put, mode=mode)
        # f = open(filename, 'rb')
        # modem.send(f)
        #
        with open(filename, 'rb') as f:
            modem.send(f)


class BurningTool:

    def __init__(self, port, baudrate, tool_file, timeout=60, **kwargs):
        self.port = port
        self.baudrate = baudrate
        self.timeout = timeout
        self.tool_file = tool_file
        self.conn = serial.Serial(port=self.port, baudrate=self.baudrate, timeout=self.timeout)
        self.__buffer = io.BytesIO()
        self.kwargs = kwargs
        #
        self.sn = self.kwargs.get('sn')
        self.test_log = LogHelper(sn=self.sn, base_dir='PFT-LOGS')
        #
        self.show_pass = self.kwargs.get('show_pass')
        self.show_error = self.kwargs.get('show_error')
        self.show_info = self.kwargs.get('show_info')
        self.tk_log = self.kwargs.get('tk_log')
        self.test_finish = self.kwargs.get('test_finish')
        #
        self.init_test_log()

    def init_test_log(self):
        self.test_log.write_header(key='Script Version', value=settings.full_version)
        self.test_log.write_header(key='Machine', value=platform.node())
        self.test_log.write_header(key='Port', value=self.port)
        self.test_log.write_header(key='Baudrate', value=self.baudrate)
        self.test_log.write_header(key='Tool File', value=self.tool_file)
        self.test_log.write_header(key='Tool Version', value=PRE_CONFIG_TOOL_VERSION)
        self.test_log.write_header(key='Public Key', value=PUBLIC_KEY)
        self.test_log.write_header(key='CRC 32', value=PUBLIC_KEY_CRC_32)
        self.test_log.write_header(key='Device ID', value=DEVICE_ID)

        self.test_log.write_line(f'{"*" * 100}\n')

    @property
    def buffer(self):
        return self.__buffer.getvalue().decode(errors='ignore')

    def simple_wait(self, expected: str):
        if not isinstance(expected, str):
            raise Exception(f'please ensure type of expected is str, got {type(expected)}!! bad!!')
        buf = self.conn.read_until(expected.encode())
        if expected.encode() not in buf:
            raise Exception(f'wait for {expected} meet timeout({self.timeout})!')
        self.__buffer.write(buf)
        self.tk_log(buf.decode(errors='ignore'), suffix='')
        self.test_log.write(buf)

    def simple_send(self, cmd: str, expected: str, suffix='\r'):
        self.__buffer = io.BytesIO()
        if not isinstance(cmd, str):
            raise Exception(f'please ensure type of cmd is str, got {type(expected)}!! bad!!')
        self.conn.write(f'{cmd}{suffix}'.encode())
        if expected:
            self.simple_wait(expected)

    def burning_public_key(self):
        self.tk_log(f'[Burn Public Key] Please Power Cycle UUT in {self.timeout} second(s)...')
        self.simple_wait('## Ready to download binary to 0xB0000000 with xmodem protocol')
        self.simple_wait('CCC')
        if not os.path.exists(self.tool_file):
            raise Exception('tool file does not exist! -> {}'.format(self.tool_file))
        # send file
        XMODEMUtil(self.conn).upload(self.tool_file)
        # Configure public key hash SHA-256 (64 hexadecimal digit)
        # e.g. e863cd8f744de023df5a49f164f714d64f798670e87f2d08eda20c02374d5e63
        self.simple_wait('Configure public key hash SHA-256 (64 hexadecimal digit)')
        if PRE_CONFIG_TOOL_VERSION not in self.buffer:
            raise Exception('check pre config tool version failed!')

        self.simple_wait('e.g. e863cd8f744de023df5a49f164f714d64f798670e87f2d08eda20c02374d5e63')
        self.simple_send(PUBLIC_KEY, 'Enter 1 (correct) or 2 (wrong)')
        if self.buffer.count(PUBLIC_KEY) != 2:
            raise Exception('program public key error!')
        self.simple_send('1', expected='Enter 1 (correct) or 2 (wrong)')
        captured_crc32 = re.search(r'CRC-32:\s+(\S+)', self.buffer)
        if captured_crc32 is None:
            raise Exception('not found Public KEY CRC 32')
        captured_crc32 = captured_crc32.group(1)
        if captured_crc32 != PUBLIC_KEY_CRC_32:
            raise Exception(f'captured CRC32({captured_crc32}) and PUBLIC KEY CRC 32({PUBLIC_KEY_CRC_32}) mismatch!')
        self.tk_log(
            f'\nCapture PublicKey CRC32({captured_crc32}) and Expected PublicKey CRC 32({PUBLIC_KEY_CRC_32}) match!')
        self.simple_send('1', 'Public key hash programmed successfully')
        self.simple_wait('Enter 2 for input platform key')
        self.simple_send('2', 'Enter 2 for 128 bits')
        # self.simple_send('1', 'Input 64 hexadecimal digit for platform key')
        self.simple_send('1', 'Input 64 hexadecimal digit for platform key size 32')
        self.simple_send(PUBLIC_KEY, 'Enter 1 (correct) or 2 (wrong)')
        if self.buffer.count(PUBLIC_KEY) != 2:
            raise Exception('program 64 hexadecimal digit for platform key error!')
        self.simple_send('1', 'Enter 1 (correct) or 2 (wrong)')
        hex_digit_crc32 = re.search(r'CRC-32:\s+(\S+)', self.buffer)
        if hex_digit_crc32 is None:
            raise Exception('not found hex digit platform key!')
        hex_digit_crc32 = hex_digit_crc32.group(1)
        if hex_digit_crc32 != PUBLIC_KEY_CRC_32:
            raise Exception(f'captured hex digit public key: {hex_digit_crc32} is not expected({PUBLIC_KEY_CRC_32})')
        self.simple_send('1', 'SUCCESS: program platform key')

        # self.simple_wait('Enter other for not configuring device ID')
        # self.simple_send('1', 'Input device ID (8 hexadecimal digit): e.g. 12345678')
        self.simple_wait('Input device ID (8 hexadecimal digit): e.g. 12345678')
        # self.simple_send(DEVICE_ID, 'Power cycle to make pre_config setting effective')
        self.simple_send(DEVICE_ID, 'Enter 1 (correct) or 2 (wrong)')
        if self.buffer.count(DEVICE_ID) != 2:
            raise Exception('program DEVICE ID failed!')
        self.simple_send('1', 'Enter 1 (yes) or 2 (no)')
        self.simple_send('2', 'Power cycle to make pre_config setting effective')

    def check_burning_result(self):
        self.tk_log(f'[Check Burning Result] Please Power Cycle UUT in {self.timeout} second(s)...')
        self.simple_wait('Read request msg from iHost via HPI')
        if 'pcie FW load OK' not in self.buffer:
            raise Exception('not found key words: pcie FW load OK')
        self.tk_log('found key words: pcie FW load OK')
        if 'SPL Auth PASS' not in self.buffer:
            raise Exception('not found key words: SPL Auth PASS')
        self.tk_log('found key words: SPL Auth PASS')

    def run_burning(self):
        self.show_info('[1] Power Cycle UUT')

        try:
            self.burning_public_key()
        except Exception as e:
            self.test_fail(title=f'{self.sn} - Burn FAIL', exception=e)
            return

        self.show_info('[2] Power Cycle UUT')
        try:
            self.check_burning_result()
        except Exception as e:
            self.test_fail(title=f'{self.sn} - Check Result FAIL', exception=e)
            return

        # Pass
        self.test_pass(title=f'{self.sn} - PASS')

    def test_pass(self, title):
        self.show_pass(f'{title}')
        self.test_finish()

        self.test_log.write_line('')
        self.test_log.write_header(key='Test Result', value='PASS')
        self.test_log.write_header(key='End Time', value=f'{dt.datetime.now().strftime("%Y%m%d.%H%M%S")}')

        self.tk_log('Test Result: PASS')
        self.tk_log(f'End Time: {dt.datetime.now().strftime("%Y%m%d.%H%M%S")}')

        self.test_log.rename_test_log('PASS')

    def test_fail(self, title, exception):
        end_time = dt.datetime.now()
        self.show_error(f'{title}')
        self.test_finish()

        self.test_log.write_line(traceback.format_exc())
        self.test_log.write_line(exception)

        self.tk_log(traceback.format_exc())
        self.tk_log(exception)

        self.test_log.write_line('')
        self.test_log.write_header(key='Test Result', value='FAIL')
        self.test_log.write_header(key='End Time', value=f'{end_time.strftime("%Y%m%d.%H%M%S")}')

        self.tk_log('Test Result: FAIL')
        self.tk_log(f'End Time: {end_time.strftime("%Y%m%d.%H%M%S")}')

        self.test_log.rename_test_log('FAIL')

    def __del__(self):
        try:
            self.conn.close()
        except Exception as e:
            print(e)
