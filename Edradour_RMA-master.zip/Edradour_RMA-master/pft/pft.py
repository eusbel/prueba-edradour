import time
import tkinter as tk
from tkinter import ttk
from tkinter import simpledialog, messagebox
import traceback
import threading as td
import re

import misc
from settings import settings
from burn import BurningTool


class Window(tk.Tk):

    def __init__(self, title):
        super().__init__()
        self.title(title)
        self.iconbitmap('logo.ico')
        # self.geometry('600x400')
        # self.resizable(width=False, height=False)
        # TOP panel
        top_panel = ttk.LabelFrame(self, text='>>>')
        top_panel.pack(fill=tk.X, padx=8)
        self.sn = tk.StringVar(top_panel)
        ttk.Label(top_panel, text='SN').pack(side=tk.LEFT)
        ipt_sn = ttk.Entry(top_panel, textvariable=self.sn)
        ipt_sn.pack(side=tk.LEFT, padx=10)
        ipt_sn.bind('<Return>', self.burn_command)
        # Burn button
        self.btn_burn = ttk.Button(top_panel, text='Burn', command=self.burn_command)
        self.btn_burn.pack(side=tk.LEFT)

        # Get all COM ports
        self.serial_port = tk.StringVar(top_panel)
        ttk.Combobox(top_panel, values=misc.get_com_ports(), textvariable=self.serial_port, width=10).pack(side=tk.LEFT,
                                                                                                           padx=8)
        # self.serial_port = ttk.Combobox(top_panel, values=['COM1', 'COM2', 'COM3'], width=10)

        # Baudrate
        self.baudrate = tk.IntVar(top_panel)
        ttk.Entry(top_panel, textvariable=self.baudrate, width=10).pack(side=tk.LEFT)

        # STATUS
        result_panel = tk.LabelFrame(self, text='Status')
        result_panel.pack(fill=tk.X, padx=8)
        self.result = tk.Variable(result_panel)
        self.lb_result = tk.Label(result_panel, textvariable=self.result, font=('Arial', 16))
        self.lb_result.pack(expand=True, fill=tk.BOTH)
        self.result.set('---')

        # LOG
        self.mid_panel = ttk.LabelFrame(self, text='LOG')
        self.mid_panel.pack(padx=5, pady=5, fill=tk.BOTH, expand=True)
        self.log_data = tk.Text(self.mid_panel)
        self.log_data.config({'state': tk.DISABLED})
        self.log_data.pack(fill=tk.BOTH, expand=True)
        # OP
        self.operator = f'[RD Version]'
        # self.operator = InputDialog(self, 'Operator ID').input_value.get()
        ttk.Label(top_panel, text=self.operator).pack(side=tk.RIGHT, expand=True)

        # Init
        # self.sn.set('GV1724AV0001')
        self.serial_port.set(settings.com_port)
        self.baudrate.set(settings.baudrate)

    def disable_burn_button(self):
        self.btn_burn.config(state=tk.DISABLED)

    def enable_burn_button(self):
        self.btn_burn.config(state=tk.NORMAL)

    def show_running(self, text):
        self.result.set('{}'.format(text))
        self.lb_result.config(fg='#ffffff', bg='#ffc107')
        self.update()

    def show_error(self, text):
        self.result.set('{}'.format(text))
        self.lb_result.config(fg='#ffffff', bg='#dc3545')
        self.update()

    def show_pass(self, text):
        self.result.set('{}'.format(text))
        self.lb_result.config(fg='#ffffff', bg='#198754')
        self.update()

    def show_info(self, text):
        self.result.set('{}'.format(text))
        self.lb_result.config(fg='#ffffff', bg='#0d6efd')
        self.update()

    def log(self, text, suffix='\n'):
        self.log_data.config({'state': tk.NORMAL})
        self.log_data.insert(tk.END, f'{text}{suffix}')
        self.log_data.see(tk.END)
        self.log_data.config({'state': tk.DISABLED})

    def burn_command(self, e=None):
        if self.operator is None or self.operator == '':
            op_id = InputDialog(self, 'Operator ID').input_value.get()
            if op_id is None or op_id.strip() == "":
                return
            self.operator = op_id

        # Check SN
        user_sn = self.sn.get().strip().upper()
        self.sn.set('')
        if not user_sn:
            self.log('PLEASE SCAN SN')
            self.show_error('PLEASE SCAN SN')
            return
        if re.fullmatch(r'[A-Z]{2}\d{4}[A-Z]{2}\d{4}', user_sn) is None:
            self.log(f'WRONG SN: {user_sn}')
            self.show_error(f'WRONG SN: {user_sn}')
            return
        self.log(f"SN: {user_sn}")

        # Check Serial Port
        com_port = self.serial_port.get().strip().upper()
        if com_port == '':
            self.log('PLEASE SELECT A COM PORT')
            self.show_error('PLEASE SELECT A COM PORT')
            return
        self.log(f'SELECTED COM PORT: {com_port}')

        # start burning
        try:
            self.disable_burn_button()
            burn = BurningTool(
                port=self.serial_port.get(),
                baudrate=self.baudrate.get(),
                tool_file=settings.pre_config_tool,
                sn=user_sn,
                show_pass=self.show_pass,
                show_error=self.show_error,
                show_info=self.show_info,
                test_finish=self.enable_burn_button,
                tk_log=self.log,
            )
            td.Thread(target=burn.run_burning, daemon=True).start()

            # td.Thread(target=self.tmp_example, daemon=True).start()

        except Exception as e:
            self.log(traceback.format_exc())
            self.log(e)
            self.show_error(f'{user_sn} - FAIL')
            self.enable_burn_button()
        else:
            self.show_running(f'{user_sn} - RUNNING')

    def tmp_example(self):
        time.sleep(5)
        self.show_pass(f'{self.sn.get()} - PASS')


class InputDialog(simpledialog.Dialog):

    def __init__(self, parent, title):
        self.input_value = tk.StringVar()
        super().__init__(parent, title)

    def body(self, master):
        ttk.Label(self, text='Operator NO :').pack(side=tk.LEFT)
        op = ttk.Entry(self, textvariable=self.input_value)
        op.pack(side=tk.LEFT, padx=10)
        op.bind('<Return>', lambda e: self.valid_input())
        # op.bind('<Key>', self.valid_input)
        self.config(padx=10, pady=10)
        ttk.Button(self, text='Submit', command=self.valid_input).pack(side=tk.LEFT, padx=10)
        self.bind('<Key>', lambda e: e.keycode == 27 and self.destroy())

    def buttonbox(self):
        pass

    def valid_input(self):
        ipt = self.input_value.get()
        if re.fullmatch(r'[a-zA-Z]?\d{6,7}', ipt) is not None:
            self.destroy()
        else:
            messagebox.showerror("Error", f"ID [{ipt}] is invalid!")


if __name__ == '__main__':
    Window(f'PFT - {settings.full_version}').mainloop()
