import logging
import os
import pathlib
import tkinter as tk
import datetime as dt


class TkTextHandler(logging.Handler):
    def __init__(self, tk_wdg):
        super().__init__()
        self.tk_wdg = tk_wdg  # type: tk.Text

    def emit(self, record):
        self.tk_wdg.insert(tk.END, self.format(record))


class ConsoleFileHandler(logging.FileHandler):
    def emit(self, record):
        self.stream.write(self.format(record))


class LogHelper:

    def __init__(self, sn, base_dir):
        self.sn = sn
        self.base_dir = pathlib.Path(base_dir)
        os.makedirs(self.base_dir, exist_ok=True)
        # %Y%m%d_%H%M%S.txt
        self.start_time = dt.datetime.now()
        self.end_time = None

        self.log_name = f'{sn}~{self.start_time.strftime("%Y%m%d_%H%M%S")}~tmp.txt'
        self.fullname = self.base_dir / self.log_name
        self.create_test_log()

    def create_test_log(self):
        with open(self.fullname, 'w'):
            pass
        self.write_line('*' * 100)
        self.write_header('Start Time', value=self.start_time.strftime("%Y%m%d.%H%M%S"))
        self.write_header('SN', value=self.sn)

    def write(self, text):
        if isinstance(text, bytes):
            with open(self.fullname, 'ab+') as f:
                f.write(text)
        else:
            with open(self.fullname, 'a+') as f:
                f.write(str(text))

    def write_header(self, key, value, sep=':'):
        self.write_line(f'{str(key).ljust(30, " ")} {sep} {value}')

    def write_line(self, text):
        if isinstance(text, bytes):
            with open(self.fullname, 'ab+') as f:
                f.write(text + b'\n')
        else:
            with open(self.fullname, 'a+') as f:
                f.write(f'{text}\n')

    def rename_test_log(self, status=None):
        if status is None:
            return
        self.fullname.rename(self.base_dir / f'{self.sn}~{self.start_time.strftime("%Y%m%d_%H%M%S")}~{status}.txt')

# if __name__ == '__main__':
#     lg = LogHelper('VN234AV001', '.')
#     lg.write('NIHAO')
#     lg.rename_test_log('PASS')
