from cx_Freeze import setup, Executable
from string import Template
from settings import VERSION
import pathlib

# Dependencies are automatically detected, but they might need fine-tuning.
build_exe_options = {
    # "excludes": ["tkinter", "unittest"],
    # "zip_include_packages": ["encodings", "PySide6", "shiboken6"],
    "build_exe": pathlib.Path.home() / 'Desktop' / 'Edradour-PFT-Build' / f'edradour-pft-portable-{VERSION}',
    "include_msvcr": True,
    "include_files": ["sb_preconfig_tool_1_0", "settings.toml", "logo.ico"],
    "optimize": 2,
}

setup(
    name="Edradour PFT",
    version=VERSION,
    description="Edradour PFT Burn Public Key Program",
    options={"build_exe": build_exe_options},
    executables=[Executable("pft.py", base="gui", icon='logo')],
)


# def update_iss_template(data: dict):
#     with open('./edradour-pft-setup-template.iss') as f:
#         text = f.read()
#
#     template = Template(text)
#     new_text = template.safe_substitute(data)
#
#     with open('./edradour-pft-setup.iss', 'w') as f:
#         f.write(new_text)
#
#
# update_iss_template({'version': VERSION, 'basedir': build_exe_options['build_exe']})
