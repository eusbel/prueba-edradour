import tomllib as tml

VERSION = '0.1.0'
FULL_VERSION = f'v{VERSION}_20241018'


class Settings:

    def __init__(self, config_file):
        self.__config_file = config_file
        with open(self.__config_file, 'rb') as f:
            self.__config = tml.load(f)

    @property
    def version(self):
        return VERSION

    @property
    def full_version(self):
        return FULL_VERSION

    @property
    def config(self):
        return self.__config

    @property
    def com_port(self):
        return self.config['com_port']

    @property
    def baudrate(self):
        return self.config['baudrate']

    @property
    def pre_config_tool(self):
        return self.config['pre_config_tool']


settings = Settings('settings.toml')
