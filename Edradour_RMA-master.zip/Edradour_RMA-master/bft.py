import random
import re
import time

from .common.dcn import TimerMeta
from .common.scanner import yes_or_enter_to_continue
from .common.quantum import Quantum
from .common.utils import helper
from .common.fields import StrField, Field
from .common import sfchelper
from .define import define as df
from .define.define import cookie_mapping, EX4K
from .common import machelper
from .common.uut import UUT
from .common.pdu import PDU
from .common.apc import APC
from .common.iporter2 import IPorter2
from .common.reachpoe5 import ReachPoE5
from .common import scanner
from .common.logger import log
import datetime as dt
from .define.rework import NONE_CHECK_SECONDARY_CPLD_48MP_SN, NONE_CHECK_SECONDARY_CPLD_12_24MP_SN

import random
from collections import defaultdict

# LED测试各型号配置
PRODUCT_CONFIG = {
    "48": {   # 原始型号：52灯
        "modules": {
            0: list(range(0, 12)),   # 0-11
            1: list(range(12, 24)),  # 12-23
            2: list(range(24, 36)),  # 24-35
            3: list(range(36, 48)),  # 36-47
            4: list(range(48, 52)),  # 48-51
        },
        "min_per_round": 4,
        "max_per_round": 8,
    },
    "24": {   # 你的1号新型号
        "modules": {
            0: list(range(0, 12)),   # 0-11
            1: list(range(12, 24)),  # 12-23
            2: list(range(24, 28)),  # 24-27
        },
        "min_per_round": 3,
        "max_per_round": 7,
    },
    "12": {   # 你的2号新型号
        "modules": {
            0: list(range(0, 12)),   # 0-11
            1: list(range(12, 16)),  # 12-15
        },
        "min_per_round": 2,
        "max_per_round": 6,
    },
    "8": {   # 你的3号新型号
        "modules": {
            0: list(range(0, 8)),    # 0-7
            1: list(range(8, 12)),   # 8-11
        },
        "min_per_round": 1,
        "max_per_round": 5,
    }
}


class BFT(Quantum, metaclass=TimerMeta):
    sernum = StrField()
    area = 'BFT'
    product_name = 'Edradour'
    update_cpld_file = None
    sec_cpld = None
    cpld_diag_version = None

    mapping = Field()  # type: EX4K

    uut = None
    # poe1 = None
    # poe2 = None
    # poe3 = None

    poe_group = []

    pdu = None

    u_boot_prompt = 'u-boot>'
    diag_prompt = 'DIAG>'

    def scan_uut_info(self):

        # 扫描 SN
        ans = scanner.ask_question(question='Please scan label. 请扫描标签。 Quét thẻ SN')
        self.sernum = ans.strip()

        ans = helper.ask_question(question='Please scan SKU label. 请扫描标签。 Quét thẻ SKU', image='Edradour/images/scan_sku.png')
        self.sku_label = ans.strip()

        ans = helper.ask_question(question='Please scan PN label. 请扫描标签。 Quét thẻ PN', image='Edradour/images/scan_pn.png')
        self.pn_label = ans.strip()

        ans = helper.ask_question(question='Please scan MAC label. 请扫描标签。 Quét thẻ MAC', image='Edradour/images/scan_mac.png')
        self.mac_label = ans.strip().replace(":", "")

        pn = self.pn_label.split("REV")[0].strip()
        if pn not in cookie_mapping.keys():
            raise Exception(f'Part Number: {pn} is not supported! acceptable list: {list(cookie_mapping.keys())}')
        self.uuttype = pn

        # 读取预定义数据
        self.mapping = cookie_mapping[pn]

        # 打印初始化的参数
        log.debug(f'SN: {self.sernum}, Label PN:{pn}, UUTType: {self.uuttype}, Model: {self.mapping.platform}')

        # Double Check mapping APN
        if self.mapping.apn.r_val not in self.uuttype:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn r value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn r val: {self.mapping.apn.r_val}. PASS')

        if self.mapping.apn.w_val not in self.uuttype:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn w value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn w val: {self.mapping.apn.w_val}. PASS')

        # 记得添加测试记录
        helper.add_record(sn=self.sernum, pn=self.uuttype, area=self.area)

    def check_mes_event(self):
        self.mes_check_event(sn=self.sernum, area=self.area)
        if self.area in ["POE"]:
            # 检查genius测试工站
            self.genius_check_event(sn=self.sernum, current_station="BFT")
        # if self.area in ["TRAFFIC"]:
        #     # 检查genius测试工站
        #     self.genius_check_event(sn=self.sernum, current_station="RIT")

    def query_mes_mac(self):
        mac, size = sfchelper.get_mac_address_from_mes(wsn=self.sernum)
        if mac is None:
            helper.quick_set('NO MAC FROM MES')
            raise Exception('no MAC from MES!!!')

        if size != self.mapping.mac_block_size:
            helper.quick_set('MAC Block Size Incorrect')
            raise Exception(f'MAC Block Size Incorrect, expected: {self.mapping.mac_block_size}, got: {size}, FAIL!!!')

        mac_helper = machelper.MacAddressHelper()
        mac = mac_helper.convert(mac, lower=True, delimiter=':')
        size = int(size)
        self.mac_address, self.mac_block_size = mac, size

    def read_config(self):

        self.mapping.uut_ip = helper.config['uut_ip']
        self.mapping.serverip = helper.config['serverip']
        self.mapping.netmask = helper.config['netmask']

        self.mapping.mac.set(w_val=self.mac_label, r_val=self.mac_label.upper())
        self.mapping.asn.set(w_val=self.sernum, r_val=self.sernum)
        self.mapping.chas_sn.set(w_val=self.sernum, r_val=self.sernum)
        self.mac_address = self.mac_label

        # # UTC
        # now = dt.datetime.now(dt.timezone.utc)
        # hex_year = f'{now.year:04X}'
        # self.mapping.asy.set(w_val=hex_year, r_val=f'{hex_year[0:2]} {hex_year[2:4]}')
        # self.mapping.asm.set(w_val=f'{now.month:02X}', r_val=f'{now.month:02X}')
        # self.mapping.asd.set(w_val=f'{now.day:02X}', r_val=f'{now.day:02X}')

        # MES
        # rev = sfchelper.get_label_aver_min_from_mes(self.sernum)
        rev = self.pn_label.split("REV")[-1].strip()
        self.mapping.aver_min.set(w_val=rev, r_val=rev)
        self.mapping.arev.set(w_val=rev, r_val=rev)
        # model_maj_rev = sfchelper.get_label_model_maj_rev_from_mes(self.sernum)
        model_maj_rev = self.sku_label.split("REV")[-1].upper().strip()
        self.mapping.mrev_maj.set(w_val=model_maj_rev, r_val=model_maj_rev)

        # clei = sfchelper.get_label_clei_from_mes(self.sernum)
        # if clei != self.mapping.clei.w_val:
        #     log.error(f"MES clei is: {clei}, script define is: {self.mapping.clei.w_val}, not match!!")
        #     raise Exception(f"MES clei is: {clei}, script define is: {self.mapping.clei.w_val}, not match!!")
        # else:
        #     log.debug(f"MES clei is: {clei}, script define is: {self.mapping.clei.w_val}, match!!")

    def get_uut_console(self):
        self.uut.do_connect(close_before_open=True)
        # self.poe.do_connect(close_before_open=True)

    def get_u_boot(self):
        pass

    def erase_shmoo_register(self):
        if self.mapping.erase_shmoo is not True:
            self.debug(f'{self.mapping.platform} NO to erase shmoo...SKIP...')
            return helper.SKIP

        self.debug(f'{self.mapping.platform} need to erase shmoo.')
        self.uut.send_wise('sf probe; sf erase 0x100000 0x10000', self.u_boot_prompt)
        if 'Erased: OK' not in self.uut.buffer:
            raise Exception('erase failed!')
        self.uut.send_wise('sf probe; sf erase 0x110000 0x10000', self.u_boot_prompt)
        if 'Erased: OK' not in self.uut.buffer:
            raise Exception('erase failed!')
        self.uut.send_wise('reset', '')
        #
        # 设置一次就好了
        if not self.mapping.ddr_mode_speed:
            log.warning(f'DDR Mode and speed are not set!! -> {self.mapping.platform}')
            raise Exception('please set ddr mode and speed!')

        log.debug(f'{self.mapping.platform} DDR Mode and Speed -> {self.mapping.ddr_mode_speed}')
        ddr_mode, ddr_speed = self.mapping.ddr_mode_speed
        # 只有48T P MP 需要按3 1, 其他都是 4 1
        self.uut.waitfor('Please select DDR mode -')
        time.sleep(0.2)
        self.uut.send_wise(ddr_mode, 'Please select DDR speed -', suffix='')
        time.sleep(0.2)
        self.uut.send_wise(ddr_speed, '', suffix='')

        self.wait_for_u_boot()

    def bootloader_mem_test(self):
        self.uut.send_ctrl_c(self.u_boot_prompt)
        # self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        # # Stop the Swizzle Boot and WDT, otherwise it will reboot in 5 min.
        # self.uut.send_wise('i2c mw 0x31 0x39 0x0', self.u_boot_prompt)
        # self.uut.send_wise('i2c mw 0x31 0x11 0x2', self.u_boot_prompt)
        #
        self.uut.send_wise('mtest 0x60000000 0xC0000000 0x5a00ff1234567890 20', self.u_boot_prompt, 300)
        if 'iteration(s) with 0 errors.' not in self.uut.buffer:
            log.error(
                f'[Pass Criteria] capture value: {self.uut.buffer}, expect value: iteration(s) with 0 errors., result: FAIL')
            raise Exception("expected value: 'iteration(s) with 0 errors.', captured not found, FAIL")
        log.debug(
            f'[Pass Criteria] capture value: {self.uut.buffer}, expect value: iteration(s) with 0 errors., result: PASS')

        self.uut.send_wise('mtest 0x480000000 0x500000000 0x5a00ff1234567890 20', self.u_boot_prompt, 300)
        if 'iteration(s) with 0 errors.' not in self.uut.buffer:
            log.error(
                f'[Pass Criteria] capture value: {self.uut.buffer}, expect value: iteration(s) with 0 errors., result: FAIL')
            raise Exception("expected value: 'iteration(s) with 0 errors.', captured not found, FAIL")
        log.debug(
            f'[Pass Criteria] capture value: {self.uut.buffer}, expect value: iteration(s) with 0 errors., result: PASS')

    def u_boot_tftp_download(self):
        while True:
            # tftpboot 0x6a000000 192.168.11.20:Edradour_UBOOT_1.0.3_sb_u-boot.img
            self.uut.send_wise(f'tftpboot 0x6a000000 {self.mapping.serverip}:edradour/{self.mapping.u_boot_file}',
                               self.u_boot_prompt)
            if 'Bytes transferred =' not in self.uut.buffer:
                log.error(f'download u boot: {self.mapping.u_boot_file} failed!')
                if scanner.yes_or_enter_to_continue(
                        question=f'Download u boot: {self.mapping.u_boot_file} failed, retry?\n下载u boot 文件失败，重试？'
                                 f'\nTải xuống tệp U-Boot thất bại, thử lại?') is False:
                    raise Exception('download u boot failed!')
                # retry
                continue

            break

    def update_u_boot_version(self, boot_bank):
        log.debug(f'update u boot bank: {boot_bank}')

        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version in self.uut.buffer:
            log.debug(f'{boot_bank} u boot version is the latest! {self.mapping.u_boot_version}')
            log.debug(f'[Pass Criteria]{boot_bank} u boot version is: {self.mapping.u_boot_version}, expect value:{self.mapping.u_boot_version}, result: PASS')
            return

        self.uut.send_wise('fatls  mmc 0:1', self.u_boot_prompt)
        if 'No partition table - mmc 0' in self.uut.buffer:

            self.boot_diag()

            self.uut.send_wise('exit', "login:")
            self.uut.send_wise('root', "#")
            self.uut.send_wise('fdisk /dev/mmcblk0', "Command")
            self.uut.send_wise('n', "primary partition")
            self.uut.send_wise('p', "number")
            self.uut.send_wise('1', "")
            self.sleep_time(1)
            self.uut.send_wise('', "")
            self.sleep_time(1)
            self.uut.send_wise('', "Command")
            self.uut.send_wise('t', "(type L to list codes)")
            self.uut.send_wise('b', "Command")
            self.uut.send_wise('w', "#")
            self.uut.send_wise('mkfs.vfat /dev/mmcblk0p1', "#")
            self.uut.send_wise('reboot', "#")

            # set boot env
            self.wait_for_u_boot()

        log.warning(f'u boot bank: {boot_bank}, need upgrade to version: {self.mapping.u_boot_version}')

        self.uut.send_wise(f'fatrm mmc 0:1 /efi/boot/UpdateCapsule/uboot_prd_cap', self.u_boot_prompt)
        self.uut.send_wise(f'fatrm mmc 0:1 /efi/boot/UpdateCapsule/uboot_dev_cap', self.u_boot_prompt)
        self.uut.send_wise(f'fatrm mmc 0:1 /efi/boot/UpdateCapsule/flash_image', self.u_boot_prompt)

        self.uut.send_wise(f'fatmkdir mmc 0:1 /efi', self.u_boot_prompt)
        self.uut.send_wise(f'fatmkdir mmc 0:1 /efi/boot', self.u_boot_prompt)
        self.uut.send_wise(f'fatmkdir mmc 0:1 /efi/boot/UpdateCapsule', self.u_boot_prompt)

        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # self.uut.send_wise(f'setenv gatewayip {self.mapping.gateway}', self.u_boot_prompt)

        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.u_boot_file}', self.u_boot_prompt)

            if 'TFTP server died' in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(question='TFTP server is died, call TE') is False:
                    raise Exception('tftp server is not online!')
                continue

            if 'Bytes transferred =' not in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(
                        question='not found "Bytes transferred =" in uut buffer, retry?') is False:
                    raise Exception('not found "Bytes transferred =" in uut buffer!')
                continue
            break

        self.uut.send_wise('fatwrite  mmc 0:1 ${loadaddr} efi/boot/UpdateCapsule/uboot_dev_cap 0x800000;', self.u_boot_prompt)
        self.uut.send_wise('fatwrite  mmc 0:1 ${loadaddr} efi/boot/UpdateCapsule/do_upgrade 0;', self.u_boot_prompt)

        self.uut.send_wise('reset', '')
        self.wait_for_u_boot()
        self.uut.send_wise('', self.u_boot_prompt)

        # self.setup_u_boot_env()
        # # download
        # self.u_boot_tftp_download()
        #
        # self.uut.send_wise('sf probe; sf erase 0x0 0x800000; sf write 0x6a000000 0x0 0x800000', self.u_boot_prompt)
        # if 'Erased: OK' not in self.uut.buffer:
        #     raise Exception('erase failed!')
        # if 'Written: OK' not in self.uut.buf:
        #     raise Exception('write failed!')
        #
        # self.sleep_time(3)
        # # Reset之后新版本才会生效
        # self.uut.send_wise('reset', '')
        # current_boot_bank = self.wait_for_u_boot()
        # if current_boot_bank != '1':
        #     raise Exception(f'current boot bank should be {boot_bank}, but now is: {current_boot_bank}')

        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(
                f'[Pass Criteria]{boot_bank} u boot version is: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception(f'upgrade u boot failed!')
        log.debug(f'boot bank: {boot_bank}\' u boot version is the latest. {self.mapping.u_boot_version}')
        log.debug(
        f'[Pass Criteria]{boot_bank} u boot version is: {self.mapping.u_boot_version}, expect value:{self.mapping.u_boot_version}, result: PASS')

    def switch_to_primary_u_boot(self, plan):
        log.debug('switch to primary u boot bank(1)')
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x39 0x2', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x8 0x1a', self.u_boot_prompt)
        if plan == 'a':
            self.uut.send_wise('i2c mw 0x31 0x9 0x1', '')

        # 两颗uboot 更新完后这个地方应该要OK
        elif plan == 'b':
            self.uut.send_wise('i2c mw 0x31 0x9 0x1', 'Validate Shmoo parameters stored in flash ..... OK')
            log.debug('Check Validate Shmoo parameters stored in flash ..... OK')

        boot_bank = self.wait_for_u_boot()
        if boot_bank != '1':
            log.error(f'switch to primary u boot failed! expected boot bank: 1, but now is: {boot_bank}')
            raise Exception(f'switch to primary u boot failed! expected boot bank: 1, but now is: {boot_bank}')
        log.debug(f'switch to u boot bank: {boot_bank} OK')
        return boot_bank

    def switch_to_secondary_u_boot(self):
        log.debug('switch to secondary u boot bank(2)')
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x39 0x3', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x8 0x1a', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x9 0x1', '')
        boot_bank = self.wait_for_u_boot()
        if boot_bank != '2':
            log.error(f'switch to primary u boot failed! expected boot bank: 2, but now is: {boot_bank}')
            raise Exception(f'switch to primary u boot failed! expected boot bank: 2, but now is: {boot_bank}')
        log.debug(f'switch to u boot bank: {boot_bank} OK')
        return boot_bank

    def check_u_boot_version(self):
        self.quick_set('Check Primary U Boot')
        # change to 1
        self.switch_to_primary_u_boot('a')
        # update u boot, flash is locked! so skip... 2024-11-08
        self.update_u_boot_version('1')
        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(f'[Pass Criteria] primary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception(f'expected primary u boot version: {self.mapping.u_boot_version}, captured: {self.uut.buffer}, FAIL')
        else:
            log.debug(f'[Pass Criteria] primary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: PASS')

        self.quick_set('Check Secondary U Boot')
        # change to 2
        # self.uut.send_wise('fatrm mmc 0 efi/boot/UpdateCapsule/uboot_dev_cap', self.u_boot_prompt)
        self.switch_to_secondary_u_boot()
        # update u boot, flash is locked! so skip... 2024-11-08
        # self.update_u_boot_version('2')
        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(f'[Pass Criteria] secondary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception(f'expected secondary u boot version: {self.mapping.u_boot_version}, captured: {self.uut.buffer}, FAIL')
        else:
            log.debug(f'[Pass Criteria] secondary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: PASS')

        # change back to 1
        self.switch_to_primary_u_boot('b')

    def bootloader_version_check(self):
        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(
                f'[Pass Criteria] secondary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception('check u boot version failed!')
        log.debug(
            f'[Pass Criteria] secondary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: PASS')

        self.uut.send_wise('pciephy', self.u_boot_prompt)

        # PCIe FW version
        pcie_fw_version = re.search(r'PCIe FW version: (\S+)', self.uut.buffer)
        if pcie_fw_version is None:
            log.error(
                f'[Pass Criteria] PCIe FW version: None, expect value:{self.mapping.pcie_fw_version}, result: FAIL')
            raise Exception('not found PCIe FW loader version')
        pcie_fw_version = pcie_fw_version.group(1)
        if pcie_fw_version != self.mapping.pcie_fw_version:
            log.error(
                f'[Pass Criteria] PCIe FW version: {pcie_fw_version}, expect value:{self.mapping.pcie_fw_version}, result: FAIL')
            raise Exception('PCIe FW version not match !')
        else:
            log.debug(
                f'[Pass Criteria] PCIe FW version: {pcie_fw_version}, expect value:{self.mapping.pcie_fw_version}, result: PASS')

    def setup_u_boot_env(self):
        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=1008M'", self.u_boot_prompt)
        # self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"', self.u_boot_prompt)

        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)
        # self.uut.send_wise(f"setenv diag_file Edradour_DIAG_v2.0.6_uImage_initramfs.img", self.u_boot_prompt)

        # if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
        #     self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"',
        #                        self.u_boot_prompt)
        # else:
        #     self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3pe"',
        #                        self.u_boot_prompt)

    def setup_u_boot_env2(self):
        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        # self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        # self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"', self.u_boot_prompt)

        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)

    def load_diag(self):
        self.setup_u_boot_env()

        # download DIAG
        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.diag_file}', self.u_boot_prompt, 300)
            if 'Bytes transferred =' not in self.uut.buffer:
                self.error(f'download diag file failed, edradour/{self.mapping.diag_file}')
                if scanner.yes_or_enter_to_continue(
                        question=f'Download DIAG img failed! retest? '
                                 f'下载DIAG文件失败！重试？'
                                 f'Tải xuống tệp DIAG không thành công! Thử lại?') is False:
                    raise Exception(f'download diag img file failed!')
                continue
            break

    def boot_diag(self):
        # self.setup_u_boot_env()
        #
        # # download DIAG
        # while True:
        #     self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.diag_file}', self.u_boot_prompt, 300)
        #     if 'Bytes transferred =' not in self.uut.buffer:
        #         self.error(f'download diag file failed, edradour/{self.mapping.diag_file}')
        #         if scanner.yes_or_enter_to_continue(
        #                 question=f'Download DIAG img failed! retest? '
        #                          f'下载DIAG文件失败！重试？'
        #                          f'Tải xuống tệp DIAG không thành công! Thử lại?') is False:
        #             raise Exception(f'download diag img file failed!')
        #         continue
        #     break

        # self.uut.send_wise('mmc erase 0 102400', self.u_boot_prompt)
        # self.uut.send_wise('mmc write 0x6a000000 0 102400', self.u_boot_prompt)
        # self.uut.send_wise('run bootcmd', '')
        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('bootm ${loadaddr}#wh3p',
                               '')
        else:
            self.uut.send_wise('bootm ${loadaddr}#wh3pe',
                               '')

        self.uut.waitfor(self.diag_prompt, 600)
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)

        # diag version
        self.uut.send_wise('version', self.diag_prompt)
        diag_version = re.search(r'DIAG\s*:\s*(.*)', self.uut.buffer)
        if diag_version is None:
            log.error(
                f'[Pass Criteria] diag version: None, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('not found diag version!!')
        diag_version = diag_version.group(1).strip()
        if diag_version != self.mapping.diag_version:
            log.error(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('diag version not match!!')
        log.debug(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: PASS')

        if 'P' in self.mapping.platform:
            # poe
            poe_version = re.search(r'PoE  : (\S+)', self.uut.buffer)
            if poe_version is None:
                log.error(
                f'[Pass Criteria] POE version: None, expect value:{self.mapping.bft_poe}, result: FAIL')
                helper.set_display3(f'Not found Poe version: {self.mapping.bft_poe}')
                raise Exception(f'not found expected Poe version: {self.mapping.bft_poe}')
            poe_version = poe_version.group(1)
            if poe_version not in self.mapping.bft_poe:
                log.error(
                f'[Pass Criteria] POE version: {poe_version}, expect value:{self.mapping.bft_poe}, result: FAIL')
                helper.set_display3('POE version mismatch')
                raise Exception('POE version mismatch')
            log.debug(
                f'[Pass Criteria] POE version: {poe_version}, expect value:{self.mapping.bft_poe}, result: PASS')

    def create_vfat_paration(self):

        self.uut.send_wise('exit', "login:")
        self.uut.send_wise('root', "#")
        self.uut.send_wise('fdisk /dev/mmcblk0', "Command")
        self.uut.send_wise('n', "primary partition")
        self.uut.send_wise('p', "number")
        self.uut.send_wise('1', "")
        self.sleep_time(1)
        self.uut.send_wise('', "")
        self.sleep_time(1)
        self.uut.send_wise('', "Command")
        self.uut.send_wise('t', "(type L to list codes)")
        self.uut.send_wise('b', "Command")
        self.uut.send_wise('w', "#")

        self.uut.send_wise('mkfs.vfat /dev/mmcblk0p1', "#")
        self.uut.send_wise('reboot', "#")

        # set boot env
        self.wait_for_u_boot(check="pre")
        self.setup_u_boot_env2()

        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # download DIAG
        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.diag_file}', self.u_boot_prompt, 360)
            if 'Bytes transferred =' not in self.uut.buffer:
                self.error(f'download diag file failed, edradour/{self.mapping.diag_file}')
                if scanner.yes_or_enter_to_continue(
                        question=f'Download DIAG img failed! retest? '
                                 f'下载DIAG文件失败！重试？'
                                 f'Tải xuống tệp DIAG không thành công! Thử lại?') is False:
                    raise Exception(f'download diag img file failed!')
                continue
            break

        self.uut.send_wise('fatwrite mmc 0 0x6a000000 /${diag_file} ${filesize}', self.u_boot_prompt)

        self.uut.send_wise('run bootcmd', '')
        self.uut.waitfor(self.diag_prompt, 360)
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)
        # config network
        self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.uut_ip} netmask {self.mapping.netmask} up',
                           self.diag_prompt)
        self.sleep_time(5)


    def download_cpld(self):
        # 下载CPLD文件
        log.debug(f"update file: {self.update_cpld_file}")
        tftp_timeout = 0
        while True:
            self.uut.send_wise('', self.diag_prompt)
            self.uut.send_wise('', self.diag_prompt)
            self.uut.send_wise('syscall ifconfig eth0 down', self.diag_prompt)
            self.sleep_time(30)
            self.uut.send_wise('syscall ifconfig eth0 up', self.diag_prompt)
            self.sleep_time(30)
            self.uut.send_wise(f'syscall tftp -r edradour/{self.update_cpld_file} -g {self.mapping.serverip}',
                               self.diag_prompt)
            # tftp: server error: (1) File not found
            if 'tftp: timeout' in self.uut.buffer:
                if tftp_timeout > 1:
                    if scanner.yes_or_enter_to_continue(
                            question='Download CPLD file failed, retry? 下载CPLD文件失败，重试？'
                                     '\nTải xuống tệp CPLD thất bại, thử lại?') is False:
                        raise Exception('download cpld file failed!')
                    tftp_timeout += 1
                self.uut.send_wise('syscall ifconfig eth0 down', self.diag_prompt)
                self.sleep_time(30)
                self.uut.send_wise('syscall ifconfig eth0 up', self.diag_prompt)
                self.sleep_time(30)
                continue

            if 'File not found' in self.uut.buffer:
                log.error(f'cpld file: {self.update_cpld_file} not on server! Please call TE to check!')
                if scanner.yes_or_enter_to_continue('CPLD file not found! Please call TE check server!') is False:
                    raise Exception(f'CPLD File: {self.update_cpld_file} not found')
                self.sleep_time(5)
                continue

            self.uut.send_enter(self.diag_prompt)
            self.uut.send_enter(self.diag_prompt)
            self.uut.send_wise(f'syscall ls . | grep -x {self.update_cpld_file}', self.diag_prompt)
            if self.uut.buffer.count(self.update_cpld_file) != 2:
                raise Exception(f'not found cpld file: {self.update_cpld_file} in UUT!')

            log.debug(f'cpld file: {self.update_cpld_file} is in UUT..OK')

            # OK
            break

    def check_cpld_golden_image(self):
        # Phase 1
        self.quick_set('Upgrade CPLD Phase 1')
        # 下载CPLD文件
        self.download_cpld()
        # 开始升级，本次要求开始升级后10s断电
        self.uut.send_wise(f'cpldupdate 0 ./{self.update_cpld_file}', '', 360)
        # can not open file ./edradour_sys_cpld_v_01_14_072524_p.vme
        self.sleep_time(10)

        if '..............' not in self.uut.buffer:
            raise Exception('cpld upgrade is not running....')
        if re.search('fail|error', self.uut.buffer, flags=re.I):
            raise Exception('cpld upgrade meet fail or error....')

        self.quick_set('CPLD Boot DIAG 1')
        # 断电重启
        self.power_cycle_diag(check='secondary')


        # check version
        self.check_diag_version(check='secondary')

        # Phase 2
        self.quick_set('Upgrade CPLD Phase 2')
        # 再次下载
        self.download_cpld()
        # 这次正常升级
        self.uut.send_wise(f'cpldupdate 0 ./{self.update_cpld_file}', self.diag_prompt, 360)
        if '...DONE' not in self.uut.buffer:
            raise Exception('cpld update failed')

        self.quick_set('CPLD Boot DIAG 2')
        # power cycle then take effect
        self.power_cycle_diag(check='primary')
        self.quick_set('Check CPLD Version')
        # CPLD :
        self.uut.send_wise('version', self.diag_prompt)
        cpld_ver = re.search(r'CPLD : (\S+)', self.uut.buffer)
        if cpld_ver is None:
            log.error(f'[Pass Criteria] cpld version: None, expected value: {self.mapping.cpld_version}, FAIL')
            raise Exception('not found cpld version!')
        cpld_ver = cpld_ver.group(1)
        if cpld_ver != self.cpld_diag_version:
            log.error(f'[Pass Criteria] cpld version: {cpld_ver}, expected value: {self.mapping.cpld_version}, FAIL')
            raise Exception(f'cpld version mismatch!')
        log.debug(f'[Pass Criteria] cpld version: {cpld_ver}, expected value: {self.mapping.cpld_version}, PASS')

    def login_diag(self):
        # set boot env
        self.wait_for_u_boot()
        self.setup_u_boot_env()

        # boot DIAG manually
        # self.quick_set('Boot DIAG')

        # if '48' in self.mapping.platform:
        #     self.uut.send_wise('bootm ${loadaddr}#wh3p', '')
        # else:
        #     self.uut.send_wise('bootm ${loadaddr}#wh3pe', '')

        self.uut.waitfor(self.diag_prompt, 360)
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)

        # Check Platform & Part Number
        self.quick_set('Check DIAG Platform')

        diag_platform = re.search(r'\*\s+Platform:\s+(.+)', self.uut.buffer)
        if diag_platform is None:
            raise Exception(f'not found platform: {self.mapping.platform} in DIAG')
        diag_platform = diag_platform.group(1).strip()
        if diag_platform != self.mapping.platform:
            raise Exception(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, FAIL')
        log.debug(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, PASS')

        self.quick_set('Check DIAG Part Number')
        diag_pn = re.search(r'\*\s+Part Number:\s+(.+)', self.uut.buffer)
        if diag_pn is None:
            raise Exception(f'not found part numer: {self.mapping.platform} in DIAG')
        diag_pn = diag_pn.group(1).strip()
        if diag_pn != self.mapping.apn.r_val:
            raise Exception(f'diag platform, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, FAIL')
        log.debug(f'diag part number, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, PASS')

        # config network
        self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.uut_ip} netmask {self.mapping.netmask} up',
                           self.diag_prompt)
        self.sleep_time(5)

    def wait_for_u_boot(self, check=None):
        self.uut.waitfor(['Hit any key to stop autoboot', 'Do you want to run the Shmoo? [y/N]',
                          '*** U-Boot Boot Menu ***', self.u_boot_prompt],
                         600)
        log.debug(f'found -> {self.uut.foundphrase}')
        log.debug(self.area)
        if self.area in ['POE', 'POE_STEP_7', 'TRAFFIC']:
            check = None
            self.check_u_boot_info_poe(check=check)
        else:
            self.check_u_boot_info(check=check)
        # Current Boot Bank: 	1
        current_boot_bank = re.search(r'Current Boot Bank:\s+(\d+)', self.uut.buffer)
        if current_boot_bank is not None:
            current_boot_bank = current_boot_bank.group(1)
        log.debug(f'current boot bank: {current_boot_bank}')

        # JNPR U BOOT
        if '*** U-Boot Boot Menu ***' in self.uut.buffer:
            time.sleep(0.5)
            self.uut.send_esc(['Hit any key to stop autoboot', self.u_boot_prompt])
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Do you want to run the Shmoo? [y/N]' in self.uut.buffer:
            self.uut.send_wise('N', ['Hit any key to stop autoboot', self.u_boot_prompt], 150, suffix='')
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Hit any key to stop autoboot' in self.uut.buffer:
            self.uut.send_esc("")
            self.uut.send_esc("")
            self.uut.send_enter(self.u_boot_prompt)
            log.debug(f'found -> {self.uut.foundphrase}')

        time.sleep(1)
        self.uut.send_ctrl_c(self.u_boot_prompt)
        return current_boot_bank

    def check_u_boot_info_poe(self, check):
        if self.area in ["POE", "POE_STEP_7", "TRAFFIC"]:
            check = None
        if check:
            if "JUNIPER HARDWARE ROOT OF TRUST WITH SECURE BOOT ENFORCED" not in self.uut.buffer:
                log.error("Not found: 'JUNIPER HARDWARE ROOT OF TRUST WITH SECURE BOOT ENFORCED' in Uboot info")
                helper.set_display3("Check TPM Program FAIL")
                raise Exception("Check TPM Program FAIL")
            else:
                log.debug("Found: 'JUNIPER HARDWARE ROOT OF TRUST WITH SECURE BOOT ENFORCED', This unit TPM program done")

        u_boot_mn = re.search(r'Board\s*:\s+(\S+)', self.uut.buffer)
        if u_boot_mn is None:
            helper.quick_set('Not found U Boot Model')
            raise Exception('not found u boot Model!!')
        u_boot_mn = u_boot_mn.group(1)
        if u_boot_mn != self.mapping.platform:
            helper.quick_set('U Boot Model Mismatch')
            log.error(f'u boot model match! expected: {self.mapping.platform}, captured: {u_boot_mn}. FAIL')
            raise Exception(f'u boot model mismatch! expected: {self.mapping.platform}, captured: {u_boot_mn}. FAIL')
        log.debug(f'u boot model match! expected: {self.mapping.platform}, captured: {u_boot_mn}. PASS')

        u_boot_sn = re.search(r'Serial\s*:\s+(\S+)', self.uut.buffer)
        if u_boot_sn is None:
            helper.quick_set('Not found U Boot SN')
            raise Exception('not found u boot SN!')
        u_boot_sn = u_boot_sn.group(1)
        if u_boot_sn != self.sernum:
            helper.quick_set('U Boot SN Mismatch')
            log.error(f'u boot sn match! expected: {self.sernum}, captured: {u_boot_sn}. FAIL')
            raise Exception(f'u boot sn mismatch! expected: {self.sernum}, captured: {u_boot_sn}. FAIL')
        log.debug(f'u boot sn match! expected: {self.sernum}, captured: {u_boot_sn}. PASS')

        u_boot_base_mac = re.search(r'Base MAC\s*:\s+(\S+)', self.uut.buffer)
        if u_boot_base_mac is None:
            helper.quick_set('Not found U Boot MAC')
            raise Exception('not found u boot base MAC!')
        u_boot_base_mac = u_boot_base_mac.group(1)
        if u_boot_base_mac != self.mapping.mac.r_val:
            helper.quick_set('U Boot MAC Mismatch')
            log.error(f'u boot base mac match! expected: {self.mapping.mac.r_val}, captured: {u_boot_base_mac}. FAIL')
            raise Exception(
                f'u boot base mac mismatch! expected: {self.mapping.mac.r_val}, captured: {u_boot_base_mac}. FAIL')
        log.debug(f'u boot base mac match! expected: {self.mapping.mac.r_val}, captured: {u_boot_base_mac}. PASS')

    def check_u_boot_info(self, check):
        if check is None:
            return
        if check == "system":
            self.check_system_uboot()
            return
        # if self.mapping.platform != 'EX4000-48MP':
        #     return
        log.debug(f'Currently checking CPLD FW from {check}')
        u_boot_cpld = re.search(r'CPLD Version:\s+(\S+)', self.uut.buffer)
        if u_boot_cpld is None:
            helper.quick_set('Not found U Boot CPLD')
            raise Exception('not found u boot CPLD!!')
        u_boot_cpld = u_boot_cpld.group(1)
        # log.debug(f"Pre: {u_boot_cpld}")
        # log.debug(self.mapping.cpld)
        if check == "pre":
            if u_boot_cpld == self.mapping.cpld:
                log.debug(f"Uboot cpld is: {self.mapping.cpld}")
                log.debug(f"Uboot cpld version is: {u_boot_cpld}, expect {self.mapping.cpld}, PASS")
                self.update_cpld_file = self.mapping.cpld_filename
            else:
                log.error(f"Uboot cpld version is: {u_boot_cpld}, expect {self.mapping.cpld}, FAIL")
                helper.set_display1(self.sernum)
                helper.set_display2(f"Uboot cpld: {u_boot_cpld},expect {self.mapping.cpld}")
                raise Exception(f"Uboot cpld version is: {u_boot_cpld}, expect {self.mapping.cpld}, FAIL")
            return

        # if self.current_pn_df["ECO"].tolist():
        #     eco = self.current_pn_df["ECO"].tolist()[0]
        # else:
        #     eco = ""

        if check == 'secondary':
            check_cpld = self.mapping.secondary_cpld
            # # todo special 48MP sn no need check secondary CPLD
            # if self.sernum in NONE_CHECK_SECONDARY_CPLD_48MP_SN:
            #     log.debug(f'SN: {self.sernum}, U-boot CPLD version is: {u_boot_cpld}, no need check secondary CPLD !')
            #     log.debug(f"No need check list: {NONE_CHECK_SECONDARY_CPLD_48MP_SN}")
            #     return
            # # todo special 12MP&24MP sn no need check secondary CPLD
            # if self.sernum in NONE_CHECK_SECONDARY_CPLD_12_24MP_SN:
            #     log.debug(f'SN: {self.sernum}, U-boot CPLD version is: {u_boot_cpld}, no need check secondary CPLD !')
            #     log.debug(f"No need check list: {NONE_CHECK_SECONDARY_CPLD_12_24MP_SN}")
            #     return

            # ECO-62483
            # if eco != "ECO-62483":
            #     if u_boot_cpld == self.mapping.secondary_cpld_old:
            #         check_cpld = self.mapping.secondary_cpld_old
            #         self.update_cpld_file = self.mapping.cpld_filename_old
            #         self.sec_cpld = self.mapping.secondary_cpld_old
            #         self.cpld_diag_version = self.mapping.cpld_version_old
            #     elif u_boot_cpld == self.mapping.secondary_cpld:
            #         log.debug("DEV-25845 Secondary CPLD version 1.25 --> 1.27")
            #         check_cpld = self.mapping.secondary_cpld
            #         self.update_cpld_file = self.mapping.cpld_filename
            #         self.sec_cpld = self.mapping.secondary_cpld
            #         self.cpld_diag_version = self.mapping.cpld_version
            #     else:
            #         raise Exception(f'u boot secondary CPLD version not in [{self.mapping.secondary_cpld_old}, {self.mapping.secondary_cpld}]')
            # else:
            check_cpld = self.mapping.secondary_cpld
            self.update_cpld_file = self.mapping.cpld_filename
            self.sec_cpld = self.mapping.secondary_cpld
            self.cpld_diag_version = self.mapping.cpld_version
        else:
            if self.sec_cpld == self.mapping.secondary_cpld_old:
                check_cpld = self.mapping.cpld_old
            else:
                # if eco != "ECO-62483":
                #     log.debug("DEV-25845 Primary CPLD version 1.24 --> 1.26")
                check_cpld = self.mapping.cpld
        if u_boot_cpld != check_cpld:
            helper.quick_set('U Boot CPLD Mismatch')
            log.error(f'[Pass Criteria] U boot {check} cpld version: {u_boot_cpld}, expected value: {check_cpld}, result: FAIL')
            raise Exception(f'u boot CPLD mismatch! expected: {check_cpld}, captured: {u_boot_cpld}. FAIL')
        log.debug(f'[Pass Criteria] U boot {check} cpld version: {u_boot_cpld}, expected value: {check_cpld}, result: PASS')

    def power_cycle_u_boot(self):
        # msg = '[U BOOT] Please power cycle UUT. 请拔下电源然后重新上电'
        # if scanner.yes_or_enter_to_continue(question=msg) is False:
        #     raise Exception('power cycle UUT failed! operator!')
        while True:
            try:
                self.pdu.power_cycle(helper.config['pdu_port'])
                self.uut.send_wise('', 'U-Boot', 30)
                break
            except Exception as e:
                if scanner.yes_or_enter_to_continue(
                        question='(Pre Check Step 2)\n'
                                'Vui lòng kiểm tra lại nguồn điện và cáp đã được kết nối tốt chưa\n'
                                 'Please check the power supply and cables are connected well again',
                        image='Edradour/images/check_power_console.png',
                ) is False:
                    raise Exception('OP Stop Test!')
        if self.area in ["POE", "POE_STEP_7"]:
            self.wait_for_u_boot()
        else:
            self.wait_for_u_boot(check="pre")

    def power_cycle_diag(self, check=None):
        # msg = '[DIAG] Please power cycle UUT. 请拔下电源然后重新上电'
        # if scanner.yes_or_enter_to_continue(question=msg) is False:
        #     raise Exception('power cycle UUT failed! operator!')
        self.pdu.power_cycle(helper.config['pdu_port'])
        # self.login_diag()
        self.wait_for_u_boot(check=check)
        self.setup_u_boot_env2()
        self.uut.send_wise('run bootcmd', '')
        self.uut.waitfor(self.diag_prompt, 360)
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)

        # config network
        self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.uut_ip} netmask {self.mapping.netmask} up',
                           self.diag_prompt)
        self.sleep_time(5)

    def push_button(self):
        while True:
            # Please press ENTER to start Reset Button Interrupt Test...
            # 弹窗提示确认后再去按按钮
            self.uut.send_wise('intrtest rst_button', 'ENTER to start Reset Button Interrupt Test...')
            if scanner.yes_or_enter_to_continue(
                    question='Please push REST button about 5 seconds! 请按REST按钮5秒\nVui lòng nhấn nút REST trong 5 giây.',
                    image='Edradour/images/btn-reset.png',
            ) is False:
                raise Exception('RESET Button Test Failed!')
            # Please press ENTER to check Reset Button Interrupt test result...
            self.uut.send_enter('ENTER to check Reset Button Interrupt test result...')
            self.uut.send_enter(self.diag_prompt)
            if 'INTR rst_button test - PASS' not in self.uut.buffer:
                log.error('not found pass signature: INTR rst_button test - PASS')
                continue
            else:
                log.debug(f'[Pass Criteria] capture value: INTR rst_button test - PASS, expect value: INTR rst_button test - PASS, result: PASS')

            if 'INTR test - PASS' not in self.uut.buffer:
                log.error('not found pass signature: INTR test - PASS')
                continue
            else:
                log.debug(
                    f'[Pass Criteria] capture value: INTR test - PASS, expect value: INTR test - PASS, result: PASS')

            log.debug('REST button test pass')
            break

    def reset_reason(self):
        self.uut.send_wise('reasoncheck', self.diag_prompt)
        # 目前的uboot下是 No Reset Reason
        if 'No Reset Reason' not in self.uut.buffer:
            log.error(
                f'[Pass Criteria] capture value: {self.uut.buffer}, expect value: No Reset Reason, result: FAIL')
            raise Exception(f'found reason: {self.uut.buffer}')
        log.debug(
            f'[Pass Criteria] capture value: No Reset Reason, expect value: No Reset Reason, result: PASS')
        # reason = re.search('The Last Reset Reason is (\w+)', self.uut.buffer)
        # log.warning('skip check last reset reason!')
        # # if reason is None:
        # #     raise Exception('not found reset reason!')
        # # reason = reason.group(1)
        # # if reason != 'PON_RST':
        # #     raise Exception('last reset reason is not PON_RST!! FAIL')

    def check_diag_version(self, check=None):
        self.uut.send_wise('version', self.diag_prompt)
        # diag
        diag_version = re.search(r'DIAG\s*:\s*(.*)', self.uut.buffer)
        if diag_version is None:
            log.error(
                f'[Pass Criteria] diag version: None, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('not found diag version!!')
        diag_version = diag_version.group(1).strip()
        if diag_version != self.mapping.diag_version:
            log.error(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('diag version not match!!')
        log.debug(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: PASS')

        # uboot
        uboot_version = re.search(r'Uboot\s*:\s*(.*)', self.uut.buffer)
        if uboot_version is None:
            log.error(
                f'[Pass Criteria] uboot version: None, expect value:{self.mapping.check_u_boot_version}, result: FAIL')
            raise Exception('not found diag version!!')
        uboot_version = uboot_version.group(1).strip()
        if uboot_version != self.mapping.check_u_boot_version:
            log.error(
            f'[Pass Criteria] Uboot version: {uboot_version}, expect value:{self.mapping.check_u_boot_version}, result: FAIL')
            raise Exception('Uboot version not match!!')
        log.debug(
            f'[Pass Criteria] Uboot version: {uboot_version}, expect value:{self.mapping.check_u_boot_version}, result: PASS')

        # cpld
        cpld_version = re.search(r'CPLD\s*:\s*(.*)', self.uut.buffer)
        if cpld_version is None:
            log.error(
                f'[Pass Criteria] CPLD version: None, expect value:{self.mapping.cpld_version}, result: FAIL')
            raise Exception('not found diag version!!')
        cpld_version = cpld_version.group(1).strip()
        if cpld_version != self.cpld_diag_version:
            # # todo special 48MP sn no need check secondary CPLD
            # if (self.sernum in NONE_CHECK_SECONDARY_CPLD_48MP_SN) and (check == 'secondary'):
            #     log.debug(f'SN: {self.sernum}, no need check secondary CPLD !')
            #     log.debug(f"No need check list: {NONE_CHECK_SECONDARY_CPLD_48MP_SN}")
            # # todo special 12MP&24MP sn no need check secondary CPLD
            # elif (self.sernum in NONE_CHECK_SECONDARY_CPLD_12_24MP_SN) and (check == 'secondary'):
            #     log.debug(f'SN: {self.sernum}, no need check secondary CPLD !')
            #     log.debug(f"No need check list: {NONE_CHECK_SECONDARY_CPLD_12_24MP_SN}")
            # else:
            log.error(
            f'[Pass Criteria] CPLD version: {cpld_version}, expect value: {self.mapping.cpld_version}, result: FAIL')
            raise Exception('CPLD version not match!!')
        log.debug(
            f'[Pass Criteria] CPLD version: {cpld_version}, expect value:{self.mapping.cpld_version}, result: PASS')

        if 'P' in self.mapping.platform:
            # poe
            poe_version = re.search(r'PoE  : (\S+)', self.uut.buffer)
            if poe_version is None:
                log.error(
                f'[Pass Criteria] POE version: None, expect value:{self.mapping.bft_poe}, result: FAIL')
                raise Exception(f'not found expected Poe version: {self.mapping.bft_poe}')
            poe_version = poe_version.group(1)
            if poe_version not in self.mapping.bft_poe:
                log.error(
                f'[Pass Criteria] POE version: {poe_version}, expect value:{self.mapping.bft_poe}, result: FAIL')
                # todo debug skip
                raise Exception('POE version mismatch')
            log.debug(
                f'[Pass Criteria] POE version: {poe_version}, expect value:{self.mapping.bft_poe}, result: PASS')

        # EPDM
        if self.mapping.group == 'G1':
            log.debug('G1 need to check EPDM')
            epdm_version = re.search(r'EPDM\s*:\s*(.*)', self.uut.buffer)
            if epdm_version is None:
                log.error(
                    f'[Pass Criteria] EPDM version: None, expect value:{self.mapping.epdm}, result: FAIL')
                raise Exception('not found epdm version!!')
            epdm_version = epdm_version.group(1).strip()
            if epdm_version != self.mapping.epdm:
                log.error(
                    f'[Pass Criteria] EPDM version: {epdm_version}, expect value:{self.mapping.epdm}, result: FAIL')
                raise Exception('epdm version not match!!')
            log.debug(
                f'[Pass Criteria] EPDM version: {epdm_version}, expect value:{self.mapping.epdm}, result: PASS')

        self.uut.send_wise('cpuinfo', self.diag_prompt)
        cpu_device = re.search(r'Device\s*:.*\(([^)]+)\)', self.uut.buffer)
        if cpu_device is None:
            log.error(
                f'[Pass Criteria] CPU device: None, expect value:{self.mapping.cpu_device}, result: FAIL')
            raise Exception('not CPU device version!!')
        cpu_device = cpu_device.group(1).strip()
        if cpu_device != self.mapping.cpu_device:
            log.error(
                f'[Pass Criteria] CPU device: {cpu_device}, expect value:{self.mapping.cpu_device}, result: FAIL')
            raise Exception('CPU device not match!!')
        log.debug(
            f'[Pass Criteria] CPU device: {cpu_device}, expect value:{self.mapping.cpu_device}, result: PASS')

    def check_pfe_fw(self):
        if self.mapping.check_pfe_fw is not True:
            self.debug(f'this {self.uuttype} no need to Check PFE FW!! SKIP...')
            return helper.SKIP

        self.debug(f'this {self.uuttype} need to Check PFE FW.')
        self.uut.send_wise('bcmcall 1 pciephy fw info', self.diag_prompt)

        pcie_fw_loader_version = re.search(r'PCIe FW loader version: (\S+)', self.uut.buffer)
        if pcie_fw_loader_version is None:
            log.error(
                f'[Pass Criteria] PCIe FW loader version: None, expect value:{self.mapping.pcie_fw_loader_version}, result: FAIL')
            raise Exception('not found PCIe FW loader version')
        pcie_fw_loader_version = pcie_fw_loader_version.group(1)
        if pcie_fw_loader_version != self.mapping.pcie_fw_loader_version:
            log.error(
                f'[Pass Criteria] PCIe FW loader version: {pcie_fw_loader_version}, expect value:{self.mapping.pcie_fw_loader_version}, result: FAIL')
            raise Exception('PCIe FW loader version mismatch')
        log.debug(
            f'[Pass Criteria] PCIe FW loader version: {pcie_fw_loader_version}, expect value:{self.mapping.pcie_fw_loader_version}, result: PASS')

        pcie_fw_version = re.search(r'PCIe FW version: (\S+)', self.uut.buffer)
        if pcie_fw_version is None:
            log.error(
                f'[Pass Criteria] PCIe FW version: None, expect value:{self.mapping.pcie_fw_version}, result: FAIL')
            raise Exception('not found PCIe FW version')
        pcie_fw_version = pcie_fw_version.group(1)
        if pcie_fw_version != self.mapping.pcie_fw_version:
            log.error(
                f'[Pass Criteria] PCIe FW version: {pcie_fw_version}, expect value:{self.mapping.pcie_fw_version}, result: FAIL')
            raise Exception('PCIe FW version mismatch')
        log.debug(
            f'[Pass Criteria] PCIe FW version: {pcie_fw_version}, expect value:{self.mapping.pcie_fw_version}, result: PASS')

    def check_emmc_fw_version(self):
        self.uut.send_wise('syscall mmc extcsd read /dev/mmcblk0 | grep Version', self.diag_prompt)
        # eMMC Firmware Version: 00000016
        emmc_version = re.search('eMMC Firmware Version:\s*(\w+)', self.uut.buffer, flags=re.I)
        if emmc_version is None:
            log.error(
                f'[Pass Criteria] eMMC Firmware Version: None, expect value:{self.mapping.emmc_version}, result: FAIL')
            raise Exception('not found eMMC version!')
        emmc_version = emmc_version.group(1)
        if emmc_version not in self.mapping.emmc_version:
            log.error(
                f'[Pass Criteria] eMMC Firmware Version: {emmc_version}, expect value:{self.mapping.emmc_version}, result: FAIL')
            raise Exception('eMMC version mismatch!')
        log.debug(
            f'[Pass Criteria] eMMC Firmware Version: {emmc_version}, expect value:{self.mapping.emmc_version}, result: PASS')

    def update_emmc_fw(self):
        """
        # manufacturer: 0x44 (ATP) oid: 0x0
        # manufacturer: 0xfb (xxx) --> Swissbit
        # manufacturer = re.search('manufacturer: 0x\w+ \((\w+)\)', self.uut.buffer)

        """
        self.uut.send_wise('syscall mmc cid read /sys/block/mmcblk0/device/', self.diag_prompt)

        manu_code_mapping = {
            '0x44': 'ATP',
            '0xfb': 'Swissbit',
        }

        manu_code = re.search('manufacturer: (0x\w+) \(', self.uut.buffer)
        if manu_code is None:
            log.error(
                f'[Pass Criteria] manufacturer: None, expect value:{manu_code_mapping}, result: FAIL')
            raise Exception('not found manufacturer code!')
        manu_code = manu_code.group(1)
        log.debug(f'manufacturer code: {manu_code}')
        if manu_code not in manu_code_mapping:
            log.error(
                f'[Pass Criteria] manufacturer: {manu_code}, expect value:{manu_code_mapping}, result: FAIL')
            raise Exception(f'unknown manufacture code: {manu_code}, please refer: {manu_code_mapping}')
        log.debug(
            f'[Pass Criteria] manufacturer: {manu_code}, expect value:{manu_code_mapping}, result: PASS')

        manufacture_name = manu_code_mapping[manu_code]
        log.debug(f'manufacture name is: {manufacture_name}')

        # if manufacture_name == 'Swissbit':
        #     log.debug('manufacturer is Swissbit, no need to upgrade eMMC FW. SKIP')
        #     return helper.SKIP
        # elif manufacture_name == 'ATP':
        #     # 以后不会有ATP
        #     log.debug('manufacturer is ATP, need to upgrade eMMC FW')
        #     raise Exception(f'manufacturer is ATP, need to upgrade eMMC FW')
        # else:
        #     raise Exception(f'unknown manufacturer: {manufacture_name}')

        # self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.serverip} netmask {self.mapping.netmask} up',
        #                    self.diag_prompt)
        # self.diag_tftp_download(remote_file='edradour/W0111.bin', local_file='W0111.bin')
        # # self.uut.send_wise(f'syscall tftp -r edradour/W0111.bin -g {self.mapping.serverip}', self.diag_prompt)
        # self.uut.send_wise(f'syscall mmc ffu W0111.bin /dev/mmcblk0', self.diag_prompt)
        # self.uut.send_wise('reboot', self.diag_prompt, 180)
        # self.uut.send_wise('syscall mmc cid read /sys/class/mmc_host/mmc0/mmc0:0001/', self.diag_prompt)
        # self.uut.send_wise('mmc extcsd read /dev/mmcblk0 | grep Version', self.diag_prompt)
        # self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.serverip} netmask {self.mapping.netmask} up',
        #                    self.diag_prompt)
        # self.diag_tftp_download(remote_file='edradour/X0805.bin', local_file='X0805.bin')
        # # self.uut.send_wise(f'syscall tftp -r edradour/X0805.bin -g  {self.mapping.serverip}', self.diag_prompt)
        # self.uut.send_wise(f'syscall mmc ffu X0805.bin /dev/mmcblk0', self.diag_prompt)
        # self.uut.send_wise('reboot', self.diag_prompt, 180)
        # self.uut.send_wise('syscall mmc cid read /sys/class/mmc_host/mmc0/mmc0:0001/', self.diag_prompt)
        # self.uut.send_wise('syscall mmc extcsd read /dev/mmcblk0 | grep Version', self.diag_prompt)
        # self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.serverip} netmask {self.mapping.netmask} up',
        #                    self.diag_prompt)
        # self.diag_tftp_download(remote_file='edradour/X0731.bin', local_file='X0731.bin')
        # # self.uut.send_wise(f'syscall tftp –r edradour/X0731.bin -g {self.mapping.serverip}', self.diag_prompt)
        # self.uut.send_wise(f'syscall mmc ffu X0731.bin /dev/mmcblk0', self.diag_prompt)
        # self.uut.send_wise('reboot', self.diag_prompt, 180)
        # self.uut.send_wise('syscall mmc cid read /sys/class/mmc_host/mmc0/mmc0:0001/', self.diag_prompt)
        # self.uut.send_wise('syscall mmc extcsd read /dev/mmcblk0 | grep Version', self.diag_prompt)

    def diag_tftp_download(self, remote_file, local_file):
        while True:
            self.uut.send_wise(f'syscall tftp -r {remote_file} -g {self.mapping.serverip}', self.diag_prompt, 90)
            if 'tftp: timeout' in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(
                        question=f'Download {remote_file} failed, retry?\n下载{remote_file}文件失败，重试？'
                                 f'\nTải xuống tệp {remote_file} thất bại, thử lại?') is False:
                    raise Exception(f'download {remote_file} file failed!')
                self.uut.send_wise('syscall ifconfig eth0 down', self.diag_prompt)
                self.sleep_time(3)
                self.uut.send_wise('syscall ifconfig eth0 up', self.diag_prompt)
                self.sleep_time(5)
                continue

            if 'File not found' in self.uut.buffer:
                log.error(f'file: {remote_file} not on server! Please call TE to check!')
                if scanner.yes_or_enter_to_continue(
                        f'file: {remote_file} not found! Please call TE check server!') is False:
                    raise Exception(f'File: {remote_file} not found')
                self.sleep_time(5)
                continue

            self.uut.send_wise(f'syscall ls | grep -x {local_file}', self.diag_prompt)
            if self.uut.buffer.count(local_file) != 2:
                raise Exception(f'not found local file: {local_file}')

            break

    def program_ideeprom(self):
        # Disable the IDEEPROM WP
        self.uut.send_wise('cpldwrite 0 0x1f 0x0', self.diag_prompt)

        # for i in range(10):
        #     self.uut.send_wise('ideeprom clear_to_ff CPU_EEPROM 0 0x80', self.diag_prompt)
        #     if re.search('error|fail', self.uut.buffer, re.I):
        #         if scanner.yes_or_enter_to_continue('clear id eeprom failed, retry? 清理ID EEPROM失败，重测？') is False:
        #             raise Exception('clear id eeprom failed 1!')
        #         continue
        #     self.uut.send_wise('ideeprom default CPU_EEPROM', self.diag_prompt)
        #     if re.search('error|fail', self.uut.buffer, re.I):
        #         if scanner.yes_or_enter_to_continue(
        #                 'default id eeprom failed, retry? default ID EEPROM失败，重测？') is False:
        #             raise Exception('default id eeprom failed 1!')
        #         continue
        #     break
        # else:
        #     raise Exception('clear id eeprom failed 2!')
        self.uut.send_wise('ideeprom clear_to_ff CPU_EEPROM 0x0 0x40', self.diag_prompt)
        self.sleep_time(10)
        self.uut.send_wise('ideeprom dump CPU_EEPROM 0 0x40', self.diag_prompt)
        self.sleep_time(10)
        self.uut.send_wise('ideeprom clear_to_ff CPU_EEPROM 0x40 0x80', self.diag_prompt)
        self.sleep_time(10)
        self.uut.send_wise('ideeprom dump CPU_EEPROM 0x40 0x40', self.diag_prompt)
        self.sleep_time(10)

        self.uut.send_wise('ideeprom default CPU_EEPROM', self.diag_prompt)

        targets = [
            self.mapping.jedec,
            self.mapping.eeprom_ver,
            self.mapping.bit_field,
            self.mapping.aver_maj,
            self.mapping.aver_min,

            self.mapping.arev,
            self.mapping.afg,
            self.mapping.mac_mc,
            self.mapping.mac_fv,
            self.mapping.mac_ent,
            self.mapping.msi,
            self.mapping.clei,
            self.mapping.mrev_maj,
            self.mapping.mrev_min,

            # year month day
            self.mapping.asd,
            self.mapping.asm,
            self.mapping.asy,
            #
            self.mapping.aid,
            self.mapping.apn,
            self.mapping.mn,
            #
            self.mapping.mac,
            self.mapping.asn,
            self.mapping.chas_sn,
        ]
        for tg in targets:
            log.debug(f'program: {tg}')
            self.uut.send_wise(f'ideeprom edit CPU_EEPROM {tg.w_name} {tg.w_val}', self.diag_prompt)
            if re.search('error|fail', self.uut.buffer, re.I):
                raise Exception('found error or fail in buffer!')
            if 'Verify the write content - pass' not in self.uut.buffer:
                raise Exception(f'program {tg.w_name} failed!!')
            log.debug(f'program {tg.w_name}: {tg.w_val} PASS.')

        # 这个值会自动写进去，只是做个别项目的CheckSum好像每个SKU都是固定的值
        self.uut.send_wise('ideeprom cksum CPU_EEPROM', self.diag_prompt)
        if re.search('error|fail', self.uut.buffer, re.I):
            raise Exception('check sum failed, found error or fail in buffer!')

    def check_ideeprom(self):
        # 注意此处的检查项目要和上面写的项目保持一致
        self.uut.send_wise('ideeprom show CPU_EEPROM', self.diag_prompt)
        targets = [
            self.mapping.jedec,
            self.mapping.eeprom_ver,
            self.mapping.bit_field,
            self.mapping.aver_maj,
            self.mapping.aver_min,

            self.mapping.arev,
            self.mapping.afg,
            self.mapping.mac_mc,
            self.mapping.mac_fv,
            self.mapping.mac_ent,
            self.mapping.msi,
            # self.mapping.clei,
            self.mapping.mrev_maj,
            self.mapping.mrev_min,

            # year month day
            # self.mapping.asd,
            # self.mapping.asm,
            # self.mapping.asy,
            #
            self.mapping.aid,
            self.mapping.apn,
            self.mapping.mn,
            #
            self.mapping.mac,
            self.mapping.asn,
            self.mapping.chas_sn,
        ]
        for tg in targets:
            log.debug(f'verify: {tg}')
            captured = re.search(f'{re.escape(tg.r_name)}: ([^\r\n]*)', self.uut.buffer)
            if captured is None:
                raise Exception(f'not found {tg.r_name}!!!')
            captured = captured.group(1).strip()
            if tg == self.mapping.mac:
                captured = captured.replace(":", "")
            if captured != tg.r_val:
                if tg in [self.mapping.aver_min, self.mapping.arev, self.mapping.mrev_maj, self.mapping.asn,
                          self.mapping.clei, self.mapping.mac, self.mapping.apn, self.mapping.mn, self.mapping.chas_sn]:
                    log.error(
                        f'[Pass Criteria] {tg.r_name}: {captured}, expect value get from MES:{tg.r_val}, result: FAIL')
                else:
                    log.error(
                        f'[Pass Criteria] {tg.r_name}: {captured}, expect value:{tg.r_val}, result: FAIL')
                raise Exception(f'{tg.r_name} mismatch!')
            else:
                if tg in [self.mapping.aver_min, self.mapping.arev, self.mapping.mrev_maj, self.mapping.asn,
                          self.mapping.clei, self.mapping.mac, self.mapping.apn, self.mapping.mn, self.mapping.chas_sn]:
                    log.debug(
                        f'[Pass Criteria] {tg.r_name}: {captured}, expect value get from MES:{tg.r_val}, result: PASS')
                else:
                    log.debug(
                        f'[Pass Criteria] {tg.r_name}: {captured}, expect value:{tg.r_val}, result: PASS')

        self.uut.send_wise('ideeprom dump CPU_EEPROM 0 80', self.diag_prompt)

    def check_system_status(self):
        self.uut.send_wise('reboot', "")
        self.wait_for_u_boot()
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c md 0x50 0xfc 2', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x50 0xfc 0xff', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x50 0xfd 0xff', self.u_boot_prompt)
        # self.uut.send_wise('i2c mw 0x50 0xfe 0xff', self.u_boot_prompt)
        # self.uut.send_wise('i2c mw 0x50 0xff 0xff', self.u_boot_prompt)
        self.uut.send_wise('i2c md 0x50 0xfc 2', self.u_boot_prompt)
        output_value = re.search(r"00fc:\s*((?:[0-9a-fA-F]{2}\s*)+)", self.uut.buffer)
        if output_value:
            check_value = output_value.group(1).strip()
            if "ff ff" != check_value:
                log.error(f"[Pass Criteria] capture value: {check_value}, expect value: ff ff, result: FAIL")
                raise Exception(f"[Pass Criteria] capture value: {check_value}, expect value: ff ff, result: FAIL")
            else:
                log.debug(f"[Pass Criteria] capture value: {check_value}, expect value: ff ff, result: PASS")
        else:
            raise Exception("Not Found any output value !")

        self.uut.send_wise('reset', "")
        self.wait_for_u_boot(check="system")
        self.enter_diag_mode()

    def check_system_uboot(self):
        if "Initialising nvram" not in self.uut.buffer:
            log.error(f"[Pass Criteria] capture value: None, expect value: Initialising nvram, result: FAIL")
            raise Exception("Not found 'Initialising nvram' in uboot info ")
        else:
            log.debug(f"[Pass Criteria] capture value: Initialising nvram, expect value: Initialising nvram, result: PASS")

        system_status = re.search(r'System Status:\s+(\S+)', self.uut.buffer)
        if system_status:
            system_status_value = system_status.group(1)
            last_value = system_status_value[-1]
            log.debug(f"System Status is {system_status_value}")
            binary_value = format(int(last_value, 16), '04b')
            log.debug(f"The last value is {last_value}, to binary is {binary_value}, the last bits is {binary_value[-2:]}")
            if 'P' in self.mapping.platform:
                if binary_value[-2:] != "11":
                    log.error(
                        f"[Pass Criteria] POE SKU the last bits capture value: {binary_value[-2:]}, expect value: 11, result: FAIL")
                    raise Exception("check system status fail")
                else:
                    log.debug(
                        f"[Pass Criteria] POE SKU the last bits capture value: {binary_value[-2:]}, expect value: 11, result: PASS")
            else:
                if binary_value[-2:] != "00":
                    log.error(
                        f"[Pass Criteria] Non-POE SKU the last bits capture value: {binary_value[-2:]}, expect value: 00, result: FAIL")
                    raise Exception("check system status fail")
                else:
                    log.debug(
                        f"[Pass Criteria] Non-POE SKU the last bits capture value: {binary_value[-2:]}, expect value: 00, result: PASS")
        else:
            raise Exception("not found system status fail")

    def enter_diag_mode(self):
        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)
        self.uut.send_wise('run bootcmd', self.diag_prompt, 600)

        diag_platform = re.search(r'\*\s+Platform:\s+(.+)', self.uut.buffer)
        if diag_platform is None:
            raise Exception(f'not found platform: {self.mapping.platform} in DIAG')
        diag_platform = diag_platform.group(1).strip()
        if diag_platform != self.mapping.platform:
            raise Exception(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, FAIL')
        log.debug(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, PASS')

        self.quick_set('Check DIAG Part Number')
        diag_pn = re.search(r'\*\s+Part Number:\s+(.+)', self.uut.buffer)
        if diag_pn is None:
            raise Exception(f'not found part numer: {self.mapping.platform} in DIAG')
        diag_pn = diag_pn.group(1).strip()
        if diag_pn != self.mapping.apn.r_val:
            raise Exception(f'diag platform, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, FAIL')
        log.debug(f'diag part number, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, PASS')
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)

    def memory_test(self):
        self.uut.send_wise('memtest marchc 3 2800', self.diag_prompt, 120)
        if 'Memory test - PASS' not in self.uut.buffer:
            log.error(
                f'[Pass Criteria] capture: {self.uut.buffer}, expect value: Memory test - PASS, result: FAIL')
            raise Exception('mem test failed!')
        log.debug(
            f'[Pass Criteria] capture: {self.uut.buffer}, expect value: Memory test - PASS, result: PASS')

    def cpu_full_load(self):
        self.uut.send_wise('syscall stress-ng -c 4 --cpu-method all --timeout 10', self.diag_prompt)
        if 'successful run completed' not in self.uut.buffer:
            log.error('CPU Full Load test failed!')
            raise Exception('CPU Full Load test failed!')
        else:
            log.debug(
                f'[Pass Criteria] capture: {self.uut.buffer}, expect value: successful run completed, result: PASS')

    def set_clock(self):
        # 使用 UTC
        utc_time = dt.datetime.now(dt.timezone.utc)
        time_str = utc_time.strftime('rtcwrite %y %m %d %w %H %M %S')
        self.uut.send_wise(time_str, self.diag_prompt)
        if re.search('error|fail', self.uut.buffer, re.I):
            raise Exception('rtc write failed!')

        if 'is set to RTC.' not in self.uut.buffer:
            raise Exception('rtc write failed2!')
        log.debug(
            f"[Pass Criteria] capture: {self.uut.buffer}, expect value: is set to RTC., result: PASS")

    def check_clock(self):
        self.uut.send_wise('rtctest', self.diag_prompt)
        if 'Rtc test - PASS' not in self.uut.buffer:
            raise Exception('check rtc clock failed!')
        self.uut.send_wise('rtcread', self.diag_prompt)
        log.debug(
            f"[Pass Criteria] capture: 'Rtc test - PASS', expect value: 'Rtc test - PASS', result: PASS")

    def transceiver_port_pinchk(self):
        sfp_ports = self.mapping.sfp_ports
        while True:
            self.uut.send_wise(f'transceiver {sfp_ports[0]}-{sfp_ports[-1]} pinchk 1 1', self.diag_prompt)
            pattern = re.compile(r'^(P\d+)\s+(\w+)', re.MULTILINE)
            bad_ports = []

            for port, status in pattern.findall(self.uut.buffer):
                if status.lower() != "present":
                    bad_ports.append((port, status))

            if not bad_ports:
                log.debug("all port are present")
                return helper.PASS
            else:
                msg = f"以下 port 状态异常/Các cổng sau đang ở trạng thái bất thường/The following ports are in an abnormal state：\n"\
                       f"{', '.join(f'{port}:{status}' for port, status in bad_ports)}"
                if scanner.yes_or_enter_to_continue(
                        question=msg) is False:
                    raise Exception(msg)

    def i2c_test(self):
        # 需要确保已插入所有的 SFP
        # scanner.yes_or_enter_to_continue(question='Please install all SFPs. 请安装所有SFP\nVui lòng cài đặt tất cả các SFP.',
        #                                  image='Edradour/images/all-sfp-24-48.png')
        while True:
            self.uut.send_wise('i2ctest all all', self.diag_prompt)

            if re.search('error|fail', self.uut.buffer, re.I):
                log.error(f'I2C test failed')
                if scanner.yes_or_enter_to_continue(
                        question=f'I2C test failed, found error or fail, retry? I2C测试失败，重试？\nKiểm tra I2C thất bại, thử lại?'
                ) is False:
                    raise Exception(f'I2C test failed')
                continue

            if 'i2ctest all - PASS' not in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(
                        'I2C Test failed, not found PASS, retry? I2C 测试失败，重试？') is False:
                    log.error('not found pass signature: i2ctest all - PASS')
                    raise Exception('i2c test failed!')
                continue

            log.debug(
                f"[Pass Criteria] capture: 'i2ctest all - PASS', expect value: 'i2ctest all - PASS', result: PASS")
            break

    def sfp_check(self):
        # 虽然写的是 SFP PN REV check，但是实际并没有限定 SFP 的型号
        if self.mapping.platform in [df.MN_EX4000_8P]:
            # 8P 只有两个 SFP
            commands = [
                ('SFP 0', 'eeprom dump SFP#1'),
                ('SFP 1', 'eeprom dump SFP#2'),
            ]
        else:
            commands = [
                ('SFP 0', 'eeprom dump SFP#1'),
                ('SFP 1', 'eeprom dump SFP#2'),
                ('SFP 2', 'eeprom dump SFP#3'),
                ('SFP 3', 'eeprom dump SFP#4'),
            ]

        for sfp_no, cmd in commands:
            while True:
                self.uut.send_wise(cmd, self.diag_prompt)
                if re.search('error|fail', self.uut.buffer, re.I):
                    log.error(f'{sfp_no} test failed')
                    if scanner.yes_or_enter_to_continue(
                            question=f'{sfp_no} test failed, retry? {sfp_no} 测试失败，重试？'
                                     f'\n{sfp_no} Kiểm tra thất bại, thử lại?'
                    ) is False:
                        raise Exception(f'{sfp_no} test failed')
                    continue

                log.debug(f"[Pass Criteria] {sfp_no} test capture: no error or fail, expect value: no error or fail, result: PASS")
                break

    def dump_sfp_info(self):
        for port in self.mapping.sfp_ports:
            while True:
                self.uut.send_wise(f'port {port} sfp', self.diag_prompt)
                if re.search('fail|error', self.uut.buffer, flags=re.I):
                    question = (f"Port {port} SFP test Fail, please change anothor one\n"
                                f"Cổng {port} kiểm tra SFP thất bại, vui lòng thay cái khác")
                    if scanner.yes_or_enter_to_continue(question=question) is False:
                        helper.quick_set(f'Port {port} SFP Fail')
                        raise Exception(f'Port {port} SFP Fail')
                    else:
                        continue
                else:
                    log.debug(f"[Pass Criteria] Port {port} SFP test capture: no error or fail, expect value: no error or fail, result: PASS")
                    try:
                        self.record_sfp(buf=self.uut.buffer, DB_PATH="/tftpboot/bft_sfp_usage.db")
                    except:
                        pass
                    break

    def check_all_ports_status(self, speed=None):
        helper.quick_set("check all port status")
        # if self.mapping.platform == 'EX4000-48MP':
        #     self.uut.send_wise('bcmcall 0 port hg speed=20000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg speed=20000', self.diag_prompt)
        # if self.mapping.platform in ['EX4000-48P', 'EX4000-48T']:
        #     self.uut.send_wise('bcmcall 0 port hg speed=25000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg speed=25000', self.diag_prompt)

        while True:
            self.uut.send_wise('port all status', self.diag_prompt)

            # port 52 53(48 P/T/MP) link down is true failure
            ports = re.findall(r'^P(\d+)\s+(\S+)\s+', self.uut.buffer, flags=re.M)
            if len(ports) != self.mapping.traffic_port_num:
                raise Exception(f'expected port num: {self.mapping.traffic_port_num}, got: {len(ports)}')

            down_ports = [p[0] for p in ports if p[1].upper() != 'UP']
            if len(down_ports) != 0:
                # 48MP -> 52, 53 Down True Fail. 48P/T -> 52, 53, 54, 55 Down True Fail!
                # port 52 53(48 P/T/MP) link down is true failure
                if '52' in down_ports or '53' in down_ports or '54' in down_ports or '55' in down_ports:
                    self.quick_set('Port 52 or 53 or 54 or 55 Down')
                    raise Exception('Port 52 or 53 or 54 or 55 Down, this is true failure, please send to RE!')
                question = (f'Some ports are down! {",".join(down_ports)}\n'
                            f'这些端口是没起来，请检查：{",".join(down_ports)}\n'
                            f'Một số cổng bị hỏng! Kiểm tra lại? {",".join(down_ports)}')
                if scanner.yes_or_enter_to_continue(question=question) is False:
                    raise Exception(f'traffic test failed, ports are down: {",".join(down_ports)}')
                continue

            log.debug('all ports status OK')
            # all ports are UP
            self.check_port_status(log_text=self.uut.buffer, speed=speed)
            break

    def traffic_test_48mp(self, seconds=300, min_pkg=1_000_000):
        # traffic port num。 52，53需要单独测试，但是检查状态的时候是需要的。Traffic 单独测试！
        # 先测试52 53 Port
        log.debug(f'{self.mapping.platform} need to do test port 52, 53')
        # 52
        self.uut.send_wise('bcmcall 0 port hg0 speed=20000', self.diag_prompt)
        self.uut.send_wise('bcmcall 1 port hg0 speed=20000', self.diag_prompt)
        self.sleep_time(2)
        self.uut.send_wise('port 53 loopback mac-rmt', self.diag_prompt)
        self.sleep_time(3)
        self.do_traffic_test(f'linespeed exts 52 5a 1518 10 {seconds}', 1, 420, min_pkg)
        self.uut.send_wise('port 53 loopback none', self.diag_prompt)
        # 53
        self.uut.send_wise('bcmcall 0 port hg0 speed=20000', self.diag_prompt)
        self.uut.send_wise('bcmcall 1 port hg0 speed=20000', self.diag_prompt)
        self.sleep_time(2)
        self.uut.send_wise('port 52 loopback mac-rmt', self.diag_prompt)
        self.sleep_time(3)
        self.do_traffic_test(f'linespeed exts 53 5a 1518 10 {seconds}', 1, 420, min_pkg)
        self.uut.send_wise('port 52 loopback none', self.diag_prompt)

        self.uut.send_wise('bcmcall 0 port hg0 speed=20000', self.diag_prompt)
        self.uut.send_wise('bcmcall 1 port hg0 speed=20000', self.diag_prompt)

        # 再测试其他端口
        self.do_traffic_test(f'linespeed extp 0-51 5a 256 10 {seconds} mfg', 52, 420,
                             min_pkg)
        self.do_traffic_test(f'linespeed extp 0-51 5a 1518 10 {seconds} mfg', 52, 420,
                             min_pkg)

    def traffic_test_48t_48p(self, seconds=300, min_pkg=1_000_000):
        # traffic port num。 52，53需要单独测试，但是检查状态的时候是需要的。Traffic 单独测试！
        # 先测试 52 53 Port
        log.debug(f'{self.mapping.platform} need to do test port 52, 53, 54, 55')
        # 52
        self.uut.send_wise('bcmcall 0 port hg0 speed=25000', self.diag_prompt)
        self.uut.send_wise('bcmcall 1 port hg0 speed=25000', self.diag_prompt)
        self.sleep_time(2)
        self.uut.send_wise('port 53 loopback mac-rmt', self.diag_prompt)
        self.sleep_time(3)
        self.do_traffic_test(f'linespeed exts 52 5a 1518 10 {seconds}', 1, 420, min_pkg)
        self.uut.send_wise('port 53 loopback none', self.diag_prompt)
        # 53
        self.uut.send_wise('bcmcall 0 port hg0 speed=25000', self.diag_prompt)
        self.uut.send_wise('bcmcall 1 port hg0 speed=25000', self.diag_prompt)
        self.sleep_time(2)
        self.uut.send_wise('port 52 loopback mac-rmt', self.diag_prompt)
        self.sleep_time(3)
        self.do_traffic_test(f'linespeed exts 53 5a 1518 10 {seconds}', 1, 420, min_pkg)
        self.uut.send_wise('port 52 loopback none', self.diag_prompt)

        self.uut.send_wise('bcmcall 0 port hg0 speed=25000', self.diag_prompt)
        self.uut.send_wise('bcmcall 1 port hg0 speed=25000', self.diag_prompt)

        # 54
        self.uut.send_wise('bcmcall 0 port hg1 speed=25000', self.diag_prompt)
        self.uut.send_wise('bcmcall 1 port hg1 speed=25000', self.diag_prompt)
        self.sleep_time(2)
        self.uut.send_wise('port 55 loopback mac-rmt', self.diag_prompt)
        self.sleep_time(3)
        self.do_traffic_test(f'linespeed exts 54 5a 1518 10 {seconds}', 1, 420, min_pkg)
        self.uut.send_wise('port 55 loopback none', self.diag_prompt)

        # 55
        self.uut.send_wise('bcmcall 0 port hg1 speed=25000', self.diag_prompt)
        self.uut.send_wise('bcmcall 1 port hg1 speed=25000', self.diag_prompt)
        self.sleep_time(2)
        self.uut.send_wise('port 54 loopback mac-rmt', self.diag_prompt)
        self.sleep_time(3)
        self.do_traffic_test(f'linespeed exts 55 5a 1518 10 {seconds}', 1, 420, min_pkg)
        self.uut.send_wise('port 54 loopback none', self.diag_prompt)

        self.uut.send_wise('bcmcall 0 port hg1 speed=25000', self.diag_prompt)
        self.uut.send_wise('bcmcall 1 port hg1 speed=25000', self.diag_prompt)

        self.do_traffic_test(f'linespeed extp 0-51 5a 256 10 {seconds} mfg', 52, 420,
                             min_pkg)
        self.do_traffic_test(f'linespeed extp 0-51 5a 1518 10 {seconds} mfg', 52, 420,
                             min_pkg)

    def traffic_test(self, pop=True, seconds=300, min_pkg=1_000_000, get_sngr=False):
        """
            speed: [high|low]
        """

        # if pop is True:
        #     if scanner.yes_or_enter_to_continue(
        #             question='Please ensure all network cable and SFP are installed!\n请确认所有的网线和SFP已安装'
        #                      '\nVui lòng xác nhận tất cả các dây mạng và SFP đã được cài đặt.',
        #             image='Edradour/images/traffic.png'
        #     ) is False:
        #         raise Exception('operator stop traffic test')
        if self.mapping.group == "G1":
            get_sngr = True
        # 等待端口起来
        self.sleep_time(60)
        # 需要在一开始就把网线和SFP都是插好
        self.check_all_ports_status()

        if get_sngr:
            self.get_snr_value()
        log.debug(f'{self.mapping.platform} - Normal Traffic Test')
        self.do_traffic_test(f'linespeed extp all 5a 256 10 {seconds} mfg', self.mapping.traffic_port_num, 420,
                             min_pkg)
        if get_sngr:
            self.get_snr_value()
        self.do_traffic_test(f'linespeed extp all 5a 1518 10 {seconds} mfg', self.mapping.traffic_port_num, 420,
                             min_pkg)
        if get_sngr:
            self.get_snr_value()

    def traffic_test_bg(self, seconds=300):

        # 等待端口起来
        self.sleep_time(20)
        # 需要在一开始就把网线和SFP都是插好
        self.check_all_ports_status()

        self.uut.send_wise(f'linespeed extp all 5a 256 10 {seconds} mfg bg', self.diag_prompt, 600)
        self.sleep_time(60)
        self.get_snr_value()
        self.sleep_time(240)
        self.stop_traffic_test_and_check(self.mapping.traffic_port_num, 1_000_000)

        # self.uut.send_wise(f'linespeed extp all 5a 1518 10 {seconds} mfg bg', self.diag_prompt, 600)
        # self.sleep_time(60)
        # self.get_snr_value()
        # self.sleep_time(240)
        # self.stop_traffic_test_and_check(self.mapping.traffic_port_num, 1_000_000)

    def do_traffic_test(self, command, port_num, timeout, min_pkg):
        while True:
            self.uut.send_wise(command, self.diag_prompt, timeout)
            # ports = re.findall(r'Port(\d+)\s+.+ speed test \(P\1\.TX:(\d+) P\d+\.RX:(\d+) @ \d+\.\d+\w bps \) (\S+)',
            #                    self.uut.buffer)

            ports = re.findall(r'Port(\d+)\s+\d+(?:\.\d+)?[GM] speed test \(P\1\.TX:(\d+) P\d+\.RX:(\d+)\) (\w+)',
                               self.uut.buffer)

            # ('51', '265951010', '265951010', 'PASS')
            # ('52', '10', '0', 'FAILED')
            failed = []
            for p in ports:
                num, tx, rx, result = p
                tx, rx = int(tx), int(rx)
                if result != 'PASS':
                    log.error(f'Port: {num} status is not PASS!')
                    failed.append(num)
                    continue
                if tx < min_pkg or rx < min_pkg:
                    failed.append(num)
                    log.error(f'Port: {num} TX or RX less than {min_pkg}, failed!')
                    continue
                if tx != rx:
                    failed.append(num)
                    log.error(f'Port: {num} Tx: {tx}, Rx: {rx} not equal!')
                    continue

                log.debug(f'[Pass Criteria] Port: {num} traffic test TX: {tx}, RX: {rx}, expect: TX&RX > {min_pkg} and TX=RX, result: PASS')

            # 52, 53, 54, 55 有问题的话就不再重试了
            if '52' in failed or '53' in failed or '54' in failed or '55' in failed:
                raise Exception('52 or 53 or 54 or 55 port failed! Please call RD or RE for help!')

            if len(failed) != 0:
                fps = ','.join(failed)
                # msg = f'These ports are failed: {fps}. \n这些端口Traffic failed: {fps}。\nCác cổng này bị lỗi: {fps}'
                # if scanner.yes_or_enter_to_continue(question=msg) is False:
                raise Exception(f'traffic test failed: {fps} are down!')
                # continue
            # 确保查找到的端口数量符合预期
            if len(ports) != port_num:
                raise Exception(f'port num mismatch, expected: {port_num}, captured: {len(ports)}')

            if 'PASSED' not in self.uut.buffer:
                msg = ('Not found PASSED in buffer, retry?\n'
                       '没有发现PASSED标记，重测？\n'
                       'không tìm thấy ĐẠT trong bộ đệm, hãy thử lại')
                # if scanner.yes_or_enter_to_continue(question=msg) is False:
                raise Exception('not found PASSED in buffer!')
                # continue

            # everything is OK
            break

    def set_full_speed(self):
        if self.mapping.platform == df.MN_EX4000_12MP:
            self.uut.send_wise('port 0-3 speed 2.5g', self.diag_prompt)
            self.uut.send_wise('port 4-11 speed 1g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_24MP:
            self.uut.send_wise('port 0-3 speed 2.5g', self.diag_prompt)
            self.uut.send_wise('port 4-23 speed 1g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_48MP:
            self.uut.send_wise('port 0-7 speed 2.5g', self.diag_prompt)
            self.uut.send_wise('port 8-47 speed 1g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_8P:
            self.uut.send_wise('port 0-9 speed 1g', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_12P, df.MN_EX4000_12T]:
            self.uut.send_wise('port 0-11 speed 1g', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_24P, df.MN_EX4000_24T]:
            self.uut.send_wise('port 0-23 speed 1g', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_48P, df.MN_EX4000_48T]:
            self.uut.send_wise('port 0-47 speed 1g', self.diag_prompt)
        else:
            raise Exception(f'set full speed, unknown platform -> {self.mapping.platform}')

    def set_low_speed(self):
        if self.mapping.platform == df.MN_EX4000_12MP:
            self.uut.send_wise('port 0-3 speed 1g', self.diag_prompt)
            self.uut.send_wise('port 4-11 speed 100m', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_24MP:
            self.uut.send_wise('port 0-3 speed 1g', self.diag_prompt)
            self.uut.send_wise('port 4-23 speed 100m', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_48MP:
            self.uut.send_wise('port 0-7 speed 1g', self.diag_prompt)
            self.uut.send_wise('port 8-47 speed 100m', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_8P:
            self.uut.send_wise('port 0-9 speed 100m', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_12P, df.MN_EX4000_12T]:
            self.uut.send_wise('port 0-11 speed 100m', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_24P, df.MN_EX4000_24T]:
            self.uut.send_wise('port 0-23 speed 100m', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_48P, df.MN_EX4000_48T]:
            self.uut.send_wise('port 0-47 speed 100m', self.diag_prompt)
        else:
            raise Exception(f'set low speed, unknown platform -> {self.mapping.platform}')

    def low_speed_traffic_test(self):
        self.set_low_speed()
        self.sleep_time(20)

        self.check_all_ports_status(speed="low")

        # self.get_snr_value()

        self.do_traffic_test('linespeed extp all 5a 256 10 300 mfg', self.mapping.traffic_port_num, 420,
                             min_pkg=100_000)

        # self.get_snr_value()

        self.do_traffic_test('linespeed extp all 5a 1518 10 300 mfg', self.mapping.traffic_port_num, 420,
                             min_pkg=100_000)

        # self.get_snr_value()

    def mgmt_test(self):
        if yes_or_enter_to_continue('Please insert MGMT LoopBack\n请安装MGMT LoopBack!\nVui lòng cài đặt MGMT LoopBack!',
                                    image='Edradour/images/mgmt-loopback.png') is False:
            raise Exception('user stop mgmt test!')

        while True:
            self.uut.send_wise('mgmt eth0 exts 0x5a 64 10 1000', self.diag_prompt)
            if 'Test pass' not in self.uut.buffer:
                if yes_or_enter_to_continue(question='MGMT test failed! retry? MGMT测试失败，重试？'
                                                     '\nKiểm tra MGMT thất bại, thử lại?') is False:
                    raise Exception('mgmt test failed!')
                continue

            tx_rx = re.search('Port eth0 TX = (\d+) RX = (\d+)', self.uut.buffer)
            if tx_rx is None:
                if yes_or_enter_to_continue(question='not found MGMT TX RX, retry?\nKhông tìm thấy MGMT TX RX, thử lại?') is False:
                    raise Exception('not found TX RX data!')
                continue

            tx, rx = tx_rx.groups()
            log.debug(f'MGMT TX: {tx}, RX: {rx}')
            if tx != '10' or rx != '10':
                if yes_or_enter_to_continue(question='TX or RX is not 10! retry?\nTX hoặc RX không phải là 10! Thử lại?') is False:
                    raise Exception('TX or RX is not 10')
                continue

            log.debug('[Pass Criteria] MGMT test capture: tx=10 rx=10, expect value: tx=10 rx=10, result: PASS')
            break

    def poe_do_connect(self):
        while True:
            try:
                for conn in self.poe_group:
                    conn.do_connect(close_before_open=True)
                break
            except Exception as e:
                log.error(f"Connect to POE fail: {e}")
                if yes_or_enter_to_continue(
                    question='Please call TE check POE console! Vui lòng gọi TE để kiểm tra bảng điều khiển POE!') is False:
                    raise Exception(f"Connect to POE fail: {e}")
                else:
                    continue

    def poe_do_disconnect(self):
        for conn in self.poe_group:
            conn.do_disconnect()

    def poe_set_current(self, current):
        for conn in self.poe_group:
            conn.set_current(current)

    def poe_conn_on(self):
        for conn in self.poe_group:
            conn.conn_on()

    def poe_conn_off(self):
        for conn in self.poe_group:
            conn.conn_off()

    def _poe_test_new(self):
        for start, end in self.mapping.poe_seq:
            helper.quick_set(f'PoE {start}-{end} Test')
            # enable some ports
            self.enable_ports_poe_function(start, end)

            # 检测PoE功率
            while True:

                # 重设电流值
                self.poe_set_current(400)
                self.poe_conn_on()
                self.sleep_time(10)
                self.poe_set_current(self.mapping.poe_current)
                self.sleep_time(10)

                out_of_range = self.check_poe_power(start, end)
                if len(out_of_range) != 0:
                    pts = ",".join(out_of_range)
                    msg = (f'Ports: {pts} out of range, retry?\n'
                           f'{pts} PoE功率不在允许范围内，重测？\n'
                           f'{pts} Công suất PoE của các cổng này không nằm trong phạm vi cho phép Retest?')
                    if scanner.yes_or_enter_to_continue(question=msg) is False:
                        raise Exception(f'poe test failed: {out_of_range}')
                    self.poe_conn_off()
                    continue

                # show total power
                self.check_poe_total_power()
                # off poe conn
                self.poe_conn_off()
                break

            # disable
            self.disable_ports_poe_function(start, end)

    def enable_ports_poe_function(self, start, end):
        if start is None or end is None:
            self.uut.send_wise(f'poestatus all enable', self.diag_prompt)
        else:
            self.uut.send_wise(f'poestatus {start}-{end} enable', self.diag_prompt)

    def disable_ports_poe_function(self, start, end):
        if start is None or end is None:
            self.uut.send_wise(f'poestatus all disable', self.diag_prompt)
        else:
            self.uut.send_wise(f'poestatus {start}-{end} disable', self.diag_prompt)

    def check_poe_power(self, start, end):
        """
        该函数检查端口的PoE功率。
        返回不满足要求的端口。
        若测试一切正常返回空数组。
        """
        if start is None or end is None:
            # show all poe power
            self.uut.send_wise(f'poepwshow all', self.diag_prompt)

            pw = re.findall(r'Port\s+(\d+)\s+\d+\.\d+V\s+\d+\.\d+A\s+(\d+\.\d+)W', self.uut.buffer)
            pw = {int(_[0]): float(_[1]) for _ in pw}
            out_of_range = []
            min_power = self.mapping.poe_traffic_min_power
            for idx in range(0, self.mapping.poe_ports):
                power = pw.get(idx)
                if power is None:
                    out_of_range.append(str(idx))
                    log.error(f'Port {idx} power is None!')
                    continue
                if power < min_power:
                    out_of_range.append(str(idx))
                    log.error(f'[Pass Criteria] Port {idx} power is: {power}, expect: >= {min_power}w, result: FAIL')
                    continue
                log.debug(f'[Pass Criteria] Port {idx} power is: {power}, expect: >= {min_power}w, result: PASS')

            return out_of_range

        else:
            self.uut.send_wise(f'poepwshow {start}-{end}', self.diag_prompt)

            pw = re.findall(r'Port\s+(\d+)\s+\d+\.\d+V\s+\d+\.\d+A\s+(\d+\.\d+)W', self.uut.buffer)
            pw = {int(_[0]): float(_[1]) for _ in pw}
            out_of_range = []
            min_power, max_power = self.mapping.poe_power_limit[0], self.mapping.poe_power_limit[1]
            for idx in range(start, end + 1):
                power = pw.get(idx)
                if power is None:
                    out_of_range.append(str(idx))
                    log.error(f'Port {idx} power is None!')
                    continue
                if not (min_power < power < max_power):
                    out_of_range.append(str(idx))
                    log.error(f'[Pass Criteria] Port {idx} power: {power}, expect: {min_power, max_power}, result: FAIL')
                    continue
                log.debug(f'[Pass Criteria] Port {idx} power: {power}, expect: {min_power, max_power}, result: PASS')

            return out_of_range

    def check_poe_power_low(self, start, end, set_power):
        """
        该函数检查端口的PoE功率。
        返回不满足要求的端口。
        若测试一切正常返回空数组。
        """
        if start is None or end is None:
            # show all poe power
            self.uut.send_wise(f'poepwshow all', self.diag_prompt)

            pw = re.findall(r'Port\s+(\d+)\s+\d+\.\d+V\s+\d+\.\d+A\s+(\d+\.\d+)W', self.uut.buffer)
            pw = {int(_[0]): float(_[1]) for _ in pw}
            out_of_range = []
            min_power = set_power
            for idx in range(0, self.mapping.poe_ports):
                power = pw.get(idx)
                if power is None:
                    out_of_range.append(str(idx))
                    log.error(f'Port {idx} power is None!')
                    continue
                if power < min_power:
                    out_of_range.append(str(idx))
                    log.error(f'[Pass Criteria] Port {idx} power is: {power}, expect: >= {min_power}w, result: FAIL')
                    continue
                log.debug(f'[Pass Criteria] Port {idx} power is: {power}, expect: >= {min_power}w, result: PASS')

            return out_of_range

        else:
            self.uut.send_wise(f'poepwshow {start}-{end}', self.diag_prompt)

            pw = re.findall(r'Port\s+(\d+)\s+\d+\.\d+V\s+\d+\.\d+A\s+(\d+\.\d+)W', self.uut.buffer)
            pw = {int(_[0]): float(_[1]) for _ in pw}
            out_of_range = []
            min_power, max_power = self.mapping.poe_power_limit[0], self.mapping.poe_power_limit[1]
            for idx in range(start, end + 1):
                power = pw.get(idx)
                if power is None:
                    out_of_range.append(str(idx))
                    log.error(f'Port {idx} power is None!')
                    continue
                if not (min_power < power < max_power):
                    out_of_range.append(str(idx))
                    log.error(f'[Pass Criteria] Port {idx} power: {power}, expect: {min_power, max_power}, result: FAIL')
                    continue
                log.debug(f'[Pass Criteria] Port {idx} power: {power}, expect: {min_power, max_power}, result: PASS')

            return out_of_range

    def check_poe_power_60w(self, start, end, set_power):
        self.uut.send_wise(f'poepwshow all', self.diag_prompt)

        pw = re.findall(r'Port\s+(\d+)\s+\d+\.\d+V\s+\d+\.\d+A\s+(\d+\.\d+)W', self.uut.buffer)
        pw = {int(_[0]): float(_[1]) for _ in pw}
        out_of_range = []
        min_power, max_power = self.mapping.poe_power_limit[0], self.mapping.poe_power_limit[1]
        for idx in range(0, self.mapping.poe_ports):
            power = pw.get(idx)
            if power is None:
                out_of_range.append(str(idx))
                log.error(f'Port {idx} power is None!')
                continue
            if idx in range(start, end+1):
                if not (min_power < power < max_power):
                    out_of_range.append(str(idx))
                    log.error(f'[Pass Criteria] Port {idx} power: {power}, expect: {min_power, max_power}, result: FAIL')
                    continue
                log.debug(f'[Pass Criteria] Port {idx} power: {power}, expect: {min_power, max_power}, result: PASS')
            else:
                if power < set_power:
                    out_of_range.append(str(idx))
                    log.error(f'[Pass Criteria] Port {idx} power is: {power}, expect: >= {set_power}w, result: FAIL')
                    continue
                log.debug(f'[Pass Criteria] Port {idx} power is: {power}, expect: >= {set_power}w, result: PASS')

        return out_of_range

    def check_poe_power_1w(self, start, end, set_power):
        self.uut.send_wise(f'poepwshow all', self.diag_prompt)

        pw = re.findall(r'Port\s+(\d+)\s+\d+\.\d+V\s+\d+\.\d+A\s+(\d+\.\d+)W', self.uut.buffer)
        pw = {int(_[0]): float(_[1]) for _ in pw}
        out_of_range = []
        min_power, max_power = 0, 2
        for idx in range(0, self.mapping.poe_ports):
            power = pw.get(idx)
            if power is None:
                out_of_range.append(str(idx))
                log.error(f'Port {idx} power is None!')
                continue
            if idx in range(start, end+1):
                if not (min_power < power < max_power):
                    out_of_range.append(str(idx))
                    log.error(f'[Pass Criteria] Port {idx} power: {power}, expect: {min_power, max_power}, result: FAIL')
                    continue
                log.debug(f'[Pass Criteria] Port {idx} power: {power}, expect: {min_power, max_power}, result: PASS')
            else:
                if power < set_power:
                    out_of_range.append(str(idx))
                    log.error(f'[Pass Criteria] Port {idx} power is: {power}, expect: >= {set_power}w, result: FAIL')
                    continue
                log.debug(f'[Pass Criteria] Port {idx} power is: {power}, expect: >= {set_power}w, result: PASS')

        return out_of_range

    def check_poe_total_power(self):
        self.uut.send_wise('poetotalpwshow', self.diag_prompt)
        # Total Power:  237.4W
        power = re.search('Total Power:\s+(\d+\.\d+)W', self.uut.buffer)
        if power is None:
            raise Exception('not found total poe power!')
        log.debug(f'total PoE power: {power.group(1)}w')
        power = float(power.group(1))
        if power == 0:
            raise Exception('total power is 0W')
        log.debug(f'[Pass Criteria] total PoE power: {power}w, expect: > 0w, result: PASS')

    def set_poe_four_pair(self):
        if self.mapping.group in {df.GROUP_2, df.GROUP_3}:
            log.debug(f'{self.mapping.platform} is Group: {self.mapping.group}, NO need to enabled PoE manually!')
            return

        log.debug(f'{self.mapping.platform} is Group: {self.mapping.group}, need to enabled PoE manually!')
        for i in range(5):
            self.uut.send_wise(f'pohfourpair all bt3', self.diag_prompt)
            if re.search('error|fail', self.uut.buffer, re.I):
                log.error('enable poe function failed! found error or fail, retry!')
                time.sleep(3)
                continue
            break
        else:
            raise Exception('enable poe function failed!')

    def poe_traffic_test(self):
        if not self.mapping.poe_function:
            log.debug(f'{self.mapping.platform} has no PoE function! SKIP...')
            return helper.SKIP
        log.debug(f'{self.mapping.platform} need to test PoE function!')
        # do PoE and traffic test
        # self.do_poe_traffic_test()
        model = self.mapping.platform
        # container = helper.container_number
        # if container in ["01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14"]:
        #     if "48" in model:
        #         return self.poe_test_cell_1_48port()
        #     else:
        #         return self.poe_test_cell_1_non48port()
        if "48" in model:
            return self.poe_test_cell_1_48port()
        else:
            return self.poe_test_cell_1_non48port()
        # if container == "02":
        #     if "48" in model:
        #         return self.poe_test_cell_2_48port()
        #     else:
        #         return self.poe_test_cell_2_non48port()
        # if container == "03":
        #     if "48" in model:
        #         return self.poe_test_cell_3_48port()
        #     else:
        #         return self.poe_test_cell_3_non48port()
        # if container == "04":
        #     if "48" in model:
        #         return self.poe_test_cell_4_48port()
        #     else:
        #         return self.poe_test_cell_4_non48port()
        # if container == "05":
        #     if "48" in model:
        #         return self.poe_test_cell_5_48port()
        #     else:
        #         return self.poe_test_cell_5_non48port()
        # if container == "06":
        #     if "48" in model:
        #         return self.poe_test_cell_6_48port()
        #     else:
        #         return self.poe_test_cell_6_non48port()
        #
        # if container == "17":
        #     if "48" in model:
        #         return self.poe_test_cell_17_48port()
        #     else:
        #         return self.poe_test_cell_17_non48port()
        # if container == "18":
        #     if "48" in model:
        #         return self.poe_test_cell_18_48port()
        #     else:
        #         return self.poe_test_cell_18_non48port()
        # if container == "19":
        #     if "48" in model:
        #         return self.poe_test_cell_19_48port()
        #     else:
        #         return self.poe_test_cell_19_non48port()
        # if container == "20":
        #     if "48" in model:
        #         return self.poe_test_cell_20_48port()
        #     else:
        #         return self.poe_test_cell_20_non48port()
        # if container == "21":
        #     if "48" in model:
        #         return self.poe_test_cell_21_48port()
        #     else:
        #         return self.poe_test_cell_21_non48port()
        # if container == "22":
        #     if "48" in model:
        #         return self.poe_test_cell_22_48port()
        #     else:
        #         return self.poe_test_cell_22_non48port()

    @helper.fifo_locking(name='cell1-2-48-24', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell1-2-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_1_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell1-2-24-48', wait_timeout=48 * 3600)
    def poe_test_cell_1_non48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell1-2-24-48', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell1-2-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_2_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell1-2-48-24', wait_timeout=48 * 3600)
    def poe_test_cell_2_non48port(self):
        return self.do_poe_traffic_test()


    @helper.fifo_locking(name='cell3-4-48-24', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell3-4-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_3_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell3-4-24-48', wait_timeout=48 * 3600)
    def poe_test_cell_3_non48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell3-4-24-48', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell3-4-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_4_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell3-4-48-24', wait_timeout=48 * 3600)
    def poe_test_cell_4_non48port(self):
        return self.do_poe_traffic_test()


    @helper.fifo_locking(name='cell5-6-48-24', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell5-6-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_5_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell5-6-24-48', wait_timeout=48 * 3600)
    def poe_test_cell_5_non48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell5-6-24-48', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell5-6-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_6_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell5-6-48-24', wait_timeout=48 * 3600)
    def poe_test_cell_6_non48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell17-18-48-24', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell17-18-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_17_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell17-18-24-48', wait_timeout=48 * 3600)
    def poe_test_cell_17_non48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell17-18-24-48', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell17-18-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_18_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell17-18-48-24', wait_timeout=48 * 3600)
    def poe_test_cell_18_non48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell19-20-48-24', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell19-20-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_19_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell19-20-24-48', wait_timeout=48 * 3600)
    def poe_test_cell_19_non48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell19-20-24-48', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell19-20-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_20_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell19-20-48-24', wait_timeout=48 * 3600)
    def poe_test_cell_20_non48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell21-22-48-24', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell21-22-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_21_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell21-22-24-48', wait_timeout=48 * 3600)
    def poe_test_cell_21_non48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell21-22-24-48', wait_timeout=48 * 3600)
    @helper.fifo_locking(name='cell21-22-48-48', wait_timeout=48 * 3600)
    def poe_test_cell_22_48port(self):
        return self.do_poe_traffic_test()

    @helper.fifo_locking(name='cell21-22-48-24', wait_timeout=48 * 3600)
    def poe_test_cell_22_non48port(self):
        return self.do_poe_traffic_test()

    def do_poe_traffic_test(self):
        server = helper.config.get('server')
        container = helper.container_number
        model = self.mapping.platform
        poe_config = helper.config.get('poe_config')
        if "48" in model:
            poe_cable1 = poe_config[server]["48"][container][0][1].split(" ")[-1]
            poe_cable2 = poe_config[server]["48"][container][1][1].split(" ")[-1]
            question = (f"Please connect all PoE({poe_cable1}&{poe_cable2}) ports and SFPs! 请连接所有的PoE、SFP端口！"
                        f"'\nVui lòng kết nối tất cả các cổng PoE({poe_cable1}&{poe_cable2}) và SFPs!")
        else:
            poe_cable1 = poe_config[server]["non48"][container][1].split(" ")[-1]
            question = (f"Please connect all PoE({poe_cable1}) ports and SFPs! 请连接所有的PoE、SFP端口！"
                        f"\nVui lòng kết nối tất cả các cổng PoE({poe_cable1}) và SFPs!")
        image = 'Edradour/images/poe-traffic.png'
        if scanner.yes_or_enter_to_continue(question=question, image=image) is False:
            raise Exception(f'operator stop poe traffic testing')

        # connect poe
        self.poe_do_connect()
        self.setup_poe_tester()

        # PoE test at first
        # disable all ports
        self.disable_ports_poe_function(None, None)
        # enable poe four pair
        self.set_poe_four_pair()

        if self.area == "POE_STEP_7":
            try:
                self.enable_ports_poe_function(None, None)
                self.poe_set_current((self.mapping.poe_traffic_current - 200, 1))
                self.poe_conn_on()
                self.sleep_time(30)
                self.poe_set_current((self.mapping.poe_traffic_current, 1))
                self.poe_conn_on()
                self.get_snr_value()
                while True:
                    out_of_range = []

                    for _ in range(3):
                        self.sleep_time(20)
                        out_of_range = self.check_poe_power(None, None)
                        if len(out_of_range) == 0:
                            break
                    else:
                        if scanner.yes_or_enter_to_continue(
                                f'PoE power out of limit! > {", ".join(out_of_range)}') is False:
                            raise Exception('some PoE ports out of limit!')
                        continue

                    break

                self.traffic_test_with_poe()
                self.check_poe_total_power()
            except Exception:
                raise
            finally:
                try:
                    # off conn
                    self.poe_conn_off()
                except Exception as e:
                    log.error(f'off poe conn failed! {e}')

                self.poe_do_disconnect()
        else:
            try:
                self._poe_test_new()

                # helper.quick_set('Check All PoE Power')
                self.enable_ports_poe_function(None, None)
                self.poe_set_current((self.mapping.poe_traffic_current-200, 1))
                self.poe_conn_on()
                self.sleep_time(30)
                self.poe_set_current((self.mapping.poe_traffic_current, 1))
                self.poe_conn_on()
                self.check_all_ports_status()
                self.get_snr_value()
                while True:
                    out_of_range = []

                    for _ in range(3):
                        self.sleep_time(20)
                        out_of_range = self.check_poe_power(None, None)
                        if len(out_of_range) == 0:
                            break
                    else:
                        if scanner.yes_or_enter_to_continue(
                                f'PoE power out of limit! > {", ".join(out_of_range)}') is False:
                            raise Exception('some PoE ports out of limit!')
                        continue

                    break

                self.check_poe_total_power()

                self.quick_set('Traffic Test with PoE')
                # # Traffic Test
                if self.mapping.group == "G1":
                    self.traffic_test_bg(seconds=300)
                    self.traffic_test_with_poe()
                else:
                    self.traffic_test(pop=False, seconds=300, min_pkg=100_000, get_sngr=True)
                self.check_poe_total_power()
            except Exception:
                raise
            finally:
                try:
                    # off conn
                    self.poe_conn_off()
                except Exception as e:
                    log.error(f'off poe conn failed! {e}')

                self.poe_do_disconnect()

    def traffic_test_with_poe(self):
        if self.mapping.platform in ["EX4000-48MP", "EX4000-48P"]:
            test_group = 12
        elif self.mapping.platform in ["EX4000-24MP", "EX4000-24P"]:
            test_group = 6
        elif self.mapping.platform in ["EX4000-12MP", "EX4000-12P"]:
            # todo plan 1
            test_group = 6
            # test_group = 3
        else:
            test_group = 2

        self.check_all_ports_status()

        helper.quick_set("POE power changes dur linespeed")
        self.uut.send_wise(f'linespeed extp all 5a 1518 10 900 mfg bg', self.diag_prompt, 600)
        # start_time = time.time()

        self.poe_power_change(test_group)

        # during_time = time.time() - start_time
        # if during_time < 900:
        #     self.sleep_time(900 - during_time)
        self.stop_traffic_test_and_check(self.mapping.traffic_port_num, 1_000_000)

    def poe_power_change(self, test_group):
        change_60w_current = self.mapping.poe_current
        change_1w_current = 21
        poe_traffic_current = (self.mapping.poe_traffic_current, 1)
        set_power = self.mapping.poe_traffic_min_power
        if self.mapping.platform in ["EX4000-48MP", "EX4000-24MP", "EX4000-12MP"]:
            change_60w_current = 1105
            change_1w_current = 21
            if self.mapping.platform in ["EX4000-24MP", "EX4000-12MP"]:
                change_60w_current = 1105
                self.poe_set_current(210)
                set_power = 10
                poe_traffic_current = 210
            # if self.mapping.platform in ["EX4000-12MP"]:
            #     self.poe_set_current(40)
            #     change_60w_current = 1040
            #     set_power = 1.8
            #     poe_traffic_current = 40
            #     self.mapping.poe_power_limit = (54, 56)
        if self.mapping.platform in ["EX4000-48P", "EX4000-24P", "EX4000-12P"]:
            change_1w_current = 42
        for group in range(test_group):
            start = group * 4
            end = start + 3
            if self.mapping.platform in ["EX4000-12MP"]:
                start = group * 2
                end = start + 1
            poe_port_start = start + 1
            poe_port_end = end + 1
            helper.quick_set(f"Group {group+1}/{test_group} (Port {start}-{end}) Testing")
            log.debug(f"=====Group {group+1} (Port {start}-{end}) Change PoE power rating during traffic test=====")
            for cycle in range(6):
                # 检测PoE功率 60w
                while True:
                    # 重设电流值
                    # self.poe_set_port_current(poe_port_start, poe_port_end, 400)
                    # self.sleep_time(2)
                    self.poe_set_port_current(poe_port_start, poe_port_end, change_60w_current)
                    self.sleep_time(3)

                    out_of_range = self.check_poe_power_60w(start, end, set_power=set_power)
                    if len(out_of_range) != 0:
                        pts = ",".join(out_of_range)
                        msg = (f'Ports: {pts} out of range, retry?\n'
                               f'{pts} PoE功率不在允许范围内，重测？\n'
                               f'{pts} Công suất PoE của các cổng này không nằm trong phạm vi cho phép Retest?')
                        if scanner.yes_or_enter_to_continue(question=msg) is False:
                            raise Exception(f'poe test failed: {out_of_range}')
                        continue
                    break

                # 检测PoE功率 1w
                while True:
                    # 重设电流值
                    self.poe_set_port_current(poe_port_start, poe_port_end, change_1w_current)
                    self.sleep_time(3)

                    out_of_range = self.check_poe_power_1w(start, end, set_power=set_power)
                    if len(out_of_range) != 0:
                        pts = ",".join(out_of_range)
                        msg = (f'Ports: {pts} out of range, retry?\n'
                               f'{pts} PoE功率不在允许范围内，重测？\n'
                               f'{pts} Công suất PoE của các cổng này không nằm trong phạm vi cho phép Retest?')
                        if scanner.yes_or_enter_to_continue(question=msg) is False:
                            raise Exception(f'poe test failed: {out_of_range}')
                        continue
                    break

                if cycle == 2:
                    self.get_snr_value()

            # 检测PoE功率 15w
            while True:
                # 重设电流值
                self.poe_set_port_current(poe_port_start, poe_port_end, poe_traffic_current)
                self.sleep_time(3)

                out_of_range = self.check_poe_power_low(None, None, set_power=set_power)
                if len(out_of_range) != 0:
                    pts = ",".join(out_of_range)
                    msg = (f'Ports: {pts} out of range, retry?\n'
                           f'{pts} PoE功率不在允许范围内，重测？\n'
                           f'{pts} Công suất PoE của các cổng này không nằm trong phạm vi cho phép Retest?')
                    if scanner.yes_or_enter_to_continue(question=msg) is False:
                        raise Exception(f'poe test failed: {out_of_range}')
                    continue
                break

    def poe_set_port_current(self, start, end, current):
        if end <= 24:
            self.poe_group[0].set_port_current(start, end, current)
        else:
            self.poe_group[1].set_port_current(start-24, end-24, current)

    def stop_traffic_test_and_check(self, port_num, min_pkg):
        helper.quick_set("check linespeed result")
        self.uut.send_wise("linespeed stop", self.diag_prompt, 600)
        # ports = re.findall(r'Port(\d+)\s+.+ speed test \(P\1\.TX:(\d+) P\d+\.RX:(\d+) @ \d+\.\d+\w bps \) (\S+)',
        #                    self.uut.buffer)

        ports = re.findall(r'Port(\d+)\s+\d+(?:\.\d+)?[GM] speed test \(P\1\.TX:(\d+) P\d+\.RX:(\d+)\) (\w+)',
                           self.uut.buffer)

        # ('51', '265951010', '265951010', 'PASS')
        # ('52', '10', '0', 'FAILED')
        failed = []
        for p in ports:
            num, tx, rx, result = p
            tx, rx = int(tx), int(rx)
            if result != 'PASS':
                log.error(f'Port: {num} status is not PASS!')
                failed.append(num)
                continue
            if tx < min_pkg or rx < min_pkg:
                failed.append(num)
                log.error(f'Port: {num} TX or RX less than {min_pkg}, failed!')
                continue
            if tx != rx:
                failed.append(num)
                log.error(f'Port: {num} Tx: {tx}, Rx: {rx} not equal!')
                continue

            log.debug(f'[Pass Criteria] Port: {num} traffic test TX: {tx}, RX: {rx}, expect: TX&RX > {min_pkg} and TX=RX, result: PASS')

        # 52, 53, 54, 55 有问题的话就不再重试了
        if '52' in failed or '53' in failed or '54' in failed or '55' in failed:
            raise Exception('52 or 53 or 54 or 55 port failed! Please call RD or RE for help!')

        if len(failed) != 0:
            fps = ','.join(failed)
            msg = f'These ports are failed: {fps}. \n这些端口Traffic failed: {fps}。\nCác cổng này bị lỗi: {fps}'
            # if scanner.yes_or_enter_to_continue(question=msg) is False:
            helper.quick_set(f'linespeed failed: {fps} are down')
            raise Exception(f'traffic test failed: {fps} are down!')
            # continue
        # 确保查找到的端口数量符合预期
        if len(ports) != port_num:
            raise Exception(f'port num mismatch, expected: {port_num}, captured: {len(ports)}')

        if 'PASSED' not in self.uut.buffer:
            msg = ('Not found PASSED in buffer, retry?\n'
                   '没有发现PASSED标记，重测？\n'
                   'không tìm thấy ĐẠT trong bộ đệm, hãy thử lại')
            # if scanner.yes_or_enter_to_continue(question=msg) is False:
            helper.quick_set("not found linespeed PASSED")
            raise Exception('not found PASSED in buffer!')

        self.check_port_speeds(log_text=self.uut.buffer)

    def check_port_speeds(self, log_text):
        # 定义速率标准
        product_type = self.mapping.platform
        speed_requirements = {
            "EX4000-48MP": [(0, 7, "2.5G"), (8, 47, "1G")],
            "EX4000-12MP": [(0, 3, "2.5G"), (4, 11, "1G")],
            "EX4000-24MP": [(0, 3, "2.5G"), (4, 23, "1G")],
        }

        if product_type not in speed_requirements:
            return

        # 解析日志中的端口速率
        port_pattern = re.compile(r"Port(\d+)\s+([\d\.]+G|[\d\.]+M)\s+speed\s+test")
        ports = {int(m.group(1)): m.group(2) for m in port_pattern.finditer(log_text)}

        log.debug(f"=== Speed Verification Results for {product_type} ===")
        failed_ports = []

        # Validate each port
        for (start, end, expected_speed) in speed_requirements[product_type]:
            for port in range(start, end + 1):
                actual_speed = ports.get(port)
                if helper.normalize_speed(actual_speed) != helper.normalize_speed(expected_speed):
                    log.error(f"Port{port:02d}: Wrong speed {actual_speed or 'N/A'} (expected {expected_speed}), FAIL")
                    failed_ports.append((port, actual_speed, expected_speed))
                else:
                    log.debug(f"Port{port:02d}: Correct ({actual_speed}), PASS")

        # --- Summary Section ---
        if not failed_ports:
            log.debug("All ports meet the expected speed requirements!")
        else:
            log.error(f"{len(failed_ports)} port(s) failed:")
            helper.quick_set("check port speed fail")
            raise Exception(f"{len(failed_ports)} port(s) check speed failed:")

    def check_port_status(self, log_text, speed):
        """
        Check port speed compliance from 'Port all status' output.
        Only prints ports that do not meet the expected speed.
        """
        product_type = self.mapping.platform
        # Expected speed rules by product type
        speed_requirements = {
            "EX4000-48MP": [(0, 7, "2.5G"), (8, 47, "1G")],
            "EX4000-12MP": [(0, 3, "2.5G"), (4, 11, "1G")],
            "EX4000-24MP": [(0, 3, "2.5G"), (4, 23, "1G")],
        }
        if speed == "low":
            speed_requirements = {
                "EX4000-48MP": [(0, 7, "1G"), (8, 47, "100M")],
                "EX4000-12MP": [(0, 3, "1G"), (4, 11, "100M")],
                "EX4000-24MP": [(0, 3, "1G"), (4, 23, "100M")],
            }

        if product_type not in speed_requirements:
            return

        # Regex pattern to capture: P#, speed (like 1G, 2.5G, 100M, 10G, 20G)
        port_pattern = re.compile(r"P(\d+)\s+\S+\s+\S+\s+([\d\.]+[GM])")

        # Extract all ports and their speeds
        ports = {int(m.group(1)): m.group(2) for m in port_pattern.finditer(log_text)}

        # Check against expected ranges
        failed_ports = []

        for (start, end, expected_speed) in speed_requirements[product_type]:
            for port in range(start, end + 1):
                actual_speed = ports.get(port)
                if actual_speed != expected_speed:
                    failed_ports.append(f"Port{port:02d} (got {actual_speed or 'N/A'}, expected {expected_speed})")
                    log.error(f"Port{port:02d} (got {actual_speed or 'N/A'}, expected {expected_speed})")
                else:
                    log.debug(f"Port{port:02d}: Correct ({actual_speed}), PASS")

        # --- Print Summary ---
        if not failed_ports:
            log.debug("All ports meet the expected speed requirements!")
        else:
            log.error(f"{len(failed_ports)} port(s) failed:")
            helper.quick_set("check port speed fail")
            raise Exception(f"{len(failed_ports)} port(s) check speed failed:")

    def setup_poe_tester(self):
        for conn in self.poe_group:
            conn.reset()
            time.sleep(0.5)
            conn.conn_off()
            time.sleep(0.5)
            conn.set_current(100)
            time.sleep(0.5)
            conn.single_on()
            time.sleep(0.5)
            conn.klass(self.mapping.poe_class)
            time.sleep(0.5)
            conn.det_ok()

    def eth_led_test(self):
        # ETH all green
        self.uut.send_wise('ethledwrite all left sgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sgr', self.diag_prompt)
        if scanner.yes_or_enter_to_continue(
                question='Are all eth LED ON ?\n所有Eth的灯都亮了吗？'
                         '\nTất cả đèn Eth đã sáng chưa?',
                image='Edradour/images/led-eth-all-on.png'
        ) is False:
            raise Exception('not all eth led are on!')

        # 随机灭1-6个灯, 做2次，两次灭的灯必须不一样, 不同port最大off不同
        if '8' in self.mapping.platform:
            off_led_min = 1
            off_led_max = 5

            on_led_min = 2
            on_led_max = 7
        elif '12' in self.mapping.platform:
            off_led_min = 2
            off_led_max = 6

            on_led_min = 3
            on_led_max = 8
        elif '24' in self.mapping.platform:
            off_led_min = 3
            off_led_max = 7

            on_led_min = 4
            on_led_max = 9
        else:
            off_led_min = 4
            off_led_max = 8

            on_led_min = 5
            on_led_max = 10

        # self.check_green_off(off_led_min=off_led_min, off_led_max=off_led_max)
        #
        # self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        # self.uut.send_wise('ethledwrite all right off', self.diag_prompt)
        #
        # self.check_green_on(on_led_min=on_led_min, on_led_max=on_led_max)
        self.check_green_on_off()

        # ETH all green blinking
        self.uut.send_wise('ethledwrite all left bgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right bgr', self.diag_prompt)
        if scanner.yes_or_enter_to_continue(
                question='Are all eth LED blinking ?\n所有Eth的灯都在闪烁吗？'
                         '\nTất cả đèn Eth có đang nhấp nháy không?',
                image='Edradour/images/led-eth-all-on.png'
        ) is False:
            raise Exception('not all eth led are on!')

        self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right off', self.diag_prompt)

        if self.mapping.eth_amber is True:
            log.debug(f'This SKU: {self.mapping.platform} need to test amber ETH LED.')
            # Amber
            if '48' in self.mapping.platform:
                img = 'Edradour/images/led-amber.png'
            else:
                img = 'Edradour/images/led-amber-12-24.png'
            self.uut.send_wise('ethledwrite all right sab', self.diag_prompt)
            if scanner.yes_or_enter_to_continue(
                    question='Are ETH LED on Amber? 有琥珀色的LED灯亮了？\nCó đèn LED màu hổ phách sáng lên không?',
                    image=img,
            ) is False:
                raise Exception('ETH AMBER LED test failed!')

            self.check_amber_off(off_led_max=off_led_max)

            # Amber blinking
            self.uut.send_wise('ethledwrite all right bab', self.diag_prompt)
            if scanner.yes_or_enter_to_continue(
                    question='Are ETH LED on Amber blinking? 有琥珀色的LED灯在闪烁吗？'
                             '\nCó đèn LED màu hổ phách đang nhấp nháy không?',
                    image='Edradour/images/led-amber.png',
            ) is False:
                raise Exception('ETH AMBER LED blinking test failed!')

            # 全部关闭
            self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
            self.uut.send_wise('ethledwrite all right off', self.diag_prompt)

        log.debug(f'This SKU: {self.mapping.platform} NO need to test amber ETH LED. SKIP...')

        # 全部恢复默认状态
        self.uut.send_wise('ethledwrite all left dis', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right dis', self.diag_prompt)

        self.check_mgmt_led()

        # 这一项包含了MGMT的端口LED
        if scanner.yes_or_enter_to_continue(
                question='Are all eth LED OFF (include MGMT port)?\n所有Eth的灯（包含MGMT端口）都灭了吗？'
                         '\nTất cả đèn Eth (bao gồm cả cổng MGMT) đã tắt hết chưa?',
                image='Edradour/images/led-eth-all-off.png'
        ) is False:
            raise Exception('not all eth led are off!')

        # 全部恢复默认状态
        self.uut.send_wise('ethledwrite all left dis', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right dis', self.diag_prompt)

    def check_mgmt_led(self):
        # config network
        self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.uut_ip} netmask {self.mapping.netmask} up',
                           self.diag_prompt)
        self.sleep_time(5)
        self.uut.send_wise('', self.diag_prompt)
        self.uut.send_wise('syscall ifconfig eth0 down', self.diag_prompt)
        self.sleep_time(3)
        self.uut.send_wise('syscall ifconfig eth0 up', self.diag_prompt)
        self.sleep_time(10)
        # if ('24' in self.mapping.platform) or ('48' in self.mapping.platform):
        #     img = "mgmt_led_24_48.png"
        # else:
        #     img = "mgmt_led_8_12.png"
        while True:
            self.sleep_time(5)
            self.uut.send_wise('syscall ping -c 3 10.1.1.1', self.diag_prompt)
            if "3 packets received" in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(
                        question='Please unplug net cable. \n Vui lòng rút cáp mạng.',
                        image='Edradour/images/unplug_net_cable.png'
                ) is False:
                    raise Exception('Stop Test')
            else:
                break

        status_list = [
            [f"ethledwrite {self.mapping.mgmt_port} left sgr", f"ethledwrite {self.mapping.mgmt_port} right off"],
            [f"ethledwrite {self.mapping.mgmt_port} left off", f"ethledwrite {self.mapping.mgmt_port} right sgr"],
            [f"ethledwrite {self.mapping.mgmt_port} left sgr", f"ethledwrite {self.mapping.mgmt_port} right sgr"],
            [f"ethledwrite {self.mapping.mgmt_port} left off", f"ethledwrite {self.mapping.mgmt_port} right off"],
        ]
        command_step = random.sample(list(range(4)), 4)

        language = [['1st', 'lần đầu'], ['2nd', 'Lần thứ hai'], ['3rd', 'Lần thứ ba'], ['4th', 'lần thứ tư']]

        for index, s in enumerate(command_step):
            cm = status_list[s]
            right_ans = None
            if s == 0:
                right_ans = 'Status 3'
            if s == 1:
                right_ans = 'Status 4'
            if s == 2:
                right_ans = 'Status 2'
            if s == 3:
                right_ans = 'Status 1'
            for c in cm:
                self.uut.send_wise(c, self.diag_prompt)
            scanner.get_right_answer(
                question=f'({language[index][0]})Please select MGMT LED status. \n'
                         f'({language[index][1]})Vui lòng chọn trạng thái đèn LED MGMT. ',
                answers=['Status 1', 'Status 2', 'Status 3', 'Status 4'],
                retry=2,
                right_answer=str(right_ans),
                image=f'Edradour/images/led_mgmt.png'
            )

        self.uut.send_wise(f"ethledwrite {self.mapping.mgmt_port} left off", self.diag_prompt)
        self.uut.send_wise(f"ethledwrite {self.mapping.mgmt_port} right off", self.diag_prompt)
        self.uut.send_wise(f"ethledwrite {self.mapping.mgmt_port} left bgr", self.diag_prompt)
        scanner.get_right_answer(
            question=f'Please check MGMT left LED is blinking. \n'
                     f'Vui lòng kiểm tra đèn LED bên trái của MGMT đang nhấp nháy. ',
            answers=['Đèn nháy(Blinking)', 'tắt(Off)', 'Luôn luôn bật(Constantly ON)'],
            retry=2,
            right_answer='Đèn nháy(Blinking)',
            image=f'Edradour/images/mgmt_blink.png'
        )

        self.uut.send_wise(f"ethledwrite {self.mapping.mgmt_port} left off", self.diag_prompt)
        self.uut.send_wise(f"ethledwrite {self.mapping.mgmt_port} right off", self.diag_prompt)

    def check_green_off(self, off_led_min, off_led_max):
        # 1st
        rdn_ports = random.sample(self.mapping.led_port_seq, random.randint(off_led_min, off_led_max))
        log.debug(f'turn off led: {rdn_ports}, total:{len(rdn_ports)}')
        for p in rdn_ports:
            side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} {side} off', self.diag_prompt)

        scanner.get_right_answer(
            question='(1st)As shown in the picture, how many lights are off in the following ?\n'
                     '(lần đầu)Như hình minh họa, có bao nhiêu đèn tắt?',
            answers=[str(_) for _ in range(10)],
            retry=3,
            right_answer=str(len(rdn_ports)),
            image='Edradour/images/check_led_off_count.png'
        )
        # 2nd
        self.uut.send_wise('ethledwrite all left sgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sgr', self.diag_prompt)
        led_ports = list(filter(lambda x: x not in rdn_ports, self.mapping.led_port_seq))
        rdn_ports_2 = random.sample(led_ports, random.randint(off_led_min, off_led_max))
        log.debug(f'turn off led: {rdn_ports_2}, total:{len(rdn_ports_2)}')
        for p in rdn_ports_2:
            side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} {side} off', self.diag_prompt)

        scanner.get_right_answer(
            question='(2nd)As shown in the picture, how many lights are off in the following ?\n'
                     '(Lần thứ hai)Như hình minh họa, có bao nhiêu đèn tắt ?',
            answers=[str(_) for _ in range(10)],
            retry=3,
            right_answer=str(len(rdn_ports_2)),
            image='Edradour/images/check_led_off_count.png'
        )
        # 3nd
        self.uut.send_wise('ethledwrite all left sgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sgr', self.diag_prompt)
        led_ports = list(filter(lambda x: x not in [rdn_ports_2+rdn_ports], self.mapping.led_port_seq))
        rdn_ports_3 = random.sample(led_ports, random.randint(off_led_min, off_led_max))
        log.debug(f'turn off led: {rdn_ports_3}, total:{len(rdn_ports_3)}')
        for p in rdn_ports_3:
            side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} {side} off', self.diag_prompt)

        scanner.get_right_answer(
            question='(3rd)As shown in the picture, how many lights are off in the following ?\n'
                     '(Lần thứ ba)Như hình minh họa, có bao nhiêu đèn tắt ?',
            answers=[str(_) for _ in range(10)],
            retry=3,
            right_answer=str(len(rdn_ports_3)),
            image='Edradour/images/check_led_off_count.png'
        )

    def check_green_on(self, on_led_min, on_led_max):
        # 1st
        rdn_ports = random.sample(self.mapping.led_port_seq, random.randint(on_led_min, on_led_max))
        log.debug(f'turn on led: {rdn_ports}, total:{len(rdn_ports)}')
        for p in rdn_ports:
            side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} {side} sgr', self.diag_prompt)

        scanner.get_right_answer(
            question='(1st)As shown in the picture, how many lights are on in the following ?\n'
                     '(lần đầu)Như hình minh họa, có bao nhiêu đèn sáng?',
            answers=[str(_) for _ in range(12)],
            retry=3,
            right_answer=str(len(rdn_ports)),
            image='Edradour/images/check_led_off_count.png'
        )
        # 2nd
        self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right off', self.diag_prompt)
        led_ports = list(filter(lambda x: x not in rdn_ports, self.mapping.led_port_seq))
        rdn_ports_2 = random.sample(led_ports, random.randint(on_led_min, on_led_max))
        log.debug(f'turn on led: {rdn_ports_2}, total:{len(rdn_ports_2)}')
        for p in rdn_ports_2:
            side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} {side} sgr', self.diag_prompt)

        scanner.get_right_answer(
            question='(2nd)As shown in the picture, how many lights are on in the following ?\n'
                     '(Lần thứ hai)Như hình minh họa, có bao nhiêu đèn sáng ?',
            answers=[str(_) for _ in range(12)],
            retry=3,
            right_answer=str(len(rdn_ports_2)),
            image='Edradour/images/check_led_off_count.png'
        )
        # # 3nd
        # self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        # self.uut.send_wise('ethledwrite all right off', self.diag_prompt)
        # led_ports = list(filter(lambda x: x not in [rdn_ports+led_ports], self.mapping.led_port_seq))
        # rdn_ports_3 = random.sample(led_ports, random.randint(1, off_led_max))
        # log.debug(f'turn on led: {rdn_ports_3}, total:{len(rdn_ports_3)}')
        # for p in rdn_ports_3:
        #     side = random.choice(['right', 'left'])
        #     self.uut.send_wise(f'ethledwrite {p} {side} sgr', self.diag_prompt)
        #
        # scanner.get_right_answer(
        #     question='(Second time)As shown in the picture, how many lights are on in the following ?\n'
        #              '(Lần thứ hai)Như hình minh họa, có bao nhiêu đèn tắt ?',
        #     answers=[str(_) for _ in range(6)],
        #     retry=3,
        #     right_answer=str(len(rdn_ports_3)),
        #     image='Edradour/images/check_led_off_count.png'
        # )

    def check_green_on_off(self):
        model = re.search(r"-(\d+)", self.mapping.platform).group(1)
        log.debug(f"==== Check {self.mapping.platform} LED OFF ====")
        plans = self.random_off_sequences(model)
        for i, s in enumerate(plans, 1):
            by_mod = defaultdict(list)
            for led in sorted(s):
                for m, leds in PRODUCT_CONFIG[model]["modules"].items():
                    if led in leds:
                        by_mod[m].append(led)
                        break
            log.debug(f"Round {i}  (count={len(s)}): {sorted(s)}")
            log.debug(f"by module: {dict(by_mod)}", )
            self.uut.send_wise('ethledwrite all left sgr', self.diag_prompt)
            self.uut.send_wise('ethledwrite all right sgr', self.diag_prompt)
            for p in s:
                side = random.choice(['right', 'left'])
                self.uut.send_wise(f'ethledwrite {p} {side} off', self.diag_prompt)

            scanner.get_right_answer(
                question=f'(Round {i})As shown in the picture, how many lights are off in the following ?\n'
                         f'(lần {i})Như hình minh họa, có bao nhiêu đèn tắt?',
                answers=[str(_) for _ in range(10)],
                retry=3,
                right_answer=str(len(s)),
                image='Edradour/images/check_led_off_count.png'
            )
        log.debug(f"===============================================")

        # log.debug(f"==== Check {self.mapping.platform} LED ON ====")
        # plans = self.random_off_sequences(model)
        # for i, s in enumerate(plans, 1):
        #     by_mod = defaultdict(list)
        #     for led in sorted(s):
        #         for m, leds in PRODUCT_CONFIG[model]["modules"].items():
        #             if led in leds:
        #                 by_mod[m].append(led)
        #                 break
        #     log.debug(f"Round {i}  (count={len(s)}): {sorted(s)}")
        #     log.debug(f"by module: {dict(by_mod)}", )
        #     self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        #     self.uut.send_wise('ethledwrite all right off', self.diag_prompt)
        #     for p in s:
        #         side = random.choice(['right', 'left'])
        #         self.uut.send_wise(f'ethledwrite {p} {side} sgr', self.diag_prompt)
        #
        #     scanner.get_right_answer(
        #         question=f'(Round {i})As shown in the picture, how many lights are on in the following ?\n'
        #                  f'(lần {i})Như hình minh họa, có bao nhiêu đèn sáng?',
        #         answers=[str(_) for _ in range(10)],
        #         retry=3,
        #         right_answer=str(len(s)),
        #         image='Edradour/images/check_led_on_count.png'
        #     )
        # log.debug(f"===============================================")

    @staticmethod
    def random_off_sequences(
            model: str,
            rounds=3,
            allow_repeat_across_rounds=False,
    ):
        """
        根据型号生成灭灯计划。
        返回：list[set]，长度=rounds，每个元素是该次要灭的 LED 索引集合。
        """
        cfg = PRODUCT_CONFIG[model]
        modules = cfg["modules"]
        min_per_round = cfg["min_per_round"]
        max_per_round = cfg["max_per_round"]

        all_leds = set().union(*modules.values())
        targets = [random.randint(min_per_round, max_per_round) for _ in range(rounds)]

        picks = [set() for _ in range(rounds)]
        chosen_global = set()

        # 保证覆盖：把模块分配到各轮
        module_order = list(modules.keys())
        random.shuffle(module_order)
        assigned = defaultdict(list)
        for i, m in enumerate(module_order):
            assigned[i % rounds].append(m)

        for r in range(rounds):
            for m in assigned[r]:
                candidates = modules[m]
                choices = candidates if allow_repeat_across_rounds else [x for x in candidates if
                                                                         x not in chosen_global]
                if not choices:
                    choices = candidates
                led = random.choice(choices)
                picks[r].add(led)
                if not allow_repeat_across_rounds:
                    chosen_global.add(led)

        # 补足数量
        for r in range(rounds):
            need = max(min_per_round, min(max_per_round, targets[r])) - len(picks[r])
            if need <= 0:
                continue

            pool = list(all_leds) if allow_repeat_across_rounds else list(all_leds - chosen_global)
            need = min(need, len(pool))
            extra = set(random.sample(pool, need))
            picks[r].update(extra)
            if not allow_repeat_across_rounds:
                chosen_global.update(extra)

        # 校验：每轮数量 & 覆盖所有模块
        assert all(min_per_round <= len(p) <= max_per_round for p in picks), "Round size does not meet the range"
        union_all = set().union(*picks)
        covered_modules = {m for x in union_all for m, leds in modules.items() if x in leds}
        assert covered_modules == set(modules.keys()), "Not all modules are covered"

        return picks

    def check_amber_off(self, off_led_max):
        if '48' in self.mapping.platform:
            amber_port = 8
            max_port = 3
            img = 'Edradour/images/48-amber-off.png'
        else:
            amber_port = 4
            max_port = 2
            img = 'Edradour/images/12-24-amber-off.png'
        # 1st
        self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sab', self.diag_prompt)
        rdn_ports = random.sample(list(range(amber_port)), random.randint(1, max_port))
        log.debug(f'turn off led: {rdn_ports}, total:{len(rdn_ports)}')
        for p in rdn_ports:
            # side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} right off', self.diag_prompt)

        scanner.get_right_answer(
            question=f'(1st)As shown in the picture, how many of the {amber_port} amber lights are off?\n'
                     f'(lần đầu)Như hình minh họa, có bao nhiêu trong số {amber_port} đèn màu hổ phách đã tắt?',
            answers=[str(_) for _ in range(6)],
            retry=3,
            right_answer=str(len(rdn_ports)),
            image=img
        )
        # 2nd
        self.uut.send_wise('ethledwrite all right sab', self.diag_prompt)
        led_ports = list(filter(lambda x: x not in rdn_ports, list(range(amber_port))))
        rdn_ports = random.sample(led_ports, random.randint(1, max_port))
        log.debug(f'turn off led: {rdn_ports}, total:{len(rdn_ports)}')
        for p in rdn_ports:
            # side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} right off', self.diag_prompt)

        scanner.get_right_answer(
            question=f'(2nd)As shown in the picture, how many of the {amber_port} amber lights are off?\n'
                     f'(Lần thứ hai)Như hình minh họa, có bao nhiêu trong số {amber_port} đèn màu hổ phách đã tắt?',
            answers=[str(_) for _ in range(6)],
            retry=3,
            right_answer=str(len(rdn_ports)),
            image=img
        )

    def do_test_on_cloud_mst_led(self, led, color):
        # CLD RED   ledwrite 1 1
        # CLD BLUE  ledwrite 2 1
        # CLD GREEN ledwrite 3 1
        #
        # MST RED   ledwrite 5 1
        # MST BLUE  ledwrite 6 1
        # MST GREEN ledwrite 4 1

        # turn on
        for _d in led:
            self.uut.send_wise(f'ledwrite {_d} 1', self.diag_prompt)
            if re.search('error|fail', self.uut.buffer, re.I):
                raise Exception(f'turn on CLD or MST led failed')

        log.debug(f'turn on CLD & MST: {color}')

        scanner.get_right_answer(
            question='What\'s the color of ALM, MST, CLD LED? ALM, MST, CLD灯的颜色是什么？'
                     '\nMàu sắc của đèn ALM, MST, CLD là gì?',
            answers=['Red', 'Green', 'Blue', 'Off', 'Other'],
            right_answer=color,
            image='Edradour/images/led-cld-mst.png',
            retry=3
        )
        # turn off
        for _d in led:
            self.uut.send_wise(f'ledwrite {_d} 0', self.diag_prompt)
            if re.search('error|fail', self.uut.buffer, re.I):
                raise Exception(f'turn off CLD or MST led failed')

        log.debug(f'turn off CLD & MST: {color}')

    def panel_led_test(self):
        # CLD RED   ledwrite 1 1
        # CLD BLUE  ledwrite 2 1
        # CLD GREEN ledwrite 3 1
        #
        # MST RED   ledwrite 5 1
        # MST BLUE  ledwrite 6 1
        # MST GREEN ledwrite 4 1
        #
        # ALM RED   ledwrite 8 1
        # ALM BLUE  ledwrite 9 1
        # ALM GREEN ledwrite 7 1

        led = [
            ('Red', (1, 5, 8)), ('Blue', (2, 6, 9)), ('Green', (3, 4, 7)),
        ]
        random.shuffle(led)
        for _d in led:
            self.do_test_on_cloud_mst_led(led=_d[1], color=_d[0])
        # All off
        if yes_or_enter_to_continue(
                question='ALM, MST, CLD led are off? ALM, MST, CLD 都熄灭了吗？'
                         '\nĐèn ALM, MST, CLD đã tắt hết chưa?',
                image='Edradour/images/led-cld-mst.png'
        ) is False:
            raise Exception('not all CLD & MST off!')
        log.debug('both CLD and MST are off!')

    def led_test(self):
        # 拔出 SFP
        # scanner.yes_or_enter_to_continue(question='Please unplug all the RJ45 loopback and SFPs and USB at the front\n. '
        #                                           'Vui lòng rút tất cả RJ45 và SFP, USB ở phía trước.')
        # CLD and MST
        # Panel LED
        self.panel_led_test()
        # ETH LED test
        self.eth_led_test()
        self.led_check()

    def led_check(self):

        if self.mapping.platform in ['EX4000-48MUP', 'EX4000-48MP', 'EX4000-48P', 'EX4000-48T']:
            img_front_on = 'check_led_on_48.png'
            img_front_off = 'check_led_off_48.png'
        elif self.mapping.platform in ['EX4000-24MUP', 'EX4000-24MP', 'EX4000-24P', 'EX4000-24T']:
            img_front_on = 'check_led_on_24.png'
            img_front_off = 'check_led_off_24.png'
        elif self.mapping.platform in ['EX4000-12MUP', 'EX4000-12MP', 'EX4000-12P', 'EX4000-12T']:
            img_front_on = 'check_led_on_12.png'
            img_front_off = 'check_led_off_12.png'
        else:
            img_front_on = 'check_led_on_8.png'
            img_front_off = 'check_led_off_8.png'

        self.uut.send_wise('ethledwrite all left sgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sgr', self.diag_prompt)
        # turn on
        for _d in [3, 4, 7]:
            self.uut.send_wise(f'ledwrite {_d} 1', self.diag_prompt)
            if re.search('error|fail', self.uut.buffer, re.I):
                raise Exception(f'turn on CLD or MST led failed')
        if ('24' in self.mapping.platform) or ('48' in self.mapping.platform):
            scanner.yes_or_enter_to_continue(
                question=f'\nPlease confirm all the lights in the front panel are on'
                         f'\nVui lòng xác nhận tất cả các đèn trên mặt trước đều sáng ',
                image=f'Edradour/images/{img_front_on}'
            )
            log.debug('OP confirm front panel all LED ON')
            scanner.yes_or_enter_to_continue(
                question=f'\nPlease confirm all the lights on the back panel are on'
                         f'\nVui lòng xác nhận rằng tất cả các đèn trên bảng điều khiển phía sau đều sáng',
                image=f'Edradour/images/check_back_led_on.png'
            )
            log.debug('OP confirm back panel all LED ON')
        else:
            scanner.yes_or_enter_to_continue(
                question=f'\nPlease confirm all the lights in the front panel are on'
                         f'\nVui lòng xác nhận tất cả các đèn trên mặt trước đều sáng',
                image=f'Edradour/images/{img_front_on}'
            )
            log.debug('OP confirm front panel all LED ON')

        self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right off', self.diag_prompt)
        # turn off
        for _d in [3, 4, 7]:
            self.uut.send_wise(f'ledwrite {_d} 0', self.diag_prompt)
            if re.search('error|fail', self.uut.buffer, re.I):
                raise Exception(f'turn on CLD or MST led failed')
        if ('24' in self.mapping.platform) or ('48' in self.mapping.platform):
            scanner.yes_or_enter_to_continue(
                question=f'\nPlease confirm all the lights in the front panel are off'
                         f'\nVui lòng xác nhận tất cả đèn trên bảng điều khiển đã tắt',
                image=f'Edradour/images/{img_front_off}'
            )
            log.debug('OP confirm front panel all LED OFF')
            scanner.yes_or_enter_to_continue(
                question=f'\nPlease confirm all the lights on the back panel are off'
                         f'\nVui lòng xác nhận tất cả đèn trên bảng điều khiển đều tắt',
                image=f'Edradour/images/check_back_led_off.png'
            )
            log.debug('OP confirm back panel all LED OFF')
        else:
            scanner.yes_or_enter_to_continue(
                question=f'\nPlease confirm all the lights in the front panel are off'
                         f'\nVui lòng xác nhận tất cả đèn trên bảng điều khiển đã tắt',
                image=f'Edradour/images/{img_front_off}'
            )
            log.debug('OP confirm front panel all LED OFF')

        # 全部恢复默认状态
        self.uut.send_wise('ethledwrite all left dis', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right dis', self.diag_prompt)

    def usb_speed_test(self):
        # 先检查是否已经安装了U盘，若已经安装完毕，就不再弹窗了！
        while True:
            try:
                log.debug('detect USB Drive....')
                self.uut.send_wise('syscall ls -l /dev | grep sda*', self.diag_prompt)
                if self.uut.buffer.count('sda') <= 1:
                    log.debug('USB Drive has NOT been installed! Please check!')
                    if scanner.yes_or_enter_to_continue(
                            question='Please insert the USB drive. 请安装U盘\nVui lòng cắm USB vào.',
                            image='Edradour/images/usb-drive.png'
                    ) is True:
                        time.sleep(5)
                        continue
                    else:
                        raise Exception('USB Drive is not detected!')
            except:
                log.debug('USB Drive has NOT been installed! Please check!')
                if scanner.yes_or_enter_to_continue(
                        question='Please insert the USB drive. 请安装U盘\nVui lòng cắm USB vào.',
                        image='Edradour/images/usb-drive.png'
                ) is True:
                    time.sleep(5)
                    continue
                else:
                    raise Exception('USB Drive is not detected!')
            # 已安装U盘
            log.debug('USB Drive has been installed!')
            break

        while True:
            self.uut.send_wise('storagetest usb rndwr 200', self.diag_prompt, timeout=300)
            if 'test - PASS' not in self.uut.buffer or re.search('eror|fail', self.uut.buffer, re.I):
                log.error('not found pass signature: test - PASS. FAIL!!!!')
                if scanner.yes_or_enter_to_continue(
                        question='Please check USB drive. 请检查U盘\nVui lòng kiểm tra USB.',
                        image='Edradour/images/usb-drive.png'
                ) is False:
                    raise Exception('USB Drive test failed!')
                continue
            log.debug('[Pass Criteria] usb test expect value: test - PASS, result: PASS')
            break

    def emmc_test(self):
        self.uut.send_wise('storagetest emmc rndwr 2000', self.diag_prompt, timeout=600)
        if "test - PASS" not in self.uut.buffer:
            log.error('[Pass Criteria] emmc test expect value: test - PASS, result: FAIL')
            raise Exception('emmc test failed!')
        log.debug('[Pass Criteria] emmc test expect value: test - PASS, result: PASS')

    def tpm_test_physical(self):
        # tpm_tis_spi spi1.0: 2.0 TPM (device-id 0x1D, rev-id 54)
        # tpm tpm0: A TPM error (256) occurred attempting the self test
        # tpm tpm0: starting up the TPM manually
        # 第一次测试的时候会出现上述Error，是正常的
        self.uut.send_wise('syscall modprobe tpm_tis_spi', self.diag_prompt)
        self.uut.send_wise('tpm -t', self.diag_prompt)
        if 'TPM test PASS' not in self.uut.buffer:
            raise Exception('TPM test failed!')
        log.debug("[Pass Criteria] tpm -t, expected value: TPM test PASS, result: PASS")

        self.uut.send_wise('tpm -g', self.diag_prompt)
        if 'TPM test PASS' not in self.uut.buffer:
            raise Exception('TPM -g test failed!')
        log.debug("[Pass Criteria] tpm -g, expected value: TPM test PASS, result: PASS")

        # TPM_PT_MANUFACTURER:            IFX�
        manufacturer = re.search(r'TPM_PT_MANUFACTURER:\s+(\w+)', self.uut.buffer)
        if manufacturer is None:
            raise Exception('not found TPM_PT_MANUFACTURER!')
        manufacturer = manufacturer.group(1)
        if manufacturer != self.mapping.tpm_manufacturer:
            log.error(
                f'[Pass Criteria] TPM Manufacturer, capture: {manufacturer}, expect value: {self.mapping.tpm_manufacturer}, result:FAIL')
            raise Exception(
                f'TPM Manufacturer, expected: {self.mapping.tpm_manufacturer}, capture value: {manufacturer}. FAIL')
        log.debug(
            f'[Pass Criteria] TPM Manufacturer, capture: {manufacturer}, expect value: {self.mapping.tpm_manufacturer}, result:PASS')

        # TPM_PT_VENDOR_STRING:           SLB9672���������
        vendor = re.search(r'TPM_PT_VENDOR_STRING:\s+(\w+)', self.uut.buffer)
        if vendor is None:
            raise Exception('not found: TPM_PT_VENDOR_STRING')
        vendor = vendor.group(1)
        if vendor != self.mapping.tpm_vendor:
            log.error(f'[Pass Criteria] TPM Vendor, capture: {vendor}, expect value: {self.mapping.tpm_vendor}, result: FAIL')
            raise Exception(f'TPM Vendor, expected: {self.mapping.tpm_vendor}, captured: {vendor}. FAIL')
        log.debug(f'[Pass Criteria] TPM Vendor, capture: {vendor}, expect value: {self.mapping.tpm_vendor}, result: PASS')

        # TPM_PT_FIRMWARE_VERSION:        16.13.17733.0
        fw_ver = re.search(r'TPM_PT_FIRMWARE_VERSION:\s+([\w.]+)', self.uut.buffer)
        if fw_ver is None:
            raise Exception('not found: TPM_PT_FIRMWARE_VERSION')
        fw_ver = fw_ver.group(1)
        if fw_ver != self.mapping.tpm_fw_ver:
            log.error(f'[Pass Criteria] TPM FW Version, capture: {fw_ver}, expect value: {self.mapping.tpm_fw_ver}, result: FAIL')
            raise Exception(f'TPM FW Version, expected: {self.mapping.tpm_fw_ver}, captured: {fw_ver}. FAIL')
        log.debug(
            f'[Pass Criteria] TPM FW Version, capture: {fw_ver}, expect value: {self.mapping.tpm_fw_ver}, result: PASS')

        self.uut.send_wise('syscall ./eltt2 -g', self.diag_prompt)

    def fan_speed_direction_test(self):
        # fanread all
        # 0x0 ~ 0x1FF
        # fanwrite all 0x0
        log.debug(f'this SKU has {self.mapping.fan_count} fan(s)')
        if self.mapping.fan_count == 0:
            log.debug(f'no need to do fan test!')
            return

        log.debug(f'do fan test...')
        self.uut.send_wise('fantest 6', self.diag_prompt)
        if re.search('error|fail', self.uut.buffer, re.I):
            raise Exception('Fan speed test failed')
        if 'Fan test - PASS' not in self.uut.buffer:
            log.error('not found -> Fan test - PASS')
            raise Exception('fan test failed!')
        log.debug("[Pass Criteria] Fan test, expect value: Fan test - PASS, result: PASS")

    def chassis_temp_check(self):
        """
        tempread all
        Temperature#1 : [TMP75#1] : +39.50 oC
        Temperature#2 : [TMP75#2] : +23.50 oC
        Temperature#3 : [TMP75#3] : +23.0 oC
        Temperature#4 : [MAC0_Internal] : +61.8 oC
        Temperature#5 : [MAC1_Internal] : +61.8 oC
        DIAG>
        """

        self.uut.send_wise('tempread all', self.diag_prompt)
        temp = re.findall(r':\s+([+-](?:\d+)?\.\d+)\s+oC', self.uut.buffer)
        if len(temp) == 0:
            raise Exception('not found temperatures!')

        for t in temp:
            float_t = float(t)
            if not (self.mapping.low_temp <= float_t <= self.mapping.high_temp):
                msg = f'temp: {float_t} out of range, [{self.mapping.low_temp}, {self.mapping.high_temp}]'
                log.error(msg)
                raise Exception(f'temperature out of range!')
            else:
                log.debug(f'temp: {float_t} is in range: [{self.mapping.low_temp}, {self.mapping.high_temp}]')
                log.debug(f"[Pass Criteria] tempread, capture: {float_t}, expect: [{self.mapping.low_temp}, {self.mapping.high_temp}], result: PASS")

    def hardware_inventory_check(self):
        log.debug(f'this SKU has {self.mapping.fan_count} fan(s).')
        if self.mapping.fan_count != 0:
            self.uut.send_wise('fanlist', self.diag_prompt)
            if re.search('error|fail|absent', self.uut.buffer, flags=re.I):
                raise Exception('found error in fanlist')
            fans = re.findall(r'FAN#\d+ :', self.uut.buffer)
            log.debug(f'fan count: {len(fans)}, -> {fans}')
            if len(fans) != self.mapping.fan_count:
                log.error(f'fan count mismatch! expected: {self.mapping.fan_count}, got: {len(fans)}')
                raise Exception(f'fan count mismatch! expected: {self.mapping.fan_count}, got: {len(fans)}')
            log.debug(f'[Pass Criteria] capture: {len(fans)} fans Present, expect: {self.mapping.fan_count} fans Present, result: PASS')
        else:
            log.debug('no need to check fan...SKIP')

        # self.uut.send_wise('i2cget -y 0 0x72 4', self.diag_prompt)
        # self.uut.send_wise('i2cset -y 0 0x32 0x1f 0x32', self.diag_prompt)
        self.sleep_time(5)
        self.uut.send_wise('rtcbattery', self.diag_prompt)
        if re.search('error|fail', self.uut.buffer, flags=re.I):
            raise Exception('rtcbattery failed!')
        if 'RTC Battery - PASS' not in self.uut.buffer:
            raise Exception('not found pass criteria: RTC Battery - PASS')
        log.debug(f"[Pass Criteria] rtcbattery, expect: RTC Battery - PASS, result: PASS")

    def ecc_errors_check(self):
        self.uut.send_wise('syscall dmesg > /var/log/messages', self.diag_prompt)
        self.uut.send_wise('syscall cat /var/log/messages | grep -i -A 5 "Correctable"', self.diag_prompt)
        self.uut.send_wise('syscall cat /var/log/messages | grep -i -A 5 "unCorrectable"', self.diag_prompt)
        if self.uut.buffer.count('unCorrectable') != 1:
            raise Exception('found ECC unCorrectable, failed!')
        log.debug(f"[Pass Criteria] ecc errors check, capture: {self.uut.buffer.count('unCorrectable')}, expect: count unCorrectable = 1, , PASS")

    def memory_size_check(self):
        # 可能mem size不是一个准确的数字，而是一个范围
        self.uut.send_wise('syscall cat /proc/meminfo', self.diag_prompt)
        # MemTotal:        3411088 kB
        mem_size = re.search(r'MemTotal:\s+(\d+) kB', self.uut.buffer)
        if mem_size is None:
            raise Exception('can not read mem size!')
        mem_size = mem_size.group(1)
        log.debug(f'mem size: {mem_size}')
        mem_size = int(mem_size)
        if mem_size < self.mapping.mem_size:
            raise Exception(f'mem size is not correct, expected: > {self.mapping.mem_size}, got: {mem_size}')
        log.debug(f"[Pass Criteria] memory size check, capture: {mem_size}, expect: {self.mapping.mem_size}, result: PASS")

    def check_cpu_cores(self):
        self.uut.send_wise('syscall cat /proc/cpuinfo  | grep processor', self.diag_prompt)
        cores = re.findall(r'processor\s+:\s+(\d+)', self.uut.buffer)
        if cores != ['0', '1', '2', '3']:
            raise Exception(f'cpu cores mismatch! -> bad: {cores}')
        log.debug(f"[Pass Criteria] check CPU cores, capture: {cores}, expect: {['0', '1', '2', '3']}, result: PASS")

    def type_c_test(self):
        # 先检查是否已安装 Type C - USB A
        while True:
            self.uut.send_wise('syscall ls /dev/ttyUSB0', self.diag_prompt)
            image = None
            question = 'Please connect TypeC and USB-A\n请连接TypeC和USB-A\nVui lòng kết nối TypeC và USB-A'
            if 'No such file or directory' in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(question=question, image=image) is False:
                    raise Exception('Type C to USB A failed!')
                continue
            break
        self.uut.send_wise('console test', self.uut.buffer)

    def reset_test(self):
        # I2C_MUX1
        self.uut.send_wise('rsttest I2C_MUX1', self.diag_prompt)
        if 'RST I2C_MUX1 test - PASS' not in self.uut.buffer:
            raise Exception('RST I2C_MUX1 test failed, not found -> RST I2C_MUX1 test - PASS')
        log.debug('RST I2C_MUX1 test - PASS')
        if 'RST test - PASS' not in self.uut.buffer:
            raise Exception('RST I2C_MUX1 test failed, not found -> RST test - PASS')
        log.debug('RST test - PASS')
        if re.search('fail|errro', self.uut.buffer, re.I):
            log.error('RST I2C_MUX1 failed! found: error or fail!')
            raise Exception('RST I2C_MUX1 failed! found: error or fail!')
        log.debug('[Pass Criteria] rsttest I2C_MUX1, expect: [RST I2C_MUX1 test - PASS, RST test - PASS] and no fail|error, result: PASS')

        # I2C_MUX2
        self.uut.send_wise('rsttest I2C_MUX2', self.diag_prompt)
        if 'RST I2C_MUX2 test - PASS' not in self.uut.buffer:
            raise Exception('not found -> RST I2C_MUX2 test - PASS')
        log.debug('RST I2C_MUX2 test - PASS')
        if 'RST test - PASS' not in self.uut.buffer:
            raise Exception('I2C_MUX2 test failed! not found -> RST test - PASS')
        log.debug('RST test - PASS')
        if re.search('fail|errro', self.uut.buffer, re.I):
            log.error('RST I2C_MUX2 failed! found: error or fail!')
            raise Exception('RST I2C_MUX2 failed! found: error or fail!')
        log.debug('[Pass Criteria] rsttest I2C_MUX2, expect: [RST I2C_MUX2 test - PASS, RST test - PASS] and no fail|error, result: PASS')

        # LED_SHIFT
        if self.mapping.platform in ['EX4000-48MP', 'EX4000-48P', 'EX4000-48T']:
            img_front_on = 'check_led_on_48.png'
            img_front_off = 'check_led_off_48.png'
        elif self.mapping.platform in ['EX4000-24MP', 'EX4000-24P', 'EX4000-24T']:
            img_front_on = 'check_led_on_24.png'
            img_front_off = 'check_led_off_24.png'
        elif self.mapping.platform in ['EX4000-12MP', 'EX4000-12P', 'EX4000-12T']:
            img_front_on = 'check_led_on_12.png'
            img_front_off = 'check_led_off_12.png'
        else:
            img_front_on = 'check_led_on_8.png'
            img_front_off = 'check_led_off_8.png'
        self.uut.send_wise('rsttest LED_SHIFT', [self.diag_prompt, 'Press N if the right LEDs are still on.'])
        # check front led off
        scanner.get_right_answer(
                question='[RESET] Are all LED are off? \n所有LED都熄灭了吗？\n Tất cả đèn LED đã tắt hết chưa?',
            image=f'Edradour/images/{img_front_off}',
            answers=['Yes', 'No'],
            right_answer='Yes',
            retry=1
        )
        # # check back led off only 24 48 port
        # if ('24' in self.mapping.platform) or ('48' in self.mapping.platform):
        #     scanner.get_right_answer(
        #             question='[RESET] Are all LED in rear panel are off? \n后面所有LED都熄灭了吗？\n Tất cả đèn LED ở phía sau đã tắt hết chưa?',
        #         image=f'Edradour/images/check_back_led_off.png',
        #     answers=['Yes', 'No'],
        #     right_answer='Yes',
        #     retry=1
        #     )

        if 'Press N if the right LEDs are still on.' in self.uut.buffer:
            self.uut.send('Y', self.diag_prompt)
        if 'RST LED_SHIFT test - PASS' not in self.uut.buffer:
            log.error('not found RST LED_SHIFT test - PASS')
            raise Exception('fan test failed -> RST LED_SHIFT test - PASS')
        log.debug('pass criteria -> RST LED_SHIFT test - PASS')
        if 'RST test - PASS' not in self.uut.buffer:
            log.error('RST test - PASS')
            raise Exception('fan test failed -> RST test - PASS')
        log.debug('pass criteria -> RST test - PASS')
        if re.search('fail|errro', self.uut.buffer, re.I):
            log.error('RST LED_SHIFT failed! found: error or fail!')
            raise Exception('RST LED_SHIFT failed! found: error or fail!')
        log.debug('[Pass Criteria] rsttest I2C_MUX2, expect: [RST I2C_MUX2 test - PASS, RST test - PASS] and no fail|error, result: PASS')

        # TPM
        # self.uut.send_wise('rsttest TPM', self.diag_prompt)
        # if 'RST TPM test - PASS' not in self.uut.buffer:
        #     log.error('not found -> RST TPM test - PASS')
        #     raise Exception('RST TPM failed')
        # log.debug('pass criteria: RST TPM test - PASS')
        # if 'RST test - PASS' not in self.uut.buffer:
        #     log.error('not found -> RST test - PASS')
        # log.debug('pass criteria -> RST test - PASS')

        # POE_MCU_JTAG
        if self.mapping.rst_poe_mcu_jtag is True:
            self.debug(f'This SKU: {self.mapping.platform} need to RST PoE MCU')
            for i in range(3):
                self.uut.send_wise('rsttest POE_MCU_JTAG', self.diag_prompt)
                if 'RST POE_MCU_JTAG test - PASS' not in self.uut.buffer:
                    log.error('POE_MCU_JTAG test failed, not found -> RST POE_MCU_JTAG test - PASS - PASS')
                    continue
                log.debug('RST POE_MCU_JTAG test - PASS')
                if 'RST test - PASS' not in self.uut.buffer:
                    log.error('POE_MCU_JTAG test failed, not found -> RST test - PASS')
                    continue
                log.debug('RST test - PASS')
                log.debug(
                    '[Pass Criteria] rsttest POE_MCU_JTAG, expect: [RST POE_MCU_JTAG test - PASS, RST test - PASS], result: PASS')
                # if re.search('fail|errro', self.uut.buffer, re.I):
                #     log.error('RST POE_MCU_JTAG failed! found: error or fail!')
                #     continue
                break
            else:
                raise Exception('RST POE_MCU_JTAG failed!')
        else:
            self.debug(f'This SKU: {self.mapping.platform} NO need to RST PoE MCU. SKIP..')

        # MG_PHY
        if self.mapping.rst_mg_phy is True:
            self.debug(f'This SKU: {self.mapping.platform} need to RST MG PHY.')
            self.uut.send_wise('rsttest MG_PHY', self.diag_prompt)
            if 'RST MG_PHY test - PASS' not in self.uut.buffer:
                raise Exception('MG_PHY test failed, not found -> RST MG_PHY test - PASS')
            log.debug('RST MG_PHY test - PASS')
            if 'RST test - PASS' not in self.uut.buffer:
                raise Exception('MG_PHY test failed, not found -> RST test - PASS')
            log.debug('RST test - PASS')
            if re.search('fail|errro', self.uut.buffer, re.I):
                log.error('RST MG_PHY failed! found: error or fail!')
                raise Exception('RST MG_PHY failed! found: error or fail!')
            log.debug(
                '[Pass Criteria] rsttest MG_PHY, expect: [RST MG_PHY test - PASS, RST test - PASS] and no fail|error, result: PASS')
        else:
            self.debug(f'This SKU: {self.mapping.platform} NO need to RST MG PHY. SKIP..')

    def power_off(self):
        try:
            self.pdu.power_off(helper.config['pdu_port'])
        except:
            pass

    def init_connections(self):
        self.uut = UUT(conn_str=helper.config['uut_conn_str'])
        self.pdu = APC(conn_str=helper.config['pdu_conn_str'])

        server = helper.config.get('server')
        container = helper.container_number
        poe_mapping = helper.config.get('poe_config')
        # PoE
        # if helper.config.get('poe_model') == ReachPoE5.model_name:
        #     # 测试8， 12, 24 port
        if self.mapping.platform in ['EX4000-12P', 'EX4000-12MP', 'EX4000-12MUP', 'EX4000-24P',
                                     'EX4000-24MP', 'EX4000-24MUP', 'EX4000-8P']:
            poe_name = poe_mapping[server]['non48'][container][0]
            poe_conn_str = poe_mapping[server]['non48'][container][1]
            self.poe_group.extend([
                ReachPoE5(name=poe_name, conn_str=poe_conn_str),
            ])
        # 48 port
        else:
            poe_name1 = poe_mapping[server]['48'][container][0][0]
            poe_conn_str1 = poe_mapping[server]['48'][container][0][1]
            poe_name2 = poe_mapping[server]['48'][container][1][0]
            poe_conn_str2 = poe_mapping[server]['48'][container][1][1]
            self.poe_group.extend([
                ReachPoE5(name=poe_name1, conn_str=poe_conn_str1),
                ReachPoE5(name=poe_name2, conn_str=poe_conn_str2)
            ])
        # elif helper.config.get('poe_model') == IPorter2.model_name:
        #     if self.mapping.platform in {df.PN_EX4000_8P}:
        #         self.poe_group.extend([
        #             IPorter2(name='POE1', conn_str=helper.config['poe1_conn_str']),
        #         ])
        #     else:
        #         self.poe_group.extend([
        #             IPorter2(name='POE', conn_str=helper.config['poe_conn_str']),
        #             IPorter2(name='POE2', conn_str=helper.config['poe2_conn_str'])
        #         ])
        # else:
        #     raise Exception(f'unsupported PoE model: {helper.config.get("poe_model")}')

    def first_step_of_pre_seq(self):
        # self.check_latest_repo_version(self.product_name)
        super().first_step_of_pre_seq()

    def first_step_of_main_seq(self):
        log.debug(self.mapping)

    def close_all_connections(self):
        self.uut.do_disconnect()

    def upload_test_records(self):
        self.update_test_status()
        helper.quick_set('Upload to Genius')
        super().add_genius_records(
            diagrev=self.mapping.diag_version,
            str1name='BASE_MAC',
            str1=self.mac_address,
            str2name='ASSEMBLY_REVISION',
            str2=self.mapping.arev.w_val,
            str3name='ASSEMBLY_ID',
            str3=self.mapping.aid.w_val,
            str4name='U_Boot_Version',
            str4=self.mapping.u_boot_version,
            str5name='CPLD_Version',
            str5=self.mapping.cpld_version,
            str6name='Script_Version',
            str6=self.current_version,
        )
        helper.quick_set('Upload to MES')
        self.add_mes_records()

    def get_snr_value(self):
        if self.mapping.platform not in ['EX4000-48MP', 'EX4000-24MP', 'EX4000-12MP']:
            return

        if self.mapping.platform == 'EX4000-48MP':
            traffic_port_str = "0-7"
            traffic_port_num = 8
        else:
            traffic_port_str = "0-3"
            traffic_port_num = 4

        self.uut.send_wise(f'epdmport {traffic_port_str} snrget', self.diag_prompt, 120)

        if self.area == "POE":
            # 匹配 EPDM port 和所有通道的数值
            # Regex to match EPDM port and all channel values
            pattern = (
                r"EPDM port\s+(\d+)\s*:.*?"
                r"ChA:\s*([\d.]+)dB.*?"
                r"ChB:\s*([\d.]+)dB.*?"
                r"ChC:\s*([\d.]+)dB.*?"
                r"ChD:\s*([\d.]+)dB"
            )
            matches = re.findall(pattern, self.uut.buffer)

            status = True

            # === Check if any ports were matched ===
            if not matches:
                log.error("No EPDM port data found!")
                helper.quick_set("No EPDM data found")
                raise Exception("No EPDM data found")

            # === Check if all 4 expected ports (0–3) are present ===
            found_ports = sorted(int(port) for port, *_ in matches)
            expected_ports = range(traffic_port_num)
            missing_ports = [p for p in expected_ports if p not in found_ports]

            if missing_ports:
                log.error(f"Missing ports: {missing_ports}")
                status = False
            # === Check each port and channel ===
            for port, cha_str, chb_str, chc_str, chd_str in matches:
                port = int(port)
                try:
                    cha, chb, chc, chd = map(float, [cha_str, chb_str, chc_str, chd_str])
                except ValueError:
                    log.error(f"Port {port}: Invalid numeric format in channel values.")
                    status = False
                    continue
                channel_values = {"ChA": cha, "ChB": chb, "ChC": chc, "ChD": chd}
                for ch_name, value in channel_values.items():
                    # Check for missing value
                    if value is None or value == "":
                        log.error(f"Port {port}: Missing {ch_name} value.")
                        status = False
                        continue
                    # Check range
                    if 25 <= value <= 110:
                        log.debug(f"[Pass Criteria] 25 db <= Port {port}: {ch_name} = {value} dB <= 110 db, result: PASS")
                    else:
                        log.error(f"[Pass Criteria] Port {port}: {ch_name} = {value} dB out of range (25–110), result: FAIL")
                        status = False
            # === Final result ===
            if not status:
                helper.quick_set("Check SNR port/channel value failed or missing")
                raise Exception("Check SNR port/channel value failed or missing")


class LED_CHECK(BFT):
    area = 'CHECK_LED'

    def led_check(self):

        if self.mapping.platform in ['EX4000-48MP', 'EX4000-48P', 'EX4000-48T']:
            img_front_on = 'check_led_on_48.png'
            img_front_off = 'check_led_off_48.png'
        elif self.mapping.platform in ['EX4000-24MP', 'EX4000-24P', 'EX4000-24T']:
            img_front_on = 'check_led_on_24.png'
            img_front_off = 'check_led_off_24.png'
        elif self.mapping.platform in ['EX4000-12MP', 'EX4000-12P', 'EX4000-12T']:
            img_front_on = 'check_led_on_12.png'
            img_front_off = 'check_led_off_12.png'
        else:
            img_front_on = 'check_led_on_8.png'
            img_front_off = 'check_led_off_8.png'


        self.uut.send_wise('ethledwrite all left sgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sgr', self.diag_prompt)
        if ('24' in self.mapping.platform) or ('48' in self.mapping.platform):
            scanner.get_right_answer(
                question=f'\nPlease confirm all the lights in the front panel are on and take a photo.'
                         f'\nVui lòng xác nhận tất cả các đèn trên mặt trước đều sáng và chụp ảnh.',
                answers=['Đã chụp ảnh và xác nhận ok', 'FAIL'],
                retry=1,
                right_answer='Đã chụp ảnh và xác nhận ok',
                image=f'Edradour/images/{img_front_on}'
            )
            log.debug('OP confirm front panel all LED ON')
            scanner.get_right_answer(
                question=f'\nPlease confirm all the lights on the back panel are on and take a photo.'
                         f'\nVui lòng xác nhận rằng tất cả các đèn trên bảng điều khiển phía sau đều sáng và chụp ảnh.',
                answers=['Đã chụp ảnh và xác nhận ok', 'FAIL'],
                retry=1,
                right_answer='Đã chụp ảnh và xác nhận ok',
                image=f'Edradour/images/check_back_led_on.png'
            )
            log.debug('OP confirm back panel all LED ON')
        else:
            scanner.get_right_answer(
                question=f'\nPlease confirm all the lights in the front panel are on and take a photo.'
                         f'\nVui lòng xác nhận tất cả các đèn trên mặt trước đều sáng và chụp ảnh.',
                answers=['Đã chụp ảnh và xác nhận ok', 'FAIL'],
                retry=1,
                right_answer='Đã chụp ảnh và xác nhận ok',
                image=f'Edradour/images/{img_front_on}'
            )
            log.debug('OP confirm front panel all LED ON')

        self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right off', self.diag_prompt)
        if ('24' in self.mapping.platform) or ('48' in self.mapping.platform):
            scanner.get_right_answer(
                question=f'\nPlease confirm all the lights in the front panel are off and take a photo.'
                         f'\nVui lòng xác nhận tất cả đèn trên bảng điều khiển đã tắt và chụp ảnh.',
                answers=['Đã chụp ảnh và xác nhận ok', 'FAIL'],
                retry=1,
                right_answer='Đã chụp ảnh và xác nhận ok',
                image=f'Edradour/images/{img_front_off}'
            )
            log.debug('OP confirm front panel all LED OFF')
            scanner.get_right_answer(
                question=f'\nPlease confirm all the lights on the back panel are off and take a photo.'
                         f'\nVui lòng xác nhận tất cả đèn trên bảng điều khiển đều tắt và chụp ảnh.',
                answers=['Đã chụp ảnh và xác nhận ok', 'FAIL'],
                retry=1,
                right_answer='Đã chụp ảnh và xác nhận ok',
                image=f'Edradour/images/check_back_led_off.png'
            )
            log.debug('OP confirm back panel all LED OFF')
        else:
            scanner.get_right_answer(
                question=f'\nPlease confirm all the lights in the front panel are off and take a photo.'
                         f'\nVui lòng xác nhận tất cả đèn trên bảng điều khiển đã tắt và chụp ảnh.',
                answers=['Đã chụp ảnh và xác nhận ok', 'FAIL'],
                retry=1,
                right_answer='Đã chụp ảnh và xác nhận ok',
                image=f'Edradour/images/{img_front_off}'
            )
            log.debug('OP confirm front panel all LED OFF')

        # 全部恢复默认状态
        self.uut.send_wise('ethledwrite all left dis', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right dis', self.diag_prompt)

        self.panel_led_test()

    def led_test(self):
        # CLD and MST
        # Panel LED
        self.panel_led_test()
        # ETH LED test
        self.eth_led_test()

    def eth_led_test(self):
        # ETH all green
        self.uut.send_wise('ethledwrite all left sgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sgr', self.diag_prompt)
        if scanner.yes_or_enter_to_continue(
                question='Are all eth LED ON ?\n所有Eth的灯都亮了吗？'
                         '\nTất cả đèn Eth đã sáng chưa?',
                image='Edradour/images/led-eth-all-on.png'
        ) is False:
            raise Exception('not all eth led are on!')

        # 随机灭1-6个灯, 做2次，两次灭的灯必须不一样, 不同port最大off不同
        if '8' in self.mapping.platform:
            off_led_max = 3
        elif '12' in self.mapping.platform:
            off_led_max = 4
        elif '24' in self.mapping.platform:
            off_led_max = 5
        else:
            off_led_max = 6

        self.check_green_off(off_led_max=off_led_max)

        # ETH all green blinking
        self.uut.send_wise('ethledwrite all left bgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right bgr', self.diag_prompt)
        if scanner.yes_or_enter_to_continue(
                question='Are all eth LED blinking ?\n所有Eth的灯都在闪烁吗？'
                         '\nTất cả đèn Eth có đang nhấp nháy không?',
                image='Edradour/images/led-eth-all-on.png'
        ) is False:
            raise Exception('not all eth led are on!')

        self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right off', self.diag_prompt)

        if self.mapping.eth_amber is True:
            log.debug(f'This SKU: {self.mapping.platform} need to test amber ETH LED.')
            # Amber
            if '48' in self.mapping.platform:
                img = 'Edradour/images/led-amber.png'
            else:
                img = 'Edradour/images/led-amber-12-24.png'
            self.uut.send_wise('ethledwrite all right sab', self.diag_prompt)
            if scanner.yes_or_enter_to_continue(
                    question='Are ETH LED on Amber? 有琥珀色的LED灯亮了？\nCó đèn LED màu hổ phách sáng lên không?',
                    image=img,
            ) is False:
                raise Exception('ETH AMBER LED test failed!')

            self.check_amber_off(off_led_max=off_led_max)

            # Amber blinking
            self.uut.send_wise('ethledwrite all right bab', self.diag_prompt)
            if scanner.yes_or_enter_to_continue(
                    question='Are ETH LED on Amber blinking? 有琥珀色的LED灯在闪烁吗？'
                             '\nCó đèn LED màu hổ phách đang nhấp nháy không?',
                    image='Edradour/images/led-amber.png',
            ) is False:
                raise Exception('ETH AMBER LED blinking test failed!')

            # 全部关闭
            self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
            self.uut.send_wise('ethledwrite all right off', self.diag_prompt)

        log.debug(f'This SKU: {self.mapping.platform} NO need to test amber ETH LED. SKIP...')

        # 全部恢复默认状态
        self.uut.send_wise('ethledwrite all left dis', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right dis', self.diag_prompt)

        self.check_mgmt_led()

        # 这一项包含了MGMT的端口LED
        if scanner.yes_or_enter_to_continue(
                question='Are all eth LED OFF (include MGMT port)?\n所有Eth的灯（包含MGMT端口）都灭了吗？'
                         '\nTất cả đèn Eth (bao gồm cả cổng MGMT) đã tắt hết chưa?',
                image='Edradour/images/led-eth-all-off.png'
        ) is False:
            raise Exception('not all eth led are off!')

        # 全部恢复默认状态
        self.uut.send_wise('ethledwrite all left dis', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right dis', self.diag_prompt)

    def check_mgmt_led(self):
        # config network
        self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.uut_ip} netmask {self.mapping.netmask} up',
                           self.diag_prompt)
        self.sleep_time(5)
        self.uut.send_wise('', self.diag_prompt)
        self.uut.send_wise('syscall ifconfig eth0 down', self.diag_prompt)
        self.sleep_time(3)
        self.uut.send_wise('syscall ifconfig eth0 up', self.diag_prompt)
        self.sleep_time(10)
        # if ('24' in self.mapping.platform) or ('48' in self.mapping.platform):
        #     img = "mgmt_led_24_48.png"
        # else:
        #     img = "mgmt_led_8_12.png"
        while True:
            self.sleep_time(5)
            self.uut.send_wise('syscall ping -c 3 10.1.1.1', self.diag_prompt)
            if "3 packets received" in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(
                        question='Please unplug net cable. \n Vui lòng rút cáp mạng.',
                        image='Edradour/images/unplug_net_cable.png'
                ) is False:
                    raise Exception('Stop Test')
            else:
                break

        status_list = [
            [f"ethledwrite {self.mapping.mgmt_port} left sgr", f"ethledwrite {self.mapping.mgmt_port} right off"],
            [f"ethledwrite {self.mapping.mgmt_port} left off", f"ethledwrite {self.mapping.mgmt_port} right sgr"],
            [f"ethledwrite {self.mapping.mgmt_port} left sgr", f"ethledwrite {self.mapping.mgmt_port} right sgr"],
            [f"ethledwrite {self.mapping.mgmt_port} left off", f"ethledwrite {self.mapping.mgmt_port} right off"],
        ]
        command_step = random.sample(list(range(4)), 4)

        language = [['1st', 'lần đầu'], ['2nd', 'Lần thứ hai'], ['3rd', 'Lần thứ ba'], ['4th', 'lần thứ tư']]

        for index, s in enumerate(command_step):
            cm = status_list[s]
            right_ans = None
            if s == 0:
                right_ans = 'Status 3'
            if s == 1:
                right_ans = 'Status 4'
            if s == 2:
                right_ans = 'Status 2'
            if s == 3:
                right_ans = 'Status 1'
            for c in cm:
                self.uut.send_wise(c, self.diag_prompt)
            scanner.get_right_answer(
                question=f'({language[index][0]})Please select MGMT LED status. \n'
                         f'({language[index][1]})Vui lòng chọn trạng thái đèn LED MGMT. ',
                answers=['Status 1', 'Status 2', 'Status 3', 'Status 4'],
                retry=2,
                right_answer=str(right_ans),
                image=f'Edradour/images/led_mgmt.png'
            )


        self.uut.send_wise(f"ethledwrite {self.mapping.mgmt_port} left off", self.diag_prompt)
        self.uut.send_wise(f"ethledwrite {self.mapping.mgmt_port} right off", self.diag_prompt)
        self.uut.send_wise(f"ethledwrite {self.mapping.mgmt_port} left bgr", self.diag_prompt)
        scanner.get_right_answer(
            question=f'Please check MGMT left LED is blinking. \n'
                     f'Vui lòng kiểm tra đèn LED bên trái của MGMT đang nhấp nháy. ',
            answers=['Đèn nháy(Blinking)', 'tắt(Off)'],
            retry=2,
            right_answer='Đèn nháy(Blinking)',
            image=f'Edradour/images/led_mgmt.png'
        )

    def check_green_off(self, off_led_max):
        # 1st
        rdn_ports = random.sample(self.mapping.led_port_seq, random.randint(1, off_led_max))
        log.debug(f'turn off led: {rdn_ports}, total:{len(rdn_ports)}')
        for p in rdn_ports:
            side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} {side} off', self.diag_prompt)

        scanner.get_right_answer(
            question='(1st)As shown in the picture, how many lights are off in the following ?\n'
                     '(lần đầu)Như hình minh họa, có bao nhiêu đèn tắt?',
            answers=[str(_) for _ in range(6)],
            retry=3,
            right_answer=str(len(rdn_ports)),
            image='Edradour/images/check_led_off_count.png'
        )
        # 2nd
        self.uut.send_wise('ethledwrite all left sgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sgr', self.diag_prompt)
        led_ports = list(filter(lambda x: x not in rdn_ports, self.mapping.led_port_seq))
        rdn_ports = random.sample(led_ports, random.randint(1, off_led_max))
        log.debug(f'turn off led: {rdn_ports}, total:{len(rdn_ports)}')
        for p in rdn_ports:
            side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} {side} off', self.diag_prompt)

        scanner.get_right_answer(
            question='(Second time)As shown in the picture, how many lights are off in the following ?\n'
                     '(Lần thứ hai)Như hình minh họa, có bao nhiêu đèn tắt ?',
            answers=[str(_) for _ in range(6)],
            retry=3,
            right_answer=str(len(rdn_ports)),
            image='Edradour/images/check_led_off_count.png'
        )

    def check_amber_off(self, off_led_max):
        if '48' in self.mapping.platform:
            amber_port = 8
            max_port = 3
            img = 'Edradour/images/48-amber-off.png'
        else:
            amber_port = 4
            max_port = 2
            img = 'Edradour/images/12-24-amber-off.png'
        # 1st
        self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sab', self.diag_prompt)
        rdn_ports = random.sample(list(range(amber_port)), random.randint(1, max_port))
        log.debug(f'turn off led: {rdn_ports}, total:{len(rdn_ports)}')
        for p in rdn_ports:
            # side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} right off', self.diag_prompt)

        scanner.get_right_answer(
            question=f'(1st)As shown in the picture, how many of the {amber_port} amber lights are off?\n'
                     f'(lần đầu)Như hình minh họa, có bao nhiêu trong số {amber_port} đèn màu hổ phách đã tắt?',
            answers=[str(_) for _ in range(6)],
            retry=3,
            right_answer=str(len(rdn_ports)),
            image=img
        )
        # 2nd
        self.uut.send_wise('ethledwrite all right sab', self.diag_prompt)
        led_ports = list(filter(lambda x: x not in rdn_ports, list(range(amber_port))))
        rdn_ports = random.sample(led_ports, random.randint(1, max_port))
        log.debug(f'turn off led: {rdn_ports}, total:{len(rdn_ports)}')
        for p in rdn_ports:
            # side = random.choice(['right', 'left'])
            self.uut.send_wise(f'ethledwrite {p} right off', self.diag_prompt)

        scanner.get_right_answer(
            question=f'(2nd)As shown in the picture, how many of the {amber_port} amber lights are off?\n'
                     f'(Lần thứ hai)Như hình minh họa, có bao nhiêu trong số {amber_port} đèn màu hổ phách đã tắt?',
            answers=[str(_) for _ in range(6)],
            retry=3,
            right_answer=str(len(rdn_ports)),
            image=img
        )

    def init_connections(self):
        self.uut = UUT(conn_str=helper.config['uut_conn_str'])
        self.pdu = PDU(conn_str=helper.config['pdu_conn_str'])

    def enter_diag_mode(self):
        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)
        self.uut.send_wise('run bootcmd', self.diag_prompt, 600)

        diag_platform = re.search(r'\*\s+Platform:\s+(.+)', self.uut.buffer)
        if diag_platform is None:
            raise Exception(f'not found platform: {self.mapping.platform} in DIAG')
        diag_platform = diag_platform.group(1).strip()
        if diag_platform != self.mapping.platform:
            raise Exception(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, FAIL')
        log.debug(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, PASS')

        self.quick_set('Check DIAG Part Number')
        diag_pn = re.search(r'\*\s+Part Number:\s+(.+)', self.uut.buffer)
        if diag_pn is None:
            raise Exception(f'not found part numer: {self.mapping.platform} in DIAG')
        diag_pn = diag_pn.group(1).strip()
        if diag_pn != self.mapping.apn.r_val:
            raise Exception(f'diag platform, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, FAIL')
        log.debug(f'diag part number, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, PASS')

    def get_uut_diag(self):
        self.setup_u_boot_env()
        self.uut.send_wise('run bootcmd', self.diag_prompt, 360)
        self.sleep_time(5)

    def setup_u_boot_env(self):
        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=1008M'", self.u_boot_prompt)
        # self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"', self.u_boot_prompt)

        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)
        # self.uut.send_wise(f"setenv diag_file Edradour_DIAG_v2.0.6_uImage_initramfs.img", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)

    def check_ideeprom(self):
        # 注意此处的检查项目要和上面写的项目保持一致
        self.uut.send_wise('ideeprom show CPU_EEPROM', self.diag_prompt)
        targets = [
            self.mapping.jedec,
            self.mapping.eeprom_ver,
            self.mapping.bit_field,
            self.mapping.aver_maj,
            self.mapping.aver_min,

            self.mapping.arev,
            self.mapping.afg,
            self.mapping.mac_mc,
            self.mapping.mac_fv,
            self.mapping.mac_ent,
            self.mapping.msi,
            self.mapping.clei,
            self.mapping.mrev_maj,
            self.mapping.mrev_min,

            # year month day
            # self.mapping.asd,
            # self.mapping.asm,
            # self.mapping.asy,
            #
            self.mapping.aid,
            self.mapping.apn,
            self.mapping.mn,
            #
            self.mapping.mac,
            self.mapping.asn,
            self.mapping.chas_sn,
        ]
        for tg in targets:
            log.debug(f'verify: {tg}')
            captured = re.search(f'{re.escape(tg.r_name)}: ([^\r\n]*)', self.uut.buffer)
            if captured is None:
                raise Exception(f'not found {tg.r_name}!!!')
            captured = captured.group(1).strip()
            if captured != tg.r_val:
                log.error(f'{tg.r_name}, expected: {tg.r_val}, captured: {captured}, FAIL')
                raise Exception(f'{tg.r_name} mismatch!')
            log.debug(f'{tg.r_name}, expected: {tg.r_val}, captured: {captured}, PASS')


class POE(BFT):
    area = 'POE'

    def check_diag_version(self, check=None):
        self.uut.send_wise('version', self.diag_prompt)
        # diag
        diag_version = re.search(r'DIAG\s*:\s*(.*)', self.uut.buffer)
        if diag_version is None:
            log.error(
                f'[Pass Criteria] diag version: None, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('not found diag version!!')
        diag_version = diag_version.group(1).strip()
        if (diag_version != self.mapping.diag_version) and (diag_version != self.mapping.old_diag_version):
            log.error(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('diag version not match!!')
        log.debug(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: PASS')

        # uboot
        uboot_version = re.search(r'Uboot\s*:\s*(.*)', self.uut.buffer)
        if uboot_version is None:
            log.error(
                f'[Pass Criteria] uboot version: None, expect value:{self.mapping.check_u_boot_version}, result: FAIL')
            raise Exception('not found diag version!!')
        uboot_version = uboot_version.group(1).strip()
        if uboot_version != self.mapping.check_u_boot_version:
            log.error(
            f'[Pass Criteria] Uboot version: {uboot_version}, expect value:{self.mapping.check_u_boot_version}, result: FAIL')
            raise Exception('Uboot version not match!!')
        log.debug(
            f'[Pass Criteria] Uboot version: {uboot_version}, expect value:{self.mapping.check_u_boot_version}, result: PASS')

        # cpld
        # cpld_version = re.search(r'CPLD\s*:\s*(.*)', self.uut.buffer)
        # if cpld_version is None:
        #     log.error(
        #         f'[Pass Criteria] CPLD version: None, expect value:{self.mapping.cpld_version}, result: FAIL')
        #     raise Exception('not found diag version!!')
        # cpld_version = cpld_version.group(1).strip()
        # if cpld_version != self.cpld_diag_version:
        #     # todo special 48MP sn no need check secondary CPLD
        #     if (self.sernum in NONE_CHECK_SECONDARY_CPLD_48MP_SN) and (check == 'secondary'):
        #         log.debug(f'SN: {self.sernum}, no need check secondary CPLD !')
        #         log.debug(f"No need check list: {NONE_CHECK_SECONDARY_CPLD_48MP_SN}")
        #     # todo special 12MP&24MP sn no need check secondary CPLD
        #     elif (self.sernum in NONE_CHECK_SECONDARY_CPLD_12_24MP_SN) and (check == 'secondary'):
        #         log.debug(f'SN: {self.sernum}, no need check secondary CPLD !')
        #         log.debug(f"No need check list: {NONE_CHECK_SECONDARY_CPLD_12_24MP_SN}")
        #     else:
        #         log.error(
        #         f'[Pass Criteria] CPLD version: {cpld_version}, expect value:{self.mapping.cpld_version}, result: FAIL')
        #         raise Exception('Uboot version not match!!')
        # log.debug(
        #     f'[Pass Criteria] CPLD version: {cpld_version}, expect value:{self.mapping.cpld_version}, result: PASS')

        if 'P' in self.mapping.platform:
            # poe
            poe_version = re.search(r'PoE  : (\S+)', self.uut.buffer)
            if poe_version is None:
                log.error(
                f'[Pass Criteria] POE version: None, expect value:{self.mapping.bft_poe}, result: FAIL')
                raise Exception(f'not found expected Poe version: {self.mapping.bft_poe}')
            poe_version = poe_version.group(1)
            if poe_version not in self.mapping.bft_poe:
                log.error(
                f'[Pass Criteria] POE version: {poe_version}, expect value:{self.mapping.bft_poe}, result: FAIL')
                # todo debug skip
                raise Exception('POE version mismatch')
            log.debug(
                f'[Pass Criteria] POE version: {poe_version}, expect value:{self.mapping.bft_poe}, result: PASS')

        # EPDM
        if self.mapping.group == 'G1':
            log.debug('G1 need to check EPDM')
            epdm_version = re.search(r'EPDM\s*:\s*(.*)', self.uut.buffer)
            if epdm_version is None:
                log.error(
                    f'[Pass Criteria] EPDM version: None, expect value:{self.mapping.epdm}, result: FAIL')
                raise Exception('not found epdm version!!')
            epdm_version = epdm_version.group(1).strip()
            if epdm_version != self.mapping.epdm:
                log.error(
                    f'[Pass Criteria] EPDM version: {epdm_version}, expect value:{self.mapping.epdm}, result: FAIL')
                raise Exception('epdm version not match!!')
            log.debug(
                f'[Pass Criteria] EPDM version: {epdm_version}, expect value:{self.mapping.epdm}, result: PASS')

        self.uut.send_wise('cpuinfo', self.diag_prompt)
        cpu_device = re.search(r'Device\s*:.*\(([^)]+)\)', self.uut.buffer)
        if cpu_device is None:
            log.error(
                f'[Pass Criteria] CPU device: None, expect value:{self.mapping.cpu_device}, result: FAIL')
            raise Exception('not CPU device version!!')
        cpu_device = cpu_device.group(1).strip()
        if cpu_device != self.mapping.cpu_device:
            log.error(
                f'[Pass Criteria] CPU device: {cpu_device}, expect value:{self.mapping.cpu_device}, result: FAIL')
            raise Exception('CPU device not match!!')
        log.debug(
            f'[Pass Criteria] CPU device: {cpu_device}, expect value:{self.mapping.cpu_device}, result: PASS')

    def enter_diag_mode(self):
        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)
        self.uut.send_wise('run bootcmd', [self.diag_prompt, self.u_boot_prompt], 600)
        if "Wrong Image Format" in self.uut.buffer:
            self.boot_diag()
            self.create_vfat_paration()
        else:
            diag_platform = re.search(r'\*\s+Platform:\s+(.+)', self.uut.buffer)
            if diag_platform is None:
                raise Exception(f'not found platform: {self.mapping.platform} in DIAG')
            diag_platform = diag_platform.group(1).strip()
            if diag_platform != self.mapping.platform:
                raise Exception(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, FAIL')
            log.debug(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, PASS')

            self.quick_set('Check DIAG Part Number')
            diag_pn = re.search(r'\*\s+Part Number:\s+(.+)', self.uut.buffer)
            if diag_pn is None:
                raise Exception(f'not found part numer: {self.mapping.platform} in DIAG')
            diag_pn = diag_pn.group(1).strip()
            if diag_pn != self.mapping.apn.r_val:
                raise Exception(f'diag platform, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, FAIL')
            log.debug(f'diag part number, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, PASS')
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)

    def check_ideeprom(self):
        # 注意此处的检查项目要和上面写的项目保持一致
        self.uut.send_wise('ideeprom show CPU_EEPROM', self.diag_prompt)
        targets = [
            self.mapping.jedec,
            self.mapping.eeprom_ver,
            self.mapping.bit_field,
            self.mapping.aver_maj,
            self.mapping.aver_min,

            self.mapping.arev,
            self.mapping.afg,
            self.mapping.mac_mc,
            self.mapping.mac_fv,
            self.mapping.mac_ent,
            self.mapping.msi,
            self.mapping.clei,
            self.mapping.mrev_maj,
            self.mapping.mrev_min,

            # year month day
            # self.mapping.asd,
            # self.mapping.asm,
            # self.mapping.asy,
            #
            self.mapping.aid,
            self.mapping.apn,
            self.mapping.mn,
            #
            self.mapping.mac,
            self.mapping.asn,
            self.mapping.chas_sn,
        ]
        for tg in targets:
            log.debug(f'verify: {tg}')
            captured = re.search(f'{re.escape(tg.r_name)}: ([^\r\n]*)', self.uut.buffer)
            if captured is None:
                raise Exception(f'not found {tg.r_name}!!!')
            captured = captured.group(1).strip()
            if captured != tg.r_val:
                log.error(f'{tg.r_name}, expected: {tg.r_val}, captured: {captured}, FAIL')
                raise Exception(f'{tg.r_name} mismatch!')
            log.debug(f'{tg.r_name}, expected: {tg.r_val}, captured: {captured}, PASS')

    def poe_and_traffic_test(self):
        # helper.quick_set('Set Full Speed')
        # self.set_full_speed()
        helper.quick_set('PoE Traffic Test')
        self.poe_traffic_test()


class TRAFFIC(POE):
    area = 'TRAFFIC'

    traffic_mode = "extp"
    golden_power = None
    golden_power_port = None
    golden_uut = None

    def enter_diag_mode(self):
        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)
        self.uut.send_wise('run bootcmd', [self.diag_prompt, self.u_boot_prompt], 600)
        if "Wrong Image Format" in self.uut.buffer:
            self.boot_diag()
            self.create_vfat_paration()
        else:
            diag_platform = re.search(r'\*\s+Platform:\s+(.+)', self.uut.buffer)
            if diag_platform is None:
                raise Exception(f'not found platform: {self.mapping.platform} in DIAG')
            diag_platform = diag_platform.group(1).strip()
            if diag_platform != self.mapping.platform:
                raise Exception(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, FAIL')
            log.debug(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, PASS')

            self.quick_set('Check DIAG Part Number')
            diag_pn = re.search(r'\*\s+Part Number:\s+(.+)', self.uut.buffer)
            if diag_pn is None:
                raise Exception(f'not found part numer: {self.mapping.platform} in DIAG')
            diag_pn = diag_pn.group(1).strip()
            if diag_pn != self.mapping.apn.r_val:
                raise Exception(f'diag platform, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, FAIL')
            log.debug(f'diag part number, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, PASS')
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)

    def boot_diag(self):

        self.setup_u_boot_env()

        # download DIAG
        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.diag_file}', self.u_boot_prompt, 300)
            if 'Bytes transferred =' not in self.uut.buffer:
                self.error(f'download diag file failed, edradour/{self.mapping.diag_file}')
                if scanner.yes_or_enter_to_continue(
                        question=f'Download DIAG img failed! retest? '
                                 f'下载DIAG文件失败！重试？'
                                 f'Tải xuống tệp DIAG không thành công! Thử lại?') is False:
                    raise Exception(f'download diag img file failed!')
                continue
            break

        # self.uut.send_wise('mmc erase 0 102400', self.u_boot_prompt)
        # self.uut.send_wise('mmc write 0x6a000000 0 102400', self.u_boot_prompt)
        # self.uut.send_wise('run bootcmd', '')
        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('bootm ${loadaddr}#wh3p',
                               '')
        else:
            self.uut.send_wise('bootm ${loadaddr}#wh3pe',
                               '')

        self.uut.waitfor(self.diag_prompt, 600)
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)

        # diag version
        self.uut.send_wise('version', self.diag_prompt)
        diag_version = re.search(r'DIAG\s*:\s*(.*)', self.uut.buffer)
        if diag_version is None:
            log.error(
                f'[Pass Criteria] diag version: None, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('not found diag version!!')
        diag_version = diag_version.group(1).strip()
        if diag_version != self.mapping.diag_version:
            log.error(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('diag version not match!!')
        log.debug(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: PASS')

    def init_connections(self):
        self.uut = UUT(conn_str=helper.config['uut_conn_str'])
        if helper.config['server'] == "fxvdcn131":
            self.pdu = APC(conn_str=helper.config['pdu_conn_str'])
        else:
            self.pdu = PDU(conn_str=helper.config['pdu_conn_str'])

    def select_traffic_mode(self):
        ans = scanner.ask_question(question="Please select traffic mode (exts or extp)", answers=["exts", "extp"])
        self.traffic_mode = ans.lower()
        if self.traffic_mode == "exts":
            cn = helper.container_number
            parts = helper.config['uut_conn_str'].split()
            ip = parts[1]
            port = int(parts[2])
            if int(cn) % 2 == 0:
                golden_port = port - 1
                self.golden_power_port = str(int(helper.config['pdu_port']) - 1)
                # self.golden_power = PDU(conn_str=self.golden_power_port)
                self.golden_uut = UUT(name="UUT2", conn_str=f"telnet {ip} {port - 1}")
            else:
                golden_port = port + 1
                self.golden_power_port = str(int(helper.config['pdu_port']) + 1)
                # self.golden_power = PDU(conn_str=self.golden_power_port)
                self.golden_uut = UUT(name="UUT2", conn_str=f"telnet {ip} {port + 1}")
            scanner.yes_or_enter_to_continue(question=f"Please connect Golden UUT console ({golden_port}), and power cable")
            self.golden_uut.do_connect(close_before_open=True)

    def power_cycle_golden_u_boot(self):
        if self.traffic_mode == "extp":
            return helper.SKIP

        while True:
            try:
                self.pdu.power_cycle(self.golden_power_port)
                self.golden_uut.send_wise('', 'U-Boot', 30)
                break
            except Exception as e:
                if scanner.yes_or_enter_to_continue(
                        question='(Pre Check Step 2)\n'
                                 'Please check the Golden UUT power supply and cables are connected well again',
                        image='Edradour/images/check_power_console.png',
                ) is False:
                    raise Exception('OP Stop Test!')
        self.wait_for_golden_u_boot()

    def power_cycle_u_boot(self):
        # msg = '[U BOOT] Please power cycle UUT. 请拔下电源然后重新上电'
        # if scanner.yes_or_enter_to_continue(question=msg) is False:
        #     raise Exception('power cycle UUT failed! operator!')
        while True:
            try:
                self.pdu.power_cycle(helper.config['pdu_port'])
                self.uut.send_wise('', 'U-Boot', 30)
                break
            except Exception as e:
                if scanner.yes_or_enter_to_continue(
                        question='(Pre Check Step 2)\n'
                                'Vui lòng kiểm tra lại nguồn điện và cáp đã được kết nối tốt chưa\n'
                                 'Please check the power supply and cables are connected well again',
                        image='Edradour/images/check_power_console.png',
                ) is False:
                    raise Exception('OP Stop Test!')
        self.wait_for_u_boot()

    def wait_for_u_boot(self, check=None):
        self.uut.waitfor(['Hit any key to stop autoboot', 'Do you want to run the Shmoo? [y/N]',
                          '*** U-Boot Boot Menu ***', self.u_boot_prompt],
                         600)
        log.debug(f'found -> {self.uut.foundphrase}')
        self.check_u_boot_info_poe(check=check)
        # Current Boot Bank: 	1
        current_boot_bank = re.search(r'Current Boot Bank:\s+(\d+)', self.uut.buffer)
        if current_boot_bank is not None:
            current_boot_bank = current_boot_bank.group(1)
        log.debug(f'current boot bank: {current_boot_bank}')

        # JNPR U BOOT
        if '*** U-Boot Boot Menu ***' in self.uut.buffer:
            time.sleep(0.5)
            self.uut.send_esc(['Hit any key to stop autoboot', self.u_boot_prompt])
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Do you want to run the Shmoo? [y/N]' in self.uut.buffer:
            self.uut.send_wise('N', ['Hit any key to stop autoboot', self.u_boot_prompt], 150, suffix='')
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Hit any key to stop autoboot' in self.uut.buffer:
            self.uut.send_esc("")
            self.uut.send_esc("")
            self.uut.send_enter(self.u_boot_prompt)
            log.debug(f'found -> {self.uut.foundphrase}')

        time.sleep(1)
        self.uut.send_ctrl_c(self.u_boot_prompt)
        return current_boot_bank

    def wait_for_golden_u_boot(self, check=None):
        self.golden_uut.waitfor(['Hit any key to stop autoboot', 'Do you want to run the Shmoo? [y/N]',
                          '*** U-Boot Boot Menu ***', self.u_boot_prompt],
                         600)
        log.debug(f'found -> {self.golden_uut.foundphrase}')

        current_boot_bank = re.search(r'Current Boot Bank:\s+(\d+)', self.golden_uut.buffer)
        if current_boot_bank is not None:
            current_boot_bank = current_boot_bank.group(1)
        log.debug(f'current boot bank: {current_boot_bank}')

        # JNPR U BOOT
        if '*** U-Boot Boot Menu ***' in self.uut.buffer:
            time.sleep(0.5)
            self.golden_uut.send_esc(['Hit any key to stop autoboot', self.u_boot_prompt])
            log.debug(f'found -> {self.golden_uut.foundphrase}')

        if 'Do you want to run the Shmoo? [y/N]' in self.golden_uut.buffer:
            self.golden_uut.send_wise('N', ['Hit any key to stop autoboot', self.u_boot_prompt], 150, suffix='')
            log.debug(f'found -> {self.golden_uut.foundphrase}')

        if 'Hit any key to stop autoboot' in self.golden_uut.buffer:
            self.golden_uut.send_esc("")
            self.golden_uut.send_esc("")
            self.golden_uut.send_enter(self.u_boot_prompt)
            log.debug(f'found -> {self.golden_uut.foundphrase}')

        time.sleep(1)
        self.golden_uut.send_ctrl_c(self.u_boot_prompt)
        return current_boot_bank

    def enter_golden_diag_mode(self):
        if self.traffic_mode == "extp":
            return helper.SKIP

        self.golden_uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.golden_uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.golden_uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.golden_uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)
        self.golden_uut.send_wise('run bootcmd', self.diag_prompt, 600)

        # diag_platform = re.search(r'\*\s+Platform:\s+(.+)', self.golden_uut.buffer)
        # if diag_platform is None:
        #     raise Exception(f'not found platform: {self.mapping.platform} in DIAG')
        # diag_platform = diag_platform.group(1).strip()
        # if diag_platform != self.mapping.platform:
        #     raise Exception(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, FAIL')
        # log.debug(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, PASS')
        #
        # self.quick_set('Check DIAG Part Number')
        # diag_pn = re.search(r'\*\s+Part Number:\s+(.+)', self.golden_uut.buffer)
        # if diag_pn is None:
        #     raise Exception(f'not found part numer: {self.mapping.platform} in DIAG')
        # diag_pn = diag_pn.group(1).strip()
        # if diag_pn != self.mapping.apn.r_val:
        #     raise Exception(f'diag platform, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, FAIL')
        # log.debug(f'diag part number, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, PASS')

        self.golden_uut.send_wise('bcmcall 0 port ge24-ge27 loopback=rmt', self.diag_prompt, 60)
        self.golden_uut.send_wise('bcmcall 1 port ge24-ge27 loopback=rmt', self.diag_prompt, 60)

    def check_all_ports_status(self, speed=None):
        if self.mapping.platform == 'EX4000-48MP':
            traffic_port_str = "0-7"
            traffic_port_num = 8
        else:
            traffic_port_str = "0-3"
            traffic_port_num = 4
        while True:
            self.uut.send_wise(f'port all status', self.diag_prompt, 180)

            # port 52 53(48 P/T/MP) link down is true failure
            ports = re.findall(r'^P(\d+)\s+(\S+)\s+', self.uut.buffer, flags=re.M)
            if len(ports) != self.mapping.traffic_port_num:
                raise Exception(f'expected port num: {self.mapping.traffic_port_num}, got: {len(ports)}')

            down_ports = [p[0] for p in ports if p[1].upper() != 'UP']
            if len(down_ports) != 0:
                question = (f'Some ports are down! {",".join(down_ports)}\n'
                            f'这些端口是没起来，请检查：{",".join(down_ports)}\n'
                            f'Một số cổng bị hỏng! Kiểm tra lại? {",".join(down_ports)}')
                if scanner.yes_or_enter_to_continue(question=question) is False:
                    raise Exception(f'traffic test failed, ports are down: {",".join(down_ports)}')
                continue
            log.debug('all ports status OK')
            # all ports are UP
            self.check_port_status(log_text=self.uut.buffer, speed=speed)
            break

    def set_full_speed(self):
        if self.mapping.platform == df.MN_EX4000_12MP:
            self.uut.send_wise('port 0-3 speed 2.5g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_24MP:
            self.uut.send_wise('port 0-3 speed 2.5g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_48MP:
            self.uut.send_wise('port 0-7 speed 2.5g', self.diag_prompt)
        else:
            raise Exception(f'set full speed, unknown platform -> {self.mapping.platform}')

    def set_low_speed(self):
        if self.mapping.platform == df.MN_EX4000_12MP:
            self.uut.send_wise('port 0-3 speed 1g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_24MP:
            self.uut.send_wise('port 0-3 speed 1g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_48MP:
            self.uut.send_wise('port 0-7 speed 1g', self.diag_prompt)
        else:
            raise Exception(f'set low speed, unknown platform -> {self.mapping.platform}')

    def get_snr_value(self):
        if self.mapping.platform not in ['EX4000-48MP', 'EX4000-24MP', 'EX4000-12MP']:
            return

        if self.mapping.platform == 'EX4000-48MP':
            traffic_port_str = "0-7"
            traffic_port_num = 8
        else:
            traffic_port_str = "0-3"
            traffic_port_num = 4

        self.uut.send_wise(f'epdmport {traffic_port_str} snrget', self.diag_prompt, 120)

        pattern = r"EPDM port\s+(\d+)\s*:.*?ChB:\s*([\d.]+)dB"
        matches = re.findall(pattern, self.uut.buffer)
        if not matches:
            raise Exception("No EPDM port ChB data found. Please check the input buffer.")
        # Convert matches to a dictionary for easier access
        port_data = {int(port): float(chb) for port, chb in matches}
        # Check that all ports 0–7 are present
        expected_ports = set(range(traffic_port_num))
        missing_ports = expected_ports - set(port_data.keys())
        if missing_ports:
            raise Exception(f"Missing ChB data for ports: {sorted(missing_ports)}")
        # Verify ChB value range for each port
        status = True
        for port, chb in sorted(port_data.items()):
            if 23 < chb < 33:
                log.debug(f"[Pass Criteria] 23 db < Port {port}: ChB = {chb} dB < 33 db, result PASS")
            else:
                log.error(f"[Pass Criteria] 23 db > Port {port}: ChB = {chb} dB > 33 db, result FAIL")
                status = False
        if not status:
            raise Exception("Check SNR ChB value failed")

        # Regex to match EPDM port and all channel values
        pattern = (
            r"EPDM port\s+(\d+)\s*:.*?"
            r"ChA:\s*([\d.]+)dB.*?"
            r"ChB:\s*([\d.]+)dB.*?"
            r"ChC:\s*([\d.]+)dB.*?"
            r"ChD:\s*([\d.]+)dB"
        )
        matches = re.findall(pattern, self.uut.buffer)

        status = True

        # === Check if any ports were matched ===
        if not matches:
            log.error("No EPDM port data found!")
            helper.quick_set("No EPDM data found")
            raise Exception("No EPDM data found")

        # === Check if all 4 expected ports (0–3) are present ===
        found_ports = sorted(int(port) for port, *_ in matches)
        expected_ports = range(traffic_port_num)
        missing_ports = [p for p in expected_ports if p not in found_ports]

        if missing_ports:
            log.error(f"Missing ports: {missing_ports}")
            status = False
        # === Check each port and channel ===
        for port, cha_str, chb_str, chc_str, chd_str in matches:
            port = int(port)
            try:
                cha, chb, chc, chd = map(float, [cha_str, chb_str, chc_str, chd_str])
            except ValueError:
                log.error(f"Port {port}: Invalid numeric format in channel values.")
                status = False
                continue
            channel_values = {"ChA": cha, "ChB": chb, "ChC": chc, "ChD": chd}
            for ch_name, value in channel_values.items():
                # Check for missing value
                if value is None or value == "":
                    log.error(f"Port {port}: Missing {ch_name} value.")
                    status = False
                    continue
                # Check range
                if 25 <= value <= 110:
                    log.debug(f"[Pass Criteria] 25 db <= Port {port}: {ch_name} = {value} dB <= 110 db, result: PASS")
                else:
                    log.error(f"[Pass Criteria] Port {port}: {ch_name} = {value} dB out of range (25–110), result: FAIL")
                    status = False
        # === Final result ===
        if not status:
            helper.quick_set("Check SNR port/channel value failed or missing")
            raise Exception("Check SNR port/channel value failed or missing")

    def special_full_speed_traffic_test(self):
        if self.mapping.platform == 'EX4000-48MP':
            traffic_port_str = "0-7"
            traffic_port_num = 8
        else:
            traffic_port_str = "0-3"
            traffic_port_num = 4
        # self.set_full_speed()
        # 等待端口起来
        self.sleep_time(60)
        # 需要在一开始就把网线和SFP都是插好
        self.check_all_ports_status()

        helper.quick_set(f'linespeed {self.traffic_mode} all 5a 256 10 900 mfg bg')
        self.uut.send_wise(f'linespeed {self.traffic_mode} all 5a 256 10 900 mfg bg', self.diag_prompt, 600)
        self.sleep_time(20)
        self.get_snr_value()
        for i in range(6):
            self.sleep_time(120)
            self.get_snr_value()
        self.stop_traffic_test_and_check(self.mapping.traffic_port_num, 1_000_000)
        self.get_snr_value()

        helper.quick_set(f'linespeed {self.traffic_mode} all 5a 1518 10 900 mfg bg')
        self.uut.send_wise(f'linespeed {self.traffic_mode} all 5a 1518 10 900 mfg bg', self.diag_prompt, 600)
        self.sleep_time(20)
        self.get_snr_value()
        for i in range(6):
            self.sleep_time(120)
            self.get_snr_value()
        self.stop_traffic_test_and_check(self.mapping.traffic_port_num, 1_000_000)
        self.get_snr_value()

    def check_loopback(self):
        if self.mapping.platform == "EX4000-48MP":
            port = "0-7"
            image = 'Edradour/images/48_traffic_100m.png'
        elif self.mapping.platform == "EX4000-24MP":
            port = "0-3"
            image = 'Edradour/images/24_traffic_100m.png'
        else:
            port = "0-3"
            image = 'Edradour/images/12_traffic_100m.png'
        if yes_or_enter_to_continue(
                question=f'Vui lòng kiểm tra các cổng {port} đang sử dụng cáp mạng dài 100 mét.\n'
                        f'Please check Ports {port} that are using 100-meter network cables.\n'
                         f'请检查Port {port} 使用100米网线',
                image=image,
        ) is False:
            raise Exception('OP Stop Test!')

    def special_low_speed_traffic_test(self):
        if self.mapping.platform == 'EX4000-48MP':
            traffic_port_str = "0-7"
            traffic_port_num = 8
        else:
            traffic_port_str = "0-3"
            traffic_port_num = 4
        self.set_low_speed()
        self.sleep_time(20)

        self.check_all_ports_status()
        self.get_snr_value()

        self.do_traffic_test(f'linespeed {self.traffic_mode} {traffic_port_str} 5a 256 10 900 mfg', traffic_port_num, 1200,
                             min_pkg=100_000)
        self.get_snr_value()
        self.do_traffic_test(f'linespeed {self.traffic_mode} {traffic_port_str} 5a 1518 10 900 mfg', traffic_port_num, 1200,
                             min_pkg=100_000)
        self.get_snr_value()

    def close_all_connections(self):
        self.uut.do_disconnect()
        if self.traffic_mode == "exts":
            self.golden_uut.do_disconnect()

    def power_off(self):
        try:
            self.pdu.power_off(helper.config['pdu_port'])
        except:
            pass


class POE_STEP_VII(POE):

    area = "POE_STEP_7"









