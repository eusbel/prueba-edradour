from gen.libs import lib
from . import product


step = product.Product()


def pre_sequence_definition():
    """
    :return: seq
    """
    seq = lib.get_sequence_definition("PRE SEQ")
    seq.add_step(step.first_step_of_pre_seq, name="First Step Of Pre")
    #
    seq.add_step(step.choose_repository, name="Choose repository")
    seq.add_step(step.get_authentication, name="Get Authentication")
    #
    seq.add_step(step.add_start_test_data_for_main, name="Add S Data for Main")

    return seq


def main_sequence_definition():
    """
    :return: seq
    """
    seq = lib.get_sequence_definition("Main Sequence")
    seq.add_step(step.first_step_of_main_seq, name="First Step Of Main")
    seq.add_step(step.initialize_variables, name="Initialize Variables")

    seq.add_step(step.build_multiple_repository, name="Build Multiple Repository")

    seq.add_step(step.finalization, name="Finalization", finalization=True)
    return seq
