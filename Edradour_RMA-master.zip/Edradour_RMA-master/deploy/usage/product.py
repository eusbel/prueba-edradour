from gen.libs import lib
from .. import deploy
# from ...constants import GITLAB_IP

log = lib.get_seq_logger()


class Product(deploy.Deploy):

    repositories = dict(
        top="https://{}/gitlab/genius/top.git".format("10.125.131.131"),
        Edradour_RMA="https://{}/gitlab/FJZ_Juniper_RMA/Edradour_RMA.git".format("10.125.131.131"),
        Emerald_RMA="https://{}/gitlab/FJZ_Juniper_RMA/Emerald_RMA.git".format("10.125.131.131"),
        Glenlivet_RMA="https://{}/gitlab/FJZ_Juniper_RMA/Glenlivet_RMA.git".format("10.125.131.131")
    )

    servers = dict(fjzodmjnprma01="10.14.146.46",
                   FJZRMA="10.14.146.82")
