import time
import json
import random
import datetime
import socket
import requests
from socket import gethostname
from fnmatch import fnmatch
from http.client import RemoteDisconnected

from gen.libs import lib
from ...top import top

log = lib.get_seq_logger()


class Deploy(top.TOP):
    repositories = dict()  # User should override it
    servers = dict()  # User should override it

    #
    repository = ""
    repository_list = list()
    server_list = list()

    def choose_repository(self):
        """ If sernum is DUMMY, will not do record. but still will route to correct main-seq.
        :return:
        """
        uuttype_list = list(self.repositories.keys())
        self.repository_list = self.ask_question("Please Choose Repository:", answers=uuttype_list, multiple=True)
        if len(self.repository_list) == 1:
            self.repository = self.repository_list[0]
        log.debug(self.repository_list)
        self.sernum = "DUMMY"
        self.uuttype = self.configuration_data.get("uuttype")
        log.debug("Serial Number - [{}]".format(self.sernum))
        log.debug("UUT Type - [{}]".format(self.uuttype))
        return

    def choose_server(self):
        """ Choose server to distribute script
        :return:
        """
        server_list = list(self.servers.keys())
        self.server_list = self.ask_question("Please Choose Server:", answers=server_list, multiple=True)
        log.debug(self.server_list)
        return

    def initialize_variables(self):
        """
        :return:
        """
        self.uut = lib.conn.UUT
        self.uut.close()
        log.debug("Current Area - [{}]".format(self.area))  # default is Station Name
        return

    def build_multiple_repository(self):
        """

        :return:
        """
        self.uut.open()
        for repository in self.repository_list:
            self.set_display3("Build {}".format(repository))
            self.repository = repository
            self.build_repository()
        self.uut.close()
        return

    def build_repository(self):
        """ 1. remove current repository
            2. clone repository
            3. get remote tag list, and find the latest one.
            4. create a new tag base on remote latest one.
            5. commit/push new tag.
            6. archive new tag with .tar.gz format.
            7. upload .tar.gz tag to test log server.
            8. delete local repository
        :return:
        """
        self.uut.open()
        # Step 1
        self.uut.send("cd /tmp\r".format(self.repository), expectphrase="]$", timeout=60)
        self.uut.send("rm -rf {}\r".format(self.repository), expectphrase="]$", timeout=60)
        # Step 2
        self.uut.send("git clone {}\r".format(self.repositories[self.repository]), expectphrase=["unable to access", "Username", "done"], timeout=60)
        if "unable to access" in self.uut.recbuf:
            gitlab_link = "https://10.125.131.131/gitlab/genius/{}.git".format(self.repository)
            self.uut.send("git clone {}\r".format(gitlab_link), expectphrase=["unable to access", "Username", "done"], timeout=60)
        # if "username" in self.uut.recbuf:
        #     time.sleep(1)
        #     self.uut.send("{}\r".format(self.username), expectphrase="password", timeout=60)
        #     time.sleep(1)
        #     self.uut.send("{}\r".format(self.password), expectphrase="]$", timeout=60 * 5, visible=False)
        #     if "successfully" not in self.uut.recbuf:
        #         self.go_to_failure("Clone repo {} failed.".format(self.repository))
        #     self.uut.send("cd {}\r".format(self.repository), expectphrase="]$", timeout=60)

        if "Username" in self.uut.recbuf:
            time.sleep(1)
            self.uut.send("{}\r".format(self.username), expectphrase="Password", timeout=60)
            time.sleep(1)
            self.uut.send("{}\r".format(self.password), expectphrase="]$", timeout=60 * 10, visible=False)
            if "done." not in self.uut.recbuf:
                self.go_to_failure("Clone repo {} failed.".format(self.repository))
            self.uut.send("cd {}\r".format(self.repository), expectphrase="]$", timeout=60)

        # Step 3
        date_stamp = datetime.datetime.now().strftime("%Y%m%d")
        self.uut.send("git fetch --tags\r", expectphrase=["Username", "]$"], timeout=60)
        if "Username" in self.uut.recbuf:
            time.sleep(1)
            self.uut.send("{}\r".format(self.username), expectphrase="Password", timeout=60)
            time.sleep(1)
            self.uut.send("{}\r".format(self.password), expectphrase="]$", timeout=60, visible=False)

            self.uut.send("git describe --tags `git rev-list --tags --max-count=1`\r", expectphrase="]$", timeout=60)
            if "No names found" in self.uut.recbuf:
                latest_tag = "v0.0.0_{}".format(date_stamp)
            else:
                latest_tag = self.uut.recbuf.splitlines()[1]

        else:  # mean there is not tag at all.
            latest_tag = "v0.0.0_{}".format(date_stamp)
        log.debug("Remote latest tag - [{}]".format(latest_tag))
        # Step 4
        new_version = latest_tag.strip("v").split("_")[0]
        first, second, third = new_version.split(".")
        if int(third) + 1 == 256:
            third = 0
            if int(second) + 1 == 256:
                second = 0
                first = int(first) + 1
            else:
                second = int(second) + 1
        else:
            third = int(third) + 1
        new_tag = "v{}.{}.{}_{}".format(int(first), int(second), int(third), date_stamp)
        log.debug("New tag will be - [{}]".format(new_tag))
        self.uut.send("git config user.email '{}@genius.com'\r".format(self.username), expectphrase="]$", timeout=60)
        self.uut.send("git config user.name '{}'\r".format(self.username), expectphrase="]$", timeout=60)

        # self.uut.send("git tag -d {}'\r".format(new_tag), expectphrase="]$", timeout=60)
        self.uut.send("git tag {} -m '{} create tag'\r".format(new_tag, self.username), expectphrase="]$", timeout=60)
        # Step 5
        self.uut.send("git push origin {}\r".format(new_tag), expectphrase=["Username"], timeout=60)
        if "Username" in self.uut.recbuf:
            time.sleep(1)
            self.uut.send("{}\r".format(self.username), expectphrase="Password", timeout=60)
            time.sleep(1)
            self.uut.send("{}\r".format(self.password), expectphrase="]$", timeout=60, visible=False)
            if "new tag" not in self.uut.recbuf:
                self.go_to_failure("Push new tag [{}] to remote failed".format(new_tag))

        # Step 6
        # add version to local file
        self.uut.send("""echo 'VERSION = "{}"' > __init__.py\r""".format(new_tag), expectphrase="]$", timeout=60)
        package_name = "{}-{}.tar.gz".format(self.repository, new_tag)
        # self.uut.send("git archive --format=tar {} | gzip > {}\r".format(
        #     new_tag, package_name), expectphrase="]$", timeout=60 * 3)

        self.uut.send("rm -rf .git\r", expectphrase="]$", timeout=60)
        self.uut.send("cd /tmp\r", expectphrase="]$", timeout=60)
        self.uut.send("rm -rf {}\r".format(package_name), expectphrase="]$", timeout=60)

        self.uut.send("tar cfz {} {}\r".format(package_name, self.repository), expectphrase="]$", timeout=60 * 3)
        # Step 7
        fusion_server = self.get_hosts("fusion-server")
        if not fusion_server:
            self.go_to_failure("Fusion Server is not defined yet")
        url = "http://{}:8000/genius/upload-repository-package/".format(fusion_server)

        files = {package_name: open("/tmp/{}".format(package_name), "rb")}
        data = {"repository": self.repository}

        # Fake user-agent for `Remote end closed connection without response` Error
        # all these user-agents are faked from python third-part lib `Faker`
        user_agents = [
            'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_10_2 rv:2.0; csb-PL) AppleWebKit/535.19.4 (KHTML, like Gecko) Version/4.0 Safari/535.19.4',
            'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.0; Trident/3.0)',
            'Mozilla/5.0 (compatible; MSIE 8.0; Windows CE; Trident/5.0)',
            'Opera/9.10.(X11; Linux i686; bn-IN) Presto/2.9.190 Version/12.00',
            'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_11_3; rv:1.9.2.20) Gecko/2010-08-31 00:31:56 Firefox/3.8',
            'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_2) AppleWebKit/536.1 (KHTML, like Gecko) Chrome/51.0.897.0 Safari/536.1',
            'Mozilla/5.0 (iPod; U; CPU iPhone OS 3_1 like Mac OS X; sat-IN) AppleWebKit/532.1.7 (KHTML, like Gecko) Version/3.0.5 Mobile/8B113 Safari/6532.1.7',
            'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 5.1; Trident/3.0)',
            'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_9_3) AppleWebKit/532.2 (KHTML, like Gecko) Chrome/53.0.821.0 Safari/532.2',
            'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.2; Trident/3.0)']
        ua = random.choice(user_agents)
        try:
            log.info(f"User-Agent:[{ua}]")
            r = requests.post(url, files=files, data=data, headers={"User-Agent": ua})
        except RemoteDisconnected as e:
            log.warning(f"remote disconnected:[{e}]")
        else:
            log.debug(json.loads(r.text)["payload"]["message"])

        # Step 8
        # split the fusion server as the ssh port 22 permission between different Site. 20240708 Stan
        self.machine = socket.gethostname()
        log.debug(self.machine)
        if self.repository in ["top"]:
            if 'fvn' in self.machine:
                fusion_server = '10.220.192.30'
            if 'fjz' in self.machine:
                fusion_server = "10.14.136.19"
                # fusion_server = ["10.14.136.19", "10.16.39.231"]
                # for s in targets:
                #     self.scp_to_server(s, package_name, "/opt/media/repository/top/")
            if 'fsj' in self.machine:
                fusion_server = '10.16.39.231'
            self.scp_to_server(fusion_server, package_name, "/opt/media/repository/top/")

        if self.repository in ["pure"]:
            if 'fvn' in self.machine:
                fusion_server = '10.220.192.30'
            if 'foc' in self.machine:
                fusion_server = '10.167.16.46'
            if 'fjz' in self.machine:
                fusion_server = '10.16.39.231'    #FSJ fusion
            log.debug(fusion_server)
            self.scp_to_server(fusion_server, package_name, "/opt/media/repository/pure/")

        self.uut.send("rm -rf {}\r".format(self.repository), expectphrase="]$", timeout=60)
        self.uut.send("rm -rf {}\r".format(package_name), expectphrase="]$", timeout=60)

        return

    def distribute_repository(self):
        """
        :return:
        """
        self.uut.open()
        for hostname in self.server_list:
            self.ssh_to_server(self.servers[hostname])
            for repository in self.repository_list:
                self.set_display3("Dist {} to {}".format(repository, hostname))
                self.repository = repository
                self.uut.send("genius prod update2\r", expectphrase="username:", timeout=60)
                self.uut.send("{}\r".format(self.username), expectphrase="password:", timeout=60)
                self.uut.send(
                    "{}\r".format(self.password),
                    expectphrase=["]$", "PROD Repository Name:"],
                    timeout=60,
                    visible=False,
                )
                if "]$" in self.uut.recbuf:
                    self.go_to_failure("Username does not have access to update PROD code.")
                self.uut.send(
                    "{}\r".format(self.repository),
                    expectphrase=["enter for", "an incorrect repository", "Could not find any Package"],
                    timeout=60,
                )
                if "Could not find any Package" in self.uut.recbuf:
                    self.go_to_failure("Could not find any Package, go to failure")
                if "an incorrect repository" in self.uut.recbuf:
                    self.go_to_failure("Incorrect repository name found - {}".format(self.repository))
                time.sleep(0.5)
                self.uut.send("\r", expectphrase="]$", timeout=60)  # default is latest one.
                if "Successfully" not in self.uut.recbuf:
                    self.go_to_failure("Did not get [Successfully] after update PROD code")
            self.uut.send("exit\r", expectphrase="]$", timeout=60)
        return

    def finalization(self):
        # add more information into test data if you would like.
        kwargs = dict(str1name="ios image", str1="xxxxxxxx.ios", str6name="linux image", str6="xxxxxxxx.bin")
        self.add_pass_test_data_for_main(**kwargs)
        return
