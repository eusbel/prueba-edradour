import re
import time

from .common.dcn import TimerMeta
from .common.quantum import Quantum
from .common.utils import helper
from .common.fields import StrField, Field
from .common import sfchelper
from .define import define as df
from .define.define import cookie_mapping, EX4K
from .common import machelper
from .common.uut import UUT
from .common.pdu import PDU
from .common.tpm2 import TPM2
from .common import scanner
from .common.logger import log
from .common.models import GeniusRecordFields


class TPM(Quantum, metaclass=TimerMeta):
    sernum = StrField()
    area = 'TPM'
    product_name = 'Edradour'

    mapping = Field()  # type: EX4K

    fingerprint = Field()  # type: str

    uut = None
    pdu = None
    tpm = None

    u_boot_prompt = 'u-boot>'
    diag_prompt = 'DIAG>'
    bcm_prompt = '#'
    is_fox_uboot = False

    def scan_uut_info(self):
        # 扫描 SN
        ans = scanner.ask_question(question='Please scan label. 请扫描标签。 Quét thẻ SN')
        self.sernum = ans

        self.check_fail_record(sn=self.sernum, station=self.area)

        # 查询 MES LABEL PN
        pn = sfchelper.get_label_part_number_from_mes(sn=self.sernum)

        if pn not in cookie_mapping.keys():
            raise Exception(f'Part Number: {pn} is not supported! acceptable list: {list(cookie_mapping.keys())}')
        self.uuttype = pn

        # 读取预定义数据
        self.mapping = cookie_mapping[pn]

        # if self.mapping.group != 'G1':
        #     raise Exception(f'Only Support G1 Test !')

        # 打印初始化的参数
        log.debug(f'SN: {self.sernum}, Label PN:{pn}, UUTType: {self.uuttype}, Model: {self.mapping.platform}')

        # Double Check mapping APN
        if self.mapping.apn.r_val not in self.uuttype:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn r value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn r val: {self.mapping.apn.r_val}. PASS')

        if self.mapping.apn.w_val not in self.uuttype:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn w value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn w val: {self.mapping.apn.w_val}. PASS')

        # check TAA sku
        data = sfchelper.get_sn_detail_from_mes(self.sernum)
        pn = data.get('SKUNO', None)
        if not pn:
            raise Exception('not found SKU_VER from mes')
        if pn.startswith("750") or ("TAA" in pn):
            self.is_taa = True
            self.uuttype = pn
        log.debug(f"SN {self.sernum} MES SKUNO is {pn}, check TAA sku: {self.is_taa}")

        self.check_label_v2(sn=self.sernum)

        # 记得添加测试记录
        helper.add_record(sn=self.sernum, pn=self.uuttype, area=self.area)

    def check_mes_event(self):
        self.mes_check_event(sn=self.sernum, area=self.area)
        # 检查genius测试工站
        # self.genius_check_event(sn=self.sernum, current_station="RIT")

    def query_mes_mac(self):
        mac, size = sfchelper.get_mac_address_from_mes(wsn=self.sernum)
        if mac is None:
            helper.quick_set('NO MAC FROM MES')
            raise Exception('no MAC from MES!!!')

        if size != self.mapping.mac_block_size:
            helper.quick_set('MAC Block Size Incorrect')
            raise Exception(f'MAC Block Size Incorrect, expected: {self.mapping.mac_block_size}, got: {size}, FAIL!!!')

        mac_helper = machelper.MacAddressHelper()
        mac = mac_helper.convert(mac, lower=True, delimiter=':')
        size = int(size)
        self.mac_address, self.mac_block_size = mac, size
        self.mapping.mac.set(w_val=self.mac_address, r_val=self.mac_address.upper())
        self.mapping.asn.set(w_val=self.sernum, r_val=self.sernum)

    def read_config(self):

        self.mapping.uut_ip = helper.config['uut_ip']
        self.mapping.serverip = helper.config['serverip']
        self.mapping.netmask = helper.config['netmask']

        self.mapping.chas_sn.set(w_val=self.sernum, r_val=self.sernum)

        # TPM
        self.tpm.sn = self.sernum
        self.tpm.model = self.mapping.platform

        self.tpm.uut_ip = self.mapping.uut_ip
        self.tpm.netmask = self.mapping.netmask
        self.tpm.tftp_server = self.mapping.serverip

        self.tpm.tpm2_fw_version = self.mapping.tpm2_fw_version
        self.tpm.tpm2_vendor = self.mapping.tpm2_vendor
        self.tpm.tpm2_manufacturer = self.mapping.tpm2_manufacturer
        self.tpm.tpm2_file = self.mapping.tpm2_file
        self.tpm.tpm2_file_version = self.mapping.tpm2_file_version
        self.tpm.tpm2_file_md5 = self.mapping.tpm2_file_md5
        self.tpm.tpm2_product_id = self.mapping.tpm2_product_id

        self.tpm.tpm2_file_old = self.mapping.tpm2_file_old
        self.tpm.tpm2_file_version_old = self.mapping.tpm2_file_version_old
        self.tpm.tpm2_file_md5_old = self.mapping.tpm2_file_md5_old
        self.tpm.tpm2_product_id_old = self.mapping.tpm2_product_id_old

        self.tpm.dlm_cert_filename = f'{self.sernum}_{helper.get_start_time("%Y%m%d_%H%M%S")}.txt'

        # UTC
        # now = dt.datetime.now(dt.timezone.utc)
        # hex_year = f'{now.year:04X}'
        # self.mapping.asy.set(w_val=hex_year, r_val=f'{hex_year[0:2]} {hex_year[2:4]}')
        # self.mapping.asm.set(w_val=f'{now.month:02X}', r_val=f'{now.month:02X}')
        # self.mapping.asd.set(w_val=f'{now.day:02X}', r_val=f'{now.day:02X}')

        # MES
        rev = sfchelper.get_label_aver_min_from_mes(self.sernum)
        self.mapping.aver_min.set(w_val=rev, r_val=rev)
        self.mapping.arev.set(w_val=rev, r_val=rev)
        model_maj_rev = sfchelper.get_label_model_maj_rev_from_mes(self.sernum)
        self.mapping.mrev_maj.set(w_val=model_maj_rev, r_val=model_maj_rev)

    def get_uut_console(self):
        self.uut.do_connect(close_before_open=True)
        # self.poe.do_connect(close_before_open=True)

    def setup_u_boot_env(self):
        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=1008M'", self.u_boot_prompt)
        # self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"', self.u_boot_prompt)

        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)
        # self.uut.send_wise(f"setenv diag_file Edradour_DIAG_v2.0.6_uImage_initramfs.img", self.u_boot_prompt)

        # if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
        #     self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"',
        #                        self.u_boot_prompt)
        # else:
        #     self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3pe"',
        #                        self.u_boot_prompt)

    def setup_u_boot_env2(self):
        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        # self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        # self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"', self.u_boot_prompt)

        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)

    def check_u_boot_version(self):
        self.quick_set('Check Primary U Boot')
        # change to 1
        self.switch_to_primary_u_boot('a')
        # update u boot, flash is locked! so skip... 2024-11-08
        self.update_u_boot_version('1')
        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(f'[Pass Criteria] primary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception(f'expected primary u boot version: {self.mapping.u_boot_version}, captured: {self.uut.buffer}, FAIL')
        else:
            log.debug(f'[Pass Criteria] primary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: PASS')

        self.quick_set('Check Secondary U Boot')
        # change to 2
        # self.uut.send_wise('fatrm mmc 0 efi/boot/UpdateCapsule/uboot_dev_cap', self.u_boot_prompt)
        self.switch_to_secondary_u_boot()
        # update u boot, flash is locked! so skip... 2024-11-08
        # self.update_u_boot_version('2')
        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(f'[Pass Criteria] secondary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception(f'expected secondary u boot version: {self.mapping.u_boot_version}, captured: {self.uut.buffer}, FAIL')
        else:
            log.debug(f'[Pass Criteria] secondary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: PASS')

        # change back to 1
        self.switch_to_primary_u_boot('b')

    def switch_to_primary_u_boot(self, plan):
        log.debug('switch to primary u boot bank(1)')
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x39 0x2', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x8 0x1a', self.u_boot_prompt)
        if plan == 'a':
            self.uut.send_wise('i2c mw 0x31 0x9 0x1', '')

        # 两颗uboot 更新完后这个地方应该要OK
        elif plan == 'b':
            self.uut.send_wise('i2c mw 0x31 0x9 0x1', 'Validate Shmoo parameters stored in flash ..... OK')
            log.debug('Check Validate Shmoo parameters stored in flash ..... OK')

        boot_bank = self.wait_for_u_boot()
        if boot_bank != '1':
            log.error(f'switch to primary u boot failed! expected boot bank: 1, but now is: {boot_bank}')
            raise Exception(f'switch to primary u boot failed! expected boot bank: 1, but now is: {boot_bank}')
        log.debug(f'switch to u boot bank: {boot_bank} OK')
        return boot_bank

    def update_u_boot_version(self, boot_bank):
        log.debug(f'update u boot bank: {boot_bank}')

        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version in self.uut.buffer:
            log.debug(f'{boot_bank} u boot version is the latest! {self.mapping.u_boot_version}')
            log.debug(f'[Pass Criteria]{boot_bank} u boot version is: {self.mapping.u_boot_version}, expect value:{self.mapping.u_boot_version}, result: PASS')
            self.is_fox_uboot = True
            return

        self.uut.send_wise('fatls  mmc 0:1', self.u_boot_prompt)
        if 'No partition table - mmc 0' in self.uut.buffer:

            self.boot_diag()

            self.uut.send_wise('exit', "login:")
            self.uut.send_wise('root', "#")
            self.uut.send_wise('fdisk /dev/mmcblk0', "Command")
            self.uut.send_wise('n', "primary partition")
            self.uut.send_wise('p', "number")
            self.uut.send_wise('1', "")
            self.sleep_time(1)
            self.uut.send_wise('', "")
            self.sleep_time(1)
            self.uut.send_wise('', "Command")
            self.uut.send_wise('t', "(type L to list codes)")
            self.uut.send_wise('b', "Command")
            self.uut.send_wise('w', "#")
            self.uut.send_wise('mkfs.vfat /dev/mmcblk0p1', "#")
            self.uut.send_wise('reboot', "#")

            # set boot env
            self.wait_for_u_boot()

        log.warning(f'u boot bank: {boot_bank}, need upgrade to version: {self.mapping.u_boot_version}')

        self.uut.send_wise(f'fatrm mmc 0:1 /efi/boot/UpdateCapsule/uboot_prd_cap', self.u_boot_prompt)
        self.uut.send_wise(f'fatrm mmc 0:1 /efi/boot/UpdateCapsule/uboot_dev_cap', self.u_boot_prompt)
        self.uut.send_wise(f'fatrm mmc 0:1 /efi/boot/UpdateCapsule/flash_image', self.u_boot_prompt)

        self.uut.send_wise(f'fatmkdir mmc 0:1 /efi', self.u_boot_prompt)
        self.uut.send_wise(f'fatmkdir mmc 0:1 /efi/boot', self.u_boot_prompt)
        self.uut.send_wise(f'fatmkdir mmc 0:1 /efi/boot/UpdateCapsule', self.u_boot_prompt)

        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # self.uut.send_wise(f'setenv gatewayip {self.mapping.gateway}', self.u_boot_prompt)

        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.u_boot_file}', self.u_boot_prompt)

            if 'TFTP server died' in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(question='TFTP server is died, call TE') is False:
                    raise Exception('tftp server is not online!')
                continue

            if 'Bytes transferred =' not in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(
                        question='not found "Bytes transferred =" in uut buffer, retry?') is False:
                    raise Exception('not found "Bytes transferred =" in uut buffer!')
                continue
            break

        self.uut.send_wise('fatwrite  mmc 0:1 ${loadaddr} efi/boot/UpdateCapsule/uboot_dev_cap 0x800000;', self.u_boot_prompt)
        self.uut.send_wise('fatwrite  mmc 0:1 ${loadaddr} efi/boot/UpdateCapsule/do_upgrade 0;', self.u_boot_prompt)

        self.uut.send_wise('reset', '')
        self.wait_for_u_boot()
        self.uut.send_wise('', self.u_boot_prompt)

        # self.setup_u_boot_env()
        # # download
        # self.u_boot_tftp_download()
        #
        # self.uut.send_wise('sf probe; sf erase 0x0 0x800000; sf write 0x6a000000 0x0 0x800000', self.u_boot_prompt)
        # if 'Erased: OK' not in self.uut.buffer:
        #     raise Exception('erase failed!')
        # if 'Written: OK' not in self.uut.buf:
        #     raise Exception('write failed!')
        #
        # self.sleep_time(3)
        # # Reset之后新版本才会生效
        # self.uut.send_wise('reset', '')
        # current_boot_bank = self.wait_for_u_boot()
        # if current_boot_bank != '1':
        #     raise Exception(f'current boot bank should be {boot_bank}, but now is: {current_boot_bank}')

        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(
                f'[Pass Criteria]{boot_bank} u boot version is: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception(f'upgrade u boot failed!')
        log.debug(f'boot bank: {boot_bank}\' u boot version is the latest. {self.mapping.u_boot_version}')
        log.debug(
        f'[Pass Criteria]{boot_bank} u boot version is: {self.mapping.u_boot_version}, expect value:{self.mapping.u_boot_version}, result: PASS')

    def switch_to_secondary_u_boot(self):
        log.debug('switch to secondary u boot bank(2)')
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x39 0x3', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x8 0x1a', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x9 0x1', '')
        boot_bank = self.wait_for_u_boot()
        if boot_bank != '2':
            log.error(f'switch to primary u boot failed! expected boot bank: 2, but now is: {boot_bank}')
            raise Exception(f'switch to primary u boot failed! expected boot bank: 2, but now is: {boot_bank}')
        log.debug(f'switch to u boot bank: {boot_bank} OK')
        return boot_bank

    def enter_diag_mode(self):
        if not self.is_fox_uboot:
            return
        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)
        self.uut.send_wise('run bootcmd', [self.diag_prompt, self.u_boot_prompt], 600)
        if "Wrong Image Format" in self.uut.buffer:
            self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
            self.uut.send_wise(f"setenv diag_file {self.mapping.old_diag_file}", self.u_boot_prompt)

            if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
                self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                                   self.u_boot_prompt)
            else:
                self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                                   self.u_boot_prompt)
            self.uut.send_wise('run bootcmd', [self.diag_prompt, self.u_boot_prompt], 600)
            if "Wrong Image Format" in self.uut.buffer:
                self.is_fox_uboot = False
                self.boot_diag()
                self.create_vfat_paration()
                return

        diag_platform = re.search(r'\*\s+Platform:\s+(.+)', self.uut.buffer)
        if diag_platform is None:
            raise Exception(f'not found platform: {self.mapping.platform} in DIAG')
        diag_platform = diag_platform.group(1).strip()
        if diag_platform != self.mapping.platform:
            raise Exception(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, FAIL')
        log.debug(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, PASS')

        self.quick_set('Check DIAG Part Number')
        diag_pn = re.search(r'\*\s+Part Number:\s+(.+)', self.uut.buffer)
        if diag_pn is None:
            raise Exception(f'not found part numer: {self.mapping.platform} in DIAG')
        diag_pn = diag_pn.group(1).strip()
        if diag_pn != self.mapping.apn.r_val:
            raise Exception(f'diag platform, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, FAIL')
        log.debug(f'diag part number, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, PASS')
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)

    def wait_for_u_boot(self):
        self.uut.waitfor(['Hit any key to stop autoboot', 'Do you want to run the Shmoo? [y/N]',
                          '*** U-Boot Boot Menu ***', self.u_boot_prompt],
                         600)
        log.debug(f'found -> {self.uut.foundphrase}')
        # Current Boot Bank: 	1
        current_boot_bank = re.search(r'Current Boot Bank:\s+(\d+)', self.uut.buffer)
        if current_boot_bank is not None:
            current_boot_bank = current_boot_bank.group(1)
        log.debug(f'current boot bank: {current_boot_bank}')

        # check U Boot Info
        self.check_u_boot_info(check=False)

        # JNPR U BOOT
        if '*** U-Boot Boot Menu ***' in self.uut.buffer:
            time.sleep(0.5)
            self.uut.send_esc(['Hit any key to stop autoboot', self.u_boot_prompt])
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Do you want to run the Shmoo? [y/N]' in self.uut.buffer:
            self.uut.send_wise('N', ['Hit any key to stop autoboot', self.u_boot_prompt], 150, suffix='')
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Hit any key to stop autoboot' in self.uut.buffer:
            self.uut.send_esc(self.u_boot_prompt)
            log.debug(f'found -> {self.uut.foundphrase}')

        time.sleep(1)
        self.uut.send_ctrl_c(self.u_boot_prompt)
        return current_boot_bank

    def boot_diag(self):
        if self.is_fox_uboot:
            return helper.SKIP
        self.setup_u_boot_env()

        # download DIAG
        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.diag_file}', self.u_boot_prompt, 300)
            if 'Bytes transferred =' not in self.uut.buffer:
                self.error(f'download diag file failed, edradour/{self.mapping.diag_file}')
                if scanner.yes_or_enter_to_continue(
                        question=f'Download DIAG img failed! retest? '
                                 f'下载DIAG文件失败！重试？'
                                 f'Tải xuống tệp DIAG không thành công! Thử lại?') is False:
                    raise Exception(f'download diag img file failed!')
                continue
            break

        # self.uut.send_wise('mmc erase 0 102400', self.u_boot_prompt)
        # self.uut.send_wise('mmc write 0x6a000000 0 102400', self.u_boot_prompt)
        # self.uut.send_wise('run bootcmd', '')
        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('bootm ${loadaddr}#wh3p',
                               '')
        else:
            self.uut.send_wise('bootm ${loadaddr}#wh3pe',
                               '')

        self.uut.waitfor(self.diag_prompt, 600)

        # diag version
        self.uut.send_wise('version', self.diag_prompt)
        diag_version = re.search(r'DIAG\s*:\s*(.*)', self.uut.buffer)
        if diag_version is None:
            log.error(
                f'[Pass Criteria] diag version: None, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('not found diag version!!')
        diag_version = diag_version.group(1).strip()
        if diag_version != self.mapping.diag_version:
            log.error(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('diag version not match!!')
        log.debug(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: PASS')
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)

    def check_u_boot_info(self, check):
        if check:
            if "JUNIPER HARDWARE ROOT OF TRUST WITH SECURE BOOT ENFORCED" not in self.uut.buffer:
                log.error("Not found: 'JUNIPER HARDWARE ROOT OF TRUST WITH SECURE BOOT ENFORCED' in Uboot info")
                helper.set_display3("Check TPM Program FAIL")
                raise Exception("Check TPM Program FAIL")
            else:
                log.debug("Found: 'JUNIPER HARDWARE ROOT OF TRUST WITH SECURE BOOT ENFORCED', This unit TPM program done")

        u_boot_mn = re.search(r'Board\s*:\s+(\S+)', self.uut.buffer)
        if u_boot_mn is None:
            helper.quick_set('Not found U Boot Model')
            raise Exception('not found u boot Model!!')
        u_boot_mn = u_boot_mn.group(1)
        if u_boot_mn != self.mapping.platform:
            helper.quick_set('U Boot Model Mismatch')
            log.error(f'u boot model match! expected: {self.mapping.platform}, captured: {u_boot_mn}. FAIL')
            raise Exception(f'u boot model mismatch! expected: {self.mapping.platform}, captured: {u_boot_mn}. FAIL')
        log.debug(f'u boot model match! expected: {self.mapping.platform}, captured: {u_boot_mn}. PASS')

        u_boot_sn = re.search(r'Serial\s*:\s+(\S+)', self.uut.buffer)
        if u_boot_sn is None:
            helper.quick_set('Not found U Boot SN')
            raise Exception('not found u boot SN!')
        u_boot_sn = u_boot_sn.group(1)
        if u_boot_sn != self.sernum:
            helper.quick_set('U Boot SN Mismatch')
            log.error(f'u boot sn match! expected: {self.sernum}, captured: {u_boot_sn}. FAIL')
            raise Exception(f'u boot sn mismatch! expected: {self.sernum}, captured: {u_boot_sn}. FAIL')
        log.debug(f'u boot sn match! expected: {self.sernum}, captured: {u_boot_sn}. PASS')

        u_boot_base_mac = re.search(r'Base MAC\s*:\s+(\S+)', self.uut.buffer)
        if u_boot_base_mac is None:
            helper.quick_set('Not found U Boot MAC')
            raise Exception('not found u boot base MAC!')
        u_boot_base_mac = u_boot_base_mac.group(1)
        if u_boot_base_mac != self.mapping.mac.r_val:
            helper.quick_set('U Boot MAC Mismatch')
            log.error(f'u boot base mac match! expected: {self.mapping.mac.r_val}, captured: {u_boot_base_mac}. FAIL')
            raise Exception(
                f'u boot base mac mismatch! expected: {self.mapping.mac.r_val}, captured: {u_boot_base_mac}. FAIL')
        log.debug(f'u boot base mac match! expected: {self.mapping.mac.r_val}, captured: {u_boot_base_mac}. PASS')

    def create_vfat_paration(self):
        if self.is_fox_uboot:
            return helper.SKIP
        self.uut.send_wise('exit', "login:")
        self.uut.send_wise('root', "#")
        self.uut.send_wise('fdisk /dev/mmcblk0', "Command")
        self.uut.send_wise('n', "primary partition")
        self.uut.send_wise('p', "number")
        self.uut.send_wise('1', "")
        self.sleep_time(1)
        self.uut.send_wise('', "")
        self.sleep_time(1)
        self.uut.send_wise('', "Command")
        self.uut.send_wise('t', "(type L to list codes)")
        self.uut.send_wise('b', "Command")
        self.uut.send_wise('w', "#")

        self.uut.send_wise('mkfs.vfat /dev/mmcblk0p1', "#")
        self.uut.send_wise('reboot', "#")

        # set boot env
        self.wait_for_u_boot()
        self.setup_u_boot_env2()

        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # download DIAG
        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.diag_file}', self.u_boot_prompt, 360)
            if 'Bytes transferred =' not in self.uut.buffer:
                self.error(f'download diag file failed, edradour/{self.mapping.diag_file}')
                if scanner.yes_or_enter_to_continue(
                        question=f'Download DIAG img failed! retest? '
                                 f'下载DIAG文件失败！重试？'
                                 f'Tải xuống tệp DIAG không thành công! Thử lại?') is False:
                    raise Exception(f'download diag img file failed!')
                continue
            break

        self.uut.send_wise('fatwrite mmc 0 0x6a000000 /${diag_file} ${filesize}', self.u_boot_prompt)

        self.uut.send_wise('run bootcmd', '')
        self.uut.waitfor(self.diag_prompt, 360)
        # config network
        # self.uut.send_wise(f'syscall ifconfig eth0 {self.mapping.uut_ip} netmask {self.mapping.netmask} up',
        #                    self.diag_prompt)
        self.sleep_time(5)

    def power_cycle_u_boot(self):
        # msg = '[U BOOT] Please power cycle UUT. 请拔下电源然后重新上电'
        # if scanner.yes_or_enter_to_continue(question=msg) is False:
        #     raise Exception('power cycle UUT failed! operator!')
        while True:
            try:
                self.pdu.power_cycle(helper.config['pdu_port'])
                self.uut.send_wise('', 'U-Boot', 30)
                break
            except Exception as e:
                if scanner.yes_or_enter_to_continue(
                        question='(Pre Check Step 2)\n'
                                'Vui lòng kiểm tra lại nguồn điện và cáp đã được kết nối tốt chưa\n'
                                 'Please check the power supply and cables are connected well again',
                        image='Edradour/images/check_power_console.png',
                ) is False:
                    raise Exception('OP Stop Test!')
        self.wait_for_u_boot()

    def power_cycle_diag(self):
        # msg = '[DIAG] Please power cycle UUT. 请拔下电源然后重新上电'
        # if scanner.yes_or_enter_to_continue(question=msg) is False:
        #     raise Exception('power cycle UUT failed! operator!')
        self.pdu.power_cycle(helper.config['pdu_port'])
        self.wait_for_u_boot()
        self.enter_diag_mode()

    def check_diag_version(self):
        self.uut.send_wise('version', self.diag_prompt)
        if (self.mapping.diag_version not in self.uut.buffer) and (self.mapping.old_diag_version not in self.uut.buffer):
            raise Exception(f'found expected DIAG version: {self.mapping.diag_version}')
        else:
            log.debug(f'DIAG version is OK: {self.mapping.diag_version}')

    def check_ideeprom(self):
        # 注意此处的检查项目要和上面写的项目保持一致
        self.uut.send_wise('ideeprom show CPU_EEPROM', self.diag_prompt)
        targets = [
            self.mapping.jedec,
            self.mapping.eeprom_ver,
            self.mapping.bit_field,
            self.mapping.aver_maj,
            self.mapping.aver_min,

            self.mapping.arev,
            self.mapping.afg,
            self.mapping.mac_mc,
            self.mapping.mac_fv,
            self.mapping.mac_ent,
            self.mapping.msi,
            self.mapping.clei,
            self.mapping.mrev_maj,
            self.mapping.mrev_min,

            # year month day
            # self.mapping.asd,
            # self.mapping.asm,
            # self.mapping.asy,
            #
            self.mapping.aid,
            self.mapping.apn,
            self.mapping.mn,
            #
            self.mapping.mac,
            self.mapping.asn,
            self.mapping.chas_sn,
        ]
        for tg in targets:
            log.debug(f'verify: {tg}')
            captured = re.search(f'{re.escape(tg.r_name)}: ([^\r\n]*)', self.uut.buffer)
            if captured is None:
                raise Exception(f'not found {tg.r_name}!!!')
            captured = captured.group(1).strip()
            if captured != tg.r_val:
                log.error(f'{tg.r_name}, expected: {tg.r_val}, captured: {captured}, FAIL')
                raise Exception(f'{tg.r_name} mismatch!')
            log.debug(f'{tg.r_name}, expected: {tg.r_val}, captured: {captured}, PASS')

    # def get_fingerprint(self):
    #     self.fingerprint = self.tpm.get_fingerprint()

    # def show_curl_version(self):
    #     self.tpm.show_curl_version()

    def enter_bcm_mode(self):
        self.tpm.enter_bcm_mode()

    def delete_old_tpm2_dir(self):
        self.tpm.delete_old_tpm2_dir()

    def download_tpm2_tar_file(self):
        self.tpm.download_tpm2_tar_file()

    def extract_tpm2_tar_file(self):
        self.tpm.extract_tpm2_tar_file()

    def setup_tpm2_env(self):
        self.tpm.setup_tpm2_env()

    def check_tpm2_programmed_status(self):
        self.tpm.check_tpm2_programmed_status()
        log.debug(f'fresh unit: {self.tpm.is_fresh_unit}')

    def cleanup_tpm2_certs(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.cleanup_tpm2_certs()

    def validate_hdls_pre(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.validate_hdls_pre()

    def retrieve_tpm_fw_version(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.retrieve_tpm_fw_version()

    def run_basic_program_phase(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.run_basic_program_phase()

    def run_advanced_program_phase(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.run_advanced_program_phase()

    def request_csr_file(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.request_csr_file()

    def get_device_cert(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.get_device_cert()

    def forward_csr_to_dlm(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.forward_csr_to_dlm()

    def upload_cert_file_to_datacenter(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        dlm_cert_fullpath = f'/tmp/{self.tpm.dlm_cert_filename}'
        with open(dlm_cert_fullpath, 'w') as f:
            f.write(self.tpm.dlm_cert)
        log.debug(f'save cert to {dlm_cert_fullpath} OK!')

        helper.upload_file_to_data_center(src=dlm_cert_fullpath)
        log.debug(f'copy {dlm_cert_fullpath} to datacenter OK!')

    def program_csr_into_tpm2_device(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.program_csr_into_tpm2_device()

    def verify_program_csr_into_tpm2_device(self):
        self.tpm.verify_program_csr_into_tpm2_device()

    def check_version(self):
        self.tpm.check_version()

    def check_key_handlers_after_programing(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP
        self.tpm.check_key_handlers_after_programing()

    def show_idevid_details(self):
        self.tpm.show_idevid_details()

    def finalize_cert(self):
        if not self.tpm.is_fresh_unit:
            return helper.SKIP

        self.tpm.finalize_cert()

    def lookup_session(self):
        if not self.tpm.is_fresh_unit:
            try:
                last_session_id = self.get_last_session_id()
            except Exception as e:
                last_session_id = ''
                log.error(e)

            self.tpm.lookup_session(session_id=last_session_id, expected_state='finalized')
        else:
            self.tpm.lookup_session(expected_state='finalized')

    def get_last_session_id(self):
        records = self.get_genius_records_asc(sn=self.sernum, month=6)
        records = records.loc[
            (records.area == self.area) &
            # (records.result != 'S') &
            (records.str1name == 'Session ID') &
            (records.str1 != '')
            ]
        log.debug(f'found records: {len(records)}')
        if len(records) == 0:
            raise Exception('not found any records! not found session id!')

        last_session_id = records.iloc[-1][GeniusRecordFields.str1]
        if not last_session_id:
            raise Exception('last session id is invalid!')

        log.debug(f'{self.sernum} last session id: {last_session_id}')
        return last_session_id

    def power_off(self):
        try:
            self.pdu.power_off(helper.config['pdu_port'])
        except:
            pass

    def init_connections(self):
        self.uut = UUT(conn_str=helper.config['uut_conn_str'])
        self.pdu = PDU(conn_str=helper.config['pdu_conn_str'])
        self.tpm = TPM2(name='UUT')
        self.tpm.do_connect()

    def first_step_of_pre_seq(self):
        self.check_latest_repo_version(self.product_name)
        super().first_step_of_pre_seq()

    def first_step_of_main_seq(self):
        log.debug(self.mapping)

    def close_all_connections(self):
        self.uut.do_disconnect()

    def upload_test_records(self, **kwargs):
        super().upload_test_records(
            str1name='Session ID',
            str1=self.tpm.session_id,
            str2name='Product ID',
            str2=self.tpm.tpm2_product_id,
            str3name='TPM File',
            str3=self.tpm.tpm2_file,
            str4name='TPM FW Version',
            str4=self.tpm.tpm2_fw_version,
            str5name='TPM Vendor',
            str5=self.tpm.tpm2_vendor,
            str6name='Script Version',
            str6=self.current_version,
        )