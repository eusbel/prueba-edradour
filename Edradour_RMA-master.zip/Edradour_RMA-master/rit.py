import re
import time
from enum import Enum
from time import sleep

from .common.dcn import TimerMeta
from .common.scanner import yes_or_enter_to_continue
from .common.quantum import Quantum
from .common.utils import helper
from .common.fields import Field
from .common import sfchelper
from .define import define as df
from .define.define import cookie_mapping, EX4K
from .common import machelper
from .common.uut import UUT
from .common import scanner
from .common.logger import log


class VoltageMargin(Enum):
    NORMAL = '0'
    LOW = '1'
    HIGH = '2'


class RIT(Quantum, metaclass=TimerMeta):
    area = 'RIT'
    product_name = 'Edradour'

    mapping = Field()  # type: EX4K

    u_boot_prompt = 'u-boot>'
    diag_prompt = 'DIAG>'

    __nested_methods__ = ["rit_iterations_test"]  # 启用嵌套计时的方法

    def get_uut_diag(self):
        # 等待开机后
        while True:
            try:
                self.uut.send_ctrl_c('')
                time.sleep(1)
                self.uut.send_enter('')
                time,sleep(1)
                self.uut.send_ctrl_c('')
                time.sleep(1)
                self.uut.send_enter('')
                time.sleep(1)
                self.uut.send_ctrl_c('')
                self.uut.send_wise('', timeout=120, expectphrase=[self.diag_prompt, self.u_boot_prompt])
            except Exception as e:
                log.error(f'get DIAG failed! -> {e}')
                if scanner.yes_or_enter_to_continue('Get DIAG failed! Retry? 没有等到DIAG，再试试？') is False:
                    raise Exception('get UUT DIAG failed!')
                continue

            if self.diag_prompt in self.uut.buffer:
                break

            if self.u_boot_prompt in self.uut.buffer:
                self.setup_u_boot_env()
                self.uut.send_wise('run bootcmd', [self.diag_prompt, self.u_boot_prompt], 600)
                if "Wrong Image Format" in self.uut.buffer:
                    self.setup_u_boot_env_special()
                    self.uut.send_wise('run bootcmd', self.diag_prompt, 600)
                self.sleep_time(5)
                break

    def read_diag_info(self):
        self.uut.send_wise('syscall dmesg -n 4', self.diag_prompt)
        # show SN
        self.uut.send_wise('ideeprom show CPU_EEPROM', self.diag_prompt)
        sn = re.search(r'ASSEMBLY_SERIAL_NUM \(asn\): (\w+)', self.uut.buffer)
        if sn is None:
            raise Exception('not found UUT SN!')
        sn = sn.group(1)
        log.debug(f'READ UUT SN: {sn}')

        chassis_sn = re.search('CHASSIS_SERIAL_NUM \(chas_sn\): (\w+)', self.uut.buffer)
        if chassis_sn is None:
            raise Exception('not found chassis SN!')
        chassis_sn = chassis_sn.group(1)
        log.debug(f'READ UUT CHASSIS SN: {sn}')

        # 简单检查 UUT SN和CHASSIS SN 是否一致
        if sn != chassis_sn:
            raise Exception('UUT SN and CHASSIS SN Mismatch!')

        pn = re.search(r'ASSEMBLY_PART_NUM \(apn\): (\d+-\d+)', self.uut.buffer)
        if pn is None:
            raise Exception('not found UUT PN!')
        pn = pn.group(1)
        log.debug(f'READ UUT PN: {pn}')

        mac = re.search('MAC_BASE \(mac\): ([\w:]+)', self.uut.buffer)
        if mac is None:
            raise Exception('not found MAC!')
        mac = mac.group(1)
        log.debug(f'READ UUT MAC: {mac}')

        self.sernum = sn
        self.uuttype = pn
        self.mac_address = mac

        self.check_fail_record(sn=self.sernum, station=self.area)

    def check_uut_sn_pn(self):
        if self.uuttype not in cookie_mapping:
            raise Exception(f'Part Number: {self.uuttype} is not defined! Please try: {list(cookie_mapping.keys())}')

        # 读取预定义数据
        self.mapping = cookie_mapping[self.uuttype]

        # if self.mapping.group != 'G1':
        #     raise Exception(f'Only Support G1 Test !')

        # 打印初始化的参数
        log.debug(f'SN: {self.sernum}, UUTType: {self.uuttype}, Model: {self.mapping.platform}')

        # self.check_fail_record(sn=self.sernum, station=self.area)

        # Double Check mapping APN
        if self.uuttype != self.mapping.apn.r_val:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn r value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn r val: {self.mapping.apn.r_val}. PASS')

        if self.uuttype != self.mapping.apn.w_val:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn w value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn w val: {self.mapping.apn.w_val}. PASS')

        # 查询 MES LABEL PN
        data = sfchelper.get_sn_detail_from_mes(self.sernum)

        pn = data.get('SKUNO', None)
        if not pn:
            raise Exception('not found SKUNO from mes')
        log.debug(f"SN {self.sernum} MES sku is {pn}")

        if pn != self.uuttype:
            if "TAA" in pn:
                self.uuttype = pn
                log.debug(f"sn: {self.sernum} is TAA sku")
            elif "FJZ" in pn:
                self.uuttype = pn
                log.debug(f"sn: {self.sernum} is FJZ sku")
            else:
                raise Exception(f'{self.sernum} - UUT PN({self.uuttype}) mismatch with MES PN({pn})!')

        self.check_label_v2(sn=self.sernum)
        # 记得添加测试记录
        helper.add_record(sn=self.sernum, pn=self.uuttype, area=self.area)

    def check_mes_event(self):
        self.mes_check_event(sn=self.sernum, area=self.area)
        # 检查genius测试工站
        if "P" in self.mapping.platform:
            self.genius_check_event(sn=self.sernum, current_station="POE")
        else:
            self.genius_check_event(sn=self.sernum, current_station="BFT")

    def query_mes_mac(self):
        mac, size = sfchelper.get_mac_address_from_mes(wsn=self.sernum)
        if mac is None:
            helper.quick_set('NO MAC FROM MES')
            raise Exception('no MAC from MES!!!')

        if size != self.mapping.mac_block_size:
            helper.quick_set('MAC Block Size Incorrect')
            raise Exception(f'MAC Block Size Incorrect, expected: {self.mapping.mac_block_size}, got: {size}, FAIL!!!')

        mac_helper = machelper.MacAddressHelper()
        mac = mac_helper.convert(mac, lower=True, delimiter=':')
        size = int(size)
        self.mac_address, self.mac_block_size = mac, size

    def read_config(self):

        self.mapping.uut_ip = helper.config['uut_ip']
        # self.mapping.serverip = helper.config['serverip']
        # self.mapping.netmask = helper.config['netmask']

        self.mapping.mac.set(w_val=self.mac_address, r_val=self.mac_address.upper())
        self.mapping.asn.set(w_val=self.sernum, r_val=self.sernum)
        self.mapping.chas_sn.set(w_val=self.sernum, r_val=self.sernum)

        # UTC
        # now = dt.datetime.now(dt.timezone.utc)
        # hex_year = f'{now.year:04X}'
        # self.mapping.asy.set(w_val=hex_year, r_val=f'{hex_year[0:2]} {hex_year[2:4]}')
        # self.mapping.asm.set(w_val=f'{now.month:02X}', r_val=f'{now.month:02X}')
        # self.mapping.asd.set(w_val=f'{now.day:02X}', r_val=f'{now.day:02X}')

        # MES
        rev = sfchelper.get_label_aver_min_from_mes(self.sernum)
        self.mapping.aver_min.set(w_val=rev, r_val=rev)
        self.mapping.arev.set(w_val=rev, r_val=rev)
        model_maj_rev = sfchelper.get_label_model_maj_rev_from_mes(self.sernum)
        self.mapping.mrev_maj.set(w_val=model_maj_rev, r_val=model_maj_rev)

    def check_ports(self):
        while True:
            self.uut.send_wise('port all status', self.diag_prompt)
            ports = re.findall(r'^(P\d+)\s+(\S+)\s+', self.uut.buffer, flags=re.M)
            log.debug(f'find ports: {len(ports)}')
            log.debug(f'{ports}')
            if len(ports) != self.mapping.traffic_port_num:
                if self.mapping.platform == 'EX4000-48MP' and (self.mapping.traffic_port_num + 2 == len(ports)):
                    log.debug("EX4000-48MP check 54 ports")
                else:
                    raise Exception(
                        f'{self.mapping.platform} expected ports: {self.mapping.traffic_port_num}, founded: {len(ports)}')

            error_ports = list(filter(lambda x: x[1] != 'UP', ports))
            if len(error_ports) != 0:
                ports_str = ', '.join([_[0] for _ in error_ports])
                if yes_or_enter_to_continue(f'Found down port(s): {ports_str}') is False:
                    raise Exception(f'down ports: {ports_str}')

                continue

            log.debug('all port are UP!')
            break

    def check_temperature(self):
        while True:
            self.uut.send_wise('tempread all', self.diag_prompt)
            temp = re.findall(r':\s+([+-](?:\d+)?\.\d+)\s+oC', self.uut.buffer)
            if len(temp) == 0:
                log.debug('not found temperatures! wait 60s and recheck...')
                self.sleep_time(60)
                continue

            for t in temp:
                float_t = float(t)
                if float_t < 45:
                    msg = f'temp: {float_t} < 45 , wait 60s and recheck...'
                    log.debug(msg)
                    self.sleep_time(60)
                    break
            else:
                log.debug(f"All temp > 45, can start test")
                break

    def get_uut_console(self):
        self.uut.do_connect(close_before_open=True)

    def rit_iterations_test(self):
        # 48-->3 * 4 = 12 cycles 其他 4 * 4 =16
        for cycle in range(self.mapping.traffic_cycle):
            flow = [VoltageMargin.NORMAL, VoltageMargin.HIGH, VoltageMargin.NORMAL, VoltageMargin.LOW]
            for v_idx, v_no in enumerate(flow):
                voltage_name = v_no.name
                voltage = v_no.value
                # 设置电压
                self.quick_set(f'Set Voltage {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.set_voltage_margin(voltage)

                # 检查电压
                self.quick_set(f'Check Voltage {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_voltage_margin(voltage)

                # 检查DIAG版本
                self.quick_set(f'Check DIAG Version {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_diag_version()

                # 检查PFE FE
                self.quick_set(f'Check PFE FW {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_pfe_fw()

                # 检查eMMC FW
                self.quick_set(f'Check eMMC FW {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_emmc_fw_version()

                # 检查IDEEPROM
                self.quick_set(f'Check IDEEPROM {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_ideeprom()

                # Memory Test
                self.quick_set(f'Memory Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.memory_test()

                # CPU Full load
                self.quick_set(f'CPU Full Load {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.cpu_full_load()

                # CPU Full load
                self.quick_set(f'Check System Clock {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_system_clock()

                # i2c test
                self.quick_set(f'I2C Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.i2c_test()

                # Check SFP
                self.quick_set(f'Check SFP {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_sfp_plus_eeprom()

                # Dump SFP
                self.quick_set(f'Dump SFP {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.dump_sfp_info()

                # Full Speed Traffic Test
                self.quick_set(f'Full Speed Traffic Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.traffic_test()

                # Low Speed Traffic Test
                self.quick_set(f'Low Speed Traffic Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.low_speed_traffic_test()

                # Check temperature
                self.quick_set(f'Check Temperature {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_system_temperature()

                # mgmt Traffic Test
                self.quick_set(f'MGMT Traffic Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.oob_port_traffic_test()

                # USB Test
                # self.quick_set(f'USB Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                # self.check_usb_speed_working()

                # eMMC Test
                self.quick_set(f'eMMC Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_emmc_working()

                # TPM Physical Test
                self.quick_set(f'TPM Physical Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.tpm_test_physical()

                # Fan Test
                self.quick_set(f'Fan Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.fan_speed_direction_test()

                # # Check temperature
                # self.quick_set(f'Check Temperature {voltage_name} - {cycle + 1} - {v_idx + 1}')
                # self.check_system_temperature()

                # Check system configuration
                self.quick_set(f'Check Hardware Inventory {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_system_configuration()

                # ECC Check
                self.quick_set(f'Check ECC {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.ecc_errors_check()

                # Check Memory Size
                self.quick_set(f'Check Memory Size {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.memory_size_check()

                # Check CPU Cores
                self.quick_set(f'Check CPU Cores {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_cpu_cores()

                # Rest Test
                self.quick_set(f'Rest Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_reset_function()

    def set_voltage_margin(self, voltage):
        self.uut.send_wise(f'volcontrol all setmargin {voltage}', self.diag_prompt)
        vol = re.findall(r'cmd 1 data (\d)', self.uut.buffer)
        if len(vol) != 6:
            log.error(
                f'[Pass Criteria] volcontrol all setmargin {voltage} capture: count vol {vol}, expect:count vol 6, result: FAIL')
            raise Exception(f'expected voltage count: 6, founded: {len(vol)}')
        log.debug(
                f'[Pass Criteria] volcontrol all setmargin {voltage} capture: count vol {vol}, expect:count vol 6, result: PASS')
        found_voltage_set = set(vol)
        expected_voltage_set = {voltage}
        if found_voltage_set != expected_voltage_set:
            log.error(
                f'[Pass Criteria] volcontrol all setmargin {voltage} capture: {found_voltage_set}, expect: {expected_voltage_set}, result: FAIL')
            raise Exception(f'expected voltage: {expected_voltage_set}, found: {found_voltage_set}, FAIL!')
        log.debug(
                f'[Pass Criteria] volcontrol all setmargin {voltage} capture: {found_voltage_set}, expect: {expected_voltage_set}, result: PASS')

    def check_voltage_margin(self, expected_voltage):
        self.uut.send_wise(f'volcontrol all getmargin {expected_voltage}', self.diag_prompt)
        vol = re.findall(r'cmd 2 data (\d)', self.uut.buffer)
        if len(vol) != 6:
            log.error(
                f'[Pass Criteria] volcontrol all getmargin {expected_voltage} capture: count vol {vol}, expect:count vol 6, result: FAIL')
            raise Exception(f'expected voltage count: 6, founded: {len(vol)}')
        log.debug(f'found voltage count: {len(vol)}, PASS')
        found_voltage_set = set(vol)
        expected_voltage_set = {expected_voltage}
        if found_voltage_set != expected_voltage_set:
            log.error(
                f'[Pass Criteria] volcontrol all getmargin {expected_voltage} capture: {found_voltage_set}, expect: {expected_voltage_set}, result: FAIL')
            raise Exception(f'expected voltage: {expected_voltage_set}, found: {found_voltage_set}, FAIL!')
        log.debug(
                f'[Pass Criteria] volcontrol all getmargin {expected_voltage} capture: {found_voltage_set}, expect: {expected_voltage_set}, result: PASS')

    def setup_u_boot_env(self):
        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file Edradour_DIAG_v2.3.0_uImage_initramfs.img", self.u_boot_prompt)

        # 首先确定板子是什么类型，然后再写入不同的值
        self.uut.send_wise('print hw.board.name', self.u_boot_prompt)
        board_name = re.search('hw\.board\.name=(\S+)', self.uut.buffer)
        if board_name is None:
            raise Exception('not found u boot model!')
        board_name = board_name.group(1)
        log.debug(f'U Boot Board Name: {board_name}')
        if board_name.upper() in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)

    def setup_u_boot_env_special(self):
        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file Edradour_DIAG_v2.2.8_uImage_initramfs.img", self.u_boot_prompt)

        # 首先确定板子是什么类型，然后再写入不同的值
        self.uut.send_wise('print hw.board.name', self.u_boot_prompt)
        board_name = re.search('hw\.board\.name=(\S+)', self.uut.buffer)
        if board_name is None:
            raise Exception('not found u boot model!')
        board_name = board_name.group(1)
        log.debug(f'U Boot Board Name: {board_name}')
        if board_name.upper() in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)

    def login_diag(self):
        self.wait_for_u_boot()
        self.setup_u_boot_env()
        self.uut.send_wise('run bootcmd', self.diag_prompt, 600)
        self.sleep_time(5)

    def wait_for_u_boot(self):
        self.uut.waitfor(['Hit any key to stop autoboot', 'Do you want to run the Shmoo? [y/N]',
                          '*** U-Boot Boot Menu ***', self.u_boot_prompt],
                         150)
        log.debug(f'found -> {self.uut.foundphrase}')
        # JNPR U BOOT
        if '*** U-Boot Boot Menu ***' in self.uut.buffer:
            time.sleep(0.5)
            self.uut.send_esc(['Hit any key to stop autoboot', self.u_boot_prompt])
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Do you want to run the Shmoo? [y/N]' in self.uut.buffer:
            self.uut.send_wise('N', ['Hit any key to stop autoboot', self.u_boot_prompt], 150, suffix='')
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Hit any key to stop autoboot' in self.uut.buffer:
            self.uut.send_esc(self.u_boot_prompt)
            log.debug(f'found -> {self.uut.foundphrase}')

        time.sleep(1)
        self.uut.send_ctrl_c(self.u_boot_prompt)

    def check_diag_version(self):
        self.uut.send_wise('version', self.diag_prompt)
        if (self.mapping.diag_version not in self.uut.buffer) and (self.mapping.old_diag_version not in self.uut.buffer):
            raise Exception(f'found expected DIAG version: {self.mapping.diag_version}')
        log.debug(f'found expected DIAG version: {self.mapping.diag_version}')
        log.debug(
                f'[Pass Criteria] DIAG version capture: {self.mapping.diag_version}, expect: {self.mapping.diag_version}, result: PASS')
        if self.mapping.check_u_boot_version not in self.uut.buffer:
            raise Exception(f'not found expected U-Boot version: {self.mapping.check_u_boot_version}')
        log.debug(
                f'[Pass Criteria] U-Boot version capture: {self.mapping.check_u_boot_version}, expect: {self.mapping.check_u_boot_version}, result: PASS')

        if self.mapping.platform in {df.MN_EX4000_48MP, df.MN_EX4000_24MP, df.MN_EX4000_12MP}:
            log.debug(f'{self.mapping.platform} need to check EPDM version!')
            captured_ver = re.search(r'EPDM\s+:\s+(\S+)', self.uut.buffer)
            if captured_ver is None:
                raise Exception('not found EPDM version!')
            captured_ver = captured_ver.group(1)
            if captured_ver != self.mapping.epdm:
                log.error(f'[Pass Criteria] EPDM version, capture: {captured_ver}, expect: {self.mapping.epdm}, result: FAIL')
                raise Exception(f'EPDM version, captured: {captured_ver}, expected: {self.mapping.epdm}. FAIL')
            log.debug(f'[Pass Criteria] EPDM version, capture: {captured_ver}, expect: {self.mapping.epdm}, result: PASS')
        else:
            log.debug(f'{self.mapping.platform} no need to check EPDM version!')

        self.uut.send_wise('cpuinfo', self.diag_prompt)
        if re.search('error|fail', self.uut.buffer, flags=re.I):
            raise Exception('check cpu info failed, found error or fail!')
        if self.mapping.cpu_device not in self.uut.buffer:
            raise Exception(f'not found expected Device: {self.mapping.cpu_device}')
        log.debug(f'[Pass Criteria] CPU device, capture: {self.mapping.cpu_device}, expect: {self.mapping.cpu_device}, result: PASS')

    def check_pfe_fw(self):
        if self.mapping.check_pfe_fw is not True:
            self.debug(f'this {self.uuttype} no need to Check PFE FW!! SKIP...')
            return helper.SKIP

        self.debug(f'this {self.uuttype} need to Check PFE FW.')
        self.uut.send_wise('bcmcall 1 pciephy fw info', self.diag_prompt)

        pcie_fw_version = re.search(r'PCIe FW version: (\S+)', self.uut.buffer)
        if pcie_fw_version is None:
            raise Exception('not found PCIe FW version')
        pcie_fw_version = pcie_fw_version.group(1)
        if pcie_fw_version != self.mapping.pcie_fw_version:
            log.error(f'[Pass Criteria] PCIe FW version, capture: {pcie_fw_version}, expect: {self.mapping.pcie_fw_version}, result: FAIL')
            raise Exception('PCIe FW version mismatch')
        log.debug(f'[Pass Criteria] PCIe FW version, capture: {pcie_fw_version}, expect: {self.mapping.pcie_fw_version}, result: PASS')

    def check_emmc_fw_version(self):
        self.uut.send_wise('syscall mmc extcsd read /dev/mmcblk0 | grep Version', self.diag_prompt)
        # eMMC Firmware Version: 00000016
        version = re.search('eMMC Firmware Version:\s*(\w+)', self.uut.buffer, flags=re.I)
        if version is None:
            raise Exception('not found eMMC version!')
        version = version.group(1)
        if version not in self.mapping.emmc_version:
            log.error(
                f'[Pass Criteria] eMMC version, capture: {version}, expect: {self.mapping.emmc_version}, result: FAIL')
            raise Exception('eMMC version mismatch!')
        log.debug(
            f'[Pass Criteria] eMMC version, capture: {version}, expect: {self.mapping.emmc_version}, result: PASS')

    def check_ideeprom(self):
        # 注意此处的检查项目要和上面写的项目保持一致
        self.uut.send_wise('ideeprom show CPU_EEPROM', self.diag_prompt)
        targets = [
            self.mapping.jedec,
            self.mapping.eeprom_ver,
            self.mapping.bit_field,
            self.mapping.aver_maj,
            self.mapping.aver_min,

            self.mapping.arev,
            self.mapping.afg,
            self.mapping.mac_mc,
            self.mapping.mac_fv,
            self.mapping.mac_ent,
            self.mapping.msi,
            self.mapping.clei,
            self.mapping.mrev_maj,
            self.mapping.mrev_min,

            # year month day
            # 这个不在这里检查
            # self.mapping.asd,
            # self.mapping.asm,
            # self.mapping.asy,
            #
            self.mapping.aid,
            self.mapping.apn,
            self.mapping.mn,
            #
            self.mapping.mac,
            self.mapping.asn,
            self.mapping.chas_sn,
        ]
        for tg in targets:
            log.debug(f'verify: {tg}')
            captured = re.search(f'{re.escape(tg.r_name)}: ([^\r\n]*)', self.uut.buffer)
            if captured is None:
                raise Exception(f'not found {tg.r_name}!!!')
            captured = captured.group(1).strip()
            if captured != tg.r_val:
                log.error(f'[Pass Criteria] {tg.r_name}, capture: {captured}, expect: {tg.r_val}, result: FAIL')
                raise Exception(f'{tg.r_name} mismatch!')
            log.debug(f'[Pass Criteria] {tg.r_name}, capture: {captured}, expect: {tg.r_val}, result: PASS')

        self.uut.send_wise('ideeprom dump CPU_EEPROM 0 80', self.diag_prompt)

    def memory_test(self):
        self.uut.send_wise('memtest marchc', self.diag_prompt)
        if 'Memory test - PASS' not in self.uut.buffer:
            log.error(
                f'[Pass Criteria] capture: {self.uut.buffer}, expect value: Memory test - PASS, result: FAIL')
            raise Exception('mem test failed!')
        log.debug(
            f'[Pass Criteria] capture: {self.uut.buffer}, expect value: Memory test - PASS, result: PASS')

    def cpu_full_load(self):
        self.uut.send_wise('syscall stress-ng -c 4 --cpu-method all --timeout 10', self.diag_prompt)
        if 'successful run completed' not in self.uut.buffer:
            log.error('CPU Full Load test failed!')
            raise Exception('CPU Full Load test failed!')
        else:
            log.debug(
                f'[Pass Criteria] capture: {self.uut.buffer}, expect value: successful run completed, result: PASS')

    def check_clock(self):
        self.uut.send_wise('rtctest', self.diag_prompt)
        if 'Rtc test - PASS' not in self.uut.buffer:
            raise Exception('check rtc clock failed!')
        self.uut.send_wise('rtcread', self.diag_prompt)
        log.debug(
            f"[Pass Criteria] capture: 'Rtc test - PASS', expect value: 'Rtc test - PASS', result: PASS")

    check_system_clock = check_clock

    def i2c_test(self):
        # 需要确保已插入所有的 SFP
        # scanner.yes_or_enter_to_continue(question='Please install all SFPs. 请安装所有SFP')
        while True:
            self.uut.send_wise('i2ctest all all', self.diag_prompt)

            if re.search('error|fail', self.uut.buffer, re.I):
                log.error(f'I2C test failed')
                # if scanner.yes_or_enter_to_continue(
                #         question=f'I2C test failed, found error or fail, retry? I2C测试失败，重试？'
                # ) is False:
                raise Exception(f'I2C test failed')
                # continue

            if 'i2ctest all - PASS' not in self.uut.buffer:
                # if scanner.yes_or_enter_to_continue(
                #         'I2C Test failed, not found PASS, retry? I2C 测试失败，重试？') is False:
                #     log.error('not found pass signature: i2ctest all - PASS')
                raise Exception('i2c test failed!')
                # continue

            log.debug(
                f"[Pass Criteria] capture: 'i2ctest all - PASS', expect value: 'i2ctest all - PASS', result: PASS")
            break

    def sfp_check(self):
        # 虽然写的是 SFP PN REV check，但是实际并没有限定 SFP 的型号
        if self.mapping.platform in [df.MN_EX4000_8P]:
            # 8P 只有两个 SFP
            commands = [
                ('SFP 0', 'eeprom dump SFP#1'),
                ('SFP 1', 'eeprom dump SFP#2'),
            ]
        else:
            commands = [
                ('SFP 0', 'eeprom dump SFP#1'),
                ('SFP 1', 'eeprom dump SFP#2'),
                ('SFP 2', 'eeprom dump SFP#3'),
                ('SFP 3', 'eeprom dump SFP#4'),
            ]

        for sfp_no, cmd in commands:
            while True:
                self.uut.send_wise(cmd, self.diag_prompt)
                if re.search('error|fail', self.uut.buffer, re.I):
                    log.error(f'{sfp_no} test failed')
                    # if scanner.yes_or_enter_to_continue(
                    #         question=f'{sfp_no} test failed, retry? {sfp_no} 测试失败，重试？'
                    # ) is False:
                    raise Exception(f'{sfp_no} test failed')
                    # continue

                log.debug(f"[Pass Criteria] {sfp_no} test capture: no error or fail, expect value: no error or fail, result: PASS")
                break

    check_sfp_plus_eeprom = sfp_check

    def dump_sfp_info(self):
        for port in self.mapping.sfp_ports:
            while True:
                self.uut.send_wise(f'port {port} sfp', self.diag_prompt)
                if re.search('fail|error', self.uut.buffer, flags=re.I):
                    # question = (f"Port {port} SFP test Fail, please change anothor one\n"
                    #             f"Cổng {port} kiểm tra SFP thất bại, vui lòng thay cái khác")
                    # if scanner.yes_or_enter_to_continue(question=question) is False:
                    helper.quick_set(f'Port {port} SFP Fail')
                    raise Exception(f'Port {port} SFP Fail')
                    # else:
                    #     continue
                else:
                    log.debug(f"[Pass Criteria] Port {port} SFP test capture: no error or fail, expect value: no error or fail, result: PASS")
                    break

    def check_all_ports_status(self):

        # if self.mapping.platform == 'EX4000-48MP':
        #     self.uut.send_wise('bcmcall 0 port hg speed=20000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg speed=20000', self.diag_prompt)
        # if self.mapping.platform in ['EX4000-48P', 'EX4000-48T']:
        #     self.uut.send_wise('bcmcall 0 port hg speed=25000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg speed=25000', self.diag_prompt)

        while True:
            self.uut.send_wise('port all status', self.diag_prompt)

            # port 52 53(48 P/T/MP) link down is true failure
            ports = re.findall(r'P(\d+)\s+(\S+)\s+', self.uut.buffer)
            if len(ports) != self.mapping.traffic_port_num:
                if self.mapping.platform == 'EX4000-48MP' and (self.mapping.traffic_port_num + 2 == len(ports)):
                    log.debug("EX4000-48MP check 54 ports")
                else:
                    raise Exception(f'expected port num: {self.mapping.traffic_port_num}, got: {len(ports)}')

            down_ports = [p[0] for p in ports if p[1].upper() != 'UP']
            if len(down_ports) != 0:
                # 48MP -> 52, 53 Down True Fail. 48P/T -> 52, 53, 54, 55 Down True Fail!
                # port 52 53(48 P/T/MP) link down is true failure
                if '52' in down_ports or '53' in down_ports or '54' in down_ports or '55' in down_ports:
                    self.quick_set('Port 52 or 53 or 54 or 55 Down')
                    raise Exception('Port 52 or 53 or 54 or 55 Down, this is true failure, please send to RE!')
                # question = (f'Some ports are down! {",".join(down_ports)}\n'
                #             f'这些端口是没起来，请检查：{",".join(down_ports)}\n'
                #             f'Một số cổng bị hỏng! Kiểm tra lại? {",".join(down_ports)}')
                # if scanner.yes_or_enter_to_continue(question=question) is False:
                raise Exception(f'traffic test failed, ports are down: {",".join(down_ports)}')
                # continue

            log.debug('all ports status OK')
            # all ports are UP
            break

    def pre_check_all_ports_status(self):

        # if self.mapping.platform == 'EX4000-48MP':
        #     self.uut.send_wise('bcmcall 0 port hg speed=20000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg speed=20000', self.diag_prompt)
        # if self.mapping.platform in ['EX4000-48P', 'EX4000-48T']:
        #     self.uut.send_wise('bcmcall 0 port hg speed=25000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg speed=25000', self.diag_prompt)

        while True:
            self.uut.send_wise('port all status', self.diag_prompt)

            # port 52 53(48 P/T/MP) link down is true failure
            ports = re.findall(r'P(\d+)\s+(\S+)\s+', self.uut.buffer)
            if len(ports) != self.mapping.traffic_port_num:
                if self.mapping.platform == 'EX4000-48MP' and (self.mapping.traffic_port_num + 2 == len(ports)):
                    log.debug("EX4000-48MP check 54 ports")
                else:
                    raise Exception(f'expected port num: {self.mapping.traffic_port_num}, got: {len(ports)}')

            down_ports = [p[0] for p in ports if p[1].upper() != 'UP']
            if len(down_ports) != 0:
                # 48MP -> 52, 53 Down True Fail. 48P/T -> 52, 53, 54, 55 Down True Fail!
                # port 52 53(48 P/T/MP) link down is true failure
                if '52' in down_ports or '53' in down_ports or '54' in down_ports or '55' in down_ports:
                    self.quick_set('Port 52 or 53 or 54 or 55 Down')
                    raise Exception('Port 52 or 53 or 54 or 55 Down, this is true failure, please send to RE!')
                question = (f'Some ports are down! {",".join(down_ports)}\n'
                            f'这些端口是没起来，请检查：{",".join(down_ports)}\n'
                            f'Một số cổng bị hỏng! Kiểm tra lại? {",".join(down_ports)}')
                if scanner.yes_or_enter_to_continue(question=question) is False:
                    raise Exception(f'traffic test failed, ports are down: {",".join(down_ports)}')
                continue

            log.debug('all ports status OK')
            # all ports are UP
            break

    def set_full_speed(self):
        if self.mapping.platform == df.MN_EX4000_12MP:
            self.uut.send_wise('port 0-3 speed 2.5g', self.diag_prompt)
            self.uut.send_wise('port 4-11 speed 1g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_24MP:
            self.uut.send_wise('port 0-3 speed 2.5g', self.diag_prompt)
            self.uut.send_wise('port 4-23 speed 1g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_48MP:
            self.uut.send_wise('port 0-7 speed 2.5g', self.diag_prompt)
            self.uut.send_wise('port 8-47 speed 1g', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_8P:
            self.uut.send_wise('port 0-9 speed 1g', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_12P, df.MN_EX4000_12T]:
            self.uut.send_wise('port 0-11 speed 1g', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_24P, df.MN_EX4000_24T]:
            self.uut.send_wise('port 0-23 speed 1g', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_48P, df.MN_EX4000_48T]:
            self.uut.send_wise('port 0-47 speed 1g', self.diag_prompt)
        else:
            raise Exception(f'set full speed, unknown platform -> {self.mapping.platform}')

    def set_low_speed(self):
        if self.mapping.platform == df.MN_EX4000_12MP:
            self.uut.send_wise('port 0-3 speed 1g', self.diag_prompt)
            self.uut.send_wise('port 4-11 speed 100m', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_24MP:
            self.uut.send_wise('port 0-3 speed 1g', self.diag_prompt)
            self.uut.send_wise('port 4-23 speed 100m', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_48MP:
            self.uut.send_wise('port 0-7 speed 1g', self.diag_prompt)
            self.uut.send_wise('port 8-47 speed 100m', self.diag_prompt)
        elif self.mapping.platform == df.MN_EX4000_8P:
            self.uut.send_wise('port 0-9 speed 100m', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_12P, df.MN_EX4000_12T]:
            self.uut.send_wise('port 0-11 speed 100m', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_24P, df.MN_EX4000_24T]:
            self.uut.send_wise('port 0-23 speed 100m', self.diag_prompt)
        elif self.mapping.platform in [df.MN_EX4000_48P, df.MN_EX4000_48T]:
            self.uut.send_wise('port 0-47 speed 100m', self.diag_prompt)
        else:
            raise Exception(f'set low speed, unknown platform -> {self.mapping.platform}')

    def low_speed_traffic_test(self):
        self.set_low_speed()
        self.sleep_time(30)

        self.check_all_ports_status()

        # if self.mapping.platform in [df.MN_EX4000_48MP, df.MN_EX4000_48P, df.MN_EX4000_48T]:
        #     self.do_traffic_test('linespeed extp 0-51 5a 256 10 300 mfg', 52, 1800, min_pkg=100_000)
        #     self.do_traffic_test('linespeed extp 0-51 5a 1518 10 300 mfg', 52, 1800, min_pkg=100_000)
        # else:
        self.do_traffic_test('linespeed extp all 5a 256 10 300 mfg', self.mapping.traffic_port_num, 1800,
                                 min_pkg=100_000)
        self.do_traffic_test('linespeed extp all 5a 1518 10 300 mfg', self.mapping.traffic_port_num, 1800,
                                 min_pkg=100_000)

    def traffic_test(self, min_pkg=1_000_000):
        """
            speed: [high|low]
        """

        self.set_full_speed()
        self.sleep_time(30)

        # 需要在一开始就把网线和SFP都是插好
        self.check_all_ports_status()

        # # 48 Port
        # if self.mapping.platform == df.MN_EX4000_48MP:
        #     # traffic port num。 52，53需要单独测试，但是检查状态的时候是需要的。Traffic 单独测试！
        #     # 先测试52 53 Port
        #     log.debug(f'{self.mapping.platform} need to do test port 52, 53')
        #     # 52
        #     self.uut.send_wise('bcmcall 0 port hg0 speed=20000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg0 speed=20000', self.diag_prompt)
        #     self.sleep_time(2)
        #     self.uut.send_wise('port 53 loopback mac-rmt', self.diag_prompt)
        #     self.sleep_time(3)
        #     self.do_traffic_test('linespeed exts 52 5a 1518 10 300', 1, 420, min_pkg)
        #     self.uut.send_wise('port 53 loopback none', self.diag_prompt)
        #     # 53
        #     self.uut.send_wise('bcmcall 0 port hg0 speed=20000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg0 speed=20000', self.diag_prompt)
        #     self.sleep_time(2)
        #     self.uut.send_wise('port 52 loopback mac-rmt', self.diag_prompt)
        #     self.sleep_time(3)
        #     self.do_traffic_test('linespeed exts 53 5a 1518 10 300', 1, 420, min_pkg)
        #     self.uut.send_wise('port 52 loopback none', self.diag_prompt)
        #
        #     self.uut.send_wise('bcmcall 0 port hg0 speed=20000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg0 speed=20000', self.diag_prompt)
        #
        #     # 再测试其他端口
        #     self.do_traffic_test('linespeed extp 0-51 5a 256 10 300 mfg', 52, 420, min_pkg)
        #     self.do_traffic_test('linespeed extp 0-51 5a 1518 10 300 mfg', 52, 420, min_pkg)
        #
        # elif self.mapping.platform in [df.MN_EX4000_48T, df.MN_EX4000_48P]:
        #     # traffic port num。 52，53需要单独测试，但是检查状态的时候是需要的。Traffic 单独测试！
        #     # 先测试 52 53 Port
        #     log.debug(f'{self.mapping.platform} need to do test port 52, 53, 54, 55')
        #     # 52
        #     self.uut.send_wise('bcmcall 0 port hg0 speed=25000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg0 speed=25000', self.diag_prompt)
        #     self.sleep_time(2)
        #     self.uut.send_wise('port 53 loopback mac-rmt', self.diag_prompt)
        #     self.sleep_time(3)
        #     self.do_traffic_test('linespeed exts 52 5a 1518 10 300', 1, 420, min_pkg)
        #     self.uut.send_wise('port 53 loopback none', self.diag_prompt)
        #     # 53
        #     self.uut.send_wise('bcmcall 0 port hg0 speed=25000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg0 speed=25000', self.diag_prompt)
        #     self.sleep_time(2)
        #     self.uut.send_wise('port 52 loopback mac-rmt', self.diag_prompt)
        #     self.sleep_time(3)
        #     self.do_traffic_test('linespeed exts 53 5a 1518 10 300', 1, 420, min_pkg)
        #     self.uut.send_wise('port 52 loopback none', self.diag_prompt)
        #
        #     self.uut.send_wise('bcmcall 0 port hg0 speed=25000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg0 speed=25000', self.diag_prompt)
        #
        #     # 54
        #     self.uut.send_wise('bcmcall 0 port hg1 speed=25000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg1 speed=25000', self.diag_prompt)
        #     self.sleep_time(2)
        #     self.uut.send_wise('port 55 loopback mac-rmt', self.diag_prompt)
        #     self.sleep_time(3)
        #     self.do_traffic_test('linespeed exts 54 5a 1518 10 300', 1, 420, min_pkg)
        #     self.uut.send_wise('port 55 loopback none', self.diag_prompt)
        #
        #     # 55
        #     self.uut.send_wise('bcmcall 0 port hg1 speed=25000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg1 speed=25000', self.diag_prompt)
        #     self.sleep_time(2)
        #     self.uut.send_wise('port 54 loopback mac-rmt', self.diag_prompt)
        #     self.sleep_time(3)
        #     self.do_traffic_test('linespeed exts 55 5a 1518 10 300', 1, 420, min_pkg)
        #     self.uut.send_wise('port 54 loopback none', self.diag_prompt)
        #
        #     self.uut.send_wise('bcmcall 0 port hg1 speed=25000', self.diag_prompt)
        #     self.uut.send_wise('bcmcall 1 port hg1 speed=25000', self.diag_prompt)
        #
        #     # Other
        #     # self.do_traffic_test('linespeed extp 0-1 5a 256 10 30 mfg', 2, 90)
        #     # self.do_traffic_test('linespeed extp 4-51 5a 256 10 30 mfg', 48, 90)
        #     # self.do_traffic_test('linespeed extp 0-1 5a 1518 10 30 mfg', 2, 90)
        #     # self.do_traffic_test('linespeed extp 4-51 5a 1518 10 30 mfg', 48, 90)
        #     self.do_traffic_test('linespeed extp 0-51 5a 256 10 300 mfg', 52, 420, min_pkg)
        #     self.do_traffic_test('linespeed extp 0-51 5a 1518 10 300 mfg', 52, 420, min_pkg)

        log.debug(f'{self.mapping.platform} - Normal Traffic Test')
        port_num = self.mapping.traffic_port_num

        self.do_traffic_test('linespeed extp all 5a 256 10 300 mfg', port_num, 420, min_pkg)
        self.do_traffic_test('linespeed extp all 5a 1518 10 300 mfg', port_num, 420, min_pkg)

    def pre_traffic_test(self, min_pkg=1_000_000):
        """
            speed: [high|low]
        """

        self.set_full_speed()
        self.sleep_time(30)

        # 需要在一开始就把网线和SFP都是插好
        self.pre_check_all_ports_status()

        log.debug(f'{self.mapping.platform} - Normal Traffic Test')
        port_num = self.mapping.traffic_port_num

        self.pre_do_traffic_test('linespeed extp all 5a 256 10 300 mfg', port_num, 420, min_pkg)

    def do_traffic_test(self, command, port_num, timeout, min_pkg):
        while True:
            self.uut.send_wise(command, self.diag_prompt, timeout)
            # ports = re.findall(r'Port(\d+)\s+.+ speed test \(P\1\.TX:(\d+) P\d+\.RX:(\d+) @ \d+\.\d+\w bps \) (\S+)',
            #                    self.uut.buffer)

            ports = re.findall(r'Port(\d+)\s+\d+(?:\.\d+)?[GM] speed test \(P\1\.TX:(\d+) P\d+\.RX:(\d+)\) (\w+)',
                               self.uut.buffer)

            # ('51', '265951010', '265951010', 'PASS')
            # ('52', '10', '0', 'FAILED')
            failed = []
            for p in ports:
                num, tx, rx, result = p
                tx, rx = int(tx), int(rx)
                if result != 'PASS':
                    log.error(f'Port: {num} status is not PASS!')
                    failed.append(num)
                    continue
                if tx < min_pkg or rx < min_pkg:
                    failed.append(num)
                    log.error(f'Port: {num} TX or RX less than {min_pkg}, failed!')
                    continue
                if tx != rx:
                    failed.append(num)
                    log.error(f'Port: {num} Tx: {tx}, Rx: {rx} not equal!')
                    continue

                log.debug(f'Port: {num} traffic test Pass. -> TX: {tx}, RX: {rx}, Result: {result}')

            # 52, 53, 54, 55 有问题的话就不再重试了
            if '52' in failed or '53' in failed or '54' in failed or '55' in failed:
                raise Exception('52 or 53 or 54 or 55 port failed! Please call RD or RE for help!')

            if len(failed) != 0:
                fps = ','.join(failed)
                # msg = f'These ports are failed: {fps}. \n这些端口Traffic failed: {fps}。\nCác cổng này bị lỗi: {fps}'
                # if scanner.yes_or_enter_to_continue(question=msg) is False:
                raise Exception(f'traffic test failed: {fps} are down!')
                # continue
            # 确保查找到的端口数量符合预期
            if len(ports) != port_num:
                raise Exception(f'port num mismatch, expected: {port_num}, actual: {len(ports)}')

            if 'PASSED' not in self.uut.buffer:
                # msg = ('Not found PASSED in buffer, retry?\n'
                #        '没有发现PASSED标记，重测？\n'
                #        'không tìm thấy ĐẠT trong bộ đệm, hãy thử lại')
                # if scanner.yes_or_enter_to_continue(question=msg) is False:
                raise Exception('not found PASSED in buffer!')
                # continue

            # everything is OK
            break

    def pre_do_traffic_test(self, command, port_num, timeout, min_pkg):
        while True:
            self.uut.send_wise(command, self.diag_prompt, timeout)
            # ports = re.findall(r'Port(\d+)\s+.+ speed test \(P\1\.TX:(\d+) P\d+\.RX:(\d+) @ \d+\.\d+\w bps \) (\S+)',
            #                    self.uut.buffer)

            ports = re.findall(r'Port(\d+)\s+\d+(?:\.\d+)?[GM] speed test \(P\1\.TX:(\d+) P\d+\.RX:(\d+)\) (\w+)',
                               self.uut.buffer)

            # ('51', '265951010', '265951010', 'PASS')
            # ('52', '10', '0', 'FAILED')
            failed = []
            for p in ports:
                num, tx, rx, result = p
                tx, rx = int(tx), int(rx)
                if result != 'PASS':
                    log.error(f'Port: {num} status is not PASS!')
                    failed.append(num)
                    continue
                if tx < min_pkg or rx < min_pkg:
                    failed.append(num)
                    log.error(f'Port: {num} TX or RX less than {min_pkg}, failed!')
                    continue
                if tx != rx:
                    failed.append(num)
                    log.error(f'Port: {num} Tx: {tx}, Rx: {rx} not equal!')
                    continue

                log.debug(f'Port: {num} traffic test Pass. -> TX: {tx}, RX: {rx}, Result: {result}')

            # 52, 53, 54, 55 有问题的话就不再重试了
            if '52' in failed or '53' in failed or '54' in failed or '55' in failed:
                raise Exception('52 or 53 or 54 or 55 port failed! Please call RD or RE for help!')

            if len(failed) != 0:
                fps = ','.join(failed)
                msg = f'These ports are failed: {fps}. \n这些端口Traffic failed: {fps}。\nCác cổng này bị lỗi: {fps}'
                if scanner.yes_or_enter_to_continue(question=msg) is False:
                    raise Exception(f'traffic test failed: {fps} are down!')
                continue
            # 确保查找到的端口数量符合预期
            if len(ports) != port_num:
                raise Exception(f'port num mismatch, expected: {port_num}, actual: {len(ports)}')

            if 'PASSED' not in self.uut.buffer:
                msg = ('Not found PASSED in buffer, retry?\n'
                       '没有发现PASSED标记，重测？\n'
                       'không tìm thấy ĐẠT trong bộ đệm, hãy thử lại')
                if scanner.yes_or_enter_to_continue(question=msg) is False:
                    raise Exception('not found PASSED in buffer!')
                continue

            # everything is OK
            break

    def mgmt_test(self):
        # if yes_or_enter_to_continue('Please insert MGMT LoopBack\n请安装MGMT LoopBack!',
        #                             image='Edradour/images/mgmt-loopback.png') is False:
        #     raise Exception('user stop mgmt test!')
        reboot = False
        while True:
            # if reboot:
            #     self.reboot_diag()
            #     self.uut.send_enter(self.diag_prompt)
            self.uut.send_wise('mgmt eth0 exts 0x5a 64 10 1000', self.diag_prompt, 180)
            if 'Test pass' not in self.uut.buffer:
                # if yes_or_enter_to_continue(question='MGMT test failed! retry? MGMT测试失败，重试？') is False:
                raise Exception('mgmt test failed!')
                # reboot = True
                # continue

            tx_rx = re.search('Port eth0 TX = (\d+) RX = (\d+)', self.uut.buffer)
            if tx_rx is None:
                # if yes_or_enter_to_continue(question='not found MGMT TX RX, retry?') is False:
                raise Exception('not found TX RX data!')
                # reboot = True
                # continue

            tx, rx = tx_rx.groups()
            log.debug(f'MGMT TX: {tx}, RX: {rx}')
            if tx != '10' or rx != '10':
                # if yes_or_enter_to_continue(question='TX or RX is not 10! retry?') is False:
                raise Exception('TX or RX is not 10')
                # reboot = True
                # continue

            log.debug('[Pass Criteria] MGMT test capture: tx=10 rx=10, expect value: tx=10 rx=10, result: PASS')
            break

    def pre_mgmt_test(self):
        # if yes_or_enter_to_continue('Please insert MGMT LoopBack\n请安装MGMT LoopBack!',
        #                             image='Edradour/images/mgmt-loopback.png') is False:
        #     raise Exception('user stop mgmt test!')
        reboot = False
        while True:
            # if reboot:
            #     self.reboot_diag()
            #     self.uut.send_enter(self.diag_prompt)
            self.uut.send_wise('mgmt eth0 exts 0x5a 64 10 1000', self.diag_prompt, 180)
            if 'Test pass' not in self.uut.buffer:
                if yes_or_enter_to_continue(question='MGMT test failed! retry? MGMT测试失败，重试？') is False:
                    raise Exception('mgmt test failed!')
                # reboot = True
                continue

            tx_rx = re.search('Port eth0 TX = (\d+) RX = (\d+)', self.uut.buffer)
            if tx_rx is None:
                if yes_or_enter_to_continue(question='not found MGMT TX RX, retry?') is False:
                    raise Exception('not found TX RX data!')
                # reboot = True
                continue

            tx, rx = tx_rx.groups()
            log.debug(f'MGMT TX: {tx}, RX: {rx}')
            if tx != '10' or rx != '10':
                if yes_or_enter_to_continue(question='TX or RX is not 10! retry?') is False:
                    raise Exception('TX or RX is not 10')
                # reboot = True
                continue

            log.debug('[Pass Criteria] MGMT test capture: tx=10 rx=10, expect value: tx=10 rx=10, result: PASS')
            break

    oob_port_traffic_test = mgmt_test

    def usb_speed_test(self):
        # 先检查是否已经安装了U盘，若已经安装完毕，就不再弹窗了！
        while True:
            log.debug('detect USB Drive....')
            self.uut.send_wise('syscall ls -l /dev | grep sda*', self.diag_prompt)
            if self.uut.buffer.count('sda') <= 1:
                log.debug('USB Drive has NOT been installed! Please check!')
                if scanner.yes_or_enter_to_continue(
                        question='Please insert the USB drive. 请安装U盘',
                        image='Edradour/images/usb-drive.png'
                ) is True:
                    continue
                else:
                    raise Exception('USB Drive is not detected!')
            # 已安装U盘
            log.debug('USB Drive has been installed!')
            break

        while True:
            self.uut.send_wise('storagetest usb rndwr 200', self.diag_prompt, timeout=300)
            if 'test - PASS' not in self.uut.buffer or re.search('eror|fail', self.uut.buffer, re.I):
                log.error('not found pass signature: test - PASS. FAIL!!!!')
                if scanner.yes_or_enter_to_continue(
                        question='Please check USB drive. 请检查U盘',
                        image='Edradour/images/usb-drive.png'
                ) is False:
                    raise Exception('USB Drive test failed!')
                continue
            log.debug('found pass signature: test - PASS')
            break

    check_usb_speed_working = usb_speed_test

    def emmc_test(self):
        self.uut.send_wise('storagetest emmc rndwr 2000', self.diag_prompt, timeout=600)
        if "test - PASS" not in self.uut.buffer:
            log.error('[Pass Criteria] emmc test expect value: test - PASS, result: FAIL')
            raise Exception('emmc test failed!')
        log.debug('[Pass Criteria] emmc test expect value: test - PASS, result: PASS')

    check_emmc_working = emmc_test

    def tpm_test_physical(self):
        # tpm_tis_spi spi1.0: 2.0 TPM (device-id 0x1D, rev-id 54)
        # tpm tpm0: A TPM error (256) occurred attempting the self test
        # tpm tpm0: starting up the TPM manually
        # 第一次测试的时候会出现上述Error，是正常的
        self.uut.send_wise('syscall modprobe tpm_tis_spi', self.diag_prompt)
        self.uut.send_wise('tpm -t', self.diag_prompt)
        if 'TPM test PASS' not in self.uut.buffer:
            raise Exception('TPM test failed!')
        log.debug("[Pass Criteria] tpm -t, expected value: TPM test PASS, result: PASS")

        self.uut.send_wise('tpm -g', self.diag_prompt)
        if 'TPM test PASS' not in self.uut.buffer:
            raise Exception('TPM -g test failed!')
        log.debug("[Pass Criteria] tpm -g, expected value: TPM test PASS, result: PASS")

        # TPM_PT_MANUFACTURER:            IFX�
        manufacturer = re.search(r'TPM_PT_MANUFACTURER:\s+(\w+)', self.uut.buffer)
        if manufacturer is None:
            raise Exception('not found TPM_PT_MANUFACTURER!')
        manufacturer = manufacturer.group(1)
        if manufacturer != self.mapping.tpm_manufacturer:
            log.error(
                f'[Pass Criteria] TPM Manufacturer, capture: {manufacturer}, expect value: {self.mapping.tpm_manufacturer}, result:FAIL')
            raise Exception(
                f'TPM Manufacturer, expected: {self.mapping.tpm_manufacturer}, capture value: {manufacturer}. FAIL')
        log.debug(
            f'[Pass Criteria] TPM Manufacturer, capture: {manufacturer}, expect value: {self.mapping.tpm_manufacturer}, result:PASS')

        # TPM_PT_VENDOR_STRING:           SLB9672���������
        vendor = re.search(r'TPM_PT_VENDOR_STRING:\s+(\w+)', self.uut.buffer)
        if vendor is None:
            raise Exception('not found: TPM_PT_VENDOR_STRING')
        vendor = vendor.group(1)
        if vendor != self.mapping.tpm_vendor:
            log.error(f'[Pass Criteria] TPM Vendor, capture: {vendor}, expect value: {self.mapping.tpm_vendor}, result: FAIL')
            raise Exception(f'TPM Vendor, expected: {self.mapping.tpm_vendor}, captured: {vendor}. FAIL')
        log.debug(f'[Pass Criteria] TPM Vendor, capture: {vendor}, expect value: {self.mapping.tpm_vendor}, result: PASS')

        # TPM_PT_FIRMWARE_VERSION:        16.13.17733.0
        fw_ver = re.search(r'TPM_PT_FIRMWARE_VERSION:\s+([\w.]+)', self.uut.buffer)
        if fw_ver is None:
            raise Exception('not found: TPM_PT_FIRMWARE_VERSION')
        fw_ver = fw_ver.group(1)
        if fw_ver != self.mapping.tpm_fw_ver:
            log.error(f'[Pass Criteria] TPM FW Version, capture: {fw_ver}, expect value: {self.mapping.tpm_fw_ver}, result: FAIL')
            raise Exception(f'TPM FW Version, expected: {self.mapping.tpm_fw_ver}, captured: {fw_ver}. FAIL')
        log.debug(
            f'[Pass Criteria] TPM FW Version, capture: {fw_ver}, expect value: {self.mapping.tpm_fw_ver}, result: PASS')

        self.uut.send_wise('syscall ./eltt2 -g', self.diag_prompt)

    def fan_speed_direction_test(self):
        # fanread all
        # 0x0 ~ 0x1FF
        # fanwrite all 0x0
        log.debug(f'this SKU has {self.mapping.fan_count} fan(s)')
        if self.mapping.fan_count == 0:
            log.debug(f'no need to do fan test!')
            return

        log.debug(f'do fan test...')
        self.uut.send_wise('fantest 6', self.diag_prompt)
        if re.search('error|fail', self.uut.buffer, re.I):
            raise Exception('Fan speed test failed')
        if 'Fan test - PASS' not in self.uut.buffer:
            log.error('not found -> Fan test - PASS')
            raise Exception('fan test failed!')
        log.debug("[Pass Criteria] Fan test, expect value: Fan test - PASS, result: PASS")

    def chassis_temp_check(self):
        """
        tempread all
        Temperature#1 : [TMP75#1] : +39.50 oC
        Temperature#2 : [TMP75#2] : +23.50 oC
        Temperature#3 : [TMP75#3] : +23.0 oC
        Temperature#4 : [MAC0_Internal] : +61.8 oC
        Temperature#5 : [MAC1_Internal] : +61.8 oC
        DIAG>
        """

        self.uut.send_wise('tempread all', self.diag_prompt)
        temp = re.findall(r':\s+([+-](?:\d+)?\.\d+)\s+oC', self.uut.buffer)
        if len(temp) == 0:
            raise Exception('not found temperatures!')

        for t in temp:
            float_t = float(t)
            if not (self.mapping.low_temp <= float_t <= self.mapping.high_temp):
                msg = f'temp: {float_t} out of range, [{self.mapping.low_temp}, {self.mapping.high_temp}]'
                log.error(msg)
                raise Exception(f'temperature out of range!')
            else:
                log.debug(f'temp: {float_t} is in range: [{self.mapping.low_temp}, {self.mapping.high_temp}]')
                log.debug(f"[Pass Criteria] tempread, capture: {float_t}, expect: [{self.mapping.low_temp}, {self.mapping.high_temp}], result: PASS")

    check_system_temperature = chassis_temp_check

    def hardware_inventory_check(self):
        log.debug(f'this SKU has {self.mapping.fan_count} fan(s).')
        if self.mapping.fan_count != 0:
            self.uut.send_wise('fanlist', self.diag_prompt)
            if re.search('error|fail|absent', self.uut.buffer, flags=re.I):
                raise Exception('found error in fanlist')
            fans = re.findall(r'FAN#\d+ :', self.uut.buffer)
            log.debug(f'fan count: {len(fans)}, -> {fans}')
            if len(fans) != self.mapping.fan_count:
                log.error(f'fan count mismatch! expected: {self.mapping.fan_count}, got: {len(fans)}')
                raise Exception(f'fan count mismatch! expected: {self.mapping.fan_count}, got: {len(fans)}')
            log.debug(f'[Pass Criteria] capture: {len(fans)} fans Present, expect: {self.mapping.fan_count} fans Present, result: PASS')
        else:
            log.debug('no need to check fan...SKIP')

    check_system_configuration = hardware_inventory_check

    def ecc_errors_check(self):
        self.uut.send_wise('syscall dmesg > /var/log/messages', self.diag_prompt)
        self.uut.send_wise('syscall cat /var/log/messages | grep -i -A 5 "Correctable"', self.diag_prompt)
        self.uut.send_wise('syscall cat /var/log/messages | grep -i -A 5 "unCorrectable"', self.diag_prompt)
        if self.uut.buffer.count('unCorrectable') != 1:
            raise Exception('found ECC unCorrectable, failed!')
        log.debug(f"[Pass Criteria] ecc errors check, capture: {self.uut.buffer.count('unCorrectable')}, expect: count unCorrectable = 1, , PASS")


    def memory_size_check(self):
        self.uut.send_wise('syscall cat /proc/meminfo', self.diag_prompt)
        # MemTotal:         983960 kB
        mem_size = re.search(r'MemTotal:\s+(\d+) kB', self.uut.buffer)
        if mem_size is None:
            raise Exception('can not read mem size!')
        mem_size = mem_size.group(1)
        log.debug(f'mem size: {mem_size}')
        mem_size = int(mem_size)
        if mem_size < self.mapping.mem_size:
            raise Exception(f'mem size is not correct, expected: > {self.mapping.mem_size}, got: {mem_size}')
        log.debug(f"[Pass Criteria] memory size check, capture: {mem_size}, expect: {self.mapping.mem_size}, result: PASS")


    def check_cpu_cores(self):
        self.uut.send_wise('syscall cat /proc/cpuinfo  | grep processor', self.diag_prompt)
        cores = re.findall(r'processor\s+:\s+(\d+)', self.uut.buffer)
        if cores != ['0', '1', '2', '3']:
            raise Exception(f'cpu cores mismatch! -> bad: {cores}')
        log.debug(f"[Pass Criteria] check CPU cores, capture: {cores}, expect: {['0', '1', '2', '3']}, result: PASS")


    def type_c_test(self):
        # 先检查是否已安装 Type C - USB A
        while True:
            self.uut.send_wise('syscall ls /dev/ttyUSB0', self.diag_prompt)
            image = None
            question = 'Please connect TypeC and USB-A\n请连接TypeC和USB-A\nVui lòng kết nối TypeC và USB-A'
            if 'No such file or directory' in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(question=question, image=image) is False:
                    raise Exception('Type C to USB A failed!')
                continue
            break
        self.uut.send_wise('console test', self.uut.buffer)

    def reset_test(self):
        # I2C_MUX1
        self.uut.send_wise('rsttest I2C_MUX1', self.diag_prompt)
        if 'RST I2C_MUX1 test - PASS' not in self.uut.buffer:
            raise Exception('RST I2C_MUX1 test failed, not found -> RST I2C_MUX1 test - PASS')
        log.debug('RST I2C_MUX1 test - PASS')
        if 'RST test - PASS' not in self.uut.buffer:
            raise Exception('RST I2C_MUX1 test failed, not found -> RST test - PASS')
        log.debug('RST test - PASS')
        if re.search('fail|errro', self.uut.buffer, re.I):
            log.error('RST I2C_MUX1 failed! found: error or fail!')
            raise Exception('RST I2C_MUX1 failed! found: error or fail!')
        log.debug('[Pass Criteria] rsttest I2C_MUX1, expect: [RST I2C_MUX1 test - PASS, RST test - PASS] and no fail|error, result: PASS')

        # I2C_MUX2
        self.uut.send_wise('rsttest I2C_MUX2', self.diag_prompt)
        if 'RST I2C_MUX2 test - PASS' not in self.uut.buffer:
            raise Exception('not found -> RST I2C_MUX2 test - PASS')
        log.debug('RST I2C_MUX2 test - PASS')
        if 'RST test - PASS' not in self.uut.buffer:
            raise Exception('I2C_MUX2 test failed! not found -> RST test - PASS')
        log.debug('RST test - PASS')
        if re.search('fail|errro', self.uut.buffer, re.I):
            log.error('RST I2C_MUX2 failed! found: error or fail!')
            raise Exception('RST I2C_MUX2 failed! found: error or fail!')
        log.debug('[Pass Criteria] rsttest I2C_MUX2, expect: [RST I2C_MUX2 test - PASS, RST test - PASS] and no fail|error, result: PASS')

        # LED_SHIFT
        self.uut.send_wise('rsttest LED_SHIFT', [self.diag_prompt, 'Press N if the right LEDs are still on.'])
        if 'Press N if the right LEDs are still on.' in self.uut.buffer:
            self.uut.send('Y', self.diag_prompt)
        if 'RST LED_SHIFT test - PASS' not in self.uut.buffer:
            log.error('not found RST LED_SHIFT test - PASS')
            raise Exception('fan test failed -> RST LED_SHIFT test - PASS')
        log.debug('pass criteria -> RST LED_SHIFT test - PASS')
        if 'RST test - PASS' not in self.uut.buffer:
            log.error('RST test - PASS')
            raise Exception('fan test failed -> RST test - PASS')
        log.debug('pass criteria -> RST test - PASS')
        if re.search('fail|errro', self.uut.buffer, re.I):
            log.error('RST LED_SHIFT failed! found: error or fail!')
            raise Exception('RST LED_SHIFT failed! found: error or fail!')
        log.debug('[Pass Criteria] rsttest LED_SHIFT, expect: [RST LED_SHIFT test - PASS, RST test - PASS] and no fail|error, result: PASS')


        # TPM
        # self.uut.send_wise('rsttest TPM', self.diag_prompt)
        # if 'RST TPM test - PASS' not in self.uut.buffer:
        #     log.error('not found -> RST TPM test - PASS')
        #     raise Exception('RST TPM failed')
        # log.debug('pass criteria: RST TPM test - PASS')
        # if 'RST test - PASS' not in self.uut.buffer:
        #     log.error('not found -> RST test - PASS')
        # log.debug('pass criteria -> RST test - PASS')

        # POE_MCU_JTAG
        if self.mapping.rst_poe_mcu_jtag is True:
            self.debug(f'This SKU: {self.mapping.platform} need to RST PoE MCU')
            for i in range(3):
                self.uut.send_wise('rsttest POE_MCU_JTAG', self.diag_prompt)
                if 'RST POE_MCU_JTAG test - PASS' not in self.uut.buffer:
                    log.error('POE_MCU_JTAG test failed, not found -> RST POE_MCU_JTAG test - PASS - PASS')
                    continue
                log.debug('RST POE_MCU_JTAG test - PASS')
                if 'RST test - PASS' not in self.uut.buffer:
                    log.error('POE_MCU_JTAG test failed, not found -> RST test - PASS')
                    continue
                log.debug('RST test - PASS')
                log.debug(
                    '[Pass Criteria] rsttest POE_MCU_JTAG, expect: [RST POE_MCU_JTAG test - PASS, RST test - PASS], result: PASS')
                break
            else:
                # todo debug mode暂时跳过这个fail
                if helper.mode == helper.PROD:
                    raise Exception('RST POE_MCU_JTAG failed!')
        else:
            self.debug(f'This SKU: {self.mapping.platform} NO need to RST PoE MCU. SKIP..')

        # MG_PHY
        # if self.mapping.rst_mg_phy is True:
        #     self.debug(f'This SKU: {self.mapping.platform} need to RST MG PHY.')
        #     self.uut.send_wise('rsttest MG_PHY', self.diag_prompt)
        #     if 'RST MG_PHY test - PASS' not in self.uut.buffer:
        #         raise Exception('MG_PHY test failed, not found -> RST MG_PHY test - PASS')
        #     log.debug('RST MG_PHY test - PASS')
        #     if 'RST test - PASS' not in self.uut.buffer:
        #         raise Exception('MG_PHY test failed, not found -> RST test - PASS')
        #     log.debug('RST test - PASS')
        #     if re.search('fail|errro', self.uut.buffer, re.I):
        #         log.error('RST MG_PHY failed! found: error or fail!')
        #         raise Exception('RST MG_PHY failed! found: error or fail!')
        # else:
        #     self.debug(f'This SKU: {self.mapping.platform} NO need to RST MG PHY. SKIP..')

    check_reset_function = reset_test

    def reboot_diag(self):
        self.uut.send_wise('reboot', '')
        self.login_diag()

    def init_connections(self):
        self.uut = UUT(conn_str=helper.config['uut_conn_str'])

    def first_step_of_pre_seq(self):
        self.check_latest_repo_version(self.product_name)
        super().first_step_of_pre_seq()

    def first_step_of_main_seq(self):
        log.debug(self.mapping)

    def close_all_connections(self):
        self.uut.do_disconnect()

    def upload_test_records(self):
        self.update_test_status()
        helper.quick_set('Upload to Genius')
        super().add_genius_records(
            diagrev=self.mapping.diag_version,
            str1name='BASE_MAC',
            str1=self.mac_address,
            str2name='ASSEMBLY_REVISION',
            str2=self.mapping.arev.w_val,
            str3name='ASSEMBLY_ID',
            str3=self.mapping.aid.w_val,
            str4name='PCIE_FW_Version',
            str4=self.mapping.pcie_fw_version,
            str5name='EMMC_Version',
            str5=self.mapping.emmc_version,
            str6name='Script_Version',
            str6=self.current_version,
        )
        helper.quick_set('Upload to MES')
        self.add_mes_records()


class ORT(RIT):

    area = 'ORT'

    def ort_iterations_test(self):

        start_time = time.time()

        for cycle in range(999):
            flow = [VoltageMargin.NORMAL, VoltageMargin.HIGH, VoltageMargin.NORMAL, VoltageMargin.LOW]
            for v_idx, v_no in enumerate(flow):
                voltage_name = v_no.name
                voltage = v_no.value
                # 设置电压
                self.quick_set(f'Set Voltage {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.set_voltage_margin(voltage)

                # 检查电压
                self.quick_set(f'Check Voltage {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_voltage_margin(voltage)

                # 检查DIAG版本
                self.quick_set(f'Check DIAG Version {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_diag_version()

                # 检查PFE FE
                self.quick_set(f'Check PFE FW {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_pfe_fw()

                # 检查eMMC FW
                self.quick_set(f'Check eMMC FW {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_emmc_fw_version()

                # 检查IDEEPROM
                self.quick_set(f'Check IDEEPROM {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_ideeprom()

                # Memory Test
                self.quick_set(f'Memory Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.memory_test()

                # CPU Full load
                self.quick_set(f'CPU Full Load {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.cpu_full_load()

                # CPU Full load
                self.quick_set(f'Check System Clock {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_system_clock()

                # i2c test
                self.quick_set(f'I2C Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.i2c_test()

                # Check SFP
                self.quick_set(f'Check SFP {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_sfp_plus_eeprom()

                # Dump SFP
                self.quick_set(f'Dump SFP {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.dump_sfp_info()

                # Full Speed Traffic Test
                self.quick_set(f'Full Speed Traffic Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.traffic_test()

                # Low Speed Traffic Test
                self.quick_set(f'Low Speed Traffic Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.low_speed_traffic_test()

                # mgmt Traffic Test
                self.quick_set(f'MGMT Traffic Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.oob_port_traffic_test()

                # USB Test
                self.quick_set(f'USB Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_usb_speed_working()

                # TPM Physical Test
                self.quick_set(f'TPM Physical Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.tpm_test_physical()

                # Fan Test
                self.quick_set(f'Fan Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.fan_speed_direction_test()

                # Check temperature
                self.quick_set(f'Check Temperature {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_system_temperature()

                # Check system configuration
                self.quick_set(f'Check Hardware Inventory {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_system_configuration()

                # ECC Check
                self.quick_set(f'Check ECC {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.ecc_errors_check()

                # Check Memory Size
                self.quick_set(f'Check Memory Size {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.memory_size_check()

                # Check CPU Cores
                self.quick_set(f'Check CPU Cores {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_cpu_cores()

                # Rest Test
                self.quick_set(f'Rest Test {voltage_name} - {cycle + 1} - {v_idx + 1}')
                self.check_reset_function()

            end_time = time.time() - start_time
            if end_time >= 604800:
                break
