# Edradour

Edradour Project

## Test Station
+ PFT 主要是烧录 public key
  + BFT
    + JUNIPER_JEDEC_CODE (jedec): 7F B0 这个7FB0是常量吗？
    + 需要配置PDU，新用户：geinus/genius ADMIN
    + MSI_CHECKSUM (msi_cksum): C5 這個都是C5嗎？
    + 沒個料號的Block Size是多少？
      + iPorter2 设置
        ```text
          all conn off
          # 60w
          all setc 1120
          # 30w
          all setc 550
          all single on
          all class 8
          all det ok
          all conn on
          all meas
          ```
      + Reach 设置
          ```text
        reset all
        connect off
        single on
        class 6
        set 1111
        connect on
        det ok
        getp
        ```
## Group
G1 -- 12MP 24MP  48MP, Test Stations: BFT TPM FT
G2 -- 24P 24T 48P 48T, Test Stations: BFT TPM
G3 -- 12P 12T 8P     , Test Stations: BFT TPM
