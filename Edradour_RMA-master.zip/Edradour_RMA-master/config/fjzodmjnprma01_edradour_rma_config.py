from gen.libs import lib


ROOT = 'gen.prod.Edradour_RMA'


def ed_bft_a_config():
    genius = lib.get_genius_configuration()
    station = genius.add_test_station('ED_BFT_A')
    station.assign_pre_sequence(sequence_definition=f'{ROOT}.sequence.bft_seq.pre')

    pn_list = [
        '650-178030',
        '650-178027',
        '650-178028',
        '650-178029',
        '650-178022',
        '650-178025',
        '650-178026',
        '650-178021',
        '650-178024',
        '650-178023',
        '650-192345',
        '650-192346',
        '650-192347',

        '650-178030-TAA',
        '650-178027-TAA',
        '650-178028-TAA',
        '650-178029-TAA',
        '650-178022-TAA',
        '650-178025-TAA',
        '650-178026-TAA',
        '650-178021-TAA',
        '650-178024-TAA',
        '650-178023-TAA',
        '650-192345-TAA',
        '650-192346-TAA',
        '650-192347-TAA',

        '650-178030-FJZ',
        '650-178027-FJZ',
        '650-178028-FJZ',
        '650-178029-FJZ',
        '650-178022-FJZ',
        '650-178025-FJZ',
        '650-178026-FJZ',
        '650-178021-FJZ',
        '650-178024-FJZ',
        '650-178023-FJZ',
        '650-192345-FJZ',
        '650-192346-FJZ',
        '650-192347-FJZ',
    ]

    cell_mapping = {
        1: {'IP': '10.1.1.3', 'Port': 7001, 'APC_IP': '10.1.1.4', 'APC_Port': 1},
        2: {'IP': '10.1.1.3', 'Port': 7002, 'APC_IP': '10.1.1.4', 'APC_Port': 2},
        3: {'IP': '10.1.1.3', 'Port': 7003, 'APC_IP': '10.1.1.4', 'APC_Port': 3},
        4: {'IP': '10.1.1.3', 'Port': 7004, 'APC_IP': '10.1.1.4', 'APC_Port': 4},
        5: {'IP': '10.1.1.3', 'Port': 7005, 'APC_IP': '10.1.1.4', 'APC_Port': 5},
        6: {'IP': '10.1.1.3', 'Port': 7006, 'APC_IP': '10.1.1.4', 'APC_Port': 6},
        7: {'IP': '10.1.1.3', 'Port': 7007, 'APC_IP': '10.1.1.4', 'APC_Port': 7},
        8: {'IP': '10.1.1.3', 'Port': 7008, 'APC_IP': '10.1.1.4', 'APC_Port': 8},
        9: {'IP': '10.1.1.3', 'Port': 7009, 'APC_IP': '10.1.1.4', 'APC_Port': 9},
        10: {'IP': '10.1.1.3', 'Port': 7010, 'APC_IP': '10.1.1.4', 'APC_Port': 10},
        11: {'IP': '10.1.1.3', 'Port': 7011, 'APC_IP': '10.1.1.4', 'APC_Port': 11},
        12: {'IP': '10.1.1.3', 'Port': 7012, 'APC_IP': '10.1.1.4', 'APC_Port': 12},
        13: {'IP': '10.1.1.3', 'Port': 7013, 'APC_IP': '10.1.1.4', 'APC_Port': 13},
        14: {'IP': '10.1.1.3', 'Port': 7014, 'APC_IP': '10.1.1.4', 'APC_Port': 14},
        # 15: {'IP': '10.1.1.3', 'Port': 7015, 'APC_IP': '10.1.1.4', 'APC_Port': 15},
        # 16: {'IP': '10.1.1.3', 'Port': 7016, 'APC_IP': '10.1.1.4', 'APC_Port': 16},
    }

    for pn in pn_list:
        station.add_pid_map(pid=pn, sequence_definition=f'{ROOT}.sequence.bft_seq.main')

    for idx in range(1, 15):
        container = station.add_container(name=f'UUT{idx:02d}')
        ip, port = cell_mapping[idx]['IP'], cell_mapping[idx]['Port']
        container.add_configuration_data('uut_conn_str', f'telnet {ip} {port}')
        container.add_configuration_data('server', 'fjzodmjnprma01')

        apc_ip, apc_port = cell_mapping[idx]['APC_IP'], cell_mapping[idx]['APC_Port']
        container.add_configuration_data('pdu_conn_str', f'telnet {apc_ip}')
        container.add_configuration_data('pdu_port', f'{apc_port}')
        container.add_configuration_data('poe_config', poe_mapping)
        container.add_configuration_data('uut_ip', f'10.1.1.{100 + idx}')
        container.add_configuration_data('serverip', f'10.1.1.1')
        container.add_configuration_data('gateway', f'10.1.1.1')
        container.add_configuration_data('netmask', f'255.255.255.0')

        # connections
        container.add_connection(name='UUT', protocol='ssh')
        container.add_connection(name='APC', protocol='ssh')
        container.add_connection(name='POE1', protocol='ssh')
        container.add_connection(name='POE2', protocol='ssh')


def ed_bft_b_config():
    genius = lib.get_genius_configuration()
    station = genius.add_test_station('ED_BFT_B')
    station.assign_pre_sequence(sequence_definition=f'{ROOT}.sequence.bft_seq.pre')

    pn_list = [
        '650-178030',
        '650-178027',
        '650-178028',
        '650-178029',
        '650-178022',
        '650-178025',
        '650-178026',
        '650-178021',
        '650-178024',
        '650-178023',
        '650-192345',
        '650-192346',
        '650-192347',

        '650-178030-TAA',
        '650-178027-TAA',
        '650-178028-TAA',
        '650-178029-TAA',
        '650-178022-TAA',
        '650-178025-TAA',
        '650-178026-TAA',
        '650-178021-TAA',
        '650-178024-TAA',
        '650-178023-TAA',
        '650-192345-TAA',
        '650-192346-TAA',
        '650-192347-TAA',

        '650-178030-FJZ',
        '650-178027-FJZ',
        '650-178028-FJZ',
        '650-178029-FJZ',
        '650-178022-FJZ',
        '650-178025-FJZ',
        '650-178026-FJZ',
        '650-178021-FJZ',
        '650-178024-FJZ',
        '650-178023-FJZ',
        '650-192345-FJZ',
        '650-192346-FJZ',
        '650-192347-FJZ',
    ]

    cell_mapping = {
        17: {'IP': '10.1.1.3', 'Port': 7017, 'APC_IP': '10.1.1.201', 'APC_Port': 1},
        18: {'IP': '10.1.1.3', 'Port': 7018, 'APC_IP': '10.1.1.201', 'APC_Port': 2},
        19: {'IP': '10.1.1.3', 'Port': 7019, 'APC_IP': '10.1.1.201', 'APC_Port': 3},
        20: {'IP': '10.1.1.3', 'Port': 7020, 'APC_IP': '10.1.1.201', 'APC_Port': 4},
        21: {'IP': '10.1.1.3', 'Port': 7021, 'APC_IP': '10.1.1.201', 'APC_Port': 5},
        22: {'IP': '10.1.1.3', 'Port': 7022, 'APC_IP': '10.1.1.201', 'APC_Port': 6},
        23: {'IP': '10.1.1.3', 'Port': 7023, 'APC_IP': '10.1.1.201', 'APC_Port': 7},
        24: {'IP': '10.1.1.3', 'Port': 7024, 'APC_IP': '10.1.1.201', 'APC_Port': 8},
        25: {'IP': '10.1.1.3', 'Port': 7025, 'APC_IP': '10.1.1.201', 'APC_Port': 9},
        26: {'IP': '10.1.1.3', 'Port': 7026, 'APC_IP': '10.1.1.201', 'APC_Port': 10},
        27: {'IP': '10.1.1.3', 'Port': 7027, 'APC_IP': '10.1.1.201', 'APC_Port': 11},
        28: {'IP': '10.1.1.3', 'Port': 7028, 'APC_IP': '10.1.1.201', 'APC_Port': 12},
        29: {'IP': '10.1.1.3', 'Port': 7029, 'APC_IP': '10.1.1.201', 'APC_Port': 13},
        30: {'IP': '10.1.1.3', 'Port': 7030, 'APC_IP': '10.1.1.201', 'APC_Port': 14},
        # 31: {'IP': '10.1.1.3', 'Port': 7031, 'APC_IP': '10.1.1.201', 'APC_Port': 15},
        # 32: {'IP': '10.1.1.3', 'Port': 7032, 'APC_IP': '10.1.1.201', 'APC_Port': 16},
    }

    for pn in pn_list:
        station.add_pid_map(pid=pn, sequence_definition=f'{ROOT}.sequence.bft_seq.main')

    for idx in range(17, 31):
        container = station.add_container(name=f'UUT{idx:02d}')
        ip, port = cell_mapping[idx]['IP'], cell_mapping[idx]['Port']
        container.add_configuration_data('uut_conn_str', f'telnet {ip} {port}')
        container.add_configuration_data('server', 'fjzodmjnprma01')

        apc_ip, apc_port = cell_mapping[idx]['APC_IP'], cell_mapping[idx]['APC_Port']
        container.add_configuration_data('pdu_conn_str', f'telnet {apc_ip}')
        container.add_configuration_data('pdu_port', f'{apc_port}')
        container.add_configuration_data('uut_ip', f'10.1.1.{100 + idx}')
        container.add_configuration_data('serverip', f'10.1.1.1')
        container.add_configuration_data('gateway', f'10.1.1.1')
        container.add_configuration_data('netmask', f'255.255.255.0')

        # connections
        container.add_connection(name='UUT', protocol='ssh')
        container.add_connection(name='APC', protocol='ssh')
        container.add_connection(name='POE1', protocol='ssh')
        container.add_connection(name='POE2', protocol='ssh')


poe_mapping = {
    'fjzodmjnprma01': {
        'non48': {
            '01': ['POE1', f'telnet 10.1.1.3 7015'],
            '02': ['POE1', f'telnet 10.1.1.3 7015'],
            '03': ['POE1', f'telnet 10.1.1.3 7015'],
            '04': ['POE1', f'telnet 10.1.1.3 7015'],
            '05': ['POE1', f'telnet 10.1.1.3 7015'],
            '06': ['POE1', f'telnet 10.1.1.3 7015'],
            '07': ['POE1', f'telnet 10.1.1.3 7015'],
            '08': ['POE1', f'telnet 10.1.1.3 7016'],
            '09': ['POE1', f'telnet 10.1.1.3 7016'],
            '10': ['POE1', f'telnet 10.1.1.3 7016'],
            '11': ['POE1', f'telnet 10.1.1.3 7016'],
            '12': ['POE1', f'telnet 10.1.1.3 7016'],
            '13': ['POE1', f'telnet 10.1.1.3 7016'],
            '14': ['POE1', f'telnet 10.1.1.3 7016'],

            '17': ['POE1', f'telnet 10.1.1.3 7031'],
            '18': ['POE1', f'telnet 10.1.1.3 7031'],
            '19': ['POE1', f'telnet 10.1.1.3 7031'],
            '20': ['POE1', f'telnet 10.1.1.3 7031'],
            '21': ['POE1', f'telnet 10.1.1.3 7031'],
            '22': ['POE1', f'telnet 10.1.1.3 7031'],
            '23': ['POE1', f'telnet 10.1.1.3 7031'],
            '24': ['POE1', f'telnet 10.1.1.3 7032'],
            '25': ['POE1', f'telnet 10.1.1.3 7032'],
            '26': ['POE1', f'telnet 10.1.1.3 7032'],
            '27': ['POE1', f'telnet 10.1.1.3 7032'],
            '28': ['POE1', f'telnet 10.1.1.3 7032'],
            '29': ['POE1', f'telnet 10.1.1.3 7032'],
            '30': ['POE1', f'telnet 10.1.1.3 7032'],
        },
        '48': {
            '01': [['POE1', f'telnet 10.1.1.3 7015'], ['POE2', f'telnet 10.1.1.3 7016']],
            '02': [['POE1', f'telnet 10.1.1.3 7015'], ['POE2', f'telnet 10.1.1.3 7016']],
            '03': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],
            '04': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],
            '05': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],
            '06': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],
            '07': [['POE1', f'telnet 10.1.1.3 7015'], ['POE2', f'telnet 10.1.1.3 7016']],
            '08': [['POE1', f'telnet 10.1.1.3 7015'], ['POE2', f'telnet 10.1.1.3 7016']],
            '09': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],
            '10': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],
            '11': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],
            '12': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],
            '13': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],
            '14': [['POE1', 'telnet 10.1.1.3 7015'], ['POE2', 'telnet 10.1.1.3 7016']],

            '17': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '18': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '19': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '20': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '21': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '22': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '23': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '24': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '25': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '26': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '27': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '28': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '29': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
            '30': [['POE1', 'telnet 10.1.1.3 7031'], ['POE2', 'telnet 10.1.1.3 7032']],
        },
    },
}




