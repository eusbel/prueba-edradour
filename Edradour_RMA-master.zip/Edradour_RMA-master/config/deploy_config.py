from gen.libs import lib

ROOT_PATH = "gen.prod.Edradour_RMA.deploy.usage"


def deploy_config():
    # get genius configuration instance.
    gen = lib.get_genius_configuration()

    # create a station. stations' name could not be duplicated.
    station = gen.add_test_station("DEPLOY")

    # create a container. container' name could not be duplicated.
    container = station.add_container(name="BUILD")
    # container assign pre sequence will override station's
    container.assign_pre_sequence(sequence_definition="{}.build_run.pre".format(ROOT_PATH))
    # container add pid map will override station's
    container.add_pid_map(pid="BUILD", sequence_definition="{}.build_run.main".format(ROOT_PATH))
    # container add a dummy connection
    container.add_connection(name="UUT", protocol="dummy")
    container.add_configuration_data("uuttype", "BUILD")

    # create a container. container' name could not be duplicated.
    container = station.add_container(name="DIST")
    # container assign pre sequence will override station's
    container.assign_pre_sequence(sequence_definition="{}.dist_run.pre".format(ROOT_PATH))
    # container add pid map will override station's
    container.add_pid_map(pid="DIST", sequence_definition="{}.dist_run.main".format(ROOT_PATH))
    # container add a dummy connection
    container.add_connection(name="UUT", protocol="dummy")
    container.add_configuration_data("uuttype", "DIST")
