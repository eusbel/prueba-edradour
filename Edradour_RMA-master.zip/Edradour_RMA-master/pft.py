import os.path
import platform
import re

from .common.models import GeniusRecordFields
from .common.quantum import Quantum
from .common.utils import helper
from .common.fields import StrField, Field
from .common import sfchelper
from .common import scanner
from .define import define
from .common.logger import log
from .define.define import cookie_mapping
from .common.pc import PC


class PFT(Quantum):
    # connection
    fixture = None
    uut = None
    pc_pw = StrField()

    sernum = StrField()
    uuttype = StrField()
    #
    mapping = Field()  # type: define.EX4K

    # connection
    pc_ip = StrField()
    uut_com_id = StrField()
    fixture_com_id = StrField()

    area = StrField('PFT')

    def first_step_of_pre_seq(self):
        super().first_step_of_pre_seq()
        self.container = helper.get_container_name()
        self.machine = platform.node()

    def scan_uut_sn(self):

        # 扫描 SN
        ans = scanner.ask_question(question='Please scan label. 请扫描标签。 Quét thẻ SN')
        self.sernum = ans

        # 查询 MES LABEL PN
        pn = sfchelper.get_611_pn_by_sn(sn=self.sernum)
        # 2nd source NPI
        if 'A' in pn:
            pn = pn[:-1]
        # if pn not in cookie_mapping.keys():
        #     raise Exception(f'Part Number: {pn} is not supported! acceptable list: {list(cookie_mapping.keys())}')
        # self.uuttype = pn
        #
        # # 读取预定义数据
        # self.mapping = cookie_mapping[pn]

        self.uuttype = pn

        # 打印初始化的参数
        log.debug(f'SN: {self.sernum}, Label PN:{pn}, UUTType: {self.uuttype}')

        # 记得添加测试记录
        helper.add_record(sn=self.sernum, pn=self.uuttype, area=self.area)


    def check_mes_event(self):
        self.mes_check_event(sn=self.sernum, area=self.area)

    def init_config(self):
        self.pc_ip = helper.config['pc_ip']
        self.fixture_com_id = helper.config['fixture_com_id']
        self.uut_com_id = helper.config['uut_com_id']
        self.pc_pw = helper.config['pc_password']

    def init_connections(self):
        self.fixture = PC(name='FIXTURE', ip=self.pc_ip, com_id=self.fixture_com_id, program_dir=r'C:\prod\jasper', password=self.pc_pw)
        self.fixture.do_connect()
        self.uut = PC(name='UUT', ip=self.pc_ip, com_id=self.uut_com_id, program_dir=r'C:\prod\jasper', password=self.pc_pw)
        self.uut.do_connect()

    def get_equipment_console(self):
        self.fixture.get_console()

    def get_uut_console(self):
        self.uut.get_console()

    def read_to_test(self):
        # if not scanner.yes_or_enter_to_continue('Ready to Test?'):
        #     raise Exception('not ready to test')

        self.fixture.send_wise('OPEN', ["OK", "OPEN_OK"])
        log.debug("Fixture open OK !")

        self.fixture.send_wise('CLOSE', ["start OK", "close OK", "CLOSE_OK"])
        log.debug("Fixture close OK !")

        self.fixture.send_wise('UP', ["OK", "UP_OK", "up1 OK"])
        log.debug("Fixture up OK !")

        self.fixture.send_wise('DOWN', ["OK", "DOWN_OK", "down OK"])
        log.debug("Fixture close OK !")

        self.fixture.send_wise('OPEN', ["OK", "OPEN_OK"])
        log.debug("Fixture open OK !")

    def close_connections(self):
        self.pc.do_disconnect()


