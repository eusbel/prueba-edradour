import xlrd
from ..common.utils import helper

def get_sn_list():
    """
    for 48MP cpld rework
    date:2025/04/05
    """
    # 打开Excel文件
    file_path = helper.get_full_path('DEV-25575 Rework SN LIst.xlsx')
    workbook = xlrd.open_workbook(file_path)
    sheet = workbook.sheet_by_name('SN LIST')

    # 获取列索引（找出SN和Mark列）
    header = sheet.row_values(0)
    sn_index = header.index("SN")
    mark_index = header.index("Mark")

    # 筛选符合条件的SN
    sn_list = []
    for row_idx in range(1, sheet.nrows):
        row = sheet.row_values(row_idx)
        if row[mark_index] == "TE-Vinson add SN to skip checking at BFT":
            sn_list.append(row[sn_index])
    return sn_list

def get_sn_list1():
    """
    for 12&4MP cpld skip check secondary
    date:2025/04/23
    """
    # 打开Excel文件
    file_path = helper.get_full_path('Edradour SN list.xlsx')
    workbook = xlrd.open_workbook(file_path)
    sheet = workbook.sheet_by_name('Sheet1')

    # 获取列索引（找出SN和Mark列）
    header = sheet.row_values(0)
    sn_index = header.index("SN")
    # mark_index = header.index("Mark")

    # 筛选符合条件的SN
    sn_list = []
    for row_idx in range(1, sheet.nrows):
        row = sheet.row_values(row_idx)
        sn_list.append(row[sn_index])
    return sn_list

NONE_CHECK_SECONDARY_CPLD_12_24MP_SN = get_sn_list1()

NONE_CHECK_SECONDARY_CPLD_48MP_SN = get_sn_list()
