# 12 24 48 都有T P MP
# 8 只有P

# Part Number
PN_EX4000_8P = '650-178030'

PN_EX4000_12MP = '650-178027'
PN_EX4000_12P = '650-178028'
PN_EX4000_12T = '650-178029'

PN_EX4000_24MP = '650-178022'
PN_EX4000_24P = '650-178025'
PN_EX4000_24T = '650-178026'

PN_EX4000_48MP = '650-178021'
PN_EX4000_48P = '650-178023'
PN_EX4000_48T = '650-178024'

PN_EX4000_8P_TAA = '650-178030-TAA'
PN_EX4000_12MP_TAA = '650-178027-TAA'
PN_EX4000_12P_TAA = '650-178028-TAA'
PN_EX4000_12T_TAA = '650-178029-TAA'
PN_EX4000_24MP_TAA = '650-178022-TAA'
PN_EX4000_24P_TAA = '650-178025-TAA'
PN_EX4000_24T_TAA = '650-178026-TAA'
PN_EX4000_48MP_TAA = '650-178021-TAA'
PN_EX4000_48P_TAA = '650-178023-TAA'
PN_EX4000_48T_TAA = '650-178024-TAA'
PN_EX4000_12MUP_TAA = '650-192345-TAA'
PN_EX4000_24MUP_TAA = '650-192346-TAA'
PN_EX4000_48MUP_TAA = '650-192347-TAA'

PN_EX4000_8P_FJZ = '650-178030-FJZ'
PN_EX4000_12MP_FJZ = '650-178027-FJZ'
PN_EX4000_12P_FJZ = '650-178028-FJZ'
PN_EX4000_12T_FJZ = '650-178029-FJZ'
PN_EX4000_24MP_FJZ = '650-178022-FJZ'
PN_EX4000_24P_FJZ = '650-178025-FJZ'
PN_EX4000_24T_FJZ = '650-178026-FJZ'
PN_EX4000_48MP_FJZ = '650-178021-FJZ'
PN_EX4000_48P_FJZ = '650-178023-FJZ'
PN_EX4000_48T_FJZ = '650-178024-FJZ'
PN_EX4000_12MUP_FJZ = '650-192345-FJZ'
PN_EX4000_24MUP_FJZ = '650-192346-FJZ'
PN_EX4000_48MUP_FJZ = '650-192347-FJZ'


# Fox PN
# G1
FOX_PN_48MP = 'BUA4O010T50'
FOX_PN_24MP = 'BUA4O010T26'
FOX_PN_12MP = 'BUA4O010T14'
# G2
FOX_PN_24T = 'BUA4O010T24'
FOX_PN_24P = 'BUA4O010T25'
FOX_PN_48T = 'BUA4O010T48'
FOX_PN_48P = 'BUA4O010T49'
# G3
FOX_PN_8P = 'BUA4O010T08'
FOX_PN_12T = 'BUA4O010T12'
FOX_PN_12P = 'BUA4O010T13'

# Model Num
MN_EX4000_8P = 'EX4000-8P'

MN_EX4000_12MP = 'EX4000-12MP'
MN_EX4000_12P = 'EX4000-12P'
MN_EX4000_12T = 'EX4000-12T'

MN_EX4000_24T = 'EX4000-24T'
MN_EX4000_24P = 'EX4000-24P'
MN_EX4000_24MP = 'EX4000-24MP'

MN_EX4000_48T = 'EX4000-48T'
MN_EX4000_48P = 'EX4000-48P'
MN_EX4000_48MP = 'EX4000-48MP'

GROUP_1 = 'G1'
GROUP_2 = 'G2'
GROUP_3 = 'G3'


class Item:
    """定义了读取的规则，当读取的内容是空字符串或者None会抛出ValueError"""

    def __init__(self, value=None):
        self.name = ''
        self.value = value

    def __get__(self, instance, owner):
        if self.value is None:
            raise ValueError(f'{self.name}, can not read a None value, please set a value before using!')
        if self.value == '':
            raise ValueError(f'{self.name}, can not read a empty string, please set a value before using!')
        return self.value

    def __set__(self, instance, value):
        self.value = value

    def __set_name__(self, owner, name):
        self.name = name

    def __str__(self):
        return f'(Item >> {self.name} = {self.value})'

    __repr__ = __str__


class EEPROM:
    def __init__(self, w_name, w_val, r_name, r_val):
        self.__w_name = w_name
        self.__w_val = w_val
        self.__r_name = r_name
        self.__r_val = r_val

    def __str__(self):
        return f'w_name = {self.w_name}, w_val = {self.w_val}, r_name = {self.__r_name}, r_val = {self.__r_val}'

    __repr__ = __str__

    @property
    def w_name(self):
        if self.__w_name is None or self.__w_name == '':
            raise NameError(f'please name: {self.__w_name} is not None or empty string')
        return self.__w_name

    @property
    def w_val(self):
        if self.__w_val is None:
            raise ValueError(f'please {self.__w_name} val: {self.__w_val} is not None')
        return self.__w_val

    @property
    def r_name(self):
        if self.__r_name is None or self.__r_name == '':
            raise NameError(f'please name: {self.__r_name} is not None or empty string')
        return self.__r_name

    @property
    def r_val(self):
        if self.__r_val is None:
            raise ValueError(f'please {self.__r_name} val:{self.__r_val} is not None')
        return self.__r_val

    def set(self, w_name=None, w_val=None, r_name=None, r_val=None):
        if w_name is not None:
            self.__w_name = w_name
        if w_val is not None:
            self.__w_val = w_val
        if r_name is not None:
            self.__r_name = r_name
        if r_val is not None:
            self.__r_val = r_val


"""
G1 -> EX4000-12MP  EX4000-24MP  EX4000-48MP
G2 -> EX4000-24P   EX4000-24T   EX4000-48P    EX4000-48T
G3 -> EX4000-8P    EX4000-12T   EX4000-12P
"""


class EX4K:
    """定义"""
    product_name = Item('Edradour')

    uut_ip = Item()
    netmask = Item()
    serverip = Item()
    gateway = Item()
    check_list_env = Item()

    # Group
    group = Item()

    # 只有48Port的需要
    check_pfe_fw = Item(False)
    epdm = Item()
    #bft_poe = Item('6.0.0.B12')
    bft_poe = Item(['6.0.0.B3', '6.0.0.B12'])

    pcie_fw_version = Item('D102_0B')
    emmc_version = Item(['0000000000000011', '0000000000000016', '0000000000000017'])

    sfp_ports = Item()
    # 只包含外部可以安装RJ45或者SFP的端口
    traffic_port_num = Item()
    # 48MP/48P/48T = 3, another = 4
    traffic_cycle = Item(4)
    led_port_seq = Item()
    mgmt_port = Item()
    eth_amber = Item()
    # 只有G1的需要，G2 G3不需要 -- 2024-06-27
    erase_shmoo = Item()
    # Erase 以后要按的动作
    ddr_mode_speed = Item()

    # fan
    # Only 24T/24P/48P/48T/12MP/24MP/48MP
    fan_count = Item()

    # U-boot
    # u_boot_file = Item('uboot-2.7-ex4000_builder-2024-10-11-secure-signed_diag_flash.img')
    # u_boot_version = Item('U-Boot 2022.10-uboot-2.7-ex4000_builder-2024-10-11.1-secure-signed (Oct 11 2024 - 10:53:00 -0700)')
    # u_boot_file = Item('uboot_diag_cap.img')
    # u_boot_version = Item('2022.10-uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed')

    u_boot_file = Item('uboot-2.11-ex4000_builder-2025-01-03-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.11-ex4000_builder-2025-01-03.1-secure-signed (Jan 03 2025 - 08:40:50 -0800)')
    check_u_boot_version = Item('uboot-2.11-ex4000_builder-2025-01-03.1-secure-signed')


    # Fox U Boot
    # u_boot_file = Item('Edradour_UBOOT_1.0.7_sb_flash_img.bin')
    # u_boot_version = Item('U-Boot 2023.10--svn36299 (Aug 26 2024 - 08:18:58 +0800)')

    # U-boot spl -- 最新烧录客人的已经不不需要这个spl文件了。
    u_boot_file_spl = Item()

    # DIAG
    # diag_file = Item('Edradour_DIAG_v2.0.3_uImage_initramfs.img')
    # diag_version = Item('DIAG_v2.0.3 (Oct 24 2024 - 18:33:32)')
    # diag_file = Item('Edradour_DIAG_v2.0.5_uImage_initramfs.img')
    # diag_version = Item('DIAG_v2.0.5 (Dec 13 2024 - 16:25:25)')
    # diag_file = Item('Edradour_DIAG_v2.0.6_uImage_initramfs.img')
    # diag_version = Item('DIAG_v2.0.6 (Jan 21 2025 - 10:06:02)')
    # old_diag_file = Item('Edradour_DIAG_v2.2.7_uImage_initramfs.img')
    # old_diag_version = Item('DIAG_v2.2.7 (Oct  3 2025 - 18:31:34)')
    old_diag_file = Item('Edradour_DIAG_v2.2.8_uImage_initramfs.img')
    old_diag_version = Item('DIAG_v2.2.8 (Nov  4 2025 - 09:20:56)')
    # diag_file = Item('Edradour_DIAG_v2.1.1_uImage_initramfs.img')
    # diag_version = Item('DIAG_v2.1.1 (May 13 2025 - 18:01:52)')
    # diag_file = Item('Edradour_DIAG_v2.2.6_uImage_initramfs.img')
    # diag_version = Item('DIAG_v2.2.6 (Sep 18 2025 - 19:52:56)')
    # diag_file = Item('Edradour_DIAG_v2.2.8_uImage_initramfs.img')
    # diag_version = Item('DIAG_v2.2.8 (Nov  4 2025 - 09:20:56)')
    diag_file = Item('Edradour_DIAG_v2.3.0_uImage_initramfs.img')
    diag_version = Item('DIAG_v2.3.0 (Dec 16 2025 - 16:27:58)')
    # CPU Device info
    cpu_device = Item('BCM953650K')
    # PCIe FW loader version: 2.13
    pcie_fw_loader_version = Item('2.13')

    # 20240807 开始全部使用下面的这个版本
    # cpld_filename = Item('edradour_sys_cpld_v_01_1A_092724_p.vme')
    # cpld_version = Item('1.13.0')
    # cpld_filename = Item('edradour_sys_cpld_v_01_22_010325_p.vme')
    # cpld_version = Item('1.17.0')
    junos_cpld_filename = Item('jfirmware-ex40xx_24.4R1S2.tgz')

    cpld_filename_old = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
    cpld_version_old = Item('1.18.0')
    cpld_old = Item('1.24')
    secondary_cpld_old = Item('1.25')
    cpld_filename = Item('edradour_sys_cpld_v_01_26_060425_p.vme')
    cpld_version = Item('1.19.0')
    cpld = Item('1.26')
    secondary_cpld = Item('1.27')


    # TPM
    # tpm_manufacturer = Item('IFX')
    # tpm_vendor = Item('SLB9672')
    # tpm_fw_ver = Item('16.13.17733.0')
    # TPM
    # todo
    # tpm_fw_ver = tpm2_fw_version = Item('16.24.19084.0')
    tpm_fw_ver = tpm2_fw_version = Item('16.13.17733.0')
    tpm_vendor = tpm2_vendor = Item('SLB9672')
    tpm_manufacturer = tpm2_manufacturer = Item('IFX')

    # tpm2_dir = 'C:\\TPM'
    # tpm2_file_old = Item('tpm2-20240112-210042Z.b716d75181.tar')
    # tpm2_file_version_old = Item('20240112-210042Z.b716d75181')
    # tpm2_file_md5_old = Item('fc9affabf5f44ed19c6b897da3c32b09')
    # tpm2_product_id_old = Item('DeMks46zxcFY8JFFk')

    # tpm2_file = Item('tpm2-20250530-220529Z.ec4146cdfe.tar')
    # tpm2_file_version = Item('20250530-220529Z.ec4146cdfe')
    # tpm2_file_md5 = Item('8a173582471a910b29f8d190a83c4341')

    # ECO-61731
    # tpm2_file = Item('tpm2-20250205-214227Z.2616853469.tar')
    # tpm2_file_version = Item('20250205-214227Z.2616853469')
    # tpm2_file_md5 = Item('0b0aba3604ad3bb62bdb358274021bce')
    # tpm2_product_id = Item('Fn9AMEtjrrZA2cWZ7')
    tpm2_file_old = Item('tpm2-20250205-214227Z.2616853469.tar')
    tpm2_file_version_old = Item('20250205-214227Z.2616853469')
    tpm2_file_md5_old = Item('0b0aba3604ad3bb62bdb358274021bce')
    tpm2_product_id_old = Item('Fn9AMEtjrrZA2cWZ7')

    # ECO-62426
    tpm2_file = Item('tpm2-20250605-211418Z.954f5568d9.tar')
    tpm2_file_version = Item('20250605-211418Z.954f5568d9')
    tpm2_file_md5 = Item('059d000de6396ad10b512e84cf741ab5')
    tpm2_product_id = Item('Fn9AMEtjrrZA2cWZ7')

    # FST JNPR UBOOT
    # jnpr_uboot = Item('uboot-2.7-ex4000_builder-2024-10-11-secure-signed_diag_flash.img')
    # jnpr_uboot_version = Item('U-Boot 2022.10-uboot-2.7-ex4000_builder-2024-10-11.1-secure-signed (Oct 11 2024 - 10:53:00 -0700)')
    # jnpr_uboot = Item('uboot-2.7-upgrade-MFG-PRD-JHROT.cap')
    # jnpr_uboot_version = Item('2022.10-uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed')
    # jnpr_uboot = Item('uboot-2.8-upgrade-MFG-PRD-jHRoT.img')
    jnpr_uboot_version = Item('uboot-2.11-ex4000_builder-2025-01-03-secure-signed (Jan 03 2025 - 08:42:50 -0800)')
    jnpr_uboot = Item('uboot-2.11-ex4000_builder-2025-01-03-secure-signed_flash.img')
    u_boot = Item('2.11')
    upload_uboot = Item("2022.10-uboot-2.14")
    poe = Item('6.0.0.12.0')
    # cpld = Item('1.22')
    # secondary_cpld = Item('1.25')

    # JUNOS
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4I-20241014.0.0829.tgz')
    # junos_version = Item('24.4I-20241014.0.0829')
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1.12.tgz')
    # junos_version = Item('24.4R1.12')
    junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R2.25.tgz')
    junos_version = Item('24.4R2.25')
    junos_poe_firmware_version = Item('6.0.0.12.0 (type4)')

    # root password
    junos_root_password = Item('Juniper123')

    rj45_ports = Item()
    platform = Item()
    poe_power_limit = Item()
    poe_power = Item()
    poe_ports = Item()
    poe_current = Item()
    poe_class = Item()
    poe_seq = Item()
    poe_function = Item()
    # ma
    poe_traffic_current = Item(295)
    # w
    poe_traffic_min_power = Item(15)

    # Only 8P/12P/24P/48P/12MP/24MP/48MP 是True，其他的都是False
    rst_poe_mcu_jtag = Item(False)
    # Only 12MP/24MP/48MP 是True，其他都是False
    rst_mg_phy = Item(False)
    # MAC Block Size，全部都是128
    mac_block_size = Item(128)

    # connection
    pc_ip = Item()
    uut_com_id = Item()
    fixture_com_id = Item()

    # ID EEPROM
    jedec = EEPROM(w_name='jedec', w_val='7FB0', r_name='JUNIPER_JEDEC_CODE (jedec)', r_val='7F B0')
    eeprom_ver = EEPROM(w_name='eeprom_ver', w_val='02', r_name='ID_EEPROM_FORMAT_VERSION (eeprom_ver)', r_val='02')
    bit_field = EEPROM(w_name='bit_field', w_val='FF', r_name='BIT_FIELDS (bit_field)', r_val='FF')
    aid = EEPROM(w_name='aid', w_val=None, r_name='ASSEMBLY_ID (aid)', r_val=None)
    aver_maj = EEPROM(w_name='aver_maj', w_val='1', r_name='ASSEMBLY_MAJOR_VERSION (aver_maj)', r_val='01')
    # 这个值从MES系统获取
    aver_min = EEPROM(w_name='aver_min', w_val=None, r_name='ASSEMBLY_MINOR_VERSION (aver_min)', r_val=None)
    # 取消这个项目
    # arev_0 = EEPROM(w_name='arev-0', w_val="'REV '", r_name='ASSEMBLY_REVISION-0 (arev-0)', r_val="REV")
    arev = EEPROM(w_name='arev', w_val='02', r_name='ASSEMBLY_REVISION (arev)', r_val='02')
    apn = EEPROM(w_name='apn', w_val=None, r_name='ASSEMBLY_PART_NUM (apn)', r_val=None)
    asn = EEPROM(w_name='asn', w_val=None, r_name='ASSEMBLY_SERIAL_NUM (asn)', r_val=None)
    afg = EEPROM(w_name='afg', w_val='0', r_name='ASSEMBLY_FLAG (afg)', r_val='00')
    # 以下三项需要在程序中动态产生，也是使用UTC，16进制的形式
    asd = EEPROM(w_name='asd', w_val=None, r_name='ASSEMBLY_MFG_DAY (asd)', r_val=None)
    asm = EEPROM(w_name='asm', w_val=None, r_name='ASSEMBLY_MFG_MONTH (asm)', r_val=None)
    asy = EEPROM(w_name='asy', w_val=None, r_name='ASSEMBLY_MFG_YEAR (asy)', r_val=None)
    # rsv1 = EEPROM(w_name='rsv1', w_val=None, r_name='RESERVED_1 (rsv1)', r_val=None)
    # cuid = EEPROM(w_name='cuid', w_val=None, r_name='CUSTOMER_IDENTIFICATION (cuid)', r_val=None)
    mac_mc = EEPROM(w_name='mac_mc', w_val="AD", r_name='MAC_MAGIC_CODE (mac_mc)', r_val="AD")
    mac_fv = EEPROM(w_name='mac_fv', w_val="01", r_name='MAC_FORMAT_VERSION (mac_fv)', r_val="01")
    mac_ent = EEPROM(w_name='mac_ent', w_val='0080', r_name='MAC_ENTRY (mac_ent)', r_val='00 80')
    mac = EEPROM(w_name='mac', w_val=None, r_name='MAC_BASE (mac)', r_val=None)
    # rsv2 = EEPROM(w_name='rsv2', w_val=None, r_name='RESERVED_2 (rsv2)', r_val=None)
    msi = EEPROM(w_name='msi', w_val='01', r_name='MSI_MFG_INFO (msi)', r_val='01')
    clei = EEPROM(w_name='clei', w_val='DUMMY_CLEI', r_name='CLEI (clei)', r_val='DUMMY_CLEI')
    mn = EEPROM(w_name='mn', w_val=None, r_name='MODEL_NUM (mn)', r_val=None)
    mrev_maj = EEPROM(w_name='mrev_maj', w_val=None, r_name='MODEL_MAJOR_REVISION (mrev_maj)', r_val=None)
    mrev_min = EEPROM(w_name='mrev_min', w_val='"0000"', r_name='MODEL_MINOR_REVISION (mrev_min)', r_val='')
    # nib_dev = EEPROM(w_name='nib_dev', w_val=None, r_name='NIBBLE_DEVIATION (nib_dev)', r_val=None)
    msi_cksum = EEPROM(w_name='msi_cksum', w_val=None, r_name='MSI_CHECKSUM (msi_cksum)', r_val=None)
    chas_sn = EEPROM(w_name='chas_sn', w_val=None, r_name='CHASSIS_SERIAL_NUM (chas_sn)', r_val=None)

    # 48 Port的需要注意。默认是False。这个决定了检查端口状态和如何做Traffic Test
    internal_link = Item(False)

    #
    low_temp = Item(20)
    high_temp = Item(110)

    # KB
    # mem_size = Item(983000)
    # todo 正式diag发布后更新这个值
    mem_size = Item(3411084)



class EX4K8P(EX4K):

    #P2B
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.7.tgz')
    # junos_version = Item('24.4R1-S2.7')
    # junos_poe_firmware_version = Item('6.0.0.12.0 (type4)')

    # cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
    # cpld_version = Item('1.18.0')
    # cpld = Item('1.24')
    # secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # todo junos
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')

    group = Item(GROUP_3)

    platform = Item(MN_EX4000_8P)
    poe_function = Item(True)
    poe_seq = Item([(0, 3), (4, 7)])
    poe_power_limit = Item((28, 31))  # w
    poe_power = Item(30)
    poe_ports = Item(8)
    poe_current = Item((550, 1))
    poe_class = Item(4)

    poe_traffic_current = Item(270)
    poe_traffic_min_power = Item(14)

    sfp_ports = Item([10, 11])
    traffic_port_num = Item(12)
    led_port_seq = Item(list(range(10)))
    mgmt_port = Item(12)
    eth_amber = Item(False)
    erase_shmoo = Item(False)
    ddr_mode_speed = Item((4, 1))
    rj45_ports = Item(8)

    rst_poe_mcu_jtag = Item(True)
    # rst_mg_phy = Item(False)

    # fan
    fan_count = Item(0)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F0C', r_name='ASSEMBLY_ID (aid)', r_val='0F 0C')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_8P, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_8P)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_8P, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_8P)
    clei = EEPROM(w_name='clei', w_val='INMM610BRA', r_name='CLEI (clei)', r_val='INMM610BRA')

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE Die Sensor',
                           'PoE Controller Sensor 1'])


class EX4K12MP(EX4K):

    # u_boot_file = Item('uboot-2.12-ex4000_builder-2025-01-30-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.12-ex4000_builder-2025-01-30.1-secure-signed (Jan 30 2025 - 03:34:21 -0800)')
    # check_u_boot_version = Item('uboot-2.12-ex4000_builder-2025-01-30.1-secure-signed')
    #
    # jnpr_uboot_version = Item('uboot-2.12-ex4000_builder-2025-01-30.1-secure-signed')
    # jnpr_uboot = Item('uboot-2.12-ex4000_builder-2025-01-30-secure-signed_flash.img')
    # u_boot = Item('2.12')

    # # todo
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')

#     cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
#     cpld_version = Item('1.18.0')
#     cpld = Item('1.24')
#     secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # todo junos
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')

    group = Item(GROUP_1)
    platform = Item(MN_EX4000_12MP)
    # PoE
    poe_function = Item(True)
    poe_seq = Item([(0, 3), (4, 7), (8, 11)])
    poe_power_limit = Item((58, 61))
    poe_power = Item(60)
    poe_ports = Item(12)
    poe_current = Item(1110)
    poe_class = Item(6)

    epdm = Item('B0-v02-03-03')

    sfp_ports = Item([12, 13, 14, 15])
    traffic_port_num = Item(16)
    led_port_seq = Item(list(range(16)))
    mgmt_port = Item(16)
    eth_amber = Item(True)
    erase_shmoo = Item(True)
    # todo 临时把12MP从4,1 改到 4,2
    ddr_mode_speed = Item((4, 2))

    rst_poe_mcu_jtag = Item(True)
    rst_mg_phy = Item(True)
    rj45_ports = Item(12)

    # fan
    fan_count = Item(0)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F0F', r_name='ASSEMBLY_ID (aid)', r_val='0F 0F')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_12MP, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_12MP)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_12MP, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_12MP)
    clei = EEPROM(w_name='clei', w_val='INMNR00BRB', r_name='CLEI (clei)', r_val='INMNR00BRB')

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE Die Sensor',
                           'PoE Controller Sensor 1', 'PoE Controller Sensor 2', 'PoE Controller Sensor 3'])


class EX4K12P(EX4K):

    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4I-20241014.0.0829.tgz')
    # junos_version = Item('24.4I-20241014.0.0829')

    #P2B
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.7.tgz')
    # junos_version = Item('24.4R1-S2.7')
    # junos_poe_firmware_version = Item('6.0.0.12.0 (type4)')

#     cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
#     cpld_version = Item('1.18.0')
#     cpld = Item('1.24')
#     secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')

    group = Item(GROUP_3)

    platform = Item(MN_EX4000_12P)
    # PoE
    poe_function = Item(True)
    # max 12 ports per time
    poe_seq = Item([(0, 7), (8, 11)])
    poe_power_limit = Item((28, 31))
    poe_power = Item(30)
    poe_ports = Item(12)
    poe_current = Item((550, 1))
    poe_class = Item(4)

    sfp_ports = Item([12, 13, 14, 15])
    traffic_port_num = Item(16)
    erase_shmoo = Item(False)
    led_port_seq = Item(list(range(16)))
    mgmt_port = Item(16)
    eth_amber = Item(False)
    ddr_mode_speed = Item((4, 1))
    rj45_ports = Item(12)

    rst_poe_mcu_jtag = Item(True)

    # fan
    fan_count = Item(0)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F0E', r_name='ASSEMBLY_ID (aid)', r_val='0F 0E')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_12P, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_12P)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_12P, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_12P)
    clei = EEPROM(w_name='clei', w_val='INMM810BRA', r_name='CLEI (clei)', r_val='INMM810BRA')

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE Die Sensor',
                           'PoE Controller Sensor 1', 'PoE Controller Sensor 2'])


class EX4K12T(EX4K):

    #P2B
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.7.tgz')
    # junos_version = Item('24.4R1-S2.7')
    # junos_poe_firmware_version = Item('6.0.0.12.0 (type4)')

#     cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
#     cpld_version = Item('1.18.0')
#     cpld = Item('1.24')
#     secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # todo junos
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')

    group = Item(GROUP_3)

    platform = Item(MN_EX4000_12T)
    # PoE
    poe_function = Item(False)

    sfp_ports = Item([12, 13, 14, 15])
    traffic_port_num = Item(16)
    erase_shmoo = Item(False)
    led_port_seq = Item(list(range(16)))
    mgmt_port = Item(16)
    eth_amber = Item(False)
    ddr_mode_speed = Item((4, 1))
    rj45_ports = Item(12)

    # fan
    fan_count = Item(0)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F0D', r_name='ASSEMBLY_ID (aid)', r_val='0F 0D')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_12T, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_12T)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_12T, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_12T)
    clei = EEPROM(w_name='clei', w_val='INMM710BRA', r_name='CLEI (clei)', r_val='INMM710BRA')

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE Die Sensor'])


class EX4K24MP(EX4K):
    group = Item(GROUP_1)
    platform = Item(MN_EX4000_24MP)
    poe_function = Item(True)
    # max 8 ports per time
    poe_seq = Item([(0, 7), (8, 15), (16, 23)])
    poe_power_limit = Item((58, 61))
    poe_power = Item(60)
    poe_ports = Item(24)
    poe_current = Item(1110)
    poe_class = Item(6)

    # u_boot_file = Item('uboot-2.12-ex4000_builder-2025-01-30-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.12-ex4000_builder-2025-01-30.1-secure-signed (Jan 30 2025 - 03:34:21 -0800)')
    # check_u_boot_version = Item('uboot-2.12-ex4000_builder-2025-01-30.1-secure-signed')
    #
    # jnpr_uboot_version = Item('uboot-2.12-ex4000_builder-2025-01-30.1-secure-signed')
    # jnpr_uboot = Item('uboot-2.12-ex4000_builder-2025-01-30-secure-signed_flash.img')
    # u_boot = Item('2.12')

#     cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
#     cpld_version = Item('1.18.0')
#     cpld = Item('1.24')
#     secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # todo junos
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')

    epdm = Item('B0-v02-03-03')

    # # cpld regression
    # cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
    # cpld_version = Item('1.18.0')
    # cpld = Item('1.24')
    # secondary_cpld = Item('1.25')
    # # todo
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')

    sfp_ports = Item([24, 25, 26, 27])
    traffic_port_num = Item(28)
    led_port_seq = Item(list(range(28)))
    mgmt_port = Item(28)
    eth_amber = Item(True)
    erase_shmoo = Item(True)
    ddr_mode_speed = Item((4, 1))
    rj45_ports = Item(24)

    rst_poe_mcu_jtag = Item(True)
    rst_mg_phy = Item(True)

    # fan
    fan_count = Item(2)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F12', r_name='ASSEMBLY_ID (aid)', r_val='0F 12')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_24MP, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_24MP)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_24MP, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_24MP)
    clei = EEPROM(w_name='clei', w_val='INMNW00BRB', r_name='CLEI (clei)', r_val='INMNW00BRB')

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE Die Sensor',
                           'PoE Controller Sensor 1', 'PoE Controller Sensor 2', 'PoE Controller Sensor 3',
                           'PoE Controller Sensor 4', 'PoE Controller Sensor 5', 'PoE Controller Sensor 6',
                           'Fan Tray 0 Fan 0', 'Fan Tray 1 Fan 0'])


class EX4K24P(EX4K):

    # P2A
    #bft_poe = Item('6.0.0.B3')
    # u_boot_file = Item('uboot_diag_cap.img')
    # u_boot_version = Item('uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed (Oct 21 2024 - 12:46:37 -0700)')
    # check_u_boot_version = Item('uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed')
    # cpld_filename = Item('edradour_sys_cpld_v_01_1A_092724_p.vme')
    # cpld_version = Item('1.13.0')
    # jnpr_uboot_version = Item('uboot-2.8-ex4000_builder-2024-10-21-secure-signed (Oct 21 2024 - 12:51:26 -0700)')
    # jnpr_uboot = Item('uboot-2.8-upgrade-MFG-PRD-jHRoT.img')
    # u_boot = Item('2.8')

    #P2B
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.7.tgz')
    # junos_version = Item('24.4R1-S2.7')
    # junos_poe_firmware_version = Item('6.0.0.12.0 (type4)')

    # Pilot
    # cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
    # cpld_version = Item('1.18.0')
    # cpld = Item('1.24')

#     cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
#     cpld_version = Item('1.18.0')
#     cpld = Item('1.24')
#     secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # todo junos
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')

    group = Item(GROUP_2)

    platform = Item(MN_EX4000_24P)
    poe_function = Item(True)
    # max 8 ports per time
    poe_seq = Item([(0, 11), (12, 23)])
    poe_power_limit = Item((28, 31))
    poe_power = Item(30)
    poe_ports = Item(24)
    poe_current = Item((550, 1))
    poe_class = Item(6)

    poe_traffic_current = Item(280)
    poe_traffic_min_power = Item(13)

    sfp_ports = Item([24, 25, 26, 27])
    traffic_port_num = Item(28)
    led_port_seq = Item(list(range(28)))
    mgmt_port = Item(28)
    eth_amber = Item(False)
    erase_shmoo = Item(False)
    ddr_mode_speed = Item((4, 1))
    rj45_ports = Item(24)

    rst_poe_mcu_jtag = Item(True)

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE Die Sensor',
                           'PoE Controller Sensor 1', 'PoE Controller Sensor 2', 'PoE Controller Sensor 3',
                           'Fan Tray 0 Fan 0', 'Fan Tray 1 Fan 0'])

    # fan
    fan_count = Item(2)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F11', r_name='ASSEMBLY_ID (aid)', r_val='0F 11')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_24P, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_24P)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_24P, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_24P)
    clei = EEPROM(w_name='clei', w_val='INMNT00BRA', r_name='CLEI (clei)', r_val='INMNT00BRA')


class EX4K24T(EX4K):

    # P2A
    #bft_poe = Item('6.0.0.B3')
    # u_boot_file = Item('uboot_diag_cap.img')
    # u_boot_version = Item('uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed (Oct 21 2024 - 12:46:37 -0700)')
    # check_u_boot_version = Item('uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed')
    # cpld_filename = Item('edradour_sys_cpld_v_01_1A_092724_p.vme')
    # cpld_version = Item('1.13.0')
    # jnpr_uboot_version = Item('uboot-2.8-ex4000_builder-2024-10-21-secure-signed (Oct 21 2024 - 12:51:26 -0700)')
    # jnpr_uboot = Item('uboot-2.8-upgrade-MFG-PRD-jHRoT.img')
    # u_boot = Item('2.8')

    #P2B
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.7.tgz')
    # junos_version = Item('24.4R1-S2.7')
    # junos_poe_firmware_version = Item('6.0.0.12.0 (type4)')

    # Pilot
    # cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
    # cpld_version = Item('1.18.0')
    # cpld = Item('1.24')

#     cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
#     cpld_version = Item('1.18.0')
#     cpld = Item('1.24')
#     secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # todo junos
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')

    group = Item(GROUP_2)

    platform = Item(MN_EX4000_24T)
    poe_function = Item(False)

    sfp_ports = Item([24, 25, 26, 27])
    traffic_port_num = Item(28)
    led_port_seq = Item(list(range(28)))
    mgmt_port = Item(28)
    eth_amber = Item(False)
    erase_shmoo = Item(False)
    ddr_mode_speed = Item((4, 1))
    rj45_ports = Item(24)

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE Die Sensor',
                           'Fan Tray 0 Fan 0'])

    # fan
    fan_count = Item(1)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F10', r_name='ASSEMBLY_ID (aid)', r_val='0F 10')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_24T, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_24T)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_24T, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_24T)
    clei = EEPROM(w_name='clei', w_val='INMNS00BRA', r_name='CLEI (clei)', r_val='INMNS00BRA')


class EX4K48MP(EX4K):

    # u_boot_file = Item('uboot-2.12-ex4000_builder-2025-01-30-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.12-ex4000_builder-2025-01-30.1-secure-signed (Jan 30 2025 - 03:34:21 -0800)')
    # check_u_boot_version = Item('uboot-2.12-ex4000_builder-2025-01-30.1-secure-signed')
    #
    # jnpr_uboot_version = Item('uboot-2.12-ex4000_builder-2025-01-30.1-secure-signed')
    # jnpr_uboot = Item('uboot-2.12-ex4000_builder-2025-01-30-secure-signed_flash.img')
    # u_boot = Item('2.12')

#     cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
#     cpld_version = Item('1.18.0')
#     cpld = Item('1.24')
#     secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')
    junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R2.25.tgz')
    junos_version = Item('24.4R2.25')
    # # todo
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')

    group = Item(GROUP_1)
    platform = Item(MN_EX4000_48MP)
    check_pfe_fw = Item(True)

    # PoE
    poe_function = Item(True)
    # max 12 ports mer time
    poe_seq = Item([(0, 15), (16, 31), (32, 47)])
    poe_power_limit = Item((58, 61))
    poe_power = Item(60)
    poe_ports = Item(48)
    poe_current = Item(1110)
    poe_class = Item(6)

    epdm = Item('B0-v02-03-05')

    sfp_ports = Item([48, 49, 50, 51])
    # 48个 RJ45 1G + 4个SFP10G
    traffic_port_num = Item(54)
    # 48MP = 3, another = 4
    traffic_cycle = Item(4)
    led_port_seq = Item(list(range(52)))
    mgmt_port = Item(54)
    eth_amber = Item(True)
    erase_shmoo = Item(True)
    ddr_mode_speed = Item((3, 1))
    rj45_ports = Item(48)

    rst_poe_mcu_jtag = Item(True)
    rst_mg_phy = Item(True)

    # fan
    fan_count = Item(3)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F15', r_name='ASSEMBLY_ID (aid)', r_val='0F 15')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_48MP, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_48MP)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_48MP, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_48MP)
    clei = EEPROM(w_name='clei', w_val='INMNX00BRB', r_name='CLEI (clei)', r_val='INMNX00BRB')

    internal_link = Item(True)

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE 0 Die Sensor', 'PFE 1 Die Sensor',
                           'PoE Controller Sensor 1', 'PoE Controller Sensor 2', 'PoE Controller Sensor 3',
                           'PoE Controller Sensor 4', 'PoE Controller Sensor 5', 'PoE Controller Sensor 6',
                           'PoE Controller Sensor 7', 'PoE Controller Sensor 8', 'PoE Controller Sensor 9',
                           'PoE Controller Sensor 10', 'PoE Controller Sensor 11', 'PoE Controller Sensor 12',
                           'Fan Tray 0 Fan 0', 'Fan Tray 1 Fan 0', 'FPC 0 Fan Tray 2 Fan 0'])


class EX4K48P(EX4K):

    # P2A
    #bft_poe = Item('6.0.0.B3')
    # u_boot_file = Item('uboot_diag_cap.img')
    # u_boot_version = Item('uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed (Oct 21 2024 - 12:46:37 -0700)')
    # check_u_boot_version = Item('uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed')
    # cpld_filename = Item('edradour_sys_cpld_v_01_1A_092724_p.vme')
    # cpld_version = Item('1.13.0')
    # jnpr_uboot_version = Item('uboot-2.8-ex4000_builder-2024-10-21-secure-signed (Oct 21 2024 - 12:51:26 -0700)')
    # jnpr_uboot = Item('uboot-2.8-upgrade-MFG-PRD-jHRoT.img')
    # u_boot = Item('2.8')

    #P2B
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.7.tgz')
    # junos_version = Item('24.4R1-S2.7')
    # junos_poe_firmware_version = Item('6.0.0.12.0 (type4)')

    # Pilot
    # cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
    # cpld_version = Item('1.18.0')
    # cpld = Item('1.24')

#     cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
#     cpld_version = Item('1.18.0')
#     cpld = Item('1.24')
#     secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # todo junos
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')

    group = Item(GROUP_2)

    platform = Item(MN_EX4000_48P)
    check_pfe_fw = Item(True)
    # PoE
    poe_function = Item(True)
    # max 12 ports mer time
    poe_seq = Item([(0, 23), (24, 47)])
    poe_power_limit = Item((28, 31))
    poe_power = Item(30)
    poe_ports = Item(48)
    poe_current = Item((550, 1))
    poe_class = Item(4)

    poe_traffic_current = Item(260)
    poe_traffic_min_power = Item(13)
    traffic_cycle = Item(4)

    sfp_ports = Item([48, 49, 50, 51])
    # 48个 RJ45, 4个SFP10G, 4个HG port
    traffic_port_num = Item(56)
    led_port_seq = Item(list(range(52)))
    mgmt_port = Item(56)
    eth_amber = Item(False)
    erase_shmoo = Item(False)
    ddr_mode_speed = Item((3, 1))
    rj45_ports = Item(48)

    rst_poe_mcu_jtag = Item(True)

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE 0 Die Sensor', 'PFE 1 Die Sensor',
                           'PoE Controller Sensor 1', 'PoE Controller Sensor 2', 'PoE Controller Sensor 3',
                           'PoE Controller Sensor 4', 'PoE Controller Sensor 5', 'PoE Controller Sensor 6',
                           'Fan Tray 0 Fan 0', 'Fan Tray 1 Fan 0', 'Fan Tray 2 Fan 0'])

    # fan
    fan_count = Item(3)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F14', r_name='ASSEMBLY_ID (aid)', r_val='0F 14')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_48P, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_48P)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_48P, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_48P)
    clei = EEPROM(w_name='clei', w_val='INMNV00BRA', r_name='CLEI (clei)', r_val='INMNV00BRA')

    internal_link = Item(True)


class EX4K48T(EX4K):

    # P2A
    #bft_poe = Item('6.0.0.B3')
    # u_boot_file = Item('uboot_diag_cap.img')
    # u_boot_version = Item('uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed (Oct 21 2024 - 12:46:37 -0700)')
    # check_u_boot_version = Item('uboot-2.8-ex4000_builder-2024-10-21.1-secure-signed')
    # cpld_filename = Item('edradour_sys_cpld_v_01_1A_092724_p.vme')
    # cpld_version = Item('1.13.0')
    # jnpr_uboot_version = Item('uboot-2.8-ex4000_builder-2024-10-21-secure-signed (Oct 21 2024 - 12:51:26 -0700)')
    # jnpr_uboot = Item('uboot-2.8-upgrade-MFG-PRD-jHRoT.img')
    # u_boot = Item('2.8')

    #P2B
    # u_boot_file = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_diag_flash.img')
    # u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed (Feb 13 2025 - 09:48:57 -0800)')
    # check_u_boot_version = Item('uboot-2.13-ex4000_builder-2025-02-13.1-secure-signed')
    # jnpr_uboot_version = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed (Feb 13 2025 - 09:50:57 -0800)')
    # jnpr_uboot = Item('uboot-2.13-ex4000_builder-2025-02-13-secure-signed_flash.img')
    # u_boot = Item('2.13')
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.7.tgz')
    # junos_version = Item('24.4R1-S2.7')
    # junos_poe_firmware_version = Item('6.0.0.12.0 (type4)')

    # Pilot
    # cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
    # cpld_version = Item('1.18.0')
    # cpld = Item('1.24')

#     cpld_filename = Item('edradour_sys_cpld_v_01_24_032625_p.vme')
#     cpld_version = Item('1.18.0')
#     cpld = Item('1.24')
#     secondary_cpld = Item('1.25')
    u_boot_file = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_diag_flash.img')
    u_boot_version = Item('uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed (Apr 11 2025 - 10:02:58 -0700)')
    check_u_boot_version = Item('2022.10-uboot-2.14-ex4000_builder-2025-04-11.1-secure-signed')
    jnpr_uboot_version = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed (Apr 11 2025 - 10:04:59 -0700)')
    jnpr_uboot = Item('uboot-2.14-ex4000_builder-2025-04-11-secure-signed_flash.img')
    u_boot = Item('2.14')

    # todo junos
    # junos_file = Item('junos-install-media-net-ex40xx-arm-64-24.4R1-S2.15.tgz')
    # junos_version = Item('24.4R1-S2.15')

    group = Item(GROUP_2)

    platform = Item(MN_EX4000_48T)
    check_pfe_fw = Item(True)
    # PoE
    poe_function = Item(False)

    traffic_cycle = Item(4)
    sfp_ports = Item([48, 49, 50, 51])
    # 48个 RJ45, 4个SFP10G
    traffic_port_num = Item(56)
    led_port_seq = Item(list(range(52)))
    mgmt_port = Item(56)
    eth_amber = Item(False)
    erase_shmoo = Item(False)
    ddr_mode_speed = Item((3, 1))
    rj45_ports = Item(48)

    # show chassis environment |no-more check list
    check_list_env = Item(['Power Supply 0',
                           'Thermal board Sensor 1', 'Thermal board Sensor 2', 'Thermal board Sensor 3',
                           'PFE 0 Die Sensor', 'PFE 1 Die Sensor',
                           'Fan Tray 0 Fan 0'])

    # fan
    fan_count = Item(1)

    # EEPROM
    aid = EEPROM(w_name='aid', w_val='0F13', r_name='ASSEMBLY_ID (aid)', r_val='0F 13')
    apn = EEPROM(w_name='apn', w_val=PN_EX4000_48T, r_name='ASSEMBLY_PART_NUM (apn)', r_val=PN_EX4000_48T)
    mn = EEPROM(w_name='mn', w_val=MN_EX4000_48T, r_name='MODEL_NUM (mn)', r_val=MN_EX4000_48T)
    clei = EEPROM(w_name='clei', w_val='INMNU00BRA', r_name='CLEI (clei)', r_val='INMNU00BRA')

    internal_link = Item(True)


# 定义了所有料号对应使用的预定义值，未经过验证的料号不可直接写在这里！！！
cookie_mapping = {
    # G1
    # FOX_PN_48MP: EX4K48MP(),
    PN_EX4000_48MP: EX4K48MP(),
    PN_EX4000_48MP_TAA: EX4K48MP(),
    PN_EX4000_48MP_FJZ: EX4K48MP(),

    # FOX_PN_24MP: EX4K24MP(),
    PN_EX4000_24MP: EX4K24MP(),
    PN_EX4000_24MP_TAA: EX4K24MP(),
    PN_EX4000_24MP_FJZ: EX4K24MP(),

    # FOX_PN_12MP: EX4K12MP(),
    PN_EX4000_12MP: EX4K12MP(),
    PN_EX4000_12MP_TAA: EX4K12MP(),
    PN_EX4000_12MP_FJZ: EX4K12MP(),

    # G2
    # FOX_PN_24T: EX4K24T(),
    PN_EX4000_24T: EX4K24T(),
    PN_EX4000_24T_TAA: EX4K24T(),
    PN_EX4000_24T_FJZ: EX4K24T(),

    # FOX_PN_24P: EX4K24P(),
    PN_EX4000_24P: EX4K24P(),
    PN_EX4000_24P_TAA: EX4K24P(),
    PN_EX4000_24P_FJZ: EX4K24P(),

    # FOX_PN_48T: EX4K48T(),
    PN_EX4000_48T: EX4K48T(),
    PN_EX4000_48T_TAA: EX4K48T(),
    PN_EX4000_48T_FJZ: EX4K48T(),

    # FOX_PN_48P: EX4K48P(),
    PN_EX4000_48P: EX4K48P(),
    PN_EX4000_48P_TAA: EX4K48P(),
    PN_EX4000_48P_FJZ: EX4K48P(),

    # G3
    # FOX_PN_8P: EX4K8P(),
    PN_EX4000_8P: EX4K8P(),
    PN_EX4000_8P_TAA: EX4K8P(),
    PN_EX4000_8P_FJZ: EX4K8P(),

    # FOX_PN_12T: EX4K12T(),
    PN_EX4000_12T: EX4K12T(),
    PN_EX4000_12T_TAA: EX4K12T(),
    PN_EX4000_12T_FJZ: EX4K12T(),

    # FOX_PN_12P: EX4K12P(),
    PN_EX4000_12P: EX4K12P(),
    PN_EX4000_12P_TAA: EX4K12P(),
    PN_EX4000_12P_FJZ: EX4K12P(),
}

