from .scanner import yes_or_enter_to_continue
from .utils import extract_conn_string
from .const import TELNET_BREAK, CR
from .terminal import Terminal
import random
import time


class Telnet(Terminal):
    """
    telnet function. conn_string following: telnet 10.1.1.5 2002, 10.1.1.5 2002 or 10.1.1.5, all of them are acceptable.
    """

    acs_username = 'root'
    acs_password = 'admin123'

    def __init__(self, name, *, suffix, conn_str=None, pop=True):
        """
        pop is True, if ip address is wrong, will pop up a window
        """
        self.pop = pop
        self.conn_str = conn_str
        self.ip, self.port = None, None
        self.set_conn_config(self.conn_str)

        super(Telnet, self).__init__(name=name, suffix=suffix)

    def set_conn_config(self, conn_str):
        """
        重新设置连接字符串
        :param conn_str:
        :return:
        """
        self.conn_str = conn_str
        if self.conn_str:
            protocol, ip, port = extract_conn_string(conn_string=self.conn_str)
            if not protocol or protocol.upper() != 'TELNET':
                raise Exception(f'found a bad protocol: {protocol} from {self.conn_str}')
            self.ip, self.port = ip, port

    def telnet_ip(self, ip=None):
        ip = ip or self.ip
        if ip is None:
            raise Exception(f'please provided a correct ip, instead of [{ip}]')

        for i in range(5):
            self.send_wise(f'telnet {ip}', expectphrase=['$', "'^]'"])
            time.sleep(0.5)
            # TELNET OK
            if '$' not in self.buffer:
                break

            if 'refused' in self.buffer:
                self.error(f'connection refused, sleep some time, retry {i + 1} time(s)')
                time.sleep(random.randint(3, 8))
                continue
            elif 'No route to host' in self.buffer:
                if self.pop is not True:
                    raise Exception(f'can not telnet {ip}, No route to host, please check IP again!')

                if yes_or_enter_to_continue(f'<{self.name}> can not telnet {ip}, please check IP again!') is False:
                    raise Exception(f'can not telnet: {ip}, No route to host')

                # retry
                continue
            else:
                raise Exception('telnet failed, unhandled case!')

        # exceed max retry!
        else:
            raise Exception(f'telnet {ip} error, exceed max retry')

    def ssh_ip(self, ip=None, user_name=None, password=None):
        ip = ip or self.ip
        if ip is None:
            raise Exception(f'please provided a correct ip, instead of [{ip}]')

        for i in range(5):
            self.send_wise(f'ssh {user_name}@{ip}', expectphrase="password:")
            time.sleep(0.5)
            if "password:" in self.buffer:
                self.send_wise(f'{password}', expectphrase="apc>")
                if "Permission denied" in self.buffer:
                    raise Exception('APC password is wrong')
                else:
                    break

            if 'No route to host' in self.buffer:
                if self.pop is not True:
                    raise Exception(f'can not ssh {ip}, No route to host, please check IP again!')

                if yes_or_enter_to_continue(f'<{self.name}> can not ssh {ip}, please check IP again!') is False:
                    raise Exception(f'can not ssh: {ip}, No route to host')
                # retry
                continue
            else:
                raise Exception('ssh failed, unhandled case!')
        # exceed max retry!
        else:
            raise Exception(f'ssh {ip} error, exceed max retry')

    def clear_ts_console_line(self, ip=None, port=None, line=None):
        """
        only useful for Cisco Terminal Server, maybe not good for other brand
        """
        ip = ip or self.ip
        port = port or self.port

        if ip is None or port is None:
            raise Exception(f'ip is {ip}, port is {port}, bad..')

        self.telnet_ip(ip)
        line = port - 2000 if line is None else line
        self.send_many([
            ('c', '>'),
            ('en', 'Password:'),
            ('c', '#'),
            (f'clear line {line}', '[confirm]'),
            ('', '#'),
            ('exit', '$'),
            ('', '$'),
        ], suffix='\r')

    def clear_console_acs(self, ip=None, port=None):
        """
        For ACS
        """
        port = self.port - 7000 if port is None else port
        self.telnet_ip(ip)
        if 'login:' not in self.buffer:
            raise Exception('not found ts login prompt!')
        self.send_wise(self.acs_username, 'Password:')
        self.send_wise(self.acs_password, ['>', 'login:'])
        # Login incorrect
        if 'login:' in self.buffer:
            raise Exception('ts username or password incorrect!')

        self.send_wise(f'disable_ports ports/serial_ports/ {port}', '>')
        self.send_wise(f'commit', '> ')

        self.debug('sleep 3s')
        time.sleep(3)

        self.send_wise(f'enable_ports ports/serial_ports/ {port}', '>')
        self.send_wise(f'commit', '> ')
        self.send_wise(f'exit', '$')

    def telnet_ip_and_port(self, ip=None, port=None):
        """
        这个可能要根据实际情况改造，具体和 Terminal Server 品牌型号有关
        """
        ip = ip or self.ip
        port = port or self.port

        if ip is None or port is None:
            raise Exception(f'both ip and port should not be None! ip = {ip}, port = {port}, failed!')

        for i in range(5):
            self.send_wise(f'telnet {ip} {port}', expectphrase=['$', "'^]'"])
            time.sleep(0.5)

            # Old ACS TS
            if 'is being used by' in self.buffer and 'Enter your option :' in self.buffer:
                if yes_or_enter_to_continue(
                        question=f'this console({self.port}) is being used by another people, continue?') is False:
                    raise Exception('console is being used by another people')
                self.send_wise('1', '', suffix='')
                # 按完 1 后，就进去了。不需要再重新telnet
                break

            # OK
            if '$' not in self.buffer:
                break

            # Cisco TS
            if 'refused' in self.buffer:
                self.error(f'console is busy, sleep some time, retry {i + 1} time(s)')
                time.sleep(random.randint(3, 10))
                self.clear_ts_console_line(ip, port)
                continue
            elif 'No route to host' in self.buffer:
                if self.pop is not True:
                    raise Exception(f'can not telnet {ip}, please check IP again!')

                if yes_or_enter_to_continue(f'<{self.name}> can not telnet {ip}, please check IP again!') is False:
                    raise Exception(f'can not telnet ip: {ip}, No route to host')

                continue
            # New ACS TS
            elif 'This connection is in use.' in self.buffer:
                if yes_or_enter_to_continue(question=f'this connection({self.port}) is in use, continue?') is False:
                    raise Exception('console is is use!')
                self.clear_console_acs()
                continue
            else:
                raise Exception('telnet failed, unhandled case!')

        # exceed max retry!
        else:
            raise Exception(f'telnet {ip} {port} failed, exceed max retry!')

    def do_connect(self, conn_str=None, close_before_open=False):
        self.set_conn_config(conn_str=conn_str)
        self.info(f'{self.readable_name} do connect -> {self.conn_str}')
        if close_before_open is True:
            self.close()
        self.open()

    def do_disconnect(self):
        self.info(f'{self.readable_name} do disconnect.')
        self.emit(TELNET_BREAK, expectphrase='>', suffix='')
        self.emit('q', expectphrase='$')
        self.info('telnet exit ok')

    def ssh_do_disconnect(self):
        self.info(f'{self.readable_name} do disconnect.')
        self.emit("bye", expectphrase='$')
        self.info('telnet exit ok')
