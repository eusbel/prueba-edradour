import re


def mac(mac_address, delimiter):
    """render_mac"""

    ma = MacAddressHelper()
    if not ma.is_valid(mac_address):
        raise Exception(f'mac address: {mac_address} is invalid!')
    return ma.convert(mac_address, delimiter=delimiter)


class MacAddressHelper:
    """
    可以匹配以下类型的 MAC 格式
    E4-54-E8-DA-5A-92
    E4:54:E8:DA:5A:92
    E454E8DA5A92
    e454e8da5a92
    E454-E8DA-5A92
    E454:E8DA:5A92
    E454E8-DA5A92
    E454E8:DA5A92
    """

    def __init__(self):
        """
        用户可以自定义 MAC 的匹配规则

        """
        self.ptn = re.compile(
            r'(?:[a-fA-F0-9]{2}-){5}[a-fA-F0-9]{2}|(?:[a-fA-F0-9]{2}:){5}[a-fA-F0-9]{2}|[a-fA-F0-9]{12}|'
            r'(?:[a-fA-F0-9]{4}[-:]){2}?[a-fA-F0-9]{4}|[a-fA-F0-9]{6}[-:][a-fA-F0-9]{6}'
        )

    def is_valid(self, mac_address):
        return self.ptn.fullmatch(mac_address) is not None

    def get_all_mac_addresses(self, text):
        return self.ptn.findall(text)

    def get_first_mac_address(self, text):
        """
        获取第一个 MAC Address，若有返回 MAC Address， 否则返回 None。请注意：符合匹配模式的字符串并不一定就是 MAC address
        :param text:
        :return:
        """
        mac_address = self.ptn.search(text)
        if mac_address is not None:
            return mac_address.group()

    def convert(self, mac_address: str, lower=None, upper=None, delimiter=None):
        """
        校验并输出指定格式的 MAC Address
        :param mac_address:
        :param lower: 转换为小写
        :param upper: 转转为大写。同时制定 lower upper，仅 upper 生效
        :param delimiter: None 标识保持原样，空字符串标识没有分隔符
        :return: 输出格式：00-11-22-33-44-55 or 00:11:22:33:44:55 or 001122334455, 具体取决于 delimiter 的值
        """
        if not self.is_valid(mac_address):
            raise ValueError(f'mac address: {mac_address} is invalid!')
        mac_address = self.get_first_mac_address(mac_address)
        if lower is True:
            mac_address = mac_address.lower()
        if upper is True:
            mac_address = mac_address.upper()
        if delimiter is not None:
            mac_address = re.sub(r'[^A-Fa-f0-9]', '', mac_address)
            mac_address = delimiter.join([mac_address[i: i + 2] for i in range(0, len(mac_address), 2)])
        # double check
        if not self.is_valid(mac_address):
            raise Exception(f'convert mac failed! -> {mac_address}')

        return mac_address

    def compare(self, mac_address_x: str, mac_address_y: str, ignore_delimiter=True, ignore_case=True):
        """
        用于比较常见的 MAC 格式的值是否相同，默认会忽略MAC的格式，字母大小写
        E4-54-E8-DA-5A-92 = E4:54:E8:DA:5A:92，因为只是分隔符不同！
        :param mac_address_x:
        :param mac_address_y:
        :param ignore_delimiter: 忽略分隔符
        :param ignore_case: 忽略大小写
        :return: 验证 MAC address 失败会报错，否则返回比较的结果。相同返回 True，不同则返回 False
        """
        if not self.is_valid(mac_address_x):
            raise ValueError(f'mac address: {mac_address_x} is invalid!')
        if not self.is_valid(mac_address_y):
            raise ValueError(f'mac address: {mac_address_y} is invalid!')
        if ignore_delimiter is True:
            mac_address_x = self.convert(mac_address_x, delimiter='')
            mac_address_y = self.convert(mac_address_y, delimiter='')
        if ignore_case is True:
            mac_address_x = mac_address_x.lower()
            mac_address_y = mac_address_y.lower()
        return mac_address_x == mac_address_y
