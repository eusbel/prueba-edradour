import redis

db = redis.Redis(db=15)
