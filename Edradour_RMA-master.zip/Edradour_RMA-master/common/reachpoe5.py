import time
from .telnet import Telnet
from .scanner import yes_or_enter_to_continue
from .logger import log


class ReachPoE5(Telnet):
    model_name = 'ReachPoE5'
    prompt = '>'

    def __init__(self, name='POE', suffix='\r', conn_str=None, pop=True):
        super(ReachPoE5, self).__init__(name, suffix=suffix, conn_str=conn_str, pop=pop)

    def do_connect(self, conn_str=None, close_before_open=False):
        """
        special
        """
        if (conn_str or self.conn_str) is None:
            raise Exception('please ensure you have provided conn str!!!')

        super().do_connect(conn_str=conn_str, close_before_open=close_before_open)
        self.telnet_ip_and_port()
        time.sleep(0.5)
        if 'is being used by' in self.buffer and 'Enter your option :' in self.buffer:
            msg = f'[{self.readable_name} {self.ip} {self.port}] this console is being used by another people, continue?'
            if yes_or_enter_to_continue(question=msg):
                self.send_wise('1', '')
            else:
                raise Exception('console is being used by another people')

    def do_disconnect(self):
        try:
            super().do_disconnect()
        except Exception as e:
            log.warning(f'close telnet connection: {self.readable_name}, failed! -> {e}')
        finally:
            self.close()

    def reset(self, ports='all', retry=5):
        self.run_command(command=f'reset', retry=retry)

    def conn_off(self, ports='all', retry=5):
        self.run_command(command=f'conn off', retry=retry)

    def conn_on(self, ports='all', retry=5):
        self.run_command(command=f'conn on', retry=retry)

    def set_current(self, current: (list, tuple, int, str), ports='all', retry=5):
        """
        current -> 550  or (550, 550)
        """
        if isinstance(current, (int, float)):
            current = str(current),
        elif isinstance(current, (list, tuple)):
            current = [str(_) for _ in current]
        else:
            raise Exception(f'current should be int or str! got: {type(current)}')

        i = ','.join(current)
        self.run_command(command=f'set {i}', retry=retry)

    def set_port_current(self, start, end, current, retry=5):
        if isinstance(current, (list, tuple)):
            current = [str(_) for _ in current]
            current = ','.join(current)
        for i in range(start, end+1):
            self.run_command(command=f'p{i} set {current}', retry=retry)

    def single_on(self, ports='all', retry=5):
        self.run_command(command=f'single on', retry=retry)

    def single_off(self, ports='all', retry=5):
        self.run_command(command=f'single off', retry=retry)

    def klass(self, klass, ports='all', retry=5):
        self.run_command(command=f'class {klass}', retry=retry)

    def det_ok(self, ports='all', retry=5):
        self.run_command(command=f'det ok', retry=retry)

    def show(self, ports='all', retry=5):
        self.run_command(command=f'show {ports}', retry=retry)

    def run_command(self, command, retry=5):
        for i in range(retry):
            try:
                self.send_wise(f'{command}', self.prompt, timeout=10)
            except Exception as e:
                log.warning(f'[{i + 1}] send [{command}] error!! -> {e}')
                time.sleep(3)
                continue
            # OK
            break
        else:
            raise Exception(f'send [{command}] error, exceed nax retry!!')


"""
all reset
all conn off
all setc 550  # 30W
all setc 1110  # 60W
all single on
all class 8
all det ok
all conn on
show all
"""
