# Define key combination, they are ASCII(OCT)
# http://www.physics.udel.edu/~watson/scen103/ascii.html

from django.conf import settings
import pytz


CTRL_C = "\003"
CTRL_D = "\004"
CTRL_W = "\027"
CTRL_X = "\030"
ESC = "\033"
TELNET_BREAK = "\035"  # ctrl + ]
CTRL_CARET = "\036"  # ctrl + ^
SSH_BREAK = r"~."
# SAME AS CTRL-C, CTRL_C == END_OF_TEST # True
END_OF_TEXT = '\x03'
# SPECIAL CASES
# https://blog.csdn.net/liewen_/article/details/89673402
# ^M, Enter
# Carriage Return
CR = '\r'
# Line Feed
LF = '\n'
# win new line
CRLF = '\r\n'


# if more combine key, just add here
CONTROL_KEY_NAME = {
    CTRL_C: "CTRL C",
    CTRL_D: "CTRL D",
    CTRL_W: "CTRL W",
    CTRL_X: "CTRL X",
    ESC: "ESC",
    TELNET_BREAK: "TELNET BREAK",  # ctrl + ]
    CTRL_CARET: "CTRL CARET",  # ctrl + ^
    SSH_BREAK: r"~.",
    # END_OF_TEXT: 'END_OF_TEXT',
    # OVERWRITE CTRL_C
    END_OF_TEXT: 'CTRL C',
    # SPECIAL CASES
    CR: r'CR(\r)',
    LF: r'LF(\n)',
    CRLF: r'CRLF(\r\n)',
}


# from top.py
# for re
RE_MAC_FORMAT = "[0-9a-fA-F]{4}.{0,1}[0-9a-fA-F]{4}.{0,1}[0-9a-fA-F]{4}"
RE_64MAC_FORMAT = "[0-9a-fA-F]{4}.{0,1}[0-9a-fA-F]{2}[fF]{2}.{0,1}[fF][eE][0-9a-fA-F]{2}.{0,1}[0-9a-fA-F]{4}"
RE_SN_FORMAT = "[FJ][CDGHJMOTX][CHLOWXZ][0-9]{4}[0-9A-Z]{4}"
RE_MODEM_SN_FORMAT = "[0-9]{15}"
RE_PN_FORMAT = "[0-9]{2}-[0-9]{6}-[0-9]{2}"
RE_73_PN_FORMAT = "73-[0-9]{4,6}-[0-9]{2}"
RE_74_PN_FORMAT = "74-[0-9]{6}-[0-9]{2}"
RE_68_PN_FORMAT = "68-[0-9]{4,6}-[0-9]{2}"
RE_800_PN_FORMAT = "800-[0-9]{4,8}-[0-9]{2,4}"
RE_PID_FORMAT = "^[a-zA-Z0-9-=_/|+]{1,50}$"
RE_DEVIATION_FORMAT = "D[P]{0,1}[0-9]{6}"
RE_QUACK_FORMAT = "[MDN][0-9]{8}"


# 越南 FVN
LOCAL_TIMEZONE = 'Asia/Ho_Chi_Minh'
DEFAULT_TIME_FMT = '%Y-%m-%d %H:%M:%S'
DJ_TIMEZONE = settings.TIME_ZONE
