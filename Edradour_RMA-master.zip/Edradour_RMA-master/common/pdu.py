import time
from .telnet import Telnet
from .scanner import yes_or_enter_to_continue
import re


class PDU(Telnet):
    username = 'genius'
    password = 'Foxconn168!!'
    # prompt = '] #'
    prompt = '# '

    def __init__(self, name='PDU', suffix='\r', conn_str=None, pop=True):
        super(PDU, self).__init__(name, suffix=suffix, conn_str=conn_str, pop=pop)

    def do_connect(self, conn_str=None, close_before_open=False):
        """
        special
        """
        if (conn_str or self.conn_str) is None:
            raise Exception('please ensure you have provided conn str!!!')

        super().do_connect(conn_str=conn_str, close_before_open=close_before_open)
        self.telnet_ip()
        time.sleep(0.5)

    def login(self):
        self.close()
        self.open()
        self.telnet_ip()
        self.waitfor('Username:')
        self.send_wise(self.username, 'Password:')
        self.send_wise(self.password, [self.prompt, ']$'], visible=False)
        if 'Authentication failed!' in self.buffer:
            raise Exception('PDU username or password incorrect!')

    def do_disconnect(self):
        super().do_disconnect()
        self.close()

    def power_on(self, ports):
        self.login()
        if isinstance(ports, (str, int)):
            ports = (ports,)
        ports = ','.join(ports)
        self.login()
        self.send_wise(f'power outlets {ports} on /y', self.prompt)
        self.do_disconnect()

    def power_off(self, ports):
        if isinstance(ports, (str, int)):
            ports = (ports,)
        ports = ','.join(ports)
        self.login()
        self.send_wise(f'power outlets {ports} off /y', self.prompt)
        self.do_disconnect()

    def power_cycle(self, ports):
        if isinstance(ports, (str, int)):
            ports = (ports,)
        ports = ','.join(ports)
        self.login()
        # self.send_wise(f'power outlets {ports} off /y', self.prompt)
        # time.sleep(interval)
        # self.send_wise(f'power outlets {ports} on /y', self.prompt)
        self.send_wise(f'power outlets {ports} cycle /y', self.prompt)
        self.do_disconnect()
