from .terminal import Terminal


class Local(Terminal):

    def __init__(self, name='LOCAL'):
        super(Local, self).__init__(name=name)

    def do_connect(self):
        self.open()

    def do_disconnect(self):
        self.close()
