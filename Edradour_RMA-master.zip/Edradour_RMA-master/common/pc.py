import re
import time
from . import scanner
from .terminal import Terminal


class PC(Terminal):

    def __init__(self, ip, program_dir=None, com_id=None, name='PC', password=None):
        super().__init__(name)
        self.ip = ip
        self.username = 'odmtest'
        self.password = password
        self.prompt = '>'
        self.hmac = '-m hmac-sha2-256'
        # self.hmac = ''

        self.program_dir = program_dir
        self.com_id = com_id

    def do_connect(self):
        self.close()
        self.open()
        self.send_wise(f'ssh {self.hmac} {self.username}@{self.ip}', expectphrase=['yes/no', '(y/n)', 'password:'])
        if 'yes/no' in self.buffer:
            self.send_wise('yes', 'password:')
        elif '(y/n)' in self.buffer:
            self.send_wise('y', 'password:')

        self.send_wise(self.password, '>')

    def do_disconnect(self, close_conn=True):
        try:
            self.send_ctrl_c('')
            time.sleep(1)
            self.send_wise('exit', '')
            time.sleep(1)
        finally:
            if close_conn:
                self.close()

    def copy_file_to_server(self, src, dst):
        self.send_wise(f'scp {src} genius@10.1.1.1:/{dst}', ['(yes/no/[fingerprint])?', 'password:'])
        if '(yes/no/[fingerprint])?' in self.buffer:
            self.send_wise('yes', 'password:')
        self.send_wise('genius', self.prompt)

    def copy_file_to_pc(self, pc_ip, src, dst, username='genius', password='genius'):
        self.pc.send_wise(
            f'scp {src} {username}@{pc_ip}:{dst}',
            expectphrase=['yes/no', '(y/n)', 'password:', '>']
        )
        if '>' in self.buffer:
            raise Exception('copy file failed, got >')
        elif 'yes/no' in self.pc.buffer:
            self.pc.send_wise('yes', 'password:')
        elif '(y/n)' in self.pc.buffer:
            self.pc.send_wise('y', 'password:')

        self.pc.send_wise(password, '>')

    def get_console(self):
        drive = re.search('[a-z]:', self.program_dir, flags=re.I)
        if not drive:
            raise Exception(f'please use a absolute Windows path, instead of {self.program_dir}')
        drive = drive.group()
        self.send_wise(f'{drive}', self.prompt)
        self.send_wise(f'cd {self.program_dir}', self.prompt)
        if 'The system cannot find the path specified.' in self.buffer:
            raise Exception(f'dir not exists! {self.program_dir}')

        self.send_wise(f'monkey.exe {self.com_id}', self.prompt)
        if re.search('error|fail', self.buffer, flags=re.I):
            raise Exception('found error when get console')
        status = re.search(r' Status:\s+(\w+)', self.buffer)
        if status is None:
            raise Exception('can not get status! please check connection console')
        status = status.group(1)
        self.debug(f'status: {status}')
        port = re.search(r' Port:\s+(\w+)', self.buffer)
        if port is None:
            raise Exception('not found port!')
        port = port.group(1)
        self.debug(f'port: {port}')
        baud = re.search(r' Baud:\s+(\d+)', self.buffer)
        if baud is None:
            raise Exception('not found baud!')
        baud = baud.group(1)
        self.debug(f'baud: {baud}')

        while True:
            self.send_wise(f'plink.exe -serial {port} -sercfg {baud}', '')
            time.sleep(1)

            if 'Unable to open connection:' in self.buffer:
                if scanner.yes_or_enter_to_continue(
                        f'Can not open console: {self.readable_name} - {port}, retry?') is False:
                    raise Exception(f'can not open console {self.readable_name} {port}')
                continue
            break

        if 'is not recognized as an internal or external command,' in self.buffer:
            raise Exception('please ensure putty is installed!')

        self.debug('get console OK!')
        return port, baud

    def switch_to_dir(self, dir_name):
        """
        这个必须是完整的 DIR Name，比如：D:/tmp/abc
        :return:
        """
        drive = re.search('[a-z]:', dir_name, flags=re.I)
        if not drive:
            raise Exception(f'please use a absolute Windows path, instead of {dir_name}')
        drive = drive.group()
        self.send_wise(f'{drive}', self.prompt)
        self.send_wise(f'cd {dir_name}', self.prompt)
        if 'The system cannot find the path specified.' in self.buffer:
            raise Exception(f'dir not exists! {dir_name}')

    def power_cycle(self, port, sleep=5):
        pmt = 'DIAG>'
        self.send_enter('>')
        if pmt not in self.buffer:
            self.get_console()
        self.send_wise(f'poestatus {port} disable', pmt)
        time.sleep(sleep)
        self.send_wise(f'poestatus {port} enable', pmt)
        self.send_ctrl_c('')

    def power_off(self, port):
        pmt = 'DIAG>'
        self.send_enter('>')
        if pmt not in self.buffer:
            self.get_console()
        self.send_wise(f'poestatus {port} disable', pmt)
        time.sleep(1)
        self.send_ctrl_c('')

    def power_on(self, port):
        pmt = 'DIAG>'
        self.send_enter('>')
        if pmt not in self.buffer:
            self.get_console()
        self.send_wise(f'poestatus {port} enable', pmt)
        time.sleep(1)
        self.send_ctrl_c('')
