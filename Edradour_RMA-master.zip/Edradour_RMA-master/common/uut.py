import time
from .telnet import Telnet
from .scanner import yes_or_enter_to_continue
import re


class UUT(Telnet):

    def __init__(self, name='UUT', suffix='\r', conn_str=None, pop=True):
        super(UUT, self).__init__(name, suffix=suffix, conn_str=conn_str, pop=pop)

    def do_connect(self, conn_str=None, close_before_open=False):
        """
        special
        """
        if (conn_str or self.conn_str) is None:
            raise Exception('please ensure you have provided conn str!!!')

        super().do_connect(conn_str=conn_str, close_before_open=close_before_open)
        self.telnet_ip_and_port()
        # time.sleep(0.5)
        # if 'is being used by' in self.buffer and 'Enter your option :' in self.buffer:
        #     if yes_or_enter_to_continue(question='this console is being used by another people, continue?'):
        #         self.send_wise('1', '')
        #     else:
        #         raise Exception('console is being used by another people')

    def do_disconnect(self):
        super().do_disconnect()
        self.close()
