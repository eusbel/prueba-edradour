import re
import time
import requests
import pandas as pd
import datetime
from .logger import log
import pymssql

# Aruba - UFI - non-Juniper
# MES_IP = '10.221.86.127'
# MES_IP = '10.221.86.122'
# MES_IP = '10.221.86.145'
# MES_IP = 'apimesdcn-cns.myfiinet.com'
#MES_IP = 'apimesjuniper-cns.myfiinet.com'
MES_IP = '10.14.129.151:443'

SFC_DB_IP = '10.221.86.249'

# 临时使用 254
SFC_IP = '10.221.81.252'
SFC_PORT = 61019

# MacSystemIp = '200.168.90.254'
# MacSystemPort = 61017
MAC_VALIDATION = '200.168.96.20'

MacSystemIp = '10.221.86.249'
MacSystemPort = 61017


#FUSION_SERVER = '10.221.81.30'
#DATA_CENTER_SERVER = '10.221.81.40'
FUSION_SERVER = '10.14.146.30'
DATA_CENTER_SERVER = '10.14.146.40'



class MSSQL:
    def __init__(self, host, user, pwd, db_name):
        self.host = host
        self.user = user
        self.pwd = pwd
        self.db_name = db_name

        self.__db = None
        self.__cursor = None

    @property
    def conn(self):
        if self.__db is None:
            self.__db = pymssql.connect(self.host, self.user, self.pwd, self.db_name)
        return self.__db

    @property
    def cursor(self):
        if self.__cursor is None:
            self.__cursor = self.conn.cursor()
        return self.__cursor

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        try:
            if self.__cursor:
                self.__cursor.close()
        except Exception as e:
            log.error(e)

        try:
            if self.__db:
                self.__db.close()
        except Exception as e:
            log.error(e)

def get_sn_detail_from_mes(sn) -> dict:
    """
    从MES获取SN的详细信息，只取第一条
    :param sn:
    :return:
    {
        "ID": "VNJUNIPER00000041XT7",
        "SN": "FJ4823AV0150",
        "SKUNO": "650-134060",
        "WORKORDERNO": "002670004763",
        "PLANT": "VUEA",
        "ROUTE_ID": "VNJUNIPER000000004LF",
        "STARTED_FLAG": "1",
        "START_TIME": "2023-12-14 23:14:39",
        "PACKED_FLAG": "0",
        "PACKDATE": null,
        "COMPLETED_FLAG": "0",
        "COMPLETED_TIME": null,
        "SHIPPED_FLAG": "0",
        "SHIPDATE": null,
        "REPAIR_FAILED_FLAG": "0",
        "CURRENT_STATION": "REWORK",
        "NEXT_STATION": "BFT",
        "KP_LIST_ID": "VNJUNIPER00000000LX8",
        "PO_NO": null,
        "CUST_ORDER_NO": null,
        "CUST_PN": "EX4100-F-12P",
        "BOXSN": null,
        "SCRAPED_FLAG": null,
        "SCRAPED_TIME": null,
        "PRODUCT_STATUS": "REWORK",
        "REWORK_COUNT": 1,
        "VALID_FLAG": "1",
        "STOCK_STATUS": "0",
        "STOCK_IN_TIME": null,
        "EDIT_EMP": "F5011010",
        "EDIT_TIME": "2023-12-16 09:53:29",
        "SKU_VER": "07",
        "TE_STATION": "BFT"
    }
    """
    # url = (f"https://{MES_IP}/MesAPI/mesapi/QUERY?SQL="
    url = (f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY?SQL="
           f"select sn.*,wo.sku_ver,sm.te_station from r_sn sn "
           f"left join r_wo_base wo on sn.workorderno = wo.workorderno "
           f"left join c_temes_station_mapping sm on sn.next_station = sm.mes_station "
           f"where sn.sn = '{sn}' and sn.valid_flag = 1")

    res_data = get_mes_api_res_data(req_func=requests.get, url=url)
    if not res_data:
        raise Exception(f'not found sn {sn} on MES')
    return res_data[0]


def get_skuno_from_mes(sn):
    #url = f"https://{MES_IP}/MESAPI/MESAPI/QUERY?SQL=SELECT * FROM R_SN WHERE SN='{sn}' AND VALID_FLAG = 1"
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY?SQL=SELECT * FROM R_SN WHERE SN='{sn}' AND VALID_FLAG = 1"
    data = get_mes_api_res_data(req_func=requests.get, url=url)
    if len(data) != 1:
        raise Exception(f'expected 1 line data, but got {len(data)}')
    return data[0]['SKUNO']

def update_mac_address_to_mes(sn, pn, mb_mac, mb_block_size):
    """
    1. 先获取数据
    2. 更新数据
    更新 MES 对应字段的 MAC address

    :return:
    """
    if not all([sn, pn, mb_mac, mb_block_size]):
        raise Exception(
            f'please ensure all parameters are valid! -> {[sn, pn, mb_mac, mb_block_size]}')

    #url = f"https://{MES_IP}/MesAPI/mesapi/WWN?WSN={sn}&VSSN=&CSSN="
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/WWN?WSN={sn}&VSSN=&CSSN="
    res_data = get_mes_api_res_data(req_func=requests.get, url=url)
    res_data[0]['MAC'] = mb_mac
    res_data[0]['MAC_BLOCK_SIZE'] = mb_block_size

    res2 = get_mes_api_res_data(req_func=requests.post, url=url, json_data=res_data)
    return res2

def verify_mac_jnp(sn, pn, ver_sku, mac_start, mac_end, mac_size):
    str_datetime = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    data = {"id": str_datetime,
            "date": str_datetime,
            "pn": pn,
            "rev": ver_sku,
            "sn": sn,
            "start_mac": mac_start,
            "end_mac": mac_end,
            "macsize": mac_size
            }
    log.debug(f'Verify data: {data}')
    url = f"http://{MAC_VALIDATION}:8000/mac-validation"
    res2 = get_mac_api_res_data(req_func=requests.post, url=url, json_data=data)
    log.debug(f"MES result: {res2}")
    return res2


def get_mes_test_records(sn, area=None):
    """
    返回按照测试开始时间升序排序的数据
    """
    station_sql = '' if not area else f" AND EVENTNAME='{area}' "
    # sql = f"SELECT * FROM R_TEST_BRCD WHERE SYSSERIALNO='{sn}' {station_sql} ORDER BY TESTDATE"
    sql = f"SELECT * FROM R_TEST_JUNIPER WHERE SYSSERIALNO='{sn}' {station_sql} ORDER BY TESTDATE"
    log.debug(f'Query SQL: {sql}')
    #url = f'https://{MES_IP}/MESAPI/MESAPI/QUERY'
    url = f'http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY'
    payload = requests.get(url, params={'SQL': sql}, verify=False)
    if not payload.ok:
        raise Exception(f'MES server response a bad status code: {payload.status_code}')
    payload = payload.json()
    status = payload.get("Status")
    error_message = payload.get("ErrorMessage")
    log.debug(f'status: {status}, error message: {error_message}')
    if status != 0 or error_message is not None:
        raise Exception(f'MES payload status: {status}, error message: {error_message}')
    return payload['ResData']


def get_current_and_next_station(sn):
    #url = f'https://{MES_IP}/MESAPI/MESAPI/GetNextStation'
    url = f'http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/GetNextStation'
    payload = requests.get(url, params={'sn': sn}, verify=False)
    log.debug(f'{payload.text}')

    if not payload.ok:
        raise Exception(f'MES server response a bad status code: {payload.status_code}')
    payload = payload.json()
    if payload['Status'] != 0 or payload['ErrorMessage'] is not None:
        raise Exception(f'MES response a non-zero status: {payload["Status"]}')
    res_data = payload['ResData']
    if len(res_data) == 0:
        raise Exception(f'mes no data found: {sn}')
    res_data = res_data[0]
    current, next_station = res_data['CURRENT_STATION'], res_data['NEXT_STATION']
    return current, next_station


def get_next_station(sn):
    #url = f'https://{MES_IP}/MESAPI/MESAPI/GetNextStation'
    url = f'http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/GetNextStation'
    payload = requests.get(url, params={'sn': sn}, verify=False)
    log.debug(f'{payload.text}')

    if not payload.ok:
        raise Exception(f'MES server response a bad status code: {payload.status_code}')
    payload = payload.json()
    if payload['Status'] != 0 or payload['ErrorMessage'] is not None:
        raise Exception(f'MES response a non-zero status: {payload["Status"]}')
    res_data = payload['ResData']
    if len(res_data) == 0:
        raise Exception(f'mes no data found: {sn}')
    res_data = res_data[0]
    next_station = res_data['NEXT_STATION']
    return next_station


def update_r_test_juniper(data):
    """
    上传至 JNPR-MES
    :param data: 已经组装好的数据
    :return:
    """
    if len(data) == 0:
        log.debug('no records were found! skip upload to MES...')
        return

    for d in data:
        log.debug(f'upload -> {d}')

    #url = f'https://{MES_IP}/MesApi/mesApi/UpdateR_TEST_JUNIPER'
    url = f'http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/UpdateR_TEST_JUNIPER'
    # url = f'http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/UpdateR_TEST_JUNIPER_New' Need Add keys for New API Address
    return get_mes_api_res_data(req_func=requests.post, url=url, json_data=data)


def upload_records_to_mes(data):
    """
    上传记录至 non-JNPR MES
    """
    for i in range(3):
        log.debug(data)
        try:
            payload = requests.post(
                #f'https://{MES_IP}/MesAPI/mesapi/UPDATE_R_TEST_BRCD',
                f'http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/UPDATE_R_TEST_BRCD',
                json=data,
                headers={'Content-type': 'application/json'}, verify=False
            )
        except Exception as e:
            log.error(e)
            time.sleep(5)
            continue

        # show status code
        log.info(f'status code: {payload.status_code}')
        log.info(f'{payload.text}')

        if not payload.ok:
            log.error(f'upload to mes failed: {payload.text[:1000]}')
            time.sleep(5)
            continue

        try:
            result = payload.json()
            if result['ErrorMessage'] is not None:
                log.warning(f'MES response error, see: {result}')
            if result['Status'] != 0:
                raise Exception(f'MES response error, see: {result}')
        except Exception as e:
            log.error(e)
            time.sleep(5)
            continue

        # 上传成功，返回MES的结果
        return result
    else:
        raise Exception(f'upload to MES failed, max try...')


def get_sn_kp_from_mes(sn):
    """
    返回的是全部数据
    :return: list[dict]
    {
    "Status": 0,
    "ResData": [
        {
            "ID": "VNJUNIPER000000QJBDJ",
            "R_SN_ID": "VNJUNIPER00000041XT7",
            "SN": "FJ4823AV0150",
            "VALUE": "611-133600",
            "PARTNO": "611-133600PN",
            "KP_NAME": "PCBA",
            "MPN": "611-133600PN",
            "SCANTYPE": "PN",
            "ITEMSEQ": 0,
            "SCANSEQ": 1,
            "DETAILSEQ": 1,
            "STATION": "MA1",
            "REGEX": "^611-133600$",
            "VALID_FLAG": 1,
            "EXKEY1": null,
            "EXVALUE1": null,
            "EXKEY2": null,
            "EXVALUE2": null,
            "EDIT_TIME": "2023-12-15 00:36:16",
            "EDIT_EMP": "V1036451",
            "LOCATION": "PCBA-1"
        },
        {
            "ID": "VNJUNIPER000000QJBDK",
            "R_SN_ID": "VNJUNIPER00000041XT7",
            "SN": "FJ4823AV0150",
            "VALUE": "FJ4823AV0150",
            "PARTNO": "611-133600",
            "KP_NAME": "KEEP_SN",
            "MPN": "611-133600",
            "SCANTYPE": "KEEP_SN",
            "ITEMSEQ": 1,
            "SCANSEQ": 1,
            "DETAILSEQ": 1,
            "STATION": "SILOADING",
            "REGEX": null,
            "VALID_FLAG": 1,
            "EXKEY1": "OLD_SN_ID",
            "EXVALUE1": "VNJUNIPER00000040GGT",
            "EXKEY2": null,
            "EXVALUE2": null,
            "EDIT_TIME": "2023-12-14 23:14:39",
            "EDIT_EMP": "V1036451",
            "LOCATION": null
        }
    ],
    "ErrorMessage": null
    }
    """
    #url = f"https://{MES_IP}/MesAPI/mesapi/QUERY?SQL=select * from r_sn_kp where sn = '%s' and valid_flag = 1" % sn
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY?SQL=select * from r_sn_kp where sn = '%s' and valid_flag = 1" % sn
    res_data = get_mes_api_res_data(requests.get, url=url)
    return res_data


def get_wwn_from_mes(sn):
    """
    只返回第一条数据
    """
    #url = f"https://{MES_IP}/MesApi/mesapi/WWN?WSN=%s&VSSN=&CSSN=" % sn
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/WWN?WSN=%s&VSSN=&CSSN=" % sn
    res_data = get_mes_api_res_data(req_func=requests.get, url=url)
    return res_data[0]

def upload_mgmt_mac(sn, mac, current_time):
    data = get_wwn_from_mes(sn)
    data['MACTB0'] = mac
    data['LASTEDITDT'] = current_time
    upload_data = [data]
    log.debug(f'Upload date: {upload_data}')
    #url = f"https://{MES_IP}/MesApi/mesApi/WWN"
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/WWN"
    res2 = get_mes_api_res_data(req_func=requests.post, url=url, json_data=upload_data)
    log.debug(f"MES result: {res2}")
    log.debug(f"Upload MGMT MAC Success!")
    return res2


def get_mes_api_res_data(req_func, url, params=None, data=None, json_data=None):
    """
    提取 MES 返回数据中的 ResData，同时对数据状态进行判断！
    :param req_func:
    :param url:
    :param params:
    :param data:
    :param json_data:
    :return:
    """
    log.debug(f'URL: {url}')
    try:
        payload = req_func(url, params=params, data=data, json=json_data, verify=False)
    except Exception as e:
        log.error(f'Failed -> {url} -> {e}')
        raise

    log.debug(f'Status Code: {payload.status_code}')
    # log.debug(f'TEXT: {payload.text}')

    if not payload.ok:
        raise Exception(f'MES server response a none-zero code: {payload.status_code}')

    payload_json = payload.json()
    status = payload_json['Status']
    error_message = payload_json['ErrorMessage']
    res_data = payload_json['ResData']

    if status != 0 or error_message:
        if error_message == 'existed':
            log.debug("Upload data existed !" )
        else:
            raise Exception(f'MES response a none-zero status: {status} or error message not empty: {error_message}')

    return res_data

def get_mac_api_res_data(req_func, url, params=None, data=None, json_data=None):
    """
    提取 MES 返回数据中的 ResData，同时对数据状态进行判断！
    :param req_func:
    :param url:
    :param params:
    :param data:
    :param json_data:
    :return:
    """
    log.debug(f'URL: {url}')
    try:
        payload = req_func(url, params=params, data=data, json=json_data)
    except Exception as e:
        log.error(f'Failed -> {url} -> {e}')
        raise

    log.debug(f'Status Code: {payload.status_code}')
    log.debug(f'TEXT: {payload.text}')

    if not payload.ok:
        raise Exception(f'MES server response a none-zero code: {payload.status_code}')

    payload_json = payload.json()
    status = payload_json['status_code']
    error_message = payload_json['status_message']

    if status != "0" or error_message != 'OK':
        raise Exception(f'JNP response a none-zero status: {status} or error message not ok: {error_message}')

    return payload.text


def update_mac_address_to_db(vsn, vpn, psn, ppn, macaddr, macsize):
    """
    1. 先获取数据
    2. 更新数据
    更新 MES 对应字段的 MAC address
    :param vsn:
    :param vpn:
    :param psn:
    :param ppn:
    :param macaddr:
    :param macsize:
    :return:
    """
    #url = f'https://{MES_IP}/MesAPI/mesapi/WWN?WSN=' + vsn + '&VSSN=&CSSN='
    url = f'http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/WWN?WSN=' + vsn + '&VSSN=&CSSN='
    res_data = get_mes_api_res_data(req_func=requests.get, url=url)
    res_data[0]['MAC'] = macaddr
    res_data[0]['MAC_BLOCK_SIZE'] = macsize
    res2 = get_mes_api_res_data(req_func=requests.post, url=url, json_data=res_data)
    return res2


def get_last_test_record(sn, station='', status=''):
    """
    看起来不像是获取最后一笔记录
    要求 Status 是 0 且 ResData 有数据，success 才是 True
    :param sn:
    :param station:
    :param status:
    :return:
    """
    station_sql = f" and eventname = '{station}' " if station else ''
    status_sql = f" and status = '{status}' " if status else ''

    sql = f"select * from r_test_juniper where sysserialno= '%s' {station_sql} {status_sql} order by testdate desc" % sn
    #url = f"https://{MES_IP}/MesAPI/mesapi/QUERY?SQL={sql}"
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY?SQL={sql}"
    res_data = get_mes_api_res_data(req_func=requests.get, url=url)
    return res_data


def get_pcba_pn_from_mes(sn):
    sql = f"SELECT * FROM R_SN_KP WHERE SN='{sn}' AND STATION='ASSY' AND KP_NAME='MB' AND SCANTYPE = 'PN' AND VALID_FLAG = 1"
    #url = f"https://{MES_IP}/MESAPI/MESAPI/QUERY?SQL={sql}"
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY?SQL={sql}"
    data = get_mes_api_res_data(req_func=requests.get, url=url)
    log.debug(f'get pcba pn from mes: {len(data)}')
    if len(data) != 1:
        raise Exception(f'get pcba records from mes failed. should be 1, got {len(data)}')
    log.debug(f'{data}')
    pcba_pn = data[0]['PARTNO']
    log.debug(f'{sn} pcba pn: {pcba_pn}')
    return pcba_pn


def get_label_part_number_from_mes(sn):
    data_label = get_kp_info_from_mes(sn)
    pn_data = next(
        (x['VALUE'] for x in data_label
         if x.get('VALUE') and x['STATION'] == "CLAIM_CODE_PRINT"
         and re.match(r'^650-\d{6} REV [A-Z0-9]{1,2}$', x['VALUE'])),
        'NOT_FOUND'
    )
    if pn_data == "NOT_FOUND":
        raise Exception("Not found PN data from MES KP where VALUE like '^650-\d{6} REV [A-Z0-9]{1,2}$'")
    pn = pn_data.split('REV')[0]
    log.debug(f'MES PN: {pn}')
    return pn.strip()

def get_611_pn_by_sn(sn):
    sql = (f"SELECT * FROM R_SN_KP WHERE SN = '{sn}' "
           f"AND KP_NAME= 'MB' "
           f"AND SCANTYPE = 'PN' "
           f"AND PARTNO LIKE '611-%' "
           )

    #url = f"https://{MES_IP}/MESAPI/MESAPI/QUERY?SQL={sql}"
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY?SQL={sql}"
    data = get_mes_api_res_data(req_func=requests.get, url=url)
    if len(data) != 1:
        raise Exception(f'expected 1 line data, but got {len(data)}')
    return data[0]['PARTNO'].strip()

def get_label_from_mes(sn):
    sql = (f"SELECT * FROM R_SN_KP "
           f"WHERE SN = '{sn}' "
           f"AND KP_NAME= 'LABEL' "
           f"AND (SCANTYPE = 'PN' OR SCANTYPE = 'REVPN' OR SCANTYPE = 'SN') "
           f"AND VALID_FLAG = 1")

    #url = f"https://{MES_IP}/MESAPI/MESAPI/QUERY?SQL={sql}"
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY?SQL={sql}"
    data = get_mes_api_res_data(req_func=requests.get, url=url)
    # if len(data) != 3:
    #     raise Exception(f'expected 3 line data, but got {len(data)}')
    return data

def get_kp_info_from_mes(sn):
    sql = (f"SELECT * FROM R_SN_KP "
           f"WHERE SN = '{sn}' "
           f"AND VALID_FLAG = 1")

    #url = f"https://{MES_IP}/MESAPI/MESAPI/QUERY?SQL={sql}"
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY?SQL={sql}"
    data = get_mes_api_res_data(req_func=requests.get, url=url)
    # if len(data) != 3:
    #     raise Exception(f'expected 3 line data, but got {len(data)}')
    return data


def get_label_aver_min_from_mes(sn):
    data_label = get_kp_info_from_mes(sn)
    pn_data = next(
        (x['VALUE'] for x in data_label
         if x.get('VALUE') and x['STATION'] == "CLAIM_CODE_PRINT"
         and re.match(r'^650-\d{6} REV [A-Z0-9]{1,2}$', x['VALUE'])),
        'NOT_FOUND'
    )
    if pn_data == "NOT_FOUND":
        raise Exception("Not found PN data from MES KP where VALUE like '^650-\d{6} REV [A-Z0-9]{1,2}$'")
    pn_rev = pn_data.split('REV')[-1]
    log.debug(f'MES PN REV: {pn_rev}')

    return pn_rev.strip()

def get_label_clei_from_mes(sn):
    data_label = get_kp_info_from_mes(sn)
    clei = next(
        (x['VALUE'][-10:] for x in data_label
         if x.get('VALUE') and '[)>' in x['VALUE']),
        'NOT_FOUND'
    )
    if clei == "NOT_FOUND":
        raise Exception("Not found CLEI data from MES KP where VALUE like '[)>'")
    log.debug(f'MES CLEI: {clei}')
    return clei.strip()


def get_label_model_maj_rev_from_mes(sn):
    data_label = get_kp_info_from_mes(sn)
    sku_data = next(
        (x['VALUE'] for x in data_label
         if x.get('VALUE') and re.match(r'^EX4000-[A-Z0-9-]+ REV [A-Z]$', x['VALUE'])),
        'NOT_FOUND'
    )
    if sku_data == "NOT_FOUND":
        raise Exception("Not found SKU data from MES KP where VALUE like '^EX4000-[A-Z0-9-]+ REV [A-Z]$'")
    sku_rev = sku_data.split('REV')[-1]
    log.debug(f'MES SKU REV: {sku_rev}')
    return sku_rev.strip()


def get_mac_address_from_mes(wsn):
    #url = f'https://{MES_IP}/MESAPI/MESAPI/WWN?WSN={wsn}&VSSN=&CSSN='
    url = f'http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/WWN?WSN={wsn}&VSSN=&CSSN='
    data = get_mes_api_res_data(req_func=requests.get, url=url)
    if len(data) != 1:
        raise Exception(f'get mac from mes failed! the length should be 1, got {len(data)}')
    log.debug(f'{wsn} MAC from MES, {data[0]["MAC"]}, {data[0]["MAC_BLOCK_SIZE"]}')
    return data[0]['MAC'], data[0]['MAC_BLOCK_SIZE']

def get_mac_data_from_mes(wsn):
    #url = f'https://{MES_IP}/MESAPI/MESAPI/WWN?WSN={wsn}&VSSN=&CSSN='
    url = f'http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/WWN?WSN={wsn}&VSSN=&CSSN='
    data = get_mes_api_res_data(req_func=requests.get, url=url)
    if len(data) != 1:
        raise Exception(f'get mac from mes failed! the length should be 1, got {len(data)}')
    log.debug(f'{wsn} MAC from MES, {data[0]["MAC"]}, {data[0]["MAC_BLOCK_SIZE"]}')
    return data[0]['MAC'], data[0]['MAC_BLOCK_SIZE'], data[0]['SKU']

def select_mac_address(serial_number):
    try:
        sql = f"select * from assignedmac where serialno='{serial_number}'"
        log.debug(sql)

        with MSSQL(host=MacSystemIp, user="sa", pwd="GZmac123@@", db_name="mac") as db:
            db.cursor.execute(sql)
            log.debug(f'affect count: {db.cursor.rowcount}')
            data = db.cursor.fetchall()
            if len(data) == 0:
                return "", "0"
            log.debug(f'affect data: {data}')
            return str(data[0][1]), str(data[0][3])
    except Exception as e:
        log.error(f'mac encounter error: {e}')
        raise Exception('mac encounter error')


def get_latest_junos_version_from_mes(model_num):
    """
    {
        "ID": "VNJUNIPER0000000000N",
        "ECONO": "ECO-59300",
        "SKUNO": "EX4100-F-12P",
        "REV": "NA",
        "OLD_JUNOS_PN": "811-1633631",
        "OLD_JUNOS_REV": "22.3R1.12",
        "NEW_JUNOS_PN": "811-179455",
        "NEW_JUNOS_REV": "22.4R3.25",
        "QE_COMFIRM_EMP": null,
        "QE_COMFIRM_FLAG": "0",
        "CREATE_BY": "F2166802",
        "CREATE_TIME": "2024-05-10 09:50:18",
        "DATA1": null,
        "DATA2": null,
        "DATA3": null,
        "DATA4": null,
        "DATA5": null,
        "DATA6": null,
        "DATA7": null,
        "EDIT_EMP": null,
        "EDIT_TIME": null
    }
    """
    sql = f"SELECT * FROM r_junos_information WHERE SKUNO='{model_num}' ORDER BY CREATE_TIME DESC"
    #url = f"https://{MES_IP}/mesapi/MESAPI/QUERY?SQL={sql}"
    url = f"http://{MES_IP}/On-linetools/Apps/CMWH-API/MESAPI/QUERY?SQL={sql}"
    data = get_mes_api_res_data(req_func=requests.get, url=url)
    if len(data) == 0:
        raise Exception(f'can not get latest JUNOS version from MES by {model_num}')
    latest_version = data[0]['NEW_JUNOS_REV']
    log.debug(f'Latest JUNOS Version from MES: {latest_version}')
    return latest_version


def get_genius_test_records(sn, month):
    # https://fusion-server:8000/vision/get-record-by-sernum/?sernum=GZ3024AV0033&database=10.221.81.40&month=3
    url = f'http://{FUSION_SERVER}:8000/vision/get-record-by-sernum/?sernum={sn}&database={DATA_CENTER_SERVER}&month={month}'
    payload = requests.get(url)
    if not payload.ok:
        raise Exception(f'bad status code: {payload.status_code}')
    payload = payload.json()
    status = payload['status']
    if status is not True:
        raise Exception('server response a not true status!')

    return payload['data']


def need_to_upload_fail(sn, station, fail_name, month=3):
    """
    确保只在Fail的时候调用此函数！
    上传Fail的条件：
    1. 连续3次且是同样的FAIL，第三次上传记录
    2. 连续FAIL5次，第五次上传最后一次的名称
    :param sn:
    :param station:
    :param fail_name:
    :param month:
    :return:
    """
    df = pd.DataFrame(get_genius_test_records(sn, month))
    df = df[(df['result'].isin(['F', 'P'])) & (df['mode'] == 'PROD') & (df['area'] == station)]
    log.debug(f'{sn} - {station}, latest {month} month total records: {len(df)}')

    df.sort_values(by=['recttime', 'id'], ascending=False, inplace=True)

    # 按时间降序
    latest_test = [(getattr(_, 'result'), getattr(_, 'test')) for _ in df.tail(5).itertuples()]
    latest_test.append(('F', fail_name))
    # log.debug(latest_test)

    if len(latest_test) < 3:
        log.debug('less than 3 records, return True')
        return False

    latest_three = latest_test[-3:]
    if len(set(latest_three)) == 1:
        log.debug(f'last 3 records: {latest_three}')
        log.error(f'consecutive 3 times same fail: {fail_name}!')
        return True

    latest_five = [_[0] for _ in latest_test][-5:]
    log.debug(f'consecutive fail times: {len(latest_five)}')
    if len(latest_five) == 5 and set(latest_five) == {'F'}:
        log.debug(f'{latest_test[-5:]}')
        return True

    return False

def check_sn_fail_times(sn, station, month=3):
    """

    """
    df = pd.DataFrame(get_genius_test_records(sn, month))
    df = df[(df['result'].isin(['F', 'P'])) & (df['mode'] == 'PROD') & (df['area'] == station)]
    log.debug(f'{sn} - {station}, latest {month} month total records: {len(df)}')

    df.sort_values(by=['recttime', 'id'], ascending=True, inplace=True)

    # 按时间降序
    latest_test = [(getattr(_, 'result'), getattr(_, 'test')) for _ in df.tail(5).itertuples()]
    log.debug(latest_test)

    if len(latest_test) < 2:
        log.debug('less than 2 records, Continue test')
        return None

    latest_two = latest_test[-2:]
    if len(set(latest_two)) == 1:
        fail_name = list(set(latest_two))[0][1]
        log.debug(f'last 2 records: {latest_two}')
        log.error(f'consecutive 2 times same fail: {fail_name}!')
        return fail_name


def control_ft_fail_times(sn, station, max_fail_time=3, month=3):
    """

    """
    df = pd.DataFrame(get_genius_test_records(sn, month))
    df = df[(df['result'].isin(['F', 'P'])) & (df['mode'] == 'PROD') & (df['area'] == station)]
    log.debug(f'{sn} - {station}, latest {month} month total records: {len(df)}')

    df.sort_values(by=['recttime', 'id'], ascending=True, inplace=True)

    # 按时间降序
    latest_test = [(getattr(_, 'result'), getattr(_, 'test')) for _ in df.tail(5).itertuples()]
    log.debug(latest_test)

    if len(latest_test) < 2:
        log.debug('less than 2 records, Continue test')
        return None

    latest_two = latest_test[-2:]
    if len(set(latest_two)) == 1:
        fail_name = list(set(latest_two))[0][1]
        log.debug(f'last 2 records: {latest_two}')
        log.error(f'consecutive 2 times same fail: {fail_name}!')
        return fail_name

def check_sn_pass_station(sn, station, month=3):
    station = "FT" if station == "FINALTEST" else station
    station = "RIT" if station == "CLAIM_CODE" else station
    df = pd.DataFrame(get_genius_test_records(sn, month))
    df = df[(df['result'].isin(['F', 'P', 'A'])) & (df['area'] == station)]
    log.debug(f'{sn} - {station}, latest {month} month total records: {len(df)}')

    df.sort_values(by=['recttime', 'id'], ascending=True, inplace=True)

    # 按时间降序
    latest_test = [(getattr(_, 'result'), getattr(_, 'test'), getattr(_, 'recttime'), getattr(_, 'mode'), getattr(_, 'area')) for _ in df.tail(6).itertuples()]
    log.debug(latest_test)
    if latest_test:
        return latest_test[-1]
    else:
        return None
