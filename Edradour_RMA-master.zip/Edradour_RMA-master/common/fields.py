from collections.abc import Mapping, Sequence

from .logger import warn, debug
from gen.libs import lib


class FieldsException(Exception):
    pass


container_dict = lib.userdict.setdefault(lib.get_container_name(), dict())  # type: dict
fields_dict = lib.userdict.setdefault('__fields_data__', dict())  # type: dict


class BaseField:

    def __init__(self, initial_value=None):
        self.check_value(initial_value)
        self.__initial_value = initial_value
        self.name = None

    def check_value(self, value):
        """
        检查是否 value 是否符合期望
        :param value:
        :return:
        """
        pass

    def __set__(self, instance, value):
        self.check_value(value)
        fields_dict[self.name] = value

    def __get__(self, instance, owner):
        return fields_dict[self.name]

    def __delete__(self, instance):
        del fields_dict[self.name]

    def __set_name__(self, owner, name):
        self.name = name
        fields_dict[self.name] = self.__initial_value


Field = BaseField


class StrField(BaseField):

    def __init__(self, initial_value=''):
        super(StrField, self).__init__(initial_value=initial_value)

    def check_value(self, value):
        if not isinstance(value, str):
            raise TypeError(f'type error: {self.name} must be str, got {type(value)}')

    def __get__(self, instance, owner) -> str:
        return super(StrField, self).__get__(instance, owner)


class NumericField(BaseField):

    def __init__(self, initial_value=0):
        """
        scope: function(value) -> bool
        """
        super(NumericField, self).__init__(initial_value)

    def check_value(self, value):
        if not isinstance(value, (int, float)):
            raise TypeError(f'type error: {self.name} must be int or float, got {type(value)}')

    def __get__(self, instance, owner) -> (int, float):
        return super(NumericField, self).__get__(instance, owner)


class IntField(BaseField):

    def __init__(self, initial_value=0):
        """
        scope: function(value) -> bool
        """
        super(IntField, self).__init__(initial_value)

    def check_value(self, value):
        if not isinstance(value, int):
            raise TypeError(f'type error: {self.name} must be int, got {type(value)}')

    def __get__(self, instance, owner) -> (int, float):
        return super(IntField, self).__get__(instance, owner)


class DictField(BaseField):

    def __init__(self, initial_value=None):
        super().__init__(initial_value={} if initial_value is None else initial_value)

    def check_value(self, value):
        if not isinstance(value, Mapping):
            raise TypeError(f'type error: {self.name} must be dict like, got {type(value)}')


class ListField(BaseField):

    def __init__(self, initial_value=None):
        super().__init__(initial_value=[] if initial_value is None else initial_value)

    def check_value(self, value):
        if not isinstance(value, Sequence):
            raise TypeError(f'type error: {self.name} must be list like, got {type(value)}')


class Config:
    """
    获取 Genius 本身的配置信息，可以读写！
    """

    def __init__(self):
        self.name = '__cn_config__'
        self.refresh()

    def __set__(self, instance, value):
        warn('cannot set config directly, try "config[key] = value", instead of "config = value"', name='Config')

    def __get__(self, instance, owner) -> dict:
        return container_dict[self.name]

    def __set_name__(self, owner, name):
        pass

    def __delete__(self, instance):
        if self.name in container_dict:
            del container_dict[self.name]

    def refresh(self):
        container_dict.setdefault(self.name, dict()).update(lib.get_configuration_data())

    def show_config(self):
        for k, v in container_dict[self.name].items():
            debug(f'{k} = {v}', name='Config')
