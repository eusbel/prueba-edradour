import logging
import platform
from collections import OrderedDict
from functools import reduce
import pathlib
import traceback
import datetime
import shutil
import pytz
import os
import re

from .models import CommonModel, JuniperMESModel
from .fields import Config

from gen.libs import lib
from . import const, sfchelper
from . import scanner
from .logger import log

NAME = 'UTILS'
PROD = 'PROD'
DEBUG = 'DEBUG'
# RAISE_ERROR_ONLY = 'raise_error_only'
RECORDS_FIELD = 'records'
SN = 'sn'
PN = 'pn'
AREA = 'area'
RESULT = 'result'
INFO = 'info'
LEGAL_RESULT = ['A', 'S', 'P', 'F']

logger = lib.get_seq_logger()  # type: logging.Logger


# 验证连接字符串
def extract_conn_string(conn_string):
    """
    telnet 10.1.1.3   or    telnet 10.1.1.3 2002
    提取连接字符串关键的信息，比如协议：telnet；ip或者端口，这里使用简单的IP提取方式，不用过于复杂的IP提取正则表达式
    返回一个元组： (协议, IP, 端口号)
    """
    # more strict ip pattern
    # ((?:(?:2[0-4]\d|25[0-5]|[01]?\d\d?)\.){3}(?:2[0-4]\d|25[0-5]|[01]?\d\d?))(?:\s+(\d+))?
    # we use simpler pattern here
    r = re.fullmatch(r'(?P<protocol>\w+\s)?(?P<ip>(\d{1,3}\.){3}\d{1,3})(?P<port>\s\d{1,4})?', conn_string)
    if r is None:
        log.warning(f'bad conn string -> {conn_string}')
        return
    protocol = r.groupdict().get('protocol')
    protocol = protocol.strip() if protocol else None
    ip = r.groupdict().get('ip')
    port = r.groupdict().get('port')
    port = int(port.lstrip()) if port else None
    log.info(f'protocol = {protocol}, ip = {ip}, port = {port}')
    return protocol, ip, port


class LibUtils:
    """
    这个类封装了对lib库的补充，和功能添加
    """

    PASS = lib.PASS
    SKIP = lib.SKIP
    FAIL = lib.FAIL
    JUMP = lib.JUMP

    PROD = 'PROD'
    DEBUG = 'DEBUG'
    PRE_SEQ = 'PRE-SEQ'
    MAIN_SEQ = 'MAIN-SEQ'

    # 保存config文件中的config data
    config = Config()
    __conn = {}

    # logging
    debug = log.debug
    info = log.info
    warn = log.warning
    warning = log.warning
    error = log.error

    abort_flag = False

    @property
    def mode(self):
        return self.get_genius_mode()

    @staticmethod
    def get_genius_mode():
        """
        PROD
        DEBUG
        """
        return lib.get_genius_mode()

    @staticmethod
    def get_traceback():
        """
        if no exception, this will be None
        """
        return lib.get_traceback()

    @property
    def everything_goes_well(self):
        return lib.get_traceback() is None

    @property
    def sequence_type(self):
        """
        获取当前测试的 SEQ 类型
        :return:
        """
        return lib.get_current_sequence_type()

    @staticmethod
    def get_current_sequence_type():
        """
        PRE-SEQ or MAIN-SEQ
        """
        return lib.get_current_sequence_type()

    @staticmethod
    def get_prod_version(repo_name):
        """
        获取某个机种的最新版本和当前版本
        return: current_version, latest_version
        """
        return lib.get_prod_version(repo_name)

    @property
    def user_dict(self) -> dict:
        return lib.userdict

    @property
    def container_name(self) -> str:
        return lib.get_container_name()

    # default max container number: 99
    @property
    def container_number(self) -> str:
        return self.container_name[-2:]

    @property
    def container_dict(self) -> dict:
        return self.user_dict.setdefault(self.container_name, dict())

    @property
    def station_name(self) -> str:
        return self.container_name.split(':')[0]

    @staticmethod
    def get_protocol_pms(con_str):
        return extract_conn_string(con_str)

    @staticmethod
    def get_full_path(*path, mode=None, project_name=None) -> str:
        """
        获取项目基础目录，默认是包含项目的名称
        :param path: 可以是一个或者若干个路径
        :param mode:
        :param project_name: 默认是项目本身的名字
        :return:
        """
        mp = {
            'PROD': '/opt/prod',
            'DEBUG': '/opt/te',
        }
        project_name = project_name or pathlib.Path(__file__).parent.parent.name
        if mode is None:
            pth = pathlib.Path(mp[lib.get_genius_mode().upper()])
        elif mode == PROD:
            pth = pathlib.Path('/opt/prod')
        elif mode == DEBUG:
            pth = pathlib.Path('/opt/te')
        else:
            raise Exception(f'mode is bad! -> {mode}')

        if len(path):
            ps = (pathlib.Path(pth) /
                  pathlib.Path(project_name) /
                  reduce(lambda x, y: pathlib.Path(x) / pathlib.Path(y), path, pathlib.Path('')))
            return str(ps)
        else:
            return str(pth)

    @staticmethod
    def get_dj_timezone():
        return const.DJ_TIMEZONE

    @staticmethod
    def acquire_locking(name, wait_timeout=3600, privilege=False):
        return lib.acquire_locking(name, wait_timeout, privilege)

    @staticmethod
    def release_locking(name):
        return lib.release_locking(name)

    # name, wait_timeout=3600, privilege=False
    FIFOLocking = lib.locking.FIFOLocking

    @staticmethod
    def fifo_locking(name, wait_timeout=3600, privilege=False):
        return lib.locking.fifo_locking(name, wait_timeout=wait_timeout, privilege=privilege)

    @staticmethod
    def clean_sync_up(group_name):
        return lib.sync.clean_sync_up(group_name)

    @staticmethod
    def sync_up(group_name, wait_timeout=3600):
        return lib.sync.sync_up(group_name, wait_timeout=wait_timeout)

    # group_name, wait_timeout=3600
    SyncUp = lib.sync.SyncUp

    @staticmethod
    def leader_sync_up(group_name, leader_container, wait_timeout=3600):
        return lib.sync.leader_sync_up(group_name, leader_container=leader_container, wait_timeout=wait_timeout)

    @staticmethod
    def get_test_log_path():
        return lib.utility.get_test_log_path()

    @staticmethod
    def set_test_name(name, step=False):
        return lib.utility.set_test_name(name, step=step)

    @staticmethod
    def get_test_step_name():
        return lib.utility.get_test_step_name()

    @staticmethod
    def get_first_fail_step_name():
        return lib.utility.get_first_fail_step_name()

    @staticmethod
    def start_container_test(name, override=True):
        return lib.utility.start_container_test(name, override=override)

    @staticmethod
    def get_conn(name):
        return lib.get_conn(name)

    @staticmethod
    def get_container_name():
        return lib.get_container_name()

    # def generate_test_report(report=True):
    #     constant.REPORT = report
    #     return

    @staticmethod
    def get_container_status(name):
        return lib.get_container_status(name)

    @staticmethod
    def get_container_test_data(container_name, count=5):
        return lib.get_container_test_data(container_name, count)

    @staticmethod
    def get_sync_group(group_name):
        return lib.get_sync_group(group_name)

    @staticmethod
    def get_group_name(container_name):
        """
        根据container_name获取所在群组名，没有群组则为空
        :param container_name:
        :return:
        """
        return lib.get_group_name(container_name)

    @staticmethod
    def get_start_time(fmt='%Y-%m-%d %H:%M:%S', local_time=True):
        """
        获取开始测试的时间
        local_time 默认是 True，返回本地时间，否则返回 Django 配置的时区时间
        :param fmt: 2023-07-10 14:13:20
        :param local_time: 默认获取本地时间
        :return:
        """
        start_time = lib.constant.START_TIME
        if isinstance(start_time, datetime.datetime):
            tm = start_time.astimezone(pytz.timezone(const.DJ_TIMEZONE))
        elif isinstance(start_time, (int, float)):
            tm = datetime.datetime.fromtimestamp(lib.constant.START_TIME, tz=pytz.timezone(const.DJ_TIMEZONE))
        else:
            raise Exception(f'invalid type of start time: {type(start_time)}, it should be datetime, int, float')

        if local_time:
            tm = tm.astimezone(pytz.timezone(const.LOCAL_TIMEZONE))
        return tm.strftime(fmt)

    @staticmethod
    def get_local_datetime(datetime_now=None, fmt=const.DEFAULT_TIME_FMT):
        return get_local_datetime(datetime_now=datetime_now, fmt=fmt)

    @staticmethod
    def get_operator_name() -> str:
        return lib.get_operator_name()

    def get_console(self, conn_name, container=None, klass=None):
        """
        对lib库的进一步封装，默认返回当前cell的指定connection
        :param conn_name: UUT, SW, POE etc...
        :param container: 默认是当前cell的connection，也可以是其他的，但是需要显示指定
        :param klass: 默认返回genius的console，如果传入指定的实列则使用指定的实例返回
        :return:
        """
        container = lib.get_container_name() if container is None else container
        conn = lib.get_conn(f'{container}:{conn_name}')
        # 防止每次调用都会生成新的实例
        if klass is not None:
            return self.__conn.setdefault(f'{conn_name}-{container}-{klass}', klass(conn_name, conn))
        conn.open()
        return conn

    @staticmethod
    def set_display1(display):
        """SN"""
        return lib.set_display1(display)

    @staticmethod
    def set_display2(display):
        """PN"""
        return lib.set_display2(display)

    @staticmethod
    def set_display3(display):
        """TEST ITEM NAME"""
        return lib.set_display3(display)

    @staticmethod
    def quick_set(text):
        lib.set_display3(text)
        lib.set_test_name(name=text)

    @staticmethod
    def upload_file_to_data_center(src):
        upload_file_to_data_center(src)

    def set_option_str(self, sn, key, name, value):
        """
        修改genius记录中的str字段
        key: 1 ~ 6
        name: str1name
        value: str1
        """
        key = str(key)
        legal_key = [str(i) for i in range(1, 7)]
        if key not in legal_key:
            raise Exception(f'key: {key} not in {legal_key}')

        log.debug(f'[{sn}] set str{key}name = {name}, str{key} = {value}')
        record = self.get_records()[sn]
        record[f'str{key}name'] = f'{name}'
        record[f'str{key}'] = f'{value}'

    @staticmethod
    def set_container_text(text):
        return lib.set_display3(text)

    @staticmethod
    def ask_question(question, timeout=7200, answers=None, image=None, visible=True,
                     privilege=False, multiple=False, upper_and_strip=True):
        """
        这是默认的原始
        """
        return scanner.ask_question(
            question, timeout=timeout, answers=answers, image=image, visible=visible, privilege=privilege,
            multiple=multiple, upper_and_strip=upper_and_strip
        )

    @staticmethod
    def ask_question2(question, timeout=7200, answers=None, image=None, visible=True, privilege=False):
        return lib.ask_question2(
            question, timeout=timeout, answers=answers, image=image, visible1=visible, privilege=privilege)

    def get_records(self) -> OrderedDict:
        return self.container_dict.setdefault(RECORDS_FIELD, OrderedDict())

    def add_record(self, sn, pn, area, **kwargs):
        """
        当需要上传的记录不仅仅只有一条或者一块板子的信息，需要调用此函数添加一条记录
        :param sn:
        :param pn:
        :param area:
        :return:
        """
        rec = CommonModel(sn=sn, pn=pn, area=area, status='', info='', kwargs=kwargs)
        for k, v in kwargs.items():
            log.debug(f'[{pn} {sn}] kwargs: {k} = {v}')
        # 若重复添加，新的会覆盖旧的
        self.get_records()[sn] = rec

    def update_records_status(self, status, **kwargs):
        """
        更新测试状态
        :param status: F P S
        :param kwargs: 上传数据库时额外的参数
        :return:
        """
        if status not in LEGAL_RESULT:
            raise Exception(f'status {status} not in {LEGAL_RESULT}')
        records = self.get_records()

        # 没有异常的话，重置 step_name 为空字符串
        step_name = '' if self.everything_goes_well else self.get_first_fail_step_name()

        for sn, rec in records.items():  # type: str, CommonModel
            rec.status = status
            rec.info = step_name
            rec.kwargs.update(kwargs)

    def upload_genius_records(self, **kwargs):
        """
        用于上传测试记录至 Genius 数据库
        :return:
        """
        # 需要事先修改记录的状态
        # self.update_records_status(status, kwargs)

        records = [c for _, c in self.get_records().items()]
        if len(records) == 0:
            raise Exception(f'Please ensure you have called add_record method! found {len(records)} record(s)')

        for i, r in enumerate(records):
            if not isinstance(r, CommonModel):
                raise lib.FailureException(f'type of {type(r)} is not CommonModel, please check it again!')
            log.info(f'{i + 1}/{len(records)} uploading -> {r}')
            # 后续可能会限制支持修改的字段！！！
            r.kwargs.update(kwargs)
            self._upload_genius_record(r)

    @staticmethod
    def _upload_genius_record(record: CommonModel):
        log.info('')
        log.info(f'/'.center(60, '/'))
        log.info(f'Genius DB'.center(60, '-'))
        log.info(f'    sn = {record.sn}')
        log.info(f'    pn = {record.pn}')
        log.info(f'  area = {record.area}')
        log.info(f'result = {record.status}')

        kwargs = record.kwargs
        # Do not change code here!
        for k, v in kwargs.items():
            # convert None to ''
            if v is None:
                kwargs[k] = ''
            else:
                kwargs[k] = str(v)

        # show additional params
        for k, v in kwargs.items():
            log.info(f'{k} = {v}')

        # def add_test_data(sernum, uuttype, area, container=None, result='S', **kwargs):
        lib.add_test_data(
            sernum=record.sn, uuttype=record.pn, area=record.area, container=helper.get_container_name(),
            result=record.status, **kwargs
        )
        log.info(f'upload to genius database successfully')

    def upload_mes_records(self):
        """
        上传 MES 测试记录
        """
        records = [c for _, c in self.get_records().items()]
        test_mode = lib.get_genius_mode()
        log.info(f'Test mode = [{test_mode}]')
        log.info(f'Start Time: {helper.get_start_time()}')

        status_mapping = {
            'P': 'PASS',
            'F': 'FAIL',
            'A': 'FAIL',
        }

        final_records = []

        for record in records:  # type: CommonModel
            if record.status not in status_mapping:
                log.info(f'skip upload to sfc, status: {record.status} not in {status_mapping}')
                continue

            # check upload fail or not
            if record.status == 'F':
                if not sfchelper.need_to_upload_fail(record.sn, record.area, fail_name=record.info):
                    log.debug('skip upload fail record!')
                    continue
                else:
                    log.debug('need to upload fail record!')

            mes_model = JuniperMESModel(
                SYSSERIALNO=record.sn,
                TESTDATE=helper.get_start_time(),
                EVENTNAME=record.area,
                STATUS=status_mapping[record.status],
                PART_NUMBER=record.pn,
                CM_ODM_PARTNUMBER=record.pn,
                SERIAL_NUMBER=record.sn,
                # 此项目由MES自动带出来
                PHASE="",
                PART_NUMBER_REVISION="",
                UNIQUE_TEST_ID="",
                TEST_START_TIMESTAMP=helper.get_start_time(),
                TEST_STEP=record.area,
                # 设定为None，由MES自行计算
                TEST_CYCLE_TEST_LOOP=None,
                CAPTURE_TIME=helper.get_local_datetime(),
                TEST_RESULT=status_mapping[record.status],
                FAILCODE=record.info,
                TEST_STATION_NUMBER=helper.get_container_name(),
                TEST_STATION_NAME=record.area,
                LOAD_DATE=helper.get_local_datetime(),
                FILE_NAME='Y',
                LASTEDITDT=helper.get_local_datetime(),
                LASTEDITBY=helper.get_operator_name(),
                TESTERNO=platform.node(),
                TATIME=helper.get_local_datetime(),
            )
            mes_model.update(**record.kwargs)
            final_records.append(mes_model)

        # FVN MES
        # 组装数据
        while True:
            try:
                sfchelper.update_r_test_juniper([fr.dumps() for fr in final_records])
            except Exception as e:
                log.error(f'upload test records to MES failed! -> {e}')
                if scanner.yes_or_enter_to_continue('Upload test records to MES failed! retry?') is False:
                    raise Exception(f'upload test records to MES failed! -> {e}')
                continue
            # OK
            break
        log.debug('upload to JNPR-MES successfully!')

    @staticmethod
    def put_cache_data(key: str, value: str):
        """
        对cache进行操作，cache是工站级别的共享对象，键和值都必须是字符串，不信可以试试用别的。
        """
        log.info(f'PUT [{key}] = [{value}]')
        lib.put_cache_data(key, value)

    @staticmethod
    def get_cache_data(key: str) -> str:
        """
        对cache进行操作，cache是工站级别的共享对象，键和值都必须是字符串，不信可以试试用别的。
        """
        data = lib.get_cache_data(key=key)
        log.info(f'GET [{key}] = [{data}]')
        return data

    @staticmethod
    def failure_exception(msg):
        """
        FailureException
        """
        return lib.FailureException(msg)

    @staticmethod
    def abort_exception(msg):
        """
        AbortException
        """
        return lib.AbortException(msg)

    @staticmethod
    def get_seq_logger() -> logging.Logger:
        return lib.get_seq_logger()

    @staticmethod
    def string_to_dict(buffer: str, sep=':'):
        result = {}
        for line in buffer.splitlines():
            try:
                pos = line.index(sep)
            except ValueError:
                pass
            else:
                result[line[: pos].strip()] = line[pos + len(sep):].strip()
        return result

    @staticmethod
    def check_item(name, expected, ptn, text):
        captured = re.search(ptn, text)
        if captured is None:
            log.error(f'not found: {name}')
            raise Exception(f'not found: {name}')
        captured = captured.group(1)
        if captured != expected:
            log.error(f'[Pass Criteria] {name}, capture: {captured}, expect: {expected}, result: FAIL')
            raise Exception(f'{name}, expected: {expected}, captured: {captured}. FAIL')
        else:
            log.debug(f'[Pass Criteria] {name}, capture: {captured}, expect: {expected}, result: PASS')


# INIT
helper = LibUtils()


class WrapConsole:

    def __init__(self, name, conn):
        self.name = name
        self.conn = conn

    def send(self, cmd, expectphrase=None, timeout=90):
        log.debug(f'[{self.name}] cmd = {cmd!r}, oath: {expectphrase!r}, timeout = {timeout!r}')
        return self.conn.send(cmd, expectphrase, timeout)

    def __getattr__(self, item):
        return getattr(self.conn, item)


def get_upload_path(filename=None, extension='.csv'):
    constant = lib.constant
    container = constant.CONTAINER_NAME

    try:
        mea_log = constant.MEASUREMENT_LOG_PATH.rstrip('/')
    except AttributeError:
        mea_log = constant.GEN_LOGS_MEA_PATH.rstrip('/')

    folder_full_path = '{}/{}/{}/{}/{}/'.format(
        mea_log,
        container.replace(':', '~'),
        constant.START_TIME.year,
        constant.START_TIME.month,
        constant.START_TIME.day
    )
    os.makedirs(folder_full_path, exist_ok=True)

    return '{}{}~{}~{}~{}{}'.format(
        folder_full_path,
        constant.LOG_TIME_STAMP,
        constant.MODE,
        container,
        filename or 'bpm2',
        extension,
    )


def upload_file_to_data_center(src):
    path = get_upload_path(filename=os.path.basename(src), extension='')
    shutil.copyfile(src, path)


def find_key_word_orderly(expected, buffer: str):
    if isinstance(expected, str):
        expected = expected,
    elif isinstance(expected, (tuple, list)):
        pass
    else:
        raise Exception(f'type of expected should be in (str, list, tuple), but you gave is {type(expected)}')

    if not isinstance(buffer, str):
        raise Exception(f'type of buffer should be str, but you gave is {type(buffer)}')

    for wanted in expected:
        try:
            wanted = str(wanted)
            index = buffer.index(wanted)
        except Exception as e:
            log.warning(f'not found {wanted} in buffer [{str(e)}]')
            log.warning(traceback.format_exc())
            raise
        buffer = buffer[index + len(wanted):]
        log.debug(f'found key word {wanted}')


def read_file(filename, raise_err=False) -> str:
    if os.path.exists(filename):
        with open(filename, 'r') as f:
            return f.read()
    else:
        if raise_err is False:
            return ''
        raise Exception(f'{filename} not exits')


def write_file(filename: str, data: str, mode=0o777, max_deep=0):
    """
    写文件的同时，修改文件权限
    """
    with open(filename, 'w') as f:
        f.write(data)
    if max_deep != 0:
        chmod_optimized(filename, mode=mode, max_deep=max_deep)


def chmod_optimized(filename: str, mode=0o777, max_deep=1):
    """
    change file mode
    :param filename:
    :param mode:
    :param max_deep:
    :return:
    """
    forbidden_dirs = os.listdir('/')
    filename = filename.rstrip('/')
    count = 1
    while count <= max_deep:
        dir_name = filename.lstrip('/')
        if dir_name == '' or dir_name in forbidden_dirs:
            log.warning(f'{filename} not allowed to change mode')
            return False
        else:
            os.chmod(filename, mode=mode)
            log.debug('change {} -> {}'.format(filename, mode))
        filename = os.path.split(filename)[0]
        count += 1
    return True


def create_dirs(path: str, mode=0o777, max_deep=1):
    os.makedirs(path, exist_ok=True)
    # it is safe here
    if max_deep is not None:
        chmod_optimized(path, mode=mode, max_deep=max_deep)


def get_file_md5(path):
    """
    by mont
    :param path:
    :return:
    """
    import hashlib

    if not os.path.exists(path):
        return

    with open(path, 'rb') as rf:
        data = rf.read()

    return hashlib.md5(data).hexdigest()


def get_datetime_by_time_zone(time_zone='America/Los_Angeles', datetime_now=None, fmt=const.DEFAULT_TIME_FMT):
    """
    返回指定时区的时间，已经考虑了夏令时和冬令时。默认返回 Cisco 所在地区的日期时间。
    :param time_zone:
    :param datetime_now: 若提供了该值，则必须是 datetime，需带上时区信息
    :param fmt:
    :return:
    """
    tz = pytz.timezone(time_zone)
    now = datetime.datetime.now(tz=pytz.timezone(const.DJ_TIMEZONE)) if datetime_now is None else datetime_now
    return now.astimezone(tz).strftime(fmt)


def get_local_datetime(datetime_now=None, fmt=const.DEFAULT_TIME_FMT):
    """
    获取本地时间
    :param datetime_now:
    :param fmt:
    :return:
    """
    return get_datetime_by_time_zone(time_zone=const.LOCAL_TIMEZONE, datetime_now=datetime_now, fmt=fmt)
