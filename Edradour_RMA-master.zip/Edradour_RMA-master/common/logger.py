import logging

from gen.libs import lib


log = lib.get_seq_logger()  # type: logging.Logger


def info(msg, name=None):
    name = f'[{name}] ' if name else ''
    return log.info(f'{name}{msg}')


def debug(msg, name=None):
    name = f'[{name}] ' if name else ''
    return log.debug(f'{name}{msg}')


def warning(msg, name=None):
    name = f'[{name}] ' if name else ''
    return log.warning(f'{name}{msg}')


warn = warning


def error(msg, name=None):
    name = f'[{name}] ' if name else ''
    return log.error(f'{name}{msg}')
