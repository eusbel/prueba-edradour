import time
from .telnet import Telnet


class APC(Telnet):
    username = 'apc'
    password = 'admin2026'
    # prompt = '] #'
    prompt = '>'

    def __init__(self, name='APC', suffix='\r', conn_str=None, pop=True):
        super(APC, self).__init__(name, suffix=suffix, conn_str=conn_str, pop=pop)

    def do_connect(self, conn_str=None, close_before_open=False):
        """
        special
        """
        if (conn_str or self.conn_str) is None:
            raise Exception('please ensure you have provided conn str!!!')

        super().do_connect(conn_str=conn_str, close_before_open=close_before_open)
        self.telnet_ip()
        time.sleep(0.5)

    def login(self):
        self.open()
        self.telnet_ip()
        self.waitfor('User Name')
        self.send_wise(self.username, 'Password')
        self.send_wise(self.password, [self.prompt, ']$'], visible=False)
        if 'Authentication failed!' in self.buffer:
            raise Exception('PDU username or password incorrect!')

    def ssh_login(self):
        self.open()
        self.ssh_ip(user_name=self.username, password=self.password)

    def do_disconnect(self):
        super().ssh_do_disconnect()
        self.close()

    def power_on(self, ports):
        if isinstance(ports, (str, int)):
            ports = (ports,)
        ports = ','.join(ports)
        self.ssh_login()
        self.send_wise(f'olOn {ports}', self.prompt)
        self.do_disconnect()

    def power_off(self, ports):
        if isinstance(ports, (str, int)):
            ports = (ports,)
        ports = ','.join(ports)
        self.ssh_login()
        self.send_wise(f'olOff {ports}', self.prompt)
        self.do_disconnect()

    def power_cycle(self, ports, interval=3):
        if isinstance(ports, (str, int)):
            ports = (ports,)
        ports = ','.join(ports)
        self.ssh_login()
        self.send_wise(f'olOff {ports}', self.prompt)
        self.do_disconnect()
        time.sleep(interval)
        self.ssh_login()
        self.send_wise(f'olOn {ports}', self.prompt)
        self.do_disconnect()
