import time
from .telnet import Telnet


class SW(Telnet):

    def __init__(self, name='SW', suffix='\r', conn_str=None, pop=True):
        super(SW, self).__init__(name=name, suffix=suffix, conn_str=conn_str, pop=pop)

    def do_connect(self, conn_str=None, close_before_open=True):
        super().do_connect(conn_str=conn_str, close_before_open=close_before_open)
        self.telnet_ip(self.ip)

    # @lib.fifo_locking(name='sw_locking', wait_timeout=900)
    def power_on(self, speed='1000'):
        self.do_connect()
        self.__login_sw()
        self.send('conf t', expectphrase='(config)#')
        self.send('int {}'.format(self.port), expectphrase='(config-if)#')
        self.send(f'speed {speed}', expectphrase='(config-if)#')
        self.send('shut', expectphrase='(config-if)#')
        self.send('no shut', expectphrase='(config-if)#')
        self.send('power inline never', expectphrase='(config-if)#')
        self.send('power inline auto', expectphrase='(config-if)#')
        self.do_disconnect()
        self.logger('power on {} ok'.format(self.port))

    # @fifo_locking_pool(name='sw', size=8, timeout=600)
    # @lib.fifo_locking(name='sw_locking', wait_timeout=900)
    def power_off(self, shut_down=True):
        # sw_conn_str = lib.get_configuration_data().get('sw_conn_str')
        # port = lib.get_configuration_data().get('sw_port')
        self.do_connect()
        self.__login_sw()
        self.send('conf t', expectphrase='(config)#')
        self.send('int {}'.format(self.port), expectphrase='(config-if)#')
        self.send('power inline never', expectphrase='(config-if)#')
        if shut_down is True:
            self.send('shut', expectphrase='(config-if)#')
        self.do_disconnect()
        self.logger('power off {} ok'.format(self.port))

    def __login_sw(self):
        time.sleep(0.5)
        self.send_enter(expectphrase=['Password:', ']$'])
        self.send('c', expectphrase='>')
        self.send('en', expectphrase='Password:')
        self.send('c', expectphrase='#')
