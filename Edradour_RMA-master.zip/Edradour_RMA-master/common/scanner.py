from .const import RE_SN_FORMAT
from . import logger
from gen.libs import lib
import re
from typing import Mapping


def ask_question(question, timeout=7200, answers=None, image=None, visible=True,
                 privilege=False, multiple=False, upper_and_strip=True) -> str:
    """
    this function will strip and upper result
    :param question:
    :param timeout:
    :param answers:
    :param image:
    :param visible:
    :param privilege:
    :param multiple:
    :param upper_and_strip: 只有当返回值是 str 类型时候才有效
    :return:
    """
    if isinstance(question, str):
        for qs in question.splitlines():
            logger.debug(qs)
    elif isinstance(question, (list, tuple)):
        for qs in question:
            logger.debug(qs)

    # ans = lib.ask_question(
    #     question=question, timeout=timeout, answers=answers, image=image,
    #     visible=visible, privilege=privilege, multiple=multiple
    # )
    # 使用 ask_question2
    ans = lib.ask_question2(question=question, timeout=timeout, answers=answers, image=image, visible=visible,
                            privilege=privilege)
    logger.debug(f'OP Scan info ---> {ans}')
    if upper_and_strip is True:
        if isinstance(ans, str):
            ans = ans.strip().upper()
    if ans in ['?S', '?STOP']:
        raise Exception(f'Scanned -> {ans}, Stop Test')
    return ans

def ask_question_no_print(question, timeout=7200, answers=None, image=None, visible=True,
                 privilege=False, multiple=False, upper_and_strip=True) -> str:
    """
    this function will strip and upper result
    :param question:
    :param timeout:
    :param answers:
    :param image:
    :param visible:
    :param privilege:
    :param multiple:
    :param upper_and_strip: 只有当返回值是 str 类型时候才有效
    :return:
    """
    if isinstance(question, str):
        for qs in question.splitlines():
            logger.debug(qs)
    elif isinstance(question, (list, tuple)):
        for qs in question:
            logger.debug(qs)

    # ans = lib.ask_question(
    #     question=question, timeout=timeout, answers=answers, image=image,
    #     visible=visible, privilege=privilege, multiple=multiple
    # )
    # 使用 ask_question2
    ans = lib.ask_question2(question=question, timeout=timeout, answers=answers, image=image, visible=visible,
                            privilege=privilege)
    # logger.debug(f'OP Scan info ---> {ans}')
    if upper_and_strip is True:
        if isinstance(ans, str):
            ans = ans.strip().upper()
    if ans in ['?S', '?STOP']:
        raise Exception(f'Scanned -> {ans}, Stop Test')
    return ans


def scan_serial_number(question='Please Scan SN, like FOC...', timeout=7200, retry=3):
    pattern = '^{}$'.format(RE_SN_FORMAT)
    for i in range(retry):
        ans = ask_question(question=question, timeout=timeout)
        logger.debug('scan times = [{}], scanned = [{}]'.format(i + 1, ans))
        r = re.search(pattern, ans)
        if r is None:
            logger.debug(f'{ans} cant match {pattern}, rescan..', 'warn')
            continue
        logger.debug(f'[{ans}] is the match.')
        return ans
    else:
        raise Exception('SCAN SERIAL NUMBER FAILED')


def scan_part_number(question='Please Scan PN(Part Number)', accept_list=None, retry=3, timeout=7200):
    if accept_list is None:
        logger.debug(f'accept_list = [{accept_list}], please provided accept list..', 'warn')
        raise Exception('accept_list is not provided')

    logger.debug(f'acceptable: {accept_list}')
    for i in range(retry):
        ans = ask_question(question=question, timeout=timeout)
        logger.debug('scan time(s) = [{}], scanned = [{}]'.format(i + 1, ans))
        for accept in accept_list:
            if accept in ans:
                logger.debug(f'[{ans}] is the match.')
                return str(ans)
        logger.debug(f'[{ans}] not in {accept_list}, rescan...', 'warn')
    else:
        raise Exception('SCAN PART NUMBER FAILED')


def scan_apollo_cell_number(question='Please Scan Cell Number...', retry=3, timeout=7200):
    cell_number = lib.get_container_name()[-2:]
    logger.debug(f'expected input = UUT x-x:{cell_number}, cell number = {cell_number}')

    for i in range(retry):
        ans = ask_question(question, timeout=timeout)
        logger.debug('scan time(s) = [{}], scanned = [{}]'.format(i + 1, ans))
        # UUT 1-4:01
        res = re.search(r'UUT\s+\d+-\d+:(\d+)', ans)
        if res is None:
            continue
        res = res.group(1)
        if res == cell_number or int(res) == int(cell_number):
            break
    else:
        raise Exception('Scan CELL NUMBER FAILED')


def scan_y_to_continue(question='Please Scan Y ...', *, timeout=7200, retry=3, image=None):
    for i in range(retry):
        ans = ask_question(question, timeout=timeout, image=image)
        logger.debug('scan times = [{}], scanned = [{}]'.format(i + 1, ans))

        if ans == 'Y':
            logger.debug('scanned = Y')
            return
        logger.debug(f'[{ans}] != Y, rescan..')

    else:
        raise Exception('SCAN Y TO CONTINUE FAILED')


def scan_y_or_enter_to_continue(question='Please Scan Y(es)/ Default -> Enter ...', timeout=7200, retry=3, image=None):
    """
    输入 Y/YES 或者直接回车然后重试
    :param question:
    :param timeout:
    :param retry:
    :param image:
    :return: True 重试， False 不重试
    """
    for i in range(retry):
        ans = ask_question(question.splitlines(), timeout=timeout, image=image, upper_and_strip=True)
        logger.debug('scan times = [{}], scanned = [{}]'.format(i + 1, ans))

        if ans in ('Y', 'YES', ''):
            return True
        if ans in ('N', 'NO'):
            return False
        logger.debug(f'[{ans}] is bad, rescan..')
    else:
        raise Exception('SCAN Y TO CONTINUE FAILED')


yes_or_enter_to_continue = scan_y_or_enter_to_continue


def select_the_right_choice(question, choices, right_choice, retry=3, image=None, ignore_case=True):
    """
    从众多选择项中选择一个。适配转码。
        若 choices 是 None 则匹配用户输入和期待值是否一致，此种情况下不会抛出超出最大次数异常
    :param question:
    :param choices:
    :param right_choice:
    :param retry:
    :param image:
    :param ignore_case: 忽略大小写
    :return:
    """

    if right_choice is None:
        raise Exception(f'please ensure the right choice is not None')
    question = question.splitlines()
    if choices:
        for i in range(retry):
            ans = ask_question(question, image=image, upper_and_strip=False).strip()
            if ignore_case is True:
                ans = ans.strip().upper()
                choices = [str(c).strip().upper() for c in choices]
                right_choice = str(right_choice).strip().upper()
            if ans not in choices:
                continue
            else:
                if isinstance(choices, Mapping):
                    final = choices[ans]
                else:
                    final = ans
                break
        else:
            raise Exception(f'scan failed, exceed {retry} time(s).')

        return final == right_choice
    else:
        for i in range(retry):
            ans = ask_question(question, image=image, upper_and_strip=False).strip()
            if ans == right_choice:
                return True
        else:
            logger.error(f'scan failed, exceed {retry} time(s).')
            return False


def get_right_answer(question, answers, right_answer, retry=5, image=None):
    for i in range(retry):
        ans = ask_question(question=question, answers=answers, image=image, upper_and_strip=False)
        if ans != right_answer:
            continue
        break
    else:
        raise Exception(f'get right answer: {right_answer} failed! exceed max retry.')
