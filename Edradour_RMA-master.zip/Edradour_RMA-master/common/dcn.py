import time
import traceback
from .fields import StrField, IntField, BaseField
from .scanner import select_the_right_choice, yes_or_enter_to_continue, ask_question_no_print
from ...top import top
from .utils import helper
from . import sfchelper
from .logger import log
import pandas as pd
from functools import wraps
import re
import os
import xlrd
from datetime import datetime

# 显示所有列（防止列被省略）
pd.set_option('display.max_columns', None)

# 显示所有行（如果你真的需要全部行）
pd.set_option('display.max_rows', None)

# 显示每列内容的宽度足够大
pd.set_option('display.max_colwidth', None)

# 设置窗口宽度（防止折行）
pd.set_option('display.width', 1000)


class DCN(top.TOP):
    sernum = StrField()
    uuttype = StrField()
    mac_address = StrField()
    mac_block_size = IntField()
    current_version = StrField()
    test_summary = []
    sku_label = StrField()
    pn_label = StrField()
    mac_label = StrField()
    current_station = StrField()
    current_pn_df = None

    sys_mac = BaseField('')
    sys_mac_size = BaseField('')
    mes_mac = BaseField('')
    mes_mac_size = BaseField('')

    machine = StrField()
    container = StrField()

    # A abort
    # 该值为 None 的表示非Abort
    abort_flag = None

    def first_step_of_pre_seq(self):
        self.check_operator()
        self.show_code_history()

    @staticmethod
    def check_operator():
        op_name = helper.get_operator_name()
        if op_name.upper() in ['GENIUS', 'ENGINEER']:
            helper.quick_set(f'{op_name.upper()} IS NOT ALLOWED')
            raise Exception('can not use default account to do test! please use your own account!')

    def first_step_of_main_seq(self):
        pass

    @staticmethod
    def debug(msg):
        return log.debug(f'[DCN] {msg}')

    @staticmethod
    def info(msg):
        return log.info(f'[DCN] {msg}')

    @staticmethod
    def warning(msg):
        return log.warning(f'[DCN] {msg}')

    @staticmethod
    def error(msg):
        return log.error(f'[DCN] {msg}')

    @staticmethod
    def check_all_led_off():
        image = 'Edradour/images/led-all-off.jpg'
        if yes_or_enter_to_continue(
            question='1. Please only plugin Power cable! 2. Are all leds off, as shown in the picture?\n'
                     '1. Chỉ cần cắm dây nguồn 2.Tất cả đèn LED đều tắt như hình minh họa phải không?',
            image=image,
        ) is False:
            raise Exception('led test failed!')
        log.debug('operator ensure all led are off!')

    @staticmethod
    def check_power_console():
        if yes_or_enter_to_continue(
                question='(Pre Check Step 1)\n'
                        'Vui lòng xác nhận xem nguồn điện và cáp mạng đã được kết nối đúng cách chưa\n'
                         'Please confirm whether the power supply and cables are connected properly',
                image='Edradour/images/check_power_console.png',
        ) is False:
            raise Exception('OP Stop Test!')

    def check_program_version(self):
        self.check_latest_repo_version(self.product_name)

    def go_to_failure(self, msg, testinfo=''):
        raise helper.FailureException(msg)

    def go_to_abort(self, msg, testinfo=''):
        raise helper.AbortException(msg)

    def send(self, cmd, expectphrase='', timeout=60, conn=None, retry=0, echo=False, size=1, do_abort=False):
        """ Wrapped send/sende, if send raise timeout exception, will involve self.go_to_failure

        :param conn: the connection name, default is self.uut.
        :param cmd:
        :param expectphrase:
        :param timeout:
        :param retry: add retry for send/sende
        :param echo: if True, will involve sende.
        :param size: it is sendesize, only work when echo is True.
        :param do_abort:
        :return:
        """
        if not conn:
            conn = self.uut

        while retry + 1:
            try:
                if echo:
                    conn.sende(cmd, expectphrase=expectphrase, timeout=timeout, sendesize=size)
                else:
                    conn.send(cmd, expectphrase=expectphrase, timeout=timeout)
                break
            except Exception as e:
                log.warning(e)
                msg = 'send [{}] meet timeout'.format(cmd)
                log.warning(msg)
                if retry:
                    msg += '[{}] retry'.format(retry)
                    log.warning(msg)
                    retry -= 1
                    continue
                if do_abort:
                    self.go_to_abort(msg)
                else:
                    self.go_to_failure(msg)
        return helper.PASS

    @staticmethod
    def area_check_mes(sn, area):
        """
        使用 MES 的测试记录做 area check，只检查传入工站的最后一笔记录是否是 PASS
        :param sn:
        :param area:
        :return:
        """
        if not sn or not area:
            raise Exception(f'please ensure both sn({sn}) and area({area} are valid!')
        records = sfchelper.get_mes_test_records(sn, area)
        df = pd.DataFrame(records)
        log.debug(f'records: {len(df)}')
        if len(df) == 0:
            raise Exception(f'no records were found: {sn} - {area}')
        last_record = df.iloc[-1]
        log.debug(f'{sn} - {area}, last record: {last_record.to_dict()}')
        if last_record['STATUS'].upper() != 'PASS':
            raise Exception(f'sn: {sn} - {area} is not PASS!, it is {last_record["STATUS"]}')
        log.debug(f'{sn} - {area} area check pass!')
        return last_record.to_dict()

    @staticmethod
    def check_mes_fail(sn, area):
        """
        使用 MES 的测试记录做 area check，只检查传入工站的最后一笔记录是否是 PASS
        :param sn:
        :param area:
        :return:
        """
        if not sn or not area:
            raise Exception(f'please ensure both sn({sn}) and area({area} are valid!')
        records = sfchelper.get_mes_test_records(sn, area)
        df = pd.DataFrame(records)
        log.debug(f'records: {len(df)}')
        if len(df) == 0:
            log.debug(f'no records were found: {sn} - {area}')
            return False
        last_record = df.iloc[-1]
        log.debug(f'{sn} - {area}, last record: {last_record.to_dict()}')
        if last_record['STATUS'].upper() == 'PASS':
            log.debug(f'sn: {sn} - {area} is PASS!, it is {last_record["STATUS"]}')
            return False
        else:
            log.debug(f'{sn} - {area} has fail record')
            return True

    def area_check(self, sn: str, area: str, month=3):
        """
        使用 Genius 的测试记录，检查某个工站最后一笔 PROD记录 是不是 PASS，是则返回 最后一条记录，否则就抛出异常
        :param sn:
        :param area:
        :param month:
        :return:
        """
        if not sn:
            raise Exception(f'please ensure sn is valid: {sn}')
        if not area:
            raise Exception(f'please ensure area is valid: {area}')

        log.debug(f'{sn} - {area} - {month}')
        records = self.get_all_test_data(sernum=sn, month=month)
        df = pd.DataFrame(records)
        log.debug(f'{sn} - {area} - {month}: total {len(df)} records')
        if len(df) == 0:
            raise Exception(f'{sn} - {area} - {month}[month], no records were found!')
        # check sn again. check area, mode == 'PROD'
        mode = helper.PROD
        df = df.loc[(df.sernum == sn) & (df.area == area) & (df['mode'] == mode), :]  # type: pd.DataFrame
        # df.sort_values(by='recttime', inplace=True)
        # last record
        last_record = df.iloc[-1]
        log.debug(f'Last Record: {last_record.to_dict()}')
        if last_record.result == 'P':
            log.debug(f'{sn} - {area} - {mode} - {month} month(s): area check pass')
            return last_record.to_dict()
        else:
            log.error(f'{sn} - {area} - {mode} - {month} month(s): area check failed')
            raise Exception(f'the last record of [{sn} - {area} - {mode} ] is not P, '
                            f'it is {last_record.result}, failed!')

    @staticmethod
    def mes_check_event(sn, area):
        """
        PROD mode performs station checks, and if the check fails, it will result in a FAIL.
        DEBUG mode also performs station checks, but it will not result in a FAIL.
        """
        log.debug(f'[{sn}] Check test station: {area}')
        try:
            next_station = sfchelper.get_next_station(sn)
        except Exception as e:
            log.error(f'Get next station failed! -> {e}')
            helper.quick_set('Get next station failed')
            raise

        log.debug(f'[{sn}] Current test station: {area}, next station: {next_station}')
        if area != next_station:
            msg = f'[{sn}] check event failed! Please test: {next_station}'
            log.error(msg)
            helper.set_display1(sn)
            helper.set_test_name(f'NEXT STATION - {next_station}')
            if helper.mode == helper.PROD:
                log.error(f'PROD mode. Stop testing!!')
                raise Exception(msg)
            else:
                log.debug('DEBUG mode. SKIP...')
                return helper.SKIP
        else:
            log.debug(f'[{sn}] check event pass! Testing {area}...')
            return helper.PASS

    @staticmethod
    def genius_check_event(sn, current_station):
        """
        PROD  模式做过站检查，检查不通过会 FAIL
        DEBUG 模式也做过站检查，但是不会 FAIL
        """
        last_status = sfchelper.check_sn_pass_station(sn=sn, station=current_station)
        log.debug(f"Check {sn} last station current Genius server record is {last_status}")
        if not last_status:
            msg = f'[{sn}] check Genius event failed!'
            log.error(msg)
            helper.set_display1(f'{sn}')
            helper.set_display2(f'Genius not PASS {current_station}')
            helper.set_display3(f'Check Genius Event FAIL')
            if helper.mode == helper.PROD:
                log.error(f'PROD mode. Stop testing!!')
                raise Exception(msg)
            else:
                log.debug('DEBUG mode. SKIP...')
                return helper.SKIP
        else:
            if last_status[0] != "P" and last_status[3] != "PROD":
                msg = f'[{sn}] check Genius event failed!'
                log.error(msg)
                helper.set_display1(f'{sn}')
                helper.set_display2(f'Genius not PASS {current_station}')
                helper.set_display3(f'Check Genius Event FAIL')
                if helper.mode == helper.PROD:
                    log.error(f'PROD mode. Stop testing!!')
                    raise Exception(msg)
                else:
                    log.debug('DEBUG mode. SKIP...')
                    return helper.SKIP
            else:
                log.debug(f'[{sn}] check Genius event pass!')
                return helper.PASS

    def check_latest_repo_version(self, repo_name):
        """
        DEBUG 模式不需要检查代码版本。
        PROD  模式检查是否是最新的版本，否则就报错！
        """
        log.debug(f'check code version for {repo_name}...')
        if helper.mode == helper.DEBUG:
            log.debug(f'this is {helper.mode} mode, code version check is useless!! SKIP!')
        elif helper.mode == helper.PROD:
            self.current_version, latest_version = helper.get_prod_version(repo_name)
            log.debug(f'{repo_name} current version: {self.current_version}, the latest version: {latest_version}')
            if self.current_version != latest_version:
                raise Exception(f'{helper.mode} mode, this is not the latest code version! FAIL!')
            else:
                log.debug(f'{helper.mode} mode, this is the latest code version. PASS!')
        else:
            raise Exception(f'unknown test mode: {helper.mode}. code version check failed!')
        return self.current_version

    def get_genius_records_asc(self, sn, month=3) -> pd.DataFrame:
        """
        返回的数据是一个DataFrame, 按照开始测试时间顺序从小到大排列的
        """
        # 这个方法获取到的数据本身就是按照时间顺序由小到大排列的
        records = self.get_all_test_data(sernum=sn, month=month)
        df = pd.DataFrame(records)
        # df.sort_values(by='recttime', inplace=True)
        return df

    def quick_set(self, text, test_name=None):
        """
        同时设定 Display3 和 test_step_name
        :param text:
        :param test_name:
        :return:
        """
        text = str(text).strip()
        self.set_display3(text)
        self.set_test_name(test_name or text)

    @staticmethod
    def add_genius_records(**kwargs):
        helper.upload_genius_records(**kwargs)

    @staticmethod
    def add_mes_records():
        """
        A S 记录不上传 MES, DEBUG 不上传记录
        :return:
        """
        if helper.sequence_type == helper.PRE_SEQ:
            log.debug('skip upload S to MES..')
            return helper.SKIP
        elif helper.mode == helper.DEBUG:
            log.debug('DEBUG mode, skip upload to MES..')
            return helper.SKIP
        elif helper.abort_flag is True:
            log.debug('skip upload A to MES..')
            return helper.SKIP

        helper.upload_mes_records()

    def update_test_status(self):
        """
        若是 PRE-SEQ 上传 S 记录
        若是 MAIN-SEQ
            若是一切正常上传 P 记录
            若是有   abort_message 上传 A 记录
            其他情况 上传 F 记录
        :return:
        """
        if helper.sequence_type == helper.PRE_SEQ:
            status = 'S'
        elif helper.everything_goes_well:
            status = 'P'
        elif helper.abort_flag is True:
            status = 'A'
        else:
            status = 'F'
        self.debug(f'SET TEST STATUS: {status}')
        helper.update_records_status(status)

    def upload_test_records(self, **kwargs):
        self.update_test_status()
        helper.quick_set('Upload to Genius')
        self.add_genius_records(**kwargs)
        helper.quick_set('Upload to MES')
        self.add_mes_records()

    def sleep_time(self, seconds):
        self.debug(f'Sleep {seconds} second(s)')
        time.sleep(seconds)

    @staticmethod
    def show_code_history(filename='history.txt'):
        """
        打印历史记录
        """
        log.debug(">> Show script version history:")
        log.debug("=" * 80)
        file = helper.get_full_path(filename)
        with open(file) as f:
            lines = f.read()
        # 用正则找出所有的版本块，以版本号开头（v0.x.xx_日期）
        blocks = re.split(r'(?=v\d+\.\d+\.\d+_\d+)', lines)

        # 前面 split 会在开头留个空字符串，要过滤掉
        blocks = [b.strip() for b in blocks if b.strip()]

        # 打印前三个版本信息
        for block in blocks[:10]:
            lns = block.split("\n")
            [log.debug(ln) for ln in lns]
            log.debug("=" * 80)  # 分隔线可选

    def timeit(self, allow_nested=False):
        """
        装饰器，统计函数运行时间，支持嵌套层数限制
        """
        def decorator(func):
            @wraps(func)
            def wrapper(instance, *args, **kwargs):
                # 检查是否允许嵌套计时
                if getattr(instance, "_is_being_called", False) and not allow_nested:
                    return func(instance, *args, **kwargs)
                setattr(instance, "_is_being_called", not allow_nested)

                start_time = time.time()
                step_name = helper.get_test_step_name()
                try:
                    func(instance, *args, **kwargs)
                    elapsed_time = round(time.time() - start_time, 2)
                    self.test_summary.append([step_name, 'PASS', elapsed_time])
                except:
                    elapsed_time = round(time.time() - start_time, 2)
                    self.test_summary.append([step_name, 'FAIL', elapsed_time])
                    raise Exception(traceback.format_exc())
                finally:
                    # 调用结束，安全移除标记
                    if hasattr(instance, "_is_being_called"):
                        delattr(instance, "_is_being_called")
            return wrapper
        return decorator

    def print_test_summary(self):
        """
        打印测试Summary，
        Sample：
        2024-11-22 17:40:16,624 INFO     dcn      Line:296 : -------------------------------------------------------------------------------------
        2024-11-22 17:40:16,646 INFO     dcn      Line:297 : Test Item                                                     Status       Time Taken
        2024-11-22 17:40:16,667 INFO     dcn      Line:302 : -------------------------------------------------------------------------------------
        2024-11-22 17:40:16,689 INFO     dcn      Line:305 : Scan UUT Label                                                 PASS              3.97
        2024-11-22 17:40:16,711 INFO     dcn      Line:305 : Check MES Event                                                PASS              0.41
        2024-11-22 17:40:16,732 INFO     dcn      Line:305 : Query MES MAC                                                  PASS              0.23
        2024-11-22 17:40:16,765 INFO     dcn      Line:305 : Read Config                                                    PASS               0.0
        2024-11-22 17:40:16,790 INFO     dcn      Line:305 : Upload Start Records                                           PASS              1.69
        2024-11-22 17:40:16,810 INFO     dcn      Line:305 : Init Connections                                               PASS              0.05
        2024-11-22 17:40:16,832 INFO     dcn      Line:305 : Get UUT Console                                                PASS              3.06
        2024-11-22 17:40:16,855 INFO     dcn      Line:305 : Power Cycle Check JUNOS Boot                                   PASS              2.02
        2024-11-22 17:40:16,877 INFO     dcn      Line:305 : Enter Cli                                                      PASS             10.02
        2024-11-22 17:40:16,898 INFO     dcn      Line:305 : Check JUNOS Version                                            PASS              3.06
        2024-11-22 17:40:16,920 INFO     dcn      Line:305 : Check Chassis Hardware                                         PASS              5.06
        2024-11-22 17:40:16,941 INFO     dcn      Line:305 : Check Chassis Firmware Detail                                  PASS              9.05
        2024-11-22 17:40:16,963 INFO     dcn      Line:305 : Request System Halt                                            PASS              2.02
        2024-11-22 17:40:16,985 INFO     dcn      Line:305 : Close All Connections                                          PASS               1.6
        2024-11-22 17:40:17,007 INFO     dcn      Line:305 : Upload Test Records                                            PASS               1.2
        2024-11-22 17:40:17,030 INFO     dcn      Line:314 : Total                                                          PASS             43.44
        2024-11-22 17:40:17,053 INFO     dcn      Line:319 : -------------------------------------------------------------------------------------
        """

        test_results = self.test_summary
        # 定义列宽
        col_widths = [60, 10, 15]  # 设置每列的宽度
        header = ["Test Item", "Status", "Time Taken"]
        log.info("-" * sum(col_widths))
        log.info(
            header[0].ljust(col_widths[0]) +
            header[1].center(col_widths[1]) +
            header[2].rjust(col_widths[2])
        )
        log.info("-" * sum(col_widths))

        for test_item, status, time_taken in test_results:
            log.info(
                test_item.ljust(col_widths[0]) +
                status.center(col_widths[1]) +
                f"{time_taken}".rjust(col_widths[2])
            )

        fail_rows = list(filter(lambda row: len(row) > 1 and row[1] == "FAIL", test_results))
        total_time = round(sum(row[2] for row in test_results if len(row) > 2), 2)
        total_status = 'FAIL' if fail_rows else 'PASS'
        log.info(
            "Total".ljust(col_widths[0]) +
            total_status.center(col_widths[1]) +
            f"{total_time}".rjust(col_widths[2])
        )
        log.info("-" * sum(col_widths))

    def check_label(self, sn):
        data_label = sfchelper.get_kp_info_from_mes(sn=sn)
        sku_data = next(
            (x['VALUE'] for x in data_label
             if x.get('VALUE') and re.match(r'^EX4000-[A-Z0-9-]+ REV [A-Z]$', x['VALUE'])),
            'NOT_FOUND'
        )
        if sku_data == "NOT_FOUND":
            raise Exception("Not found SKU data from MES KP where VALUE like '^EX4000-[A-Z0-9-]+ REV [A-Z]$'")

        pn_data = next(
            (x['VALUE'] for x in data_label
             #KP PN Validation
             if x.get('VALUE') and x['STATION'] == "CLAIM_CODE_PRINT"
             and re.match(r'^650-\d{6} REV [A-Z0-9]{1,2}$', x['VALUE'])),
            'NOT_FOUND'
        )
        if pn_data == "NOT_FOUND":
            raise Exception("No Encontrado PN data from MES KP where VALUE like '^650-\d{6} REV [A-Z0-9]{1,2}$'")

        mac_data, _ = sfchelper.get_mac_address_from_mes(wsn=self.sernum)
        if mac_data is None:
            helper.quick_set('NO MAC FROM MES')
            raise Exception('no MAC from MES!!!')
        # check control file
        rev = pn_data.split('REV')[-1].strip()
        pn = pn_data.split('REV')[0].strip()
        sku = sku_data.split('REV')[0].strip()
        if '-TAA' in sku:
            sku = sku.split('-TAA')[0]

        sku_rev = sku_data.split('REV')[-1].strip()

        pn_df = self.get_control_file_data(pn)
        pn_df_str = pn_df.iloc[:, :7].to_string(index=False)  # 不显示行号
        # 手动插入列分隔线
        lines = pn_df_str.split('\n')
        split_lines = [" | ".join(line.strip().split()) for line in lines]
        log.debug(f"Get PN data is:")
        log.debug(f"---------------------------------")
        for line in split_lines:
            log.debug(f"{line}")
        log.debug(f"---------------------------------")
        control_rev = pn_df["Assembly_Rev"].tolist()
        self.current_pn_df = pn_df[pn_df["Assembly_Rev"] == int(rev)]
        # log.debug(self.current_pn_df)
        control_sku = pn_df["SKU"].tolist()
        control_sku_rev = pn_df["SKU_Rev"].tolist()

        if sku not in control_sku:
            raise Exception(f"MES SKU info is {sku} not match control file SKU: {control_sku}")
        if sku_rev not in control_sku_rev:
            raise Exception(f"MES SKU rev info is {sku_rev} not match control file SKU rev: {control_sku_rev}")

        # ans = helper.ask_question(question='Please scan SKU label. 请扫描标签。 Quét thẻ SKU', image='Edradour/images/scan_sku.png')
        ans = helper.ask_question(question='Por favor escanee la etiqueta SKU (Modelo)', image='Edradour/images/scan_sku.png')
        while True:
            if ans.upper().replace(' ', '') != sku_data.replace(' ', ''):
                # msg = f"Scan SKU label:{ans} not match MES data, Please try again!"
                msg = f"La etiqueta SKU escaneada: {ans} no coincide con los datos del MES. ¡Por favor intente nuevamente!"
                ans = helper.ask_question(msg, image='Edradour/images/scan_sku.png')
            else:
                self.sku_label = sku_data
                # log.debug(f"SKU name get from label is {sku}, SKU name get from MES is {sku}, SKU name get from control file is {control_sku}, Match")
                # log.debug(f"SKU REV get from label is {sku_rev}, SKU REV get from MES is {sku_rev}, SKU REV get from control file is {control_sku_rev}, Match")
                break
        # ans = helper.ask_question(question='Please scan PN label. 请扫描标签。 Quét thẻ PN', image='Edradour/images/scan_pn.png')
        ans = helper.ask_question(question='Por favor escanee la etiqueta PN (Numero De Parte)', image='Edradour/images/scan_pn.png')
        while True:
            if ans.upper().replace(' ', '') != pn_data.replace(' ', ''):
                # msg = f"Scan PN label:{ans} not match MES data, Please try again!"
                msg = f"La etiqueta PN (Numero De Parte) escaneada: {ans} no coincide con los datos del MES. ¡Por favor intente nuevamente!"
                ans = helper.ask_question(msg, image='Edradour/images/scan_pn.png')
            else:
                self.pn_label = pn_data
                # log.debug(f"PN info get from label is {pn}, get from MES is {pn}, Match")
                # log.debug(f"{pn} Assembly_Rev get from label is {rev}, {pn} Assembly_Rev get from MES is {rev}, {pn} Assembly_Rev get from control file is {control_rev}, Match")
                break
        # ans = helper.ask_question(question='Please scan MAC label. 请扫描标签。 Quét thẻ MAC', image='Edradour/images/scan_mac.png')
        ans = helper.ask_question(question='Por favor escanee la etiqueta MAC', image='Edradour/images/scan_mac.png')
        while True:
            if ans.upper().replace(' ', '') != mac_data.replace(' ', ''):
                # msg = f"Scan MAC label:{ans} not match MES data, Please try again!"
                msg = f"La etiqueta MAC escaneada: {ans} no coincide con los datos del MES. ¡Por favor intente nuevamente!"
                ans = helper.ask_question(msg, image='Edradour/images/scan_mac.png')
            else:
                self.mac_label = mac_data.replace(' ', '')
                # log.debug(f"MAC info get from label is {mac_data}, MAC info get from MES is {mac_data}, Match")
                break

        raise_fail = False
        log.debug("----------------------------------------------------------------")
        log.debug("Validation Summary")
        log.debug(f"Serial Number: {sn}")
        log.debug("----------------------------------------------------------------")

        log.debug("> SKU Verification")
        log.debug(f"- Actual Value (Scanned from Label): {sku_data}")
        log.debug(f"- Expected Value (Retrieved from MES): {sku_data}")
        log.debug(f"- Reference Value (ODM Shippable List): {sku_data}")
        log.debug(f"-> All three sources matched. Verification Result: PASS")
        log.debug("")
        log.debug("> Part Number (PN) Verification")
        log.debug(f"- Actual PN (Scanned from Label): {pn}")
        log.debug(f"- Expected PN (Retrieved from MES): {pn}")
        log.debug(f"-> Both values matched. Verification Result: PASS")
        log.debug("")
        log.debug("> Assembly Revision Verification")
        log.debug(f"- Actual Revision (Scanned from Label): {rev}")
        log.debug(f"- Expected Revision (Retrieved from MES): {rev}")
        log.debug(f"- Reference Revision (ODM Shippable List): {control_rev}")
        if control_rev:
            if int(rev) not in control_rev:
                raise_fail = True
                log.debug(f"-> Revision mismatch: Label/MES = {rev}, but ODM Shippable List expects {control_rev} Verification Result: FAIL")
            else:
                log.debug(f"-> All three sources matched. Verification Result: PASS")
        else:
            raise_fail = True
            log.debug(
                f"-> Revision mismatch: Label/MES = {rev}, but ODM Shippable List expects {control_rev} Verification Result: FAIL")
        log.debug("")
        log.debug("> MAC Address Verification")
        log.debug(f"- Actual MAC (Scanned from Label): {mac_data}")
        log.debug(f"- Expected MAC (Retrieved from MES): {mac_data}")
        log.debug(f"-> All three sources matched. Verification Result: PASS")

        log.debug("----------------------------------------------------------------")
        if not raise_fail:
            log.debug("Overall Result: All parameters matched. Unit is qualified for test")
        else:
            log.debug("Overall Result: One or more verification steps failed. Unit is NOT qualified for test")
        log.debug("----------------------------------------------------------------")
        if raise_fail:
            raise Exception("Overall Result: One or more verification steps failed. Unit is NOT qualified for test")

    def check_fail_record(self, sn, station):
        try:
            fail_name = sfchelper.check_sn_fail_times(sn=sn, station=station)
        except:
            fail_name = None

        if self.check_mes_fail(sn, station):
            return

        if helper.mode == helper.DEBUG:
            return

        if fail_name:
            while True:
                ans = ask_question_no_print(
                    question=f"SN:{sn} already fail 2 times: {fail_name}, pls found TE check and unlock\n"
                             f"SN đã thất bại 2 lần, vui lòng liên hệ TE để kiểm tra và mở khóa.")
                pw = self.get_password_by_id(emp_id=ans)
                if pw["status"]:
                    ans2 = ask_question_no_print(
                        question=f"{ans}, please enter your password", visible=False)
                    if ans2 == pw["msg"]:
                        log.debug("confirm to continue test")
                        break
                    else:
                        continue
                else:
                    ans3 = ask_question_no_print(
                        question=f'{pw["msg"]}')
                    continue

    def control_ft_fail_times(self, sn, station, max_fail_time=1, month=6):
        """

        """
        df = pd.DataFrame(sfchelper.get_genius_test_records(sn, month))
        df = df[(df['result'].isin(['F', 'P'])) & (df['mode'] == 'PROD') & (df['area'] == station)]
        log.debug(f'{sn} - {station}, latest {month} month total records: {len(df)}')

        df.sort_values(by=['recttime', 'id'], ascending=True, inplace=True)

        if self.check_mes_fail(sn, station):
            return

        if helper.mode == helper.DEBUG:
            return

        # 按时间降序
        latest_test = [(getattr(_, 'result'), getattr(_, 'test')) for _ in df.tail(max_fail_time).itertuples()]
        log.debug(latest_test)
        if latest_test:
            status = latest_test[-1][0]
            if status == "F":
                fail_name = list(rc[1] for rc in latest_test)
                log.debug(f"FT fail {max_fail_time} times, fail name: {fail_name}")
                while True:
                    ans = ask_question_no_print(
                        question=f"SN:{sn} already fail FT {max_fail_time} times: {fail_name}, pls found TE check and unlock\n"
                                 f"SN đã thất bại 1 lần, vui lòng liên hệ TE để kiểm tra và mở khóa.")
                    pw = self.get_password_by_id(emp_id=ans)
                    if pw["status"]:
                        ans2 = ask_question_no_print(
                            question=f"{ans}, please enter your password", visible=False)
                        if ans2 == pw["msg"]:
                            log.debug("confirm to continue test")
                            break
                        else:
                            continue
                    else:
                        ans3 = ask_question_no_print(
                            question=f'{pw["msg"]}')
                        continue

    @staticmethod
    def get_password_by_id(emp_id):
        filename = '/tftpboot/account.txt'
        try:
            with open(filename, 'r') as f:
                for line in f:
                    if not line.strip():
                        continue  # 跳过空行
                    id_, password = line.strip().split(',', 1)
                    if id_ == emp_id:
                        return {"status": True, "msg": password.upper()}
            return {"status": False, "msg": "未找到该工号"}
        except FileNotFoundError:
            return {"status": False, "msg": f"文件 {filename} 不存在"}
        except Exception as e:
            return {"status": False, "msg": f"发生错误: {e}"}


    @staticmethod
    def get_control_file_rev(target_pn):
        path = "/tftpboot/ODM shippabel list.xlsx"
        if not os.path.exists(path):
            log.error("Not Found file: ODM shippabel list.xlsx")
            return None
        log.debug("Found file: ODM shippabel list.xlsx")

        # 打开工作簿
        workbook = xlrd.open_workbook(path)
        sheet = workbook.sheet_by_index(0)  # 默认取第一个 sheet

        # 获取列索引
        headers = sheet.row_values(0)
        try:
            pn_index = headers.index("PN")
            assembly_rev_index = headers.index("Assembly_Rev")
            status_index = headers.index("Ststus")
            expiration_index = headers.index("Expiration Date")
            sku_rev_index = headers.index("SKU_Rev")
            sku_index = headers.index("SKU")
        except ValueError as e:
            log.error(f"列名缺失: {e}")
            return None

        rev_prefixes = []
        sku = None
        sku_rev = None

        for row_idx in range(1, sheet.nrows):
            row = sheet.row_values(row_idx)

            pn = str(row[pn_index]).strip()
            status = str(row[status_index]).strip().lower()
            expiration_raw = row[expiration_index]
            assembly_rev = row[assembly_rev_index]

            # 条件1：PN 匹配
            if pn != str(target_pn).strip():
                continue

            # 条件2：Status = Production
            if status != "production":
                continue

            # 条件3：Expiration Date 为空 或 大于今天
            valid_expiration = False
            if expiration_raw in ("", None):
                valid_expiration = True
            elif isinstance(expiration_raw, float):
                try:
                    expiration_date = datetime(*xlrd.xldate_as_tuple(expiration_raw, workbook.datemode))
                    if expiration_date.date() > datetime.now().date():
                        valid_expiration = True
                except Exception:
                    pass

            if valid_expiration and assembly_rev:
                rev_prefix = str(assembly_rev)[:2]
                rev_prefixes.append(rev_prefix)
                sku = row[sku_index]
                sku_rev = row[sku_rev_index][0] if row[sku_rev_index] else None

        return sku, sku_rev, rev_prefixes

    @staticmethod
    def get_control_file_data(pn):
        path = "/tftpboot/ODM shippable list.xlsx"
        if not os.path.exists(path):
            log.error("Not Found file: ODM shippabel list.xlsx")
            return None
        log.debug("Found file: ODM shippabel list.xlsx")

        # 打开工作簿
        workbook = xlrd.open_workbook(path)
        sheet = workbook.sheet_by_index(0)  # 默认取第一个 sheet

        # 获取表头（第一行）
        header = sheet.row_values(0)

        # 找出哪些列是日期列（你也可以手动写死）
        date_columns = ["Effective Date", "Expiration Date"]  # 假设这是你的日期列

        # 获取日期列的索引
        date_indexes = [header.index(col) for col in date_columns if col in header]

        # 读取数据并处理日期
        data = []
        for row_idx in range(1, sheet.nrows):
            row = sheet.row_values(row_idx)
            for col_idx in date_indexes:
                cell = sheet.cell(row_idx, col_idx)
                if cell.ctype == xlrd.XL_CELL_DATE:
                    try:
                        row[col_idx] = xlrd.xldate_as_datetime(cell.value, workbook.datemode)
                    except:
                        row[col_idx] = None  # 处理空或异常值
            data.append(row)

        # 转换成 pandas DataFrame
        df = pd.DataFrame(data, columns=header)
        df["Assembly_Rev"] = pd.to_numeric(df["Assembly_Rev"], errors="coerce").astype("Int64")
        # log.debug(f'\n{df[["Effective Date", "Expiration Date"]].head()}')
        # 将 Effective Date 转换为日期类型（非日期的会变成 NaT）
        df['Effective Date'] = pd.to_datetime(df['Effective Date'], errors='coerce')
        df["Expiration Date"] = pd.to_datetime(df["Expiration Date"], errors="coerce")
        # 获取当前日期
        today = pd.to_datetime(datetime.today().date())
        # log.debug(today)
        # log.debug(f'\n{df[["Effective Date", "Expiration Date"]].head()}')
        # log.debug(df[df["PN"] == pn])
        target_df = df[
            (df["PN"] == pn) &
            (((df["Effective Date"].notna()) &
            (df["Effective Date"] < today)) |
            ((df["Expiration Date"].notna()) &
            (df["Expiration Date"] > today)))
        ]
        # log.debug(target_df[['Assembly_Rev', "Effective Date", "Expiration Date"]])
        if not target_df.empty:
            return target_df
        else:
            raise Exception(f"not found PN:{pn} data")


class TimerMeta(type):
    """
    元类，为所有方法自动添加计时装饰器
    """
    def __new__(cls, name, bases, dct):
        # 检查是否继承自 DCN
        if not any(issubclass(base, DCN) for base in bases):
            raise TypeError(f"{name} must inherit from DCN")

        if "__timer__" not in dct:
            dct["__timer__"] = DCN()

        timer = dct["__timer__"]
        nested_methods = dct.get("__nested_methods__", [])  # 需要允许嵌套计时的方法

        for attr_name, attr_value in dct.items():
            if callable(attr_value) and not attr_name.startswith("__"):
                # 判断是否允许嵌套计时
                allow_nested = attr_name in nested_methods
                dct[attr_name] = timer.timeit(allow_nested=allow_nested)(attr_value)

        return super().__new__(cls, name, bases, dct)

