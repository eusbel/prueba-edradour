from gen.libs import lib
from typing import Optional, Union
from . import const
from .logger import log


class Terminal:

    def __init__(self, name, suffix='\r'):
        self.suffix = suffix
        self.__name = name
        self.__proxy = getattr(lib.conn, name)

    @property
    def readable_name(self):
        """
        user define, readable name
        """
        return self.__name

    @property
    def name(self):
        """
        container name
        """
        return self.__proxy.name

    @property
    def foundphrase(self):
        """
        :return: str
        """
        return self.__proxy.foundphrase

    @property
    def buffer(self) -> str:
        return self.__proxy.recbuf

    buf = buffer
    recbuf = buffer

    @property
    def status(self):
        return self.__proxy.status

    def open(self):
        """
        OPEN = 'open'
        CLOSE = 'close'
        :return:
        """
        return self.__proxy.open()

    def close(self):
        return self.__proxy.close()

    def send(self, cmd: Optional[str], expectphrase: Union[str, list, tuple, None], timeout=60, echo=False,
             visible=True):
        """ Send command to connection, will not check the if cmd is sent or not..
        v3.0.0: cmd & expectphrase parameters must be provided.
        :param str cmd: the message to send
        :param str|list expectphrase: the expected phrase, should be a str or list
        :param echo: if True, the buf from UUT need to startswith cmd.
        :param visible: if False, the cmd will be hidden in connection log.
        :param num timeout: the timeout should be more than 0
        """
        if visible is True:
            self.debug(
                f'cmd: {const.CONTROL_KEY_NAME.get(cmd, cmd)!r}, expectphrase: {expectphrase}, timeout: {timeout}'
            )
        else:
            self.debug(f'***, expectphrase: {expectphrase}, timeout: {timeout}')

        return self.__proxy.send(cmd, expectphrase, timeout=timeout, echo=echo, visible=visible)

    def send_enter(self, expectphrase, timeout=60):
        return self.send('\r', expectphrase=expectphrase, timeout=timeout)

    def send_ctrl_c(self, expectphrase, timeout=60):
        return self.send(const.CTRL_C, expectphrase=expectphrase, timeout=timeout)

    def send_esc(self, expectphrase, timeout=60):
        return self.send(const.ESC, expectphrase=expectphrase, timeout=timeout)

    def disable_suffix(self):
        self.set_suffix('')

    def set_suffix(self, suffix='\r'):
        self.suffix = suffix

    def clear_buffer(self):
        self.send('', '')

    def send_wise(self, cmd: Optional[str], expectphrase: Union[str, list, tuple, None],
                  timeout=60, echo=False, visible=True, suffix=None):
        """
        下命令的同时看情况决定是否加上 \r 或者 用户自定义 结尾
        若 suffix is None 意味着使用初始化的 self.suffix 的值，否则使用当前传入的 suffix 的值
        :param cmd:
        :param expectphrase:
        :param timeout:
        :param echo:
        :param visible:
        :param suffix:
        :return:
        """
        cmd = f'{cmd}{self.suffix or ""}' if suffix is None else f'{cmd}{suffix}'
        return self.send(cmd, expectphrase=expectphrase, timeout=timeout, echo=echo, visible=visible)

    def send_bytes(self, cmd: Optional[bytes], expectphrase: Union[str, list, tuple, None],
                  timeout=60, echo=False, visible=True, suffix=None):
        """
        下命令的同时看情况决定是否加上 \r 或者 用户自定义 结尾
        若 suffix is None 意味着使用初始化的 self.suffix 的值，否则使用当前传入的 suffix 的值
        :param cmd:
        :param expectphrase:
        :param timeout:
        :param echo:
        :param visible:
        :param suffix:
        :return:
        """
        cmd = f'{cmd}{self.suffix or ""}' if suffix is None else f'{cmd}{suffix}'
        return self.send(cmd, expectphrase=expectphrase, timeout=timeout, echo=echo, visible=visible)

    emit = send_wise

    def send_many(self, cmd_phrase_timeout: (list, tuple), suffix=None):
        """
        send many command once
        :param cmd_phrase_timeout: like: [('ls -h',), ('df -h', ']$'), ('ifconfig', ']$', 60)]
        :param suffix:
        :return:
        """
        for cpt in cmd_phrase_timeout:
            if len(cpt) == 1:
                return self.send_wise(cpt[0], expectphrase='', timeout=60, suffix=suffix)
            elif len(cpt) == 2:
                return self.send_wise(cpt[0], expectphrase=cpt[1], timeout=60, suffix=suffix)
            elif len(cpt) == 3:
                return self.send_wise(cpt[0], expectphrase=cpt[1], timeout=cpt[2], suffix=suffix)
            else:
                raise Exception(f'accept 1-3 parameters, get {len(cpt)} -> {cpt}')

    # def sende(self, cmd, expectphrase, timeout=60):
    #     """ Send and echo and check, will not check the if cmd is sent or not..
    #     :param str cmd: the message to send
    #     :param str|list expectphrase: the expected phrase, should be a str or list
    #     :param num timeout: the timeout should be more than 0
    #     """
    #     return self.__proxy.sende(cmd, expectphrase, timeout=timeout)

    def waitfor(self, expectphrase=None, timeout=60):
        """ Wait till the expectphrase is found, or raise Exception
        :param num timeout: wait for how long time
        :param list or str expectphrase: A list of expected phrases
        :return: Return the first expected phrase, or None is time out
        """
        self.debug(f'wait for {expectphrase}, timeout: {timeout}(s)')
        return self.__proxy.waitfor(expectphrase=expectphrase, timeout=timeout)

    wait_for = waitfor

    def capturestr(self, start_string, end_string=r'\n'):
        """ This method simulates autotest capturestr.
            if many found, only use the first one matched.

            will remove the blank character outside automatically.

            Regex Example:
                a = '3 PCB Serial Number       : FOC20522BQD '
                start_string = r'PCB.*:'      # .* means any characters.
                end_string = '\n'

                then you could get 'FOC20522BQD'

        :param start_string:
        :param end_string:
        :return: return the first captured string between start_string and end_string,
                 or None if didn't find start_string or end_string
        :return:
        """
        return self.__proxy.capturestr(start_string=start_string, end_string=end_string)

    def __getattr__(self, item):
        return getattr(self.__proxy, item)

    def debug(self, msg):
        log.debug(f'[{self.readable_name}] {msg}')

    def info(self, msg):
        log.info(f'[{self.readable_name}] {msg}')

    def warning(self, msg):
        log.warning(f'[{self.readable_name}] {msg}')

    warn = warning

    def error(self, msg):
        log.error(f'[{self.readable_name}] {msg}')
