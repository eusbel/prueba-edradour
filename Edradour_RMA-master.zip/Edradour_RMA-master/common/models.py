from gen.libs import lib
from dataclasses import dataclass

from typing import Optional

logger = lib.get_seq_logger()
#
# STR1 = 'str1'
# STR2 = 'str2'
# STR3 = 'str3'
# STR4 = 'str4'
# STR5 = 'str5'
# STR6 = 'str6'
# STR1NAME = 'str1name'
# STR2NAME = 'str2name'
# STR3NAME = 'str3name'
# STR4NAME = 'str4name'
# STR5NAME = 'str5name'
# STR6NAME = 'str6name'
LEGAL_TEST_RESULT = ['S', 'F', 'P', 'A']


# Genius table: gui_testdata
# +--------------+-------------+------+-----+---------+----------------+
# | Field        | Type        | Null | Key | Default | Extra          |
# +--------------+-------------+------+-----+---------+----------------+
# | id           | int(11)     | NO   | PRI | NULL    | auto_increment |
# | machine      | varchar(16) | NO   |     | NULL    |                |
# | container    | varchar(32) | NO   |     | NULL    |                |
# | recttime     | datetime(6) | NO   |     | NULL    |                |
# | tottime      | varchar(32) | YES  |     | NULL    |                |
# | testtime     | varchar(32) | YES  |     | NULL    |                |
# | sernum       | varchar(32) | NO   |     | NULL    |                |
# | uuttype      | varchar(32) | NO   |     | NULL    |                |
# | area         | varchar(16) | NO   |     | NULL    |                |
# | result       | varchar(8)  | NO   |     | NULL    |                |
# | test         | varchar(32) | YES  |     | NULL    |                |
# | partnum      | varchar(32) | YES  |     | NULL    |                |
# | partnumrev   | varchar(32) | YES  |     | NULL    |                |
# | tannum       | varchar(32) | YES  |     | NULL    |                |
# | tannumrev    | varchar(32) | YES  |     | NULL    |                |
# | pid          | varchar(32) | YES  |     | NULL    |                |
# | vid          | varchar(32) | YES  |     | NULL    |                |
# | parentsernum | varchar(32) | YES  |     | NULL    |                |
# | username     | varchar(32) | YES  |     | NULL    |                |
# | mode         | varchar(8)  | YES  |     | NULL    |                |
# | order        | varchar(32) | YES  |     | NULL    |                |
# | lineid       | varchar(16) | YES  |     | NULL    |                |
# | bflush       | int(11)     | NO   |     | NULL    |                |
# | bitmap       | int(11)     | NO   |     | NULL    |                |
# | swrev        | varchar(64) | YES  |     | NULL    |                |
# | diagrev      | varchar(64) | YES  |     | NULL    |                |
# | hwrev        | varchar(32) | YES  |     | NULL    |                |
# | deviation    | varchar(16) | YES  |     | NULL    |                |
# | label        | varchar(16) | YES  |     | NULL    |                |
# | license      | varchar(64) | YES  |     | NULL    |                |
# | str1name     | varchar(32) | YES  |     | NULL    |                |
# | str1         | varchar(64) | YES  |     | NULL    |                |
# | str2name     | varchar(32) | YES  |     | NULL    |                |
# | str2         | varchar(64) | YES  |     | NULL    |                |
# | str3name     | varchar(32) | YES  |     | NULL    |                |
# | str3         | varchar(64) | YES  |     | NULL    |                |
# | str4name     | varchar(32) | YES  |     | NULL    |                |
# | str4         | varchar(64) | YES  |     | NULL    |                |
# | str5name     | varchar(32) | YES  |     | NULL    |                |
# | str5         | varchar(64) | YES  |     | NULL    |                |
# | str6name     | varchar(32) | YES  |     | NULL    |                |
# | str6         | varchar(64) | YES  |     | NULL    |                |
# | sync         | int(11)     | NO   |     | NULL    |                |
# +--------------+-------------+------+-----+---------+----------------+


@dataclass
class CommonModel:
    sn: str
    pn: str
    area: str
    status: str
    info: str
    kwargs: dict


class GeniusRecordFields:
    machine = 'machine'
    container = 'container'
    sernum = 'sernum'
    uuttype = 'uuttype'
    area = 'area'
    result = 'result'
    test = 'test'
    partnum = 'partnum'
    partnumrev = 'partnumrev'
    tannum = 'tannum'
    tannumrev = 'tannumrev'
    pid = 'pid'
    vid = 'vid'
    parentsernum = 'parentsernum'
    username = 'username'
    mode = 'mode'
    order = 'order'
    lineid = 'lineid'
    bflush = 'bflush'
    bitmap = 'bitmap'
    swrev = 'swrev'
    diagrev = 'diagrev'
    hwrev = 'hwrev'
    deviation = 'deviation'
    label = 'label'
    license = 'license'
    str1name = 'str1name'
    str1 = 'str1'
    str2name = 'str2name'
    str2 = 'str2'
    str3name = 'str3name'
    str3 = 'str3'
    str4name = 'str4name'
    str4 = 'str4'
    str5name = 'str5name'
    str5 = 'str5'
    str6name = 'str6name'
    str6 = 'str6'


@dataclass
class GuiTestData:
    machine: str
    container: str

    sernum: str  # serial number
    uuttype: str  # uut type
    area: str  # station
    result: str  # P,F,A,S
    test: str = ''  # failing test name

    partnum: str = ''  # Board P/N (ie 800-, 73-)  -- not necessary
    partnumrev: str = ''  # Board P/N (ie 05)  -- not necessary
    tannum: str = ''  # TAN P/N (ie 05)
    tannumrev: str = ''  # TAN P/N (ie 800-, 68-)
    pid: str = ''  # PID
    vid: str = ''  # VID

    parentsernum: str = ''  # parent serial number
    # username: str  # The user doing the test
    # mode: str  # the Minx major line - PROD/DEBUG

    order: str = ''  # the Minx sales order
    lineid: str = ''  # the Oracle line_id
    # 0=don't backflush
    bflush: int = 0  # NULL=bflushfrom
    bitmap: int = 0  # all purpose bitmap

    swrev: str = ''  # software/diag revision
    diagrev: str = ''  # diag rev
    hwrev: str = ''  # VID
    deviation: str = ''  # deviation
    label: str = ''  # label number for quack label
    license: str = ''  # license information

    str1name: str = ''  # TE defined string 1 name
    str1: str = ''  # TE defined string 1 name
    str2name: str = ''  # TE defined string 2 name
    str2: str = ''  # TE defined string 2
    str3name: str = ''  # TE defined string 3 name
    str3: str = ''  # TE defined string 3
    str4name: str = ''  # TE defined string 4 name
    str4: str = ''  # TE defined string 4 name
    str5name: str = ''  # TE defined string 5 name
    str5: str = ''  # TE defined string 5
    str6name: str = ''  # TE defined string 6 name
    str6: str = ''  # TE defined string 6

    sync: int = 0  # sync flag

    def update(self, **kwargs):
        for k, v in kwargs.items():
            if not hasattr(self, k):
                logger.info(f'[Genius] ignore: {k} {v!r}')
                continue
            setattr(self, k, v)
            logger.info(f'[Genius] update: {k} {v!r}')

    def dumps(self):
        # sernum = sernum,
        # uuttype = uuttype,
        # area = area,
        # result = result,
        # machine = machine,
        # container = container,
        # recttime = recttime,
        # tottime = tottime,
        # testtime = testtime,
        # test = "",
        # mode = mode,
        # username = username,

        # skip_fields = [
        #     'sernum', 'uuttype', 'area', 'result', 'machine', 'container', 'recttime', 'tottime', 'testtime',
        #     'test', 'mode', 'username'
        # ]
        # return {k: v for k, v in vars(self).items() if k not in skip_fields}
        return vars(self)


GeniusModel = GuiTestData


# MES Record
# "ID": "VNDCN000000T85V0",
# "SYSSERIALNO": "VN2BKYG0HR",
# "TESTDATE": "2022-12-17 23:39:03",
# "EVENTNAME": "FT",
# "STATUS": "PASS",
# "PARTNO": null,
# "SFPMPN": null,
# "LOCATION": null,
# "SYMPTOM": null,
# "PCBASN": null,
# "PCBAPN": null,
# "VSN": null,
# "VPN": null,
# "CSN": null,
# "CPN": null,
# "FRUPCBASN": null,
# "TESTREPORTNAME": null,
# "LASTEDITDT": null,
# "LASTEDITBY": "V1234567",
# "FAILURECODE": null,
# "TRAY_SN": null,
# "TESTERNO": "FCA-02_200.168.123.3",
# "TEMP4": null,
# "TEMP5": 0.0,
# "TATIME": "2022-12-18 00:44:19",
# "BK1_KEY": null,
# "BK1_VALUE": "None",
# "BK2_KEY": null,
# "BK2_VALUE": null,
# "BK3_KEY": null,
# "BK3_VALUE": null,
# "BK4_KEY": null,
# "BK4_VALUE": null,
# "R_TEST_RECORD_ID": "VNDCN000000T85SV"


class MESRecordFields:
    sysserialno = 'SYSSERIALNO'
    testdate = 'TESTDATE'
    eventname = 'EVENTNAME'
    status = 'STATUS'
    partno = 'PARTNO'
    sfpmpn = 'SFPMPN'
    location = 'LOCATION'
    symptom = 'SYMPTOM'
    pcbasn = 'PCBASN'
    pcbapn = 'PCBAPN'
    vsn = 'VSN'
    vpn = 'VPN'
    csn = 'CSN'
    cpn = 'CPN'
    frupcbasn = 'FRUPCBASN'
    testreportname = 'TESTREPORTNAME'
    lasteditdt = 'LASTEDITDT'
    lasteditby = 'LASTEDITBY'
    failurecode = 'FAILURECODE'
    tray_sn = 'TRAY_SN'
    testerno = 'TESTERNO'
    temp4 = 'TEMP4'
    temp5 = 'TEMP5'
    tatime = 'TATIME'
    bk1_key = 'BK1_KEY'
    bk1_value = 'BK1_VALUE'
    bk2_key = 'BK2_KEY'
    bk2_value = 'BK2_VALUE'
    bk3_key = 'BK3_KEY'
    bk3_value = 'BK3_VALUE'
    bk4_key = 'BK4_KEY'
    bk4_value = 'BK4_VALUE'


@dataclass
class MESModel:
    SYSSERIALNO: str
    TESTDATE: str
    EVENTNAME: str
    STATUS: str
    PARTNO: str = ''
    SFPMPN: str = ''
    LOCATION: str = ''
    SYMPTOM: str = ''
    PCBASN: str = ''
    PCBAPN: str = ''
    VSN: str = ''
    VPN: str = ''
    CSN: str = ''
    CPN: str = ''
    FRUPCBASN: str = ''
    TESTREPORTNAME: str = ''
    LASTEDITDT: str = ''
    LASTEDITBY: str = ''
    FAILURECODE: str = ''
    TRAY_SN: str = ''
    TESTERNO: str = ''
    TEMP4: str = ''
    TEMP5: str = ''
    TATIME: str = ''
    BK1_KEY: str = ''
    BK1_VALUE: str = ''
    BK2_KEY: str = ''
    BK2_VALUE: str = ''
    BK3_KEY: str = ''
    BK3_VALUE: str = ''
    BK4_KEY: str = ''
    BK4_VALUE: str = ''

    def update(self, **kwargs):
        for k, v in kwargs.items():
            if not hasattr(self, k):
                logger.info(f'[MES] ignore: {k} {v!r}')
                continue
            setattr(self, k, v)
            logger.info(f'[MES] update: {k} {v!r}')

    def dumps(self):
        return {
            MESRecordFields.sysserialno: getattr(self, MESRecordFields.sysserialno, ''),
            MESRecordFields.testdate: getattr(self, MESRecordFields.testdate, ''),
            MESRecordFields.eventname: getattr(self, MESRecordFields.eventname, ''),
            MESRecordFields.status: getattr(self, MESRecordFields.status, ''),
            MESRecordFields.partno: getattr(self, MESRecordFields.partno, ''),
            MESRecordFields.sfpmpn: getattr(self, MESRecordFields.sfpmpn, ''),
            MESRecordFields.location: getattr(self, MESRecordFields.location, ''),
            MESRecordFields.symptom: getattr(self, MESRecordFields.symptom, ''),
            MESRecordFields.pcbasn: getattr(self, MESRecordFields.pcbasn, ''),
            MESRecordFields.pcbapn: getattr(self, MESRecordFields.pcbapn, ''),
            MESRecordFields.vsn: getattr(self, MESRecordFields.vsn, ''),
            MESRecordFields.vpn: getattr(self, MESRecordFields.vpn, ''),
            MESRecordFields.csn: getattr(self, MESRecordFields.csn, ''),
            MESRecordFields.cpn: getattr(self, MESRecordFields.cpn, ''),
            MESRecordFields.frupcbasn: getattr(self, MESRecordFields.frupcbasn, ''),
            MESRecordFields.testreportname: getattr(self, MESRecordFields.testreportname, ''),
            MESRecordFields.lasteditdt: getattr(self, MESRecordFields.lasteditdt, ''),
            MESRecordFields.lasteditby: getattr(self, MESRecordFields.lasteditby, '')[:20],
            MESRecordFields.failurecode: getattr(self, MESRecordFields.failurecode, ''),
            MESRecordFields.tray_sn: getattr(self, MESRecordFields.tray_sn, ''),
            MESRecordFields.testerno: getattr(self, MESRecordFields.testerno, ''),
            MESRecordFields.temp4: getattr(self, MESRecordFields.temp4, ''),
            MESRecordFields.temp5: getattr(self, MESRecordFields.temp5, ''),
            MESRecordFields.tatime: getattr(self, MESRecordFields.tatime, ''),
            MESRecordFields.bk1_key: getattr(self, MESRecordFields.bk1_key, ''),
            MESRecordFields.bk1_value: getattr(self, MESRecordFields.bk1_value, ''),
            MESRecordFields.bk2_key: getattr(self, MESRecordFields.bk2_key, ''),
            MESRecordFields.bk2_value: getattr(self, MESRecordFields.bk2_value, ''),
            MESRecordFields.bk3_key: getattr(self, MESRecordFields.bk3_key, ''),
            MESRecordFields.bk3_value: getattr(self, MESRecordFields.bk3_value, ''),
            MESRecordFields.bk4_key: getattr(self, MESRecordFields.bk4_key, ''),
            MESRecordFields.bk4_value: getattr(self, MESRecordFields.bk4_value, ''),
        }


@dataclass()
class JuniperMESModel:
    SYSSERIALNO: str
    TESTDATE: str
    EVENTNAME: str
    STATUS: str
    PART_NUMBER: str
    CM_ODM_PARTNUMBER: str
    SERIAL_NUMBER: str
    PHASE: str
    PART_NUMBER_REVISION: str
    UNIQUE_TEST_ID: str
    TEST_START_TIMESTAMP: str
    TEST_STEP: str
    TEST_CYCLE_TEST_LOOP: Optional[int]
    CAPTURE_TIME: str
    TEST_RESULT: str
    FAILCODE: str
    TEST_STATION_NUMBER: str
    TEST_STATION_NAME: str
    LOAD_DATE: str
    FILE_NAME: str
    LASTEDITDT: str
    LASTEDITBY: str
    TESTERNO: str
    TATIME: str
    R_TEST_RECORD_ID: str = ""
    MFG_TEST_LOG: str = ""

    def update(self, **kwargs):
        for k, v in kwargs.items():
            if not hasattr(self, k):
                logger.info(f'[JNPR-MES] ignore: {k} {v!r}')
                continue
            setattr(self, k, v)
            logger.info(f'[JNPR-MES] update: {k} {v!r}')

    def dumps(self):
        return {
            JuniperMESFields.SYSSERIALNO: getattr(self, JuniperMESFields.SYSSERIALNO, ''),
            JuniperMESFields.TESTDATE: getattr(self, JuniperMESFields.TESTDATE, ''),
            JuniperMESFields.EVENTNAME: getattr(self, JuniperMESFields.EVENTNAME, ''),
            JuniperMESFields.STATUS: getattr(self, JuniperMESFields.STATUS, ''),
            JuniperMESFields.PART_NUMBER: getattr(self, JuniperMESFields.PART_NUMBER, ''),
            JuniperMESFields.CM_ODM_PARTNUMBER: getattr(self, JuniperMESFields.CM_ODM_PARTNUMBER, ''),
            JuniperMESFields.SERIAL_NUMBER: getattr(self, JuniperMESFields.SERIAL_NUMBER, ''),
            JuniperMESFields.PHASE: getattr(self, JuniperMESFields.PHASE, ''),
            JuniperMESFields.PART_NUMBER_REVISION: getattr(self, JuniperMESFields.PART_NUMBER_REVISION, ''),
            JuniperMESFields.UNIQUE_TEST_ID: getattr(self, JuniperMESFields.UNIQUE_TEST_ID, ''),
            JuniperMESFields.TEST_START_TIMESTAMP: getattr(self, JuniperMESFields.TEST_START_TIMESTAMP, ''),
            JuniperMESFields.TEST_STEP: getattr(self, JuniperMESFields.TEST_STEP, ''),
            JuniperMESFields.TEST_CYCLE_TEST_LOOP: getattr(self, JuniperMESFields.TEST_CYCLE_TEST_LOOP, ''),
            JuniperMESFields.CAPTURE_TIME: getattr(self, JuniperMESFields.CAPTURE_TIME, ''),
            JuniperMESFields.TEST_RESULT: getattr(self, JuniperMESFields.TEST_RESULT, ''),
            JuniperMESFields.FAILCODE: getattr(self, JuniperMESFields.FAILCODE, ''),
            JuniperMESFields.TEST_STATION_NUMBER: getattr(self, JuniperMESFields.TEST_STATION_NUMBER, ''),
            JuniperMESFields.TEST_STATION_NAME: getattr(self, JuniperMESFields.TEST_STATION_NAME, ''),
            JuniperMESFields.LOAD_DATE: getattr(self, JuniperMESFields.LOAD_DATE, ''),
            JuniperMESFields.FILE_NAME: getattr(self, JuniperMESFields.FILE_NAME, ''),
            JuniperMESFields.LASTEDITDT: getattr(self, JuniperMESFields.LASTEDITDT, ''),
            JuniperMESFields.LASTEDITBY: getattr(self, JuniperMESFields.LASTEDITBY, '')[:20],
            JuniperMESFields.TESTERNO: getattr(self, JuniperMESFields.TESTERNO, ''),
            JuniperMESFields.TATIME: getattr(self, JuniperMESFields.TATIME, ''),
            JuniperMESFields.R_TEST_RECORD_ID: getattr(self, JuniperMESFields.R_TEST_RECORD_ID, ''),
            JuniperMESFields.MFG_TEST_LOG: getattr(self, JuniperMESFields.MFG_TEST_LOG, ''),
        }


class JuniperMESFields:
    SYSSERIALNO = 'SYSSERIALNO'
    TESTDATE = 'TESTDATE'
    EVENTNAME = 'EVENTNAME'
    STATUS = 'STATUS'
    PART_NUMBER = 'PART_NUMBER'
    CM_ODM_PARTNUMBER = 'CM_ODM_PARTNUMBER'
    SERIAL_NUMBER = 'SERIAL_NUMBER'
    PHASE = 'PHASE'
    PART_NUMBER_REVISION = 'PART_NUMBER_REVISION'
    UNIQUE_TEST_ID = 'UNIQUE_TEST_ID'
    TEST_START_TIMESTAMP = 'TEST_START_TIMESTAMP'
    TEST_STEP = 'TEST_STEP'
    TEST_CYCLE_TEST_LOOP = 'TEST_CYCLE_TEST_LOOP'
    CAPTURE_TIME = 'CAPTURE_TIME'
    TEST_RESULT = 'TEST_RESULT'
    FAILCODE = 'FAILCODE'
    TEST_STATION_NUMBER = 'TEST_STATION_NUMBER'
    TEST_STATION_NAME = 'TEST_STATION_NAME'
    LOAD_DATE = 'LOAD_DATE'
    FILE_NAME = 'FILE_NAME'
    LASTEDITDT = 'LASTEDITDT'
    LASTEDITBY = 'LASTEDITBY'
    TESTERNO = 'TESTERNO'
    TATIME = 'TATIME'
    R_TEST_RECORD_ID = "R_TEST_RECORD_ID"
    MFG_TEST_LOG = "MFG_TEST_LOG"
