import json
import time
import datetime as dt
import zoneinfo
import platform
import requests

from .terminal import Terminal
from . import scanner
from .fields import StrField, Field
import re

from .utils import logger, helper


class TPM2(Terminal):
    mid_ip = '200.168.96.20'
    # mid_ip = '200.168.96.30'
    mid_port = 8000
    mid_username = 'odmtest'
    mid_password = 'odmtest'

    mid_prompt = '>'
    diag_prompt = 'DIAG>'
    bcm_prompt = '#'

    sn = StrField()
    model = StrField()
    uut_ip = StrField()
    netmask = StrField()
    tftp_server = StrField()

    tpm2_fw_version = StrField()
    tpm2_vendor = StrField()
    tpm2_manufacturer = StrField()

    # tpm2_dir = 'C:\\TPM'
    tpm2_file = StrField()
    tpm2_file_version = StrField()
    tpm2_file_md5 = StrField()
    tpm2_product_id = StrField()

    tpm2_file_old = StrField()
    tpm2_file_version_old = StrField()
    tpm2_file_md5_old = StrField()
    tpm2_product_id_old = StrField()

    temp_certificate = StrField()
    session_id = StrField()
    dlm_cert = StrField()
    dlm_cert_filename = StrField()

    is_fresh_unit = Field()

    def __init__(self, name='TPM'):
        super(TPM2, self).__init__(name=name)

    # @property
    # def session_id(self):
    #     if not self.__session_id:
    #         self.__session_id = db.get(f'{self.sn}-session_id') or ''
    #     return self.__session_id
    #
    # @session_id.setter
    # def session_id(self, value):
    #     db.setex(f'{self.sn}-session_id', 60 * 30, value)
    #     self.__session_id = value

    def do_connect(self):
        while True:
            self.close()
            time.sleep(1)
            self.open()
            try:
                # self.send_wise(f'ssh {self.mid_username}@{self.mid_ip}', ['(yes/no/[fingerprint])?', 'password:'])
                # if '(yes/no/[fingerprint])?' in self.buffer:
                #     self.send_wise('yes', 'password:')
                #     self.send_wise('odmtest', '>')
                # elif 'password:' in self.buffer:
                #     self.send_wise('odmtest', '>')
                # self.send_wise('', '>')
                self.send_wise(f'telnet {self.mid_ip} {self.mid_port}', 'Escape character is')
                break
            except Exception as e:
                logger.debug(f"Connect mid server failed message: {e}")
                question = (f'Connect mid server failed, please found TE check !\n'
                            f'Kết nối máy chủ trung gian thất bại, vui lòng kiểm tra TE!')
                if scanner.yes_or_enter_to_continue(question=question) is False:
                    raise Exception(f'tpm2 mid server: {self.mid_ip} response not OK!')
                else:
                    continue

        logger.debug(f'Check mid server: {self.mid_ip} OK !')

    def setup_config(self, sn, model, uut_ip, netmask, tftp_server,
                     tpm2_fw_version, tpm2_vendor, tpm2_manufacturer, tpm2_file, tpm2_file_version,
                     tpm2_file_md5, tpm2_product_id, tpm2_file_old, tpm2_file_version_old,
                     tpm2_file_md5_old, tpm2_product_id_old):
        self.sn = sn
        self.model = model

        self.uut_ip = uut_ip
        self.netmask = netmask
        self.tftp_server = tftp_server

        self.tpm2_fw_version = tpm2_fw_version
        self.tpm2_vendor = tpm2_vendor
        self.tpm2_manufacturer = tpm2_manufacturer
        self.tpm2_file = tpm2_file
        self.tpm2_file_version = tpm2_file_version
        self.tpm2_file_md5 = tpm2_file_md5
        self.tpm2_product_id = tpm2_product_id

        self.tpm2_file_old = tpm2_file_old
        self.tpm2_file_version_old = tpm2_file_version_old
        self.tpm2_file_md5_old = tpm2_file_md5_old
        self.tpm2_product_id_old = tpm2_product_id_old

        logger.debug(f'SN: {self.sn}')
        logger.debug(f'Model: {self.model}')
        logger.debug(f'uut_ip: {self.uut_ip}')
        logger.debug(f'netmask: {self.netmask}')
        logger.debug(f'tftp_server: {self.tftp_server}')
        logger.debug(f'tpm2_fw_version: {self.tpm2_fw_version}')
        logger.debug(f'tpm2_vendor: {self.tpm2_vendor}')
        logger.debug(f'tpm2_manufacturer: {self.tpm2_manufacturer}')
        logger.debug(f'tpm2_file: {self.tpm2_file}')
        logger.debug(f'tpm2_file_version: {self.tpm2_file_version}')
        logger.debug(f'tpm2_file_md5: {self.tpm2_file_md5}')
        logger.debug(f'tpm2_product_id: {self.tpm2_product_id}')

    # def get_fingerprint(self):
    #     self.send_wise(f'cd {self.tpm2_file}', self.mid_prompt)
    #     self.send_wise(f'ls -lh', self.mid_prompt)
    #     self.send_wise(f'cat fingerprint', self.mid_prompt)
    #     fingerprint = re.search('([0-9a-f]{40})', self.buffer)
    #     if fingerprint is None:
    #         raise Exception('not found fingerprint!!')
    #     fingerprint = fingerprint.group(1)
    #     logger.debug(f'fingerprint is: {fingerprint}')
    #     return fingerprint

    # def show_curl_version(self):
    #     self.send_wise('curl -V', self.prompt)

    def enter_bcm_mode(self):
        login_prompt = 'iProc login:'
        self.send_wise('', [self.diag_prompt, self.bcm_prompt, login_prompt])
        if self.diag_prompt in self.buffer:
            self.send_wise('exit', login_prompt)
            self.send_wise('root', self.bcm_prompt)
        elif login_prompt in self.buffer:
            self.send_wise('root', self.bcm_prompt)

        self.send_wise('', self.bcm_prompt)
        logger.debug('enter BCM mode OK..')

    def delete_old_tpm2_dir(self):
        self.send_wise('cd /bcm', self.bcm_prompt)
        self.send_wise('ls', self.bcm_prompt)
        if re.search('tpm2', self.buffer, flags=re.I):
            logger.debug('found tpm2 dir in UUT... doing delete..')
            self.send_wise('rm -r tpm2', self.bcm_prompt)
            if 'command not found' in self.buffer:
                raise Exception('delete old tpm2 dir failed!')
            if 'No such file or directory' in self.buffer:
                logger.debug('not found tpm2 files in UUT')
        logger.debug('delete old tpm2 dir OK!')

    def download_tpm2_tar_file(self):
        uut_ip, netmask, tftp_server = self.uut_ip, self.netmask, self.tftp_server

        self.send_wise('cd /bcm', self.bcm_prompt)
        self.send_wise(f'ifconfig eth0 {uut_ip} netmask {netmask}', self.bcm_prompt)
        time.sleep(15)

        while True:
            self.send_wise(f'ping -c 4 {tftp_server}', self.bcm_prompt)
            if ', 0% packet loss' in self.buffer:
                break
            else:
                if scanner.yes_or_enter_to_continue(
                        question=f'Please check if the network cable is properly connected.\nVui lòng kiểm tra xem cáp mạng đã được cắm chắc chưa.') is False:
                    raise Exception(f'ping tftp server failed!')
            self.send_wise('ifconfig eth0 down', self.bcm_prompt)
            time.sleep(3)
            self.send_wise('ifconfig eth0 up', self.bcm_prompt)
            time.sleep(15)


        # use tftp download instead of SCP
        while True:
            self.send_wise(f'tftp -r edradour/{self.tpm2_file} -g {tftp_server}', self.bcm_prompt)
            if 'tftp: timeout' in self.buffer:
                if scanner.yes_or_enter_to_continue(
                        question=f'Download {self.tpm2_file} failed, retry?\n下载{self.tpm2_file}文件失败，重试？') is False:
                    raise Exception(f'download {self.tpm2_file} file failed!')
                self.send_wise('syscall ifconfig eth0 down', self.diag_prompt)
                time.sleep(3)
                self.send_wise('syscall ifconfig eth0 up', self.diag_prompt)
                time.sleep(5)
                continue

            if 'File not found' in self.buffer:
                logger.error(f'file: {self.tpm2_file} not on server! Please call TE to check!')
                if scanner.yes_or_enter_to_continue(
                        f'file: {self.tpm2_file} not found! Please call TE check server!') is False:
                    raise Exception(f'File: {self.tpm2_file} not found')
                time.sleep(5)
                continue

            break

        self.send_wise(f'ls . | grep -x {self.tpm2_file}', self.bcm_prompt)
        if self.buffer.count(self.tpm2_file) != 2:
            raise Exception(f'not found tpm2 file: {self.tpm2_file}')
        logger.debug(f'download {self.tpm2_file} OK!')

        # check md5
        self.send_wise(f'md5sum {self.tpm2_file}', self.bcm_prompt)
        md5_sum = re.search('([0-9a-f]{32})\s+', self.buffer)
        if md5_sum is None:
            raise Exception('not found a 32 bytes md5 sum value!')
        md5_sum = md5_sum.group(1).strip()
        if md5_sum != self.tpm2_file_md5:
            raise Exception(f'tpm2 md5 sum mismatch! expected: {self.tpm2_file_md5}, captured: {md5_sum}')
        logger.debug(f'tpm2 md5 sum is the match! expected: {self.tpm2_file_md5}, expected: {md5_sum}')

    def extract_tpm2_tar_file(self):
        self.send_wise(f'tar xvf {self.tpm2_file}', self.bcm_prompt)
        self.send_wise("if test -d tpm2;then echo \"exist\"; fi\n", self.bcm_prompt)
        if re.search('fail|error', self.buffer, flags=re.I):
            raise Exception(f'extract {self.tpm2_file} failed!, found error or fail!')
        if self.buffer.count('exist') != 2:
            raise Exception('not found exist! extract tpm2 file failed!')

    def setup_tpm2_env(self):
        # UTC 时间
        current_date = dt.datetime.strftime(dt.datetime.now(tz=zoneinfo.ZoneInfo('UTC')), '%Y%m%d%H%M')
        logger.debug(f'current UTC time: {current_date}')

        # 设定为越南时间
        # current_date = dt.datetime.strftime(dt.datetime.now(tz=zoneinfo.ZoneInfo('Asia/Ho_Chi_Minh')), '%Y%m%d%H%M')
        # logger.debug(f'local time: {current_date}')

        self.send_wise(f"date -s {current_date}", "#")

        self.send_wise("ln -s /proc/self/fd /dev/fd", self.bcm_prompt)
        self.send_wise("bash", self.bcm_prompt)

        self.send_wise("cd /bcm/tpm2/bin/", self.bcm_prompt)
        self.send_wise("modprobe tpm_tis_spi", self.bcm_prompt)
        self.send_wise("ls /dev/tpm*", self.bcm_prompt)
        self.send_wise("mkdir -p /run/dbus", self.bcm_prompt)
        self.send_wise("dbus-daemon --system", self.bcm_prompt)
        self.send_wise(
            "dbus-send --system --dest=org.freedesktop.DBus --type=method_call --print-reply /org/freedesktop/DBus org.freedesktop.DBus.ListNames",
            self.bcm_prompt)
        self.send_wise("tpm2-abrmd --allow-root &", self.bcm_prompt)
        time.sleep(5)
        self.send_wise(
            "dbus-send --system --dest=org.freedesktop.DBus --type=method_call --print-reply /org/freedesktop/DBus org.freedesktop.DBus.ListNames",
            self.bcm_prompt)

        self.send_wise('cd /bcm/tpm2/bin', self.bcm_prompt)
        if 'No such file or directory' in self.buffer:
            raise Exception('tpm2 bin dir not exists! >> /bcm/tpm2/bin')

        logger.debug('setup tpm2 env OK...')

    def check_tpm2_programmed_status(self):
        self.send_wise("./tpm2_manufacture.sh --get-device-certs", self.bcm_prompt)
        present = re.search(r'"iak_key_present":(.+?),\s+"idevid_key_present":(.+?),', self.buffer)
        if present.groups() == ('0', '0'):
            logger.debug('===> this is a fresh unit! ---- need to do program process!')
            self.is_fresh_unit = True
        elif present.groups() == ('1', '1'):
            logger.debug('===> this is NOT a fresh unit! -- SKIP program process!')
            self.is_fresh_unit = False
        else:
            self.is_fresh_unit = None
            raise Exception('check TPM programed failed, unexpected: {}'.format(present))
        # common fail
        if re.search('error|fail', self.buffer, flags=re.I):
            raise Exception('check tpm2 programmed status failed! found error or fail!')

    def cleanup_tpm2_certs(self):
        self.send_wise("./tpm2_manufacture.sh --cleanup", self.bcm_prompt)
        if re.search('error|fail', self.buffer, flags=re.I):
            raise Exception('cleanup TPM2 certs failed! found error or fail!')

    def validate_hdls_pre(self):
        self.send_wise("./tpm2_manufacture.sh --validate-hdls-pre", self.bcm_prompt)
        if 'command not found' in self.buffer:
            raise Exception('command not fond: ./tpm2_manufacture.sh --validate-hdls-pre')
        if 'No such file or directory' in self.buffer:
            raise Exception('No such file or directory')

        # check result
        result = re.search('(\d+) Failures encountered', self.buffer)
        if result is None:
            raise Exception('not found pass criteria: 0 Failures encountered')
        result = result.group(1).strip()
        if result != '0':
            logger.error(f'validate key handlers pre FAILED!, found failures: {result}')
            raise Exception(f'validate key handlers pre FAILED!, found failures: {result}')
        else:
            logger.debug(f'validate key handlers pre PASS, found failures: {result}')

    def retrieve_tpm_fw_version(self):
        """
        ./tpm2_manufacture.sh --get-tpm-fwver
        Machine type is aarch64, skip check for TPM2 table
        Checking TPM2 device manufacturer and model type
          TPM2.0 device IFX : SLB9672
        {
          TPM2.0 FW Version : 16.13.17733.0
        }
        #
        """
        tpm2_fw_version = self.tpm2_fw_version
        self.send_wise("./tpm2_manufacture.sh --get-tpm-fwver", self.bcm_prompt)
        fw_version = re.search('TPM2\.0 FW Version\s*:\s*(.+)', self.buffer)
        if fw_version is None:
            raise Exception('not found tpm2 fw version!')
        fw_version = fw_version.group(1).strip()
        if fw_version != tpm2_fw_version:
            logger.error(
                f'check tpm2 fw version failed! captured tpm2 fw version: {fw_version}, expected: {tpm2_fw_version}')
            raise Exception(
                f'check tpm2 fw version failed! captured tpm2 fw version: {fw_version}, expected: {tpm2_fw_version}')
        logger.debug(f'check tpm2 fw version PASS! captured tpm2 fw version: {fw_version}, expected: {tpm2_fw_version}')
        self.tpm2_fw_version = fw_version

    def run_basic_program_phase(self):
        sn, model = self.sn, self.model

        cmd = f'./tpm2_manufacture.sh --run --phase basic --serial-num {sn} --model {model}'
        self.send_wise('', self.bcm_prompt)
        self.send_wise(cmd, self.bcm_prompt, 120)

        # check result
        result = re.search('(\d+) Failures encountered', self.buffer)
        if result is None:
            raise Exception('not found pass criteria: 0 Failures encountered')
        result = result.group(1)
        if result != '0':
            logger.error(f'run base programming phase FAILED!, found failures: {result}')
            raise Exception(f'run base programming phase FAILED!, found failures: {result}')
        else:
            logger.debug(f'run base programming phase PASS, found failures: {result}')

    def run_advanced_program_phase(self):
        sn, model = self.sn, self.model

        cmd = f'./tpm2_manufacture.sh --run --phase advanced --serial-num {sn} --model {model}'
        self.send_wise('', self.bcm_prompt)
        self.send_wise(cmd, self.bcm_prompt, timeout=120)

        # check result
        result = re.search('(\d+) Failures encountered', self.buffer)
        if result is None:
            raise Exception('not found pass criteria: 0 Failures encountered')
        result = result.group(1)
        if result != '0':
            logger.error(f'run advanced programming phase FAILED!, found failures: {result}')
            raise Exception(f'run advanced programming phase FAILED!, found failures: {result}')
        else:
            logger.debug(f'run advanced programming phase PASS, found failures: {result}')

    def request_csr_file(self):
        cmd = f'./tpm2_manufacture.sh --get-device-csr'
        self.send_wise('', self.bcm_prompt)
        self.send_wise(cmd, self.bcm_prompt)

        temp_cert = re.search('"tpmCertificates":"(.+?)"', self.buffer)
        if temp_cert is None:
            raise Exception('not found temp cert!')
        temp_cert = temp_cert.group(1)
        logger.debug(f'tpm certificates: {temp_cert}')
        # save temp certificate
        self.temp_certificate = temp_cert

    def get_device_cert(self):
        cmd = f'./tpm2_manufacture.sh --get-device-certs'
        self.send_wise('', self.bcm_prompt)
        self.send_wise(cmd, self.bcm_prompt)
        if re.search('fail|error', self.buffer):
            raise Exception('get device certs failed! found error or fail!')

    def show_tpm2_details(self):
        cmd = f'./tpm2_manufacture.sh --show-tpm2-details'
        self.send_wise('', self.bcm_prompt)
        self.send_wise(cmd, self.bcm_prompt)
        jsn_data = re.search('({.*})', self.buffer, flags=re.DOTALL)
        if jsn_data is None:
            raise Exception('not found tpm2 details')
        jsn_data = jsn_data.group(1)
        logger.debug(f'tpm2 details: {jsn_data}')
        return json.loads(jsn_data)

    def forward_csr_to_dlm(self):
        sn = self.sn

        tpm2_details = self.show_tpm2_details()
        machine = platform.node()
        if not self.temp_certificate:
            raise Exception('please ensure csr file is valid!')

        req_data = {
            "bpParams":
                {"TpmCsr": "%s" % self.temp_certificate,
                 "custom":
                     {"Test_Operator_Id": "V1004420@%s" % machine,
                      "TPM_Vendor": "%s" % tpm2_details["TPM_Vendor"],
                      "JNPR_Workflow": "PROD",
                      "cm_code": "FVN_ODM",
                      "FW_Version": self.tpm2_fw_version,
                      "EK_Details_ECC":
                          {
                              "certificate": "%s" % tpm2_details["EK_Details_ECC"]["certificate"],
                              "serial_num": "%s" % tpm2_details["EK_Details_ECC"]["serial_num"]
                          },
                      "EK_Details_RSA":
                          {
                              "certificate": "%s" % tpm2_details["EK_Details_RSA"]["certificate"],
                              "serial_num": "%s" % tpm2_details["EK_Details_RSA"]["serial_num"],
                          },
                      "TPM_Model": "%s" % tpm2_details["TPM_Model"]
                      },
                 "deviceID": "%s" % sn,
                 "op": "issueTpmCertificates"
                 },
            "productID": self.tpm2_product_id
        }

        logger.debug(req_data)

        resp = None
        for i in range(5):
            resp = requests.post(f'http://{self.mid_ip}:{self.mid_port}/pd/device/execute', json=req_data)
            if not resp.ok:
                logger.error(resp.text)
                question = f'tpm2 mid server: {self.mid_ip} response not OK!, please check !'
                if scanner.yes_or_enter_to_continue(question=question) is False:
                    raise Exception(f'tpm2 mid server: {self.mid_ip} response not OK!')
                else:
                    continue
            logger.debug(resp.text)
            break

        payload = resp.json()
        error_code = payload['errorCode']
        error_msg = payload['errorDesc']
        if error_code != 0:
            raise Exception(f'get DLM cert failed! code: {error_code}, msg: {error_msg}')

        data = payload['data']
        session_id = data['sessionID']
        temp_certs = data['tpmCertificates']

        self.session_id = session_id
        self.dlm_cert = temp_certs

        logger.debug(self.session_id)
        logger.debug(self.dlm_cert)
        logger.debug('Get Cert OK!')

    def program_csr_into_tpm2_device(self):
        sn = self.sn
        uut_cert_filename = self.dlm_cert_filename
        logger.debug(f'UUT Cert File: {uut_cert_filename}')
        if not self.dlm_cert:
            raise Exception('not found DLM cert!!')
        self.send_wise(f"echo '{self.dlm_cert}'>{uut_cert_filename}", self.bcm_prompt)

        self.send_wise('', self.bcm_prompt)
        self.send_wise('ls', self.bcm_prompt)

        cmd = f'./tpm2_manufacture.sh --process-csr-rsp --csr-rsp-file {uut_cert_filename} --serial-num {sn}'
        self.send_wise(cmd, self.bcm_prompt)

        # check result
        result = re.search('(\d+) Failures encountered', self.buffer)
        if result is None:
            raise Exception('not found pass criteria: 0 Failures encountered')
        result = result.group(1)
        if result != '0':
            logger.error(f'program csr into tpm2 device FAILED!, found failures: {result}')
            raise Exception(f'program csr into tpm2 device FAILED!, found failures: {result}')
        else:
            logger.debug(f'program csr into tpm2 device PASS, found failures: {result}')

    def verify_program_csr_into_tpm2_device(self):
        sn, model = self.sn, self.model

        items = ['key-hdls', 'nvidx-hdls', 'iak-cert', 'quote', 'idevid-cert', 'tls', 'sign', 'encrypt',
                 'idevid-cert-details', 'iak-cert-details']

        for item in items:
            cmd = f"./tpm2_manufacture.sh --verify --phase advanced --verify-subcmd {item} --serial-num {sn} --model {model}"
            self.send_wise('', self.bcm_prompt)
            self.send_wise(cmd, self.bcm_prompt)
            # check result
            result = re.search('(\d+) Failures encountered', self.buffer)
            if result is None:
                raise Exception('not found pass criteria: 0 Failures encountered')
            result = result.group(1)
            if result != '0':
                if "X509v3 Subject Alternative Name is not set correctly" in self.buffer:
                    self.verify_old_tpm2_file()
                    return
                logger.error(f'verify csr: {item} FAILED!, found failures: {result}')
                raise Exception(f'verify csr: {item} FAILED!, found failures: {result}')
            else:
                logger.debug(f'verify csr: {item} PASS, found failures: {result}')

    def verify_program_csr_into_tpm2_device_old(self):
        sn, model = self.sn, self.model

        items = ['key-hdls', 'nvidx-hdls', 'iak-cert', 'quote', 'idevid-cert', 'tls', 'sign', 'encrypt',
                 'idevid-cert-details', 'iak-cert-details']

        for item in items:
            cmd = f"./tpm2_manufacture.sh --verify --phase advanced --verify-subcmd {item} --serial-num {sn} --model {model}"
            self.send_wise('', self.bcm_prompt)
            self.send_wise(cmd, self.bcm_prompt)
            # check result
            result = re.search('(\d+) Failures encountered', self.buffer)
            if result is None:
                raise Exception('not found pass criteria: 0 Failures encountered')
            result = result.group(1)
            if result != '0':
                logger.error(f'verify csr: {item} FAILED!, found failures: {result}')
                raise Exception(f'verify csr: {item} FAILED!, found failures: {result}')
            else:
                logger.debug(f'verify csr: {item} PASS, found failures: {result}')

    def verify_old_tpm2_file(self):
        self.send_wise('cd', self.bcm_prompt)
        self.tpm2_file = self.tpm2_file_old
        self.tpm2_file_version = self.tpm2_file_version_old
        self.tpm2_file_md5 = self.tpm2_file_md5_old
        self.tpm2_product_id = self.tpm2_product_id_old
        self.delete_old_tpm2_dir()
        self.download_tpm2_tar_file()
        self.extract_tpm2_tar_file()
        self.setup_tpm2_env()
        self.check_tpm2_programmed_status()
        self.verify_program_csr_into_tpm2_device_old()


    def check_version(self):
        vendor, tpm2_file_version = self.tpm2_vendor, self.tpm2_file_version

        cmd = f'./tpm2_manufacture.sh --version'
        self.send_wise('', self.bcm_prompt)
        self.send_wise(cmd, self.bcm_prompt)
        captured_vendor = re.search(r'TPM2\.0 device IFX\s+:\s+(.+)', self.buffer)
        if captured_vendor is None:
            raise Exception('not found vendor!')
        captured_vendor = captured_vendor.group(1).strip()
        if captured_vendor != str(vendor):
            raise Exception(f'tpm2 vendor mismatch! expected: {vendor!r}, captured: {captured_vendor!r}')
        logger.debug(f'tpm2 vendor OK! expected: {vendor}, captured: {captured_vendor}')

        captured_tpm_file_version = re.search(r'(.+-.+\..+)', self.buffer)
        if captured_tpm_file_version is None:
            raise Exception('not found tpm2 file version!')
        captured_tpm_file_version = captured_tpm_file_version.group(1).strip()
        if captured_tpm_file_version != tpm2_file_version:
            raise Exception(
                f'tpm2 file version mismatch! expected: {tpm2_file_version}, captured: {captured_tpm_file_version}')
        logger.debug(f'tpm2 file version OK! expected: {tpm2_file_version}, captured: {captured_tpm_file_version}')

    def check_key_handlers_after_programing(self):
        cmd = './tpm2_manufacture.sh --validate-hdls-post'
        self.send_wise('', self.bcm_prompt)
        self.send_wise(cmd, self.bcm_prompt)

        result = re.search('(\d+) Failures encountered', self.buffer)
        if result is None:
            raise Exception('not found pass criteria: 0 Failures encountered')
        result = result.group(1)
        if result != '0':
            logger.error(f'check key handlers after programming FAILED!, found failures: {result}')
            raise Exception(f'check key handlers after programming FAILED!, found failures: {result}')
        else:
            logger.debug(f'check key handlers after programming PASS, found failures: {result}')

    def show_idevid_details(self):
        sn, vendor, model = self.sn, self.tpm2_vendor, self.model
        cmd = './tpm2_manufacture.sh --show-idevid-details'
        self.send_wise('', self.bcm_prompt)
        self.send_wise(cmd, self.bcm_prompt)

        captured_vendor = re.search(r'TPM2\.0 device IFX\s+:\s+(.+)', self.buffer)
        if captured_vendor is None:
            raise Exception('not found tpm2 vendor')
        captured_vendor = captured_vendor.group(1).strip()
        if captured_vendor != vendor:
            raise Exception(f'check tpm2 FAILED! expected: {vendor}, captured: {captured_vendor}')
        logger.debug(f'check tpm2 PASS! expected: {vendor}, captured: {captured_vendor}')

        captured_sn = re.search(r'serialNumber=(.+)', self.buffer)
        if captured_sn is None:
            raise Exception('not found sn')
        captured_sn = captured_sn.group(1).strip()
        if captured_sn != sn:
            raise Exception(f'check SN FAILED! expected: {sn}, captured: {captured_sn}')
        logger.debug(f'check SN PASS! expected: {sn}, captured: {captured_sn}')

        captured_model = re.search(r'model=(.+)', self.buffer)
        if captured_model is None:
            raise Exception('not found model')
        captured_model = captured_model.group(1).strip()
        if captured_model != model:
            raise Exception(f'check model FAILED! expected: {model}, captured: {captured_model}')
        logger.debug(f'check model PASS! expected: {model}, captured: {captured_model}')

    def finalize_cert(self):
        req_data = {
            "productID": self.tpm2_product_id,
            "bpParams":
                {
                    "op": "finalize",
                    "sessionID": "%s" % self.session_id,

                }
        }

        logger.debug(req_data)

        resp = None
        for i in range(5):
            resp = requests.post(f'http://{self.mid_ip}:{self.mid_port}/pd/device/execute', json=req_data)
            if not resp.ok:
                logger.error(resp.text)
                question = f'tpm2 mid server: {self.mid_ip} response not OK!, please check !'
                if scanner.yes_or_enter_to_continue(question=question) is False:
                    raise Exception(f'tpm2 mid server: {self.mid_ip} response not OK!')
                else:
                    continue
            logger.debug(resp.text)
            break

        payload = resp.json()
        error_code = payload['errorCode']
        error_msg = payload['errorDesc']
        if error_code != 0:
            raise Exception(f'finalize session failed! code: {error_code}, msg: {error_msg}')
        logger.debug(f'finalize session: {self.session_id} OK!')

    def lookup_session(self, session_id=None, expected_state='finalized'):
        session_id = session_id or self.session_id

        req_data = {
            "productID": self.tpm2_product_id,
            "bpParams":
                {
                    "op": "lookup",
                    "deviceID": "%s" % self.sn,
                }
        }

        logger.debug(req_data)

        resp = None
        for i in range(5):
            resp = requests.post(f'http://{self.mid_ip}:{self.mid_port}/pd/device/execute', json=req_data)
            if not resp.ok:
                logger.error(resp.text)
                question = f'tpm2 mid server: {self.mid_ip} response not OK!, please check !'
                if scanner.yes_or_enter_to_continue(question=question) is False:
                    raise Exception(f'tpm2 mid server: {self.mid_ip} response not OK!')
                else:
                    continue
            logger.debug(resp.text)
            break

        payload = resp.json()
        error_code = payload['errorCode']
        error_msg = payload['errorDesc']
        if error_code != 0:
            raise Exception(f'lookup session failed! code: {error_code}, msg: {error_msg}')

        sessions = payload["data"]["sessions"]
        if len(sessions) == 0:
            raise Exception('not found any sessions from Juniper DLM server!')

        # 如果没有session id，但是只有一个session id，且状态是 expected_state，也认为是 PASS
        if not session_id:
            if len(sessions) == 1:
                s_id = sessions[0]['sessionID']
                s_st = sessions[0]['state']
                logger.debug(f'the only one session id: {s_id}, state: {s_st}')
                if s_st == expected_state:
                    logger.debug(f'found the expected state: {expected_state}. PASS')
                    return
                # 状态不对
                raise Exception(f'the only one session: {s_id}\'state: {s_st}, expected: {expected_state}, FAIL')
            else:
                raise Exception('no session id is provided! can not determine the last state!')

        # 在多个 session id 中找到一个和当前session id 一致的
        for ss in sessions:
            s_id = ss['sessionID']
            s_st = ss['state']
            logger.debug(f'checking session id: {s_id}, state: {s_st}')
            if s_id == session_id and s_st == expected_state:
                logger.debug(f'found expected session id: {session_id}, state: {expected_state}')
                break
        else:
            raise Exception(f'not found session id: {session_id}, state: {expected_state}!')

    def do_disconnect(self):
        try:
            self.send_wise('exit', self.mid_prompt)
        except Exception as e:
            self.error(f'exit SSH failed! >> {e}')
        finally:
            self.close()
