from .dcn import DCN


class Quantum(DCN):
    pass
