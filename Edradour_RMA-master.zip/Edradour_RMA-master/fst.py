import re
import time
from functools import wraps
from typing import Callable

from .common.dcn import TimerMeta
from .common.quantum import Quantum
from .common.utils import helper
from .common.fields import StrField, Field
from .common import sfchelper
from .define.define import EX4K, cookie_mapping
from .define import define as df
from .common import machelper
from .common.uut import UUT
from .common.apc import APC
from .common import scanner
from .common.logger import log


class FST(Quantum, metaclass=TimerMeta):
    product_name = 'Edradour'
    sernum = StrField()
    area = 'FT'

    mapping = Field()  # type: EX4K

    uut = None
    pdu = None

    diag_prompt = 'DIAG>'
    u_boot_prompt = 'u-boot>'
    root_re_pmt = 'root@:RE:0%'
    root_cli_pmt = 'root>'
    root_pmt = 'root#'
    poe_version = None
    ignore_fan_alarm = False
    is_fox_uboot = False

    def scan_uut_info(self):
        # 扫描 SN
        # ans = scanner.ask_question(question='Please scan SN label.')
        ans = scanner.ask_question(question='Por favor escanee la etiqueta SN (Numero Serial)')
        self.sernum = ans

        #Fucntion to count failures
        #self.control_ft_fail_times(sn=self.sernum, max_fail_time=1, station=self.area)

        self.check_label(sn=self.sernum)

        if scanner.yes_or_enter_to_continue(
                # question='Please ensure all network cable and SFP are installed!\n请确认所有的网线和SFP已安装'
                #         '\nVui lòng xác nhận tất cả các dây mạng và SFP đã được cài đặt.',
                question='Por favor asegúrese de que todos los cables de red y los SFP (Opticos) estén instalados \n'
                         'Y = Se encuentran Conectados\n',
                image='Edradour/images/traffic.png'
        ) is False:
            raise Exception('operator stop traffic test')

        # search sn pn
        pn = sfchelper.get_label_part_number_from_mes(sn=self.sernum)

        if pn not in cookie_mapping.keys():
            raise Exception(f'Part Number: {pn} is not supported! acceptable list: {list(cookie_mapping.keys())}')
        self.uuttype = pn

        self.mapping = cookie_mapping[pn]
        log.debug(f'SN: {self.sernum}, Label PN:{pn}, uuttype: {self.uuttype}')

        # Double Check mapping APN
        if self.uuttype != self.mapping.apn.r_val:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn r value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn r val: {self.mapping.apn.r_val}. PASS')

        if self.uuttype != self.mapping.apn.w_val:
            raise Exception(f'uuttype({self.uuttype}) mismatch with apn w value({self.mapping.apn.r_val})!')
        else:
            log.debug(f'uuttype: {self.uuttype}, apn w val: {self.mapping.apn.w_val}. PASS')

        # add genius test record
        helper.add_record(sn=self.sernum, pn=self.uuttype, area=self.area)

    def check_mes_event(self):
        self.mes_check_event(sn=self.sernum, area=self.area)

    def query_mes_mac(self):
        mac, size = sfchelper.get_mac_address_from_mes(wsn=self.sernum)
        mac_helper = machelper.MacAddressHelper()
        mac = mac_helper.convert(mac, lower=True, delimiter=':')
        size = int(size)
        self.mac_address, self.mac_block_size = mac, size
        log.debug(f'MAC from MES: {mac}, Size: {size} >> {self.mac_address}, {self.mac_block_size}')

    def read_config(self):
        self.mapping.uut_ip = helper.config['uut_ip']
        self.mapping.serverip = helper.config['serverip']
        self.mapping.netmask = helper.config['netmask']
        self.mapping.gateway = helper.config['gateway']

        # mac 写入的时候是小写的，读取的时候是大写的！
        self.mapping.mac.set(w_val=self.mac_address, r_val=self.mac_address.upper())
        self.mapping.asn.set(w_val=self.sernum, r_val=self.sernum)
        self.mapping.chas_sn.set(w_val=self.sernum, r_val=self.sernum)

        # MES
        rev = sfchelper.get_label_aver_min_from_mes(self.sernum)
        self.mapping.aver_min.set(w_val=rev, r_val=rev)
        self.mapping.arev.set(w_val=rev, r_val=rev)

    def get_uut_console(self):
        self.uut.do_connect(close_before_open=True)

    def setup_uut_network(self):
        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv gatewayip {self.mapping.gateway}', self.u_boot_prompt)

    def check_u_boot_info(self, check):
        if check:
            if "JUNIPER HARDWARE ROOT OF TRUST WITH SECURE BOOT ENFORCED" not in self.uut.buffer:
                log.error("Not found: 'JUNIPER HARDWARE ROOT OF TRUST WITH SECURE BOOT ENFORCED' in Uboot info")
                helper.set_display3("Check TPM Program FAIL")
                raise Exception("Check TPM Program FAIL")
            else:
                log.debug("Found: 'JUNIPER HARDWARE ROOT OF TRUST WITH SECURE BOOT ENFORCED', This unit TPM program done")

        u_boot_mn = re.search(r'Board\s*:\s+(\S+)', self.uut.buffer)
        if u_boot_mn is None:
            helper.quick_set('Not found U Boot Model')
            raise Exception('not found u boot Model!!')
        u_boot_mn = u_boot_mn.group(1)
        if u_boot_mn != self.mapping.platform:
            helper.quick_set('U Boot Model Mismatch')
            log.error(f'u boot model match! expected: {self.mapping.platform}, captured: {u_boot_mn}. FAIL')
            raise Exception(f'u boot model mismatch! expected: {self.mapping.platform}, captured: {u_boot_mn}. FAIL')
        log.debug(f'u boot model match! expected: {self.mapping.platform}, captured: {u_boot_mn}. PASS')

        u_boot_sn = re.search(r'Serial\s*:\s+(\S+)', self.uut.buffer)
        if u_boot_sn is None:
            helper.quick_set('Not found U Boot SN')
            raise Exception('not found u boot SN!')
        u_boot_sn = u_boot_sn.group(1)
        if u_boot_sn != self.sernum:
            helper.quick_set('U Boot SN Mismatch')
            log.error(f'u boot sn match! expected: {self.sernum}, captured: {u_boot_sn}. FAIL')
            raise Exception(f'u boot sn mismatch! expected: {self.sernum}, captured: {u_boot_sn}. FAIL')
        log.debug(f'u boot sn match! expected: {self.sernum}, captured: {u_boot_sn}. PASS')

        u_boot_base_mac = re.search(r'Base MAC\s*:\s+(\S+)', self.uut.buffer)
        if u_boot_base_mac is None:
            helper.quick_set('Not found U Boot MAC')
            raise Exception('not found u boot base MAC!')
        u_boot_base_mac = u_boot_base_mac.group(1)
        if u_boot_base_mac != self.mapping.mac.r_val:
            helper.quick_set('U Boot MAC Mismatch')
            log.error(f'u boot base mac match! expected: {self.mapping.mac.r_val}, captured: {u_boot_base_mac}. FAIL')
            raise Exception(
                f'u boot base mac mismatch! expected: {self.mapping.mac.r_val}, captured: {u_boot_base_mac}. FAIL')
        log.debug(f'u boot base mac match! expected: {self.mapping.mac.r_val}, captured: {u_boot_base_mac}. PASS')

    def check_u_boot_version(self):
        self.quick_set('Check Primary U Boot')
        # change to 1
        self.switch_to_primary_u_boot('a')
        # update u boot, flash is locked! so skip... 2024-11-08
        self.update_u_boot_version('1')
        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(f'[Pass Criteria] primary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception(f'expected primary u boot version: {self.mapping.u_boot_version}, captured: {self.uut.buffer}, FAIL')
        else:
            log.debug(f'[Pass Criteria] primary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: PASS')

        self.quick_set('Check Secondary U Boot')
        # change to 2
        # self.uut.send_wise('fatrm mmc 0 efi/boot/UpdateCapsule/uboot_dev_cap', self.u_boot_prompt)
        self.switch_to_secondary_u_boot()
        # update u boot, flash is locked! so skip... 2024-11-08
        # self.update_u_boot_version('2')
        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(f'[Pass Criteria] secondary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception(f'expected secondary u boot version: {self.mapping.u_boot_version}, captured: {self.uut.buffer}, FAIL')
        else:
            log.debug(f'[Pass Criteria] secondary u boot version: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: PASS')

        # change back to 1
        self.switch_to_primary_u_boot('b')

    def switch_to_primary_u_boot(self, plan):
        log.debug('switch to primary u boot bank(1)')
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x39 0x2', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x8 0x1a', self.u_boot_prompt)
        if plan == 'a':
            self.uut.send_wise('i2c mw 0x31 0x9 0x1', '')

        # 两颗uboot 更新完后这个地方应该要OK
        elif plan == 'b':
            self.uut.send_wise('i2c mw 0x31 0x9 0x1', 'Validate Shmoo parameters stored in flash ..... OK')
            log.debug('Check Validate Shmoo parameters stored in flash ..... OK')

        boot_bank = self.wait_for_u_boot2()
        if boot_bank != '1':
            log.error(f'switch to primary u boot failed! expected boot bank: 1, but now is: {boot_bank}')
            raise Exception(f'switch to primary u boot failed! expected boot bank: 1, but now is: {boot_bank}')
        log.debug(f'switch to u boot bank: {boot_bank} OK')
        return boot_bank

    def update_u_boot_version(self, boot_bank):
        log.debug(f'update u boot bank: {boot_bank}')

        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version in self.uut.buffer:
            log.debug(f'{boot_bank} u boot version is the latest! {self.mapping.u_boot_version}')
            log.debug(f'[Pass Criteria]{boot_bank} u boot version is: {self.mapping.u_boot_version}, expect value:{self.mapping.u_boot_version}, result: PASS')
            self.is_fox_uboot = True
            return

        self.uut.send_wise('fatls  mmc 0:1', self.u_boot_prompt)
        if 'No partition table - mmc 0' in self.uut.buffer:

            self.boot_diag()

            self.uut.send_wise('exit', "login:")
            self.uut.send_wise('root', "#")
            self.uut.send_wise('fdisk /dev/mmcblk0', "Command")
            self.uut.send_wise('n', "primary partition")
            self.uut.send_wise('p', "number")
            self.uut.send_wise('1', "")
            self.sleep_time(1)
            self.uut.send_wise('', "")
            self.sleep_time(1)
            self.uut.send_wise('', "Command")
            self.uut.send_wise('t', "(type L to list codes)")
            self.uut.send_wise('b', "Command")
            self.uut.send_wise('w', "#")
            self.uut.send_wise('mkfs.vfat /dev/mmcblk0p1', "#")
            self.uut.send_wise('reboot', "#")

            # set boot env
            self.wait_for_u_boot()

        log.warning(f'u boot bank: {boot_bank}, need upgrade to version: {self.mapping.u_boot_version}')

        self.uut.send_wise(f'fatrm mmc 0:1 /efi/boot/UpdateCapsule/uboot_prd_cap', self.u_boot_prompt)
        self.uut.send_wise(f'fatrm mmc 0:1 /efi/boot/UpdateCapsule/uboot_dev_cap', self.u_boot_prompt)
        self.uut.send_wise(f'fatrm mmc 0:1 /efi/boot/UpdateCapsule/flash_image', self.u_boot_prompt)

        self.uut.send_wise(f'fatmkdir mmc 0:1 /efi', self.u_boot_prompt)
        self.uut.send_wise(f'fatmkdir mmc 0:1 /efi/boot', self.u_boot_prompt)
        self.uut.send_wise(f'fatmkdir mmc 0:1 /efi/boot/UpdateCapsule', self.u_boot_prompt)

        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # self.uut.send_wise(f'setenv gatewayip {self.mapping.gateway}', self.u_boot_prompt)

        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.u_boot_file}', self.u_boot_prompt)

            if 'TFTP server died' in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(question='TFTP server is died, call TE') is False:
                    raise Exception('tftp server is not online!')
                continue

            if 'Bytes transferred =' not in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(
                        question='not found "Bytes transferred =" in uut buffer, retry?') is False:
                    raise Exception('not found "Bytes transferred =" in uut buffer!')
                continue
            break

        self.uut.send_wise('fatwrite  mmc 0:1 ${loadaddr} efi/boot/UpdateCapsule/uboot_dev_cap 0x800000;', self.u_boot_prompt)
        self.uut.send_wise('fatwrite  mmc 0:1 ${loadaddr} efi/boot/UpdateCapsule/do_upgrade 0;', self.u_boot_prompt)

        self.uut.send_wise('reset', '')
        self.wait_for_u_boot()
        self.uut.send_wise('', self.u_boot_prompt)

        self.uut.send_wise('version', self.u_boot_prompt)
        if self.mapping.u_boot_version not in self.uut.buffer:
            log.error(
                f'[Pass Criteria]{boot_bank} u boot version is: {self.uut.buffer}, expect value:{self.mapping.u_boot_version}, result: FAIL')
            raise Exception(f'upgrade u boot failed!')
        log.debug(f'boot bank: {boot_bank}\' u boot version is the latest. {self.mapping.u_boot_version}')
        log.debug(
        f'[Pass Criteria]{boot_bank} u boot version is: {self.mapping.u_boot_version}, expect value:{self.mapping.u_boot_version}, result: PASS')

    def switch_to_secondary_u_boot(self):
        log.debug('switch to secondary u boot bank(2)')
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x39 0x3', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x8 0x1a', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x9 0x1', '')
        boot_bank = self.wait_for_u_boot2()
        if boot_bank != '2':
            log.error(f'switch to primary u boot failed! expected boot bank: 2, but now is: {boot_bank}')
            raise Exception(f'switch to primary u boot failed! expected boot bank: 2, but now is: {boot_bank}')
        log.debug(f'switch to u boot bank: {boot_bank} OK')
        return boot_bank

    def boot_diag(self):
        if self.is_fox_uboot:
            return helper.SKIP
        self.setup_u_boot_env()

        # download DIAG
        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.diag_file}', self.u_boot_prompt, 300)
            if 'Bytes transferred =' not in self.uut.buffer:
                self.error(f'download diag file failed, edradour/{self.mapping.diag_file}')
                if scanner.yes_or_enter_to_continue(
                        question=f'Download DIAG img failed! retest? '
                                 f'下载DIAG文件失败！重试？'
                                 f'Tải xuống tệp DIAG không thành công! Thử lại?') is False:
                    raise Exception(f'download diag img file failed!')
                continue
            break

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('bootm ${loadaddr}#wh3p',
                               '')
        else:
            self.uut.send_wise('bootm ${loadaddr}#wh3pe',
                               '')

        self.uut.waitfor(self.diag_prompt, 600)

        # diag version
        self.uut.send_wise('version', self.diag_prompt)
        diag_version = re.search(r'DIAG\s*:\s*(.*)', self.uut.buffer)
        if diag_version is None:
            log.error(
                f'[Pass Criteria] diag version: None, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('not found diag version!!')
        diag_version = diag_version.group(1).strip()
        if diag_version != self.mapping.diag_version:
            log.error(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: FAIL')
            raise Exception('diag version not match!!')
        log.debug(
            f'[Pass Criteria] diag version: {diag_version}, expect value:{self.mapping.diag_version}, result: PASS')

    def setup_u_boot_env(self):
        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=1008M'", self.u_boot_prompt)
        # self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"', self.u_boot_prompt)

        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)
        # self.uut.send_wise(f"setenv diag_file Edradour_DIAG_v2.0.6_uImage_initramfs.img", self.u_boot_prompt)

        # if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
        #     self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3p"',
        #                        self.u_boot_prompt)
        # else:
        #     self.uut.send_wise('setenv bootcmd "mmc read ${loadaddr} 0 102400;bootm ${loadaddr}#wh3pe"',
        #                        self.u_boot_prompt)

    def create_vfat_paration(self):
        if self.is_fox_uboot:
            return helper.SKIP
        self.uut.send_wise('exit', "login:")
        self.uut.send_wise('root', "#")
        self.uut.send_wise('fdisk /dev/mmcblk0', "Command")
        self.uut.send_wise('n', "primary partition")
        self.uut.send_wise('p', "number")
        self.uut.send_wise('1', "")
        self.sleep_time(1)
        self.uut.send_wise('', "")
        self.sleep_time(1)
        self.uut.send_wise('', "Command")
        self.uut.send_wise('t', "(type L to list codes)")
        self.uut.send_wise('b', "Command")
        self.uut.send_wise('w', "#")

        self.uut.send_wise('mkfs.vfat /dev/mmcblk0p1', "#")
        self.uut.send_wise('reboot', "#")

        # set boot env
        self.wait_for_u_boot()
        self.setup_u_boot_env2()

        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv ethaddr {self.mac_address}', self.u_boot_prompt)
        # download DIAG
        while True:
            self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.diag_file}', self.u_boot_prompt, 360)
            if 'Bytes transferred =' not in self.uut.buffer:
                self.error(f'download diag file failed, edradour/{self.mapping.diag_file}')
                if scanner.yes_or_enter_to_continue(
                        question=f'Download DIAG img failed! retest? '
                                 f'下载DIAG文件失败！重试？'
                                 f'Tải xuống tệp DIAG không thành công! Thử lại?') is False:
                    raise Exception(f'download diag img file failed!')
                continue
            break

        self.uut.send_wise('fatwrite mmc 0 0x6a000000 /${diag_file} ${filesize}', self.u_boot_prompt)

        self.uut.send_wise('run bootcmd', '')
        self.uut.waitfor(self.diag_prompt, 360)
        self.sleep_time(5)

    def setup_u_boot_env2(self):
        self.uut.send_wise(f'setenv ipaddr {self.mapping.uut_ip}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv netmask {self.mapping.netmask}', self.u_boot_prompt)
        self.uut.send_wise(f'setenv serverip {self.mapping.serverip}', self.u_boot_prompt)

        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)

    def enter_diag_mode(self):
        if not self.is_fox_uboot:
            return
        self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
        self.uut.send_wise(f"setenv diag_file {self.mapping.diag_file}", self.u_boot_prompt)

        if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                               self.u_boot_prompt)
        else:
            self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                               self.u_boot_prompt)
        self.uut.send_wise('run bootcmd', [self.diag_prompt, self.u_boot_prompt], 600)
        if "Wrong Image Format" in self.uut.buffer:
            self.uut.send_wise(f"setenv bootargs 'console=ttyS0,9600n8 maxcpus=4 mem=3500M'", self.u_boot_prompt)
            self.uut.send_wise(f"setenv diag_file {self.mapping.old_diag_file}", self.u_boot_prompt)

            if self.mapping.platform in {df.MN_EX4000_48T, df.MN_EX4000_48P, df.MN_EX4000_48MP}:
                self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3p"',
                                   self.u_boot_prompt)
            else:
                self.uut.send_wise('setenv bootcmd "fatload mmc 0:1 ${loadaddr} ${diag_file};bootm ${loadaddr}#wh3pe"',
                                   self.u_boot_prompt)
            self.uut.send_wise('run bootcmd', self.diag_prompt, 600)

        diag_platform = re.search(r'\*\s+Platform:\s+(.+)', self.uut.buffer)
        if diag_platform is None:
            raise Exception(f'not found platform: {self.mapping.platform} in DIAG')
        diag_platform = diag_platform.group(1).strip()
        if diag_platform != self.mapping.platform:
            raise Exception(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, FAIL')
        log.debug(f'diag platform, expected: {self.mapping.platform}, captured: {diag_platform}, PASS')

        self.quick_set('Check DIAG Part Number')
        diag_pn = re.search(r'\*\s+Part Number:\s+(.+)', self.uut.buffer)
        if diag_pn is None:
            raise Exception(f'not found part numer: {self.mapping.platform} in DIAG')
        diag_pn = diag_pn.group(1).strip()
        if diag_pn != self.mapping.apn.r_val:
            raise Exception(f'diag platform, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, FAIL')
        log.debug(f'diag part number, expected: {self.mapping.apn.r_val}, captured: {diag_pn}, PASS')

    def led_check(self):

        if self.mapping.platform in ['EX4000-48MP', 'EX4000-48P', 'EX4000-48T']:
            img_front_on = 'check_led_on_48.png'
            img_front_off = 'check_led_off_48.png'
        elif self.mapping.platform in ['EX4000-24MP', 'EX4000-24P', 'EX4000-24T']:
            img_front_on = 'check_led_on_24.png'
            img_front_off = 'check_led_off_24.png'
        elif self.mapping.platform in ['EX4000-12MP', 'EX4000-12P', 'EX4000-12T']:
            img_front_on = 'check_led_on_12.png'
            img_front_off = 'check_led_off_12.png'
        else:
            img_front_on = 'check_led_on_8.png'
            img_front_off = 'check_led_off_8.png'

        self.uut.send_wise('ethledwrite all left sgr', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right sgr', self.diag_prompt)
        self.uut.send_wise('ledwrite 3 1', self.diag_prompt)
        self.uut.send_wise('ledwrite 4 1', self.diag_prompt)
        self.uut.send_wise('ledwrite 7 1', self.diag_prompt)
        if ('24' in self.mapping.platform) or ('48' in self.mapping.platform):
            scanner.get_right_answer(
                question=f'\nPor favor confirme que todas las luces del panel frontal estén ENCENDIDAS\n'
                         f'Responda PASS si se encuentran Encendidas\n'
                         f'Responda FAIL si no es el caso',
                answers=['PASS', 'FAIL'],
                retry=1,
                right_answer='PASS',
                image=f'Edradour/images/{img_front_on}'
            )
            log.debug('OP confirm front panel all LED ON')
            scanner.get_right_answer(
                question=f'\nPor favor confirme que todas las luces del panel trasero estén ENCENDIDAS\n'
                         f'Responda PASS si se encuentran Encendidas\n'
                         f'Responda FAIL si no es el caso',
                answers=['PASS', 'FAIL'],
                retry=1,
                right_answer='PASS',
                image=f'Edradour/images/check_back_led_on.png'
            )
            log.debug('OP confirm back panel all LED ON')
        else:
            scanner.get_right_answer(
                question=f'\nPor favor confirme que todas las luces del panel frontal estén ENCENDIDAS\n'
                         f'Responda PASS si se encuentran Encendidas\n'
                         f'Responda FAIL si no es el caso',
                answers=['PASS', 'FAIL'],
                retry=1,
                right_answer='PASS',
                image=f'Edradour/images/{img_front_on}'
            )
            log.debug('OP confirm front panel all LED ON')

        self.uut.send_wise('ethledwrite all left off', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right off', self.diag_prompt)
        self.uut.send_wise('ledwrite 3 0', self.diag_prompt)
        self.uut.send_wise('ledwrite 4 0', self.diag_prompt)
        self.uut.send_wise('ledwrite 7 0', self.diag_prompt)
        if ('24' in self.mapping.platform) or ('48' in self.mapping.platform):
            scanner.get_right_answer(
                question=f'\nPor favor confirme que todas las luces del panel frontal estén APAGADAS\n'
                         f'Responda PASS si se encuentran Apagadas\n'
                         f'Responda FAIL si no es el caso',
                answers=['PASS', 'FAIL'],
                retry=1,
                right_answer='PASS',
                image=f'Edradour/images/{img_front_off}'
            )
            log.debug('OP confirm front panel all LED OFF')
            scanner.get_right_answer(
                question=f'\nPor favor confirme que todas las luces del panel trasero estén APAGADAS\n'
                         f'Responda PASS si se encuentran Apagadas\n'
                         f'Responda FAIL si no es el caso',
                answers=['PASS', 'FAIL'],
                retry=1,
                right_answer='PASS',
                image=f'Edradour/images/check_back_led_off.png'
            )
            log.debug('OP confirm back panel all LED OFF')
        else:
            scanner.get_right_answer(
                question=f'\nPor favor confirme que todas las luces del panel frontal estén APAGADAS'
                         f'Responda PASS si se encuentran Apagadas\n'
                         f'Responda FAIL si no es el caso',
                answers=['PASS', 'FAIL'],
                retry=1,
                right_answer='PASS',
                image=f'Edradour/images/{img_front_off}'
            )
            log.debug('OP confirm front panel all LED OFF')

        # 全部恢复默认状态
        self.uut.send_wise('ethledwrite all left dis', self.diag_prompt)
        self.uut.send_wise('ethledwrite all right dis', self.diag_prompt)

        self.uut.send_wise('reboot', "")
        self.wait_for_u_boot()

    def update_to_juniper_bootloader(self):
        """
        分别检查两个flash的U Boot，暂时这样吧
        """
        # first flash

        if self.mapping.jnpr_uboot == 'uboot-2.8-upgrade-MFG-PRD-jHRoT.img':
            log.debug('update first flash to JNPR U Boot...')
            self.setup_uut_network()
            while True:
                try:
                    self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.jnpr_uboot}', self.u_boot_prompt)

                    if 'TFTP server died' in self.uut.buffer:
                        if scanner.yes_or_enter_to_continue(question='TFTP server is died, call TE') is False:
                            raise Exception('tftp server is not online!')
                        continue

                    if 'Bytes transferred =' not in self.uut.buffer:
                        if scanner.yes_or_enter_to_continue(
                                question='not found "Bytes transferred =" in uut buffer, retry?') is False:
                            raise Exception('not found "Bytes transferred =" in uut buffer!')
                        continue
                    # OK
                    break
                except Exception as e:
                    if scanner.yes_or_enter_to_continue(question=f"Download uboot fail: {e}") is False:
                        raise Exception(f"Download uboot fail: {e}")

            self.uut.send_wise('mmc write 0x6a000000 0 102400', self.u_boot_prompt)
        else:
            log.debug('update first flash to JNPR U Boot...')
            self.uut.send_wise(f'fatmkdir mmc 0:1 /efi', self.u_boot_prompt)
            self.uut.send_wise(f'fatmkdir mmc 0:1 /efi/boot', self.u_boot_prompt)
            self.uut.send_wise(f'fatmkdir mmc 0:1 /efi/boot/UpdateCapsule', self.u_boot_prompt)
            self.setup_uut_network()
            while True:
                self.uut.send_wise(f'tftpboot 0x6a000000 edradour/{self.mapping.jnpr_uboot}', self.u_boot_prompt)

                if 'TFTP server died' in self.uut.buffer:
                    if scanner.yes_or_enter_to_continue(question='TFTP server is died, call TE') is False:
                        raise Exception('tftp server is not online!')
                    continue

                if 'Bytes transferred =' not in self.uut.buffer:
                    if scanner.yes_or_enter_to_continue(
                            question='not found "Bytes transferred =" in uut buffer, retry?') is False:
                        raise Exception('not found "Bytes transferred =" in uut buffer!')
                    continue
                break
            self.uut.send_wise('fatwrite  mmc 0:1 ${loadaddr} efi/boot/UpdateCapsule/uboot_prd_cap 0x800000;', self.u_boot_prompt)
            self.uut.send_wise('fatwrite  mmc 0:1 ${loadaddr} efi/boot/UpdateCapsule/do_upgrade 0;', self.u_boot_prompt)

            self.uut.send_wise('reset', '')

            self.wait_for_u_boot(check=False)
            self.uut.send_wise('', self.u_boot_prompt)

    def check_tpm_program(self):
        log.debug('change to First Flash...')
        time.sleep(1)
        self.uut.send_wise('', self.u_boot_prompt)
        self.uut.send_wise('i2c dev 0', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x39 0x2', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x8 0x1a', self.u_boot_prompt)
        # self.uut.send_wise('i2c mw 0x31 0x9 0x1', self.u_boot_prompt)
        self.uut.send_wise('i2c mw 0x31 0x9 0x1', ['Hit any key to stop autoboot:', self.u_boot_prompt], 600)
        if 'Hit any key to stop autoboot:' in self.uut.buffer:
            self.check_u_boot_info(check=True)
            self.uut.send_esc(self.u_boot_prompt)

    def set_parameters(self):
        self.setup_uut_network()
        self.uut.send_ctrl_c(self.u_boot_prompt)
        # self.uut.send_wise(
        #     'setenv bootargs "maker=Juniper hw.board.name=${hw.board.name} hw.board.maccount=${hw.board.maccount} '
        #     'hw.board.serialno=${hw.board.serialno} hw.board.macbase=$ethaddr uboot.ethaddr=$ethaddr '
        #     'hw.board.reset=16 boot_function=0 boot_phase=7 console=efi vfs.root.mountfrom=cd9660:/dev/md0.uzip '
        #     'rootdev= ipaddr=${ipaddr} netmask=${netmask} gatewayip=${gatewayip} serverip=${serverip}"',
        #     self.u_boot_prompt)
        self.uut.send_wise("setenv bootargs DUMMY=1 ipaddr=${ipaddr} netmask=${netmask} gatewayip=${gatewayip} serverip=${serverip} rootdev=net0: ${bootargs}", self.u_boot_prompt)


    def tftp_efi(self):
        while True:
            self.uut.send_wise('tftpboot ${loadaddr} edradour/bootaa64.efi', self.u_boot_prompt)
            if 'done' not in self.uut.buffer:
                if scanner.yes_or_enter_to_continue(question='download efi failed! retry?') is False:
                    raise Exception('download efi failed!')
                continue
            break

        log.debug('tftp download efi OK..')

    def boot_efi(self):
        #
        self.uut.send_wise('bootefi ${loadaddr}', "Type '?' for a list of commands, 'help' for more detailed help.")
        self.uut.send_wise('', 'OK')
        # self.uut.send_enter('OK', 15 * 60)

    def login_junos(self):
        self.uut.send_wise('', 'login:')
        # self.sleep_time(10 * 60)
        self.uut.send_wise('root', [self.root_re_pmt, 'Password:'])
        if 'Password:' in self.uut.buffer:
            self.uut.send_wise(self.mapping.junos_root_password, [self.root_re_pmt, 'login:'])
            if 'Login incorrect' in self.uut.buffer:
                raise Exception('incorrect root password!')
        self.uut.send_wise('', self.root_re_pmt)

    def install_junos(self):
        for i in range(5):
            self.sleep_time(3)
            self.uut.send_wise(f'install tftp://{self.mapping.serverip}/edradour/{self.mapping.junos_file}', '')
            try:
                self.uut.waitfor(['login:'], 15 * 60)
            except:
            # 重新下载
                log.warning('wait login timeout, retry...')
                self.pdu.power_cycle(helper.config['pdu_port'])
                self.wait_for_u_boot()
                self.update_to_juniper_bootloader()
                self.set_parameters()
                self.tftp_efi()
                self.boot_efi()
                continue

            break
        else:
            raise Exception('install JUNOS failed! max retry!')

        # sleep some time
        self.sleep_time(5 * 60)
        # login JUNOS
        self.login_junos()

    def delete_auto_message(self):
        # if self.mapping.group in [df.GROUP_2, df.GROUP_3]:
        #     return helper.SKIP

        # self.uut.send_wise('root', self.root_re_pmt)
        self.sleep_time(3)
        self.uut.send_wise('cli', self.root_cli_pmt)
        self.sleep_time(3)
        self.uut.send_wise('edit', 'root#')

        self.sleep_time(1 * 60)
        self.uut.send_wise('set system root-authentication plain-text-password', 'New password:')
        self.uut.send_wise(self.mapping.junos_root_password, 'Retype new password:')
        self.uut.send_wise(self.mapping.junos_root_password, 'root#')
        self.sleep_time(1)
        self.uut.send_wise('delete chassis auto-image-upgrade', 'root#')

        # 删除自动升级提示
        # for i in range(5):
        #    self.uut.send_wise('delete chassis auto-image-upgrade', 'root#')
        #    if 'statement not found' in self.uut.buffer or 'warning' in self.uut.buffer:
        #        log.warning(f'delete chassis auto-image-upgrade failed! retry: {i + 1}')
        #        time.sleep(3)
        #        continue
        #    # OK
        #    break
        # else:
        #    raise Exception(f'delete chassis auto-image-upgrade failed. exceed max retry!')

        self.uut.send_wise('commit', 'root#')
        # 回到Cli模式下
        self.sleep_time(1 * 60)
        self.uut.send_wise('exit', self.root_cli_pmt)

    def poe_fw_upgrade(self):
        """
        Firmware upgrade initiated. Poe Upgrade takes about 10 minutes
        Use 'show poe controller' to get the download status,
        Please Reboot the system after Upgrade is complete
        """
        if 'P' not in self.mapping.platform:
            return helper.SKIP

        # self.sleep_time(90)
        # log.debug('sleep 90 seconds and wait for FPC 0 online...')
        for i in range(15):
            self.uut.send_wise(
                'request system firmware upgrade poe fpc-slot 0',
                self.root_cli_pmt)
            if "Firmware upgrade initiated." in self.uut.buffer:
                break
            if 'Upgrade in progress...' in self.uut.buffer:
                break
            log.debug(f'waiting for upgrading PoE firmware ... {i + 1}')
            self.sleep_time(30)
        else:
            raise Exception('upgrade poe firmware failed!')

        self.sleep_time(1 * 60)

        # self.uut.send_wise('show poe controller | refresh 120', '')
        for i in range(25):
            self.uut.send_wise('show poe controller', self.root_cli_pmt)
            if 'BT_MODE' in self.uut.buffer:
                log.debug('found BT_MODE. BREAK...')
                break
            log.debug('not found BT_MODE. continue...')
            if 'AT_MODE' in self.uut.buffer:
                log.debug('found AT_MODE. BREAK...')
                break
            log.debug('not found AT_MODE. continue...')
            self.sleep_time(60)
        else:
            raise Exception('show poe controller failed!')

        # reboot
        self.uut.send_wise('request system reboot', '[yes,no] (no)')
        self.uut.send_wise('yes', 'login:', 5 * 60)
        self.sleep_time(300)
        self.login_junos()
        self.uut.send_wise('cli', self.root_cli_pmt)

        self.check_system_firmware()

    def poe_fw_version(self):
        # if self.mapping.group in [df.GROUP_2, df.GROUP_3]:
        #     return helper.SKIP

        for i in range(5):
            self.uut.send_wise('show chassis firmware detail', self.root_cli_pmt)
            poe_firmware_version = re.search(r'PoE firmware\s+(.+)', self.uut.buffer)
            if poe_firmware_version is None:
                log.debug('not found PoE firmware version, retry....')
                log.debug('sleep 60 seconds')
                time.sleep(60)
                continue
            poe_firmware_version = poe_firmware_version.group(1).strip()
            if poe_firmware_version != self.mapping.junos_poe_firmware_version:
                log.error('PoE firmware version mismatch!!')
                log.error(
                    f'expected PoE firmware version: {self.mapping.junos_poe_firmware_version}, captured PoE firmware version: {poe_firmware_version}, FAIL')
                raise Exception('PoE firmware version mismatch')
            log.debug('Check PoE firmware version OK...')
            log.debug(
                f'expected PoE firmware version: {self.mapping.junos_poe_firmware_version}, captured PoE firmware version: {poe_firmware_version}, PASS')
            break
        else:
            raise Exception('poe_fw_version failed!!')

        self.uut.send_wise('show poe controller', self.root_cli_pmt)
        self.uut.send_wise('show poe interface | no-more', self.root_cli_pmt)
        # self.uut.send_wise('show log messages| grep FW_DNLD | grep fpc0', self.root_cli_pmt)

    def power_cycle_3x(self):
        for i in range(3):
            self.power_cycle_u_boot()

    def power_cycle_u_boot(self):
        # msg = '[U BOOT] Please power cycle UUT. 请拔下电源然后重新上电'
        # if scanner.yes_or_enter_to_continue(question=msg) is False:
        #     raise Exception('power cycle UUT failed! operator!')
        # self.pdu.power_cycle(helper.config['pdu_port'])
        while True:
            try:
                self.pdu.power_off(helper.config['pdu_port'])
                self.sleep_time(2)
                self.pdu.power_on(helper.config['pdu_port'])
                log.debug('Send command')
                log.debug('power on Send command')
                self.uut.send_wise('', 'U-Boot', 30)
                log.debug('command sent')
                break
            except Exception as e:
                if scanner.yes_or_enter_to_continue(
                        question='(Pre Check Step 2)\n'
                                'Vui lòng kiểm tra lại nguồn điện và cáp đã được kết nối tốt chưa\n'
                                 'Please check the power supply and cables are connected well again',
                        image='Edradour/images/check_power_console.png',
                ) is False:
                    raise Exception('OP Stop Test!')
        self.wait_for_u_boot(check=False)

    def power_cycle_junos(self):
        self.pdu.power_cycle(helper.config['pdu_port'])
        self.uut.send_wise('', 'login:', timeout=300)

    def wait_for_u_boot2(self):
        self.uut.waitfor(['Hit any key to stop autoboot', 'Do you want to run the Shmoo? [y/N]',
                          '*** U-Boot Boot Menu ***', self.u_boot_prompt],
                         600)
        log.debug(f'found -> {self.uut.foundphrase}')
        # Current Boot Bank: 	1
        current_boot_bank = re.search(r'Current Boot Bank:\s+(\d+)', self.uut.buffer)
        if current_boot_bank is not None:
            current_boot_bank = current_boot_bank.group(1)
        log.debug(f'current boot bank: {current_boot_bank}')

        # check U Boot Info
        self.check_u_boot_info(check=False)

        # JNPR U BOOT
        if '*** U-Boot Boot Menu ***' in self.uut.buffer:
            time.sleep(0.5)
            self.uut.send_esc(['Hit any key to stop autoboot', self.u_boot_prompt])
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Do you want to run the Shmoo? [y/N]' in self.uut.buffer:
            self.uut.send_wise('N', ['Hit any key to stop autoboot', self.u_boot_prompt], 150, suffix='')
            log.debug(f'found -> {self.uut.foundphrase}')

        if 'Hit any key to stop autoboot' in self.uut.buffer:
            self.uut.send_esc(self.u_boot_prompt)
            log.debug(f'found -> {self.uut.foundphrase}')

        time.sleep(1)
        self.uut.send_ctrl_c(self.u_boot_prompt)
        return current_boot_bank

    def wait_for_u_boot(self, check=False):
        self.uut.waitfor(['Hit any key to stop autoboot', self.u_boot_prompt, 'Do you want to run the Shmoo? [y/N]',
                          '*** U-Boot Boot Menu ***'],
                         600)

        # check U Boot Info
        self.check_u_boot_info(check)

        # JNPR U BOOT
        if '*** U-Boot Boot Menu ***' in self.uut.buffer:
            time.sleep(0.5)
            self.uut.send_esc(['Hit any key to stop autoboot', self.u_boot_prompt])

        if 'Do you want to run the Shmoo? [y/N]' in self.uut.buffer:
            self.uut.send_wise('N', ['Hit any key to stop autoboot', self.u_boot_prompt], 150, suffix='')

        if 'Hit any key to stop autoboot' in self.uut.buffer:
            for i in range(5):
                try:
                    self.uut.send_esc('', 5)
                    self.uut.send_enter(self.u_boot_prompt, 5)
                except:
                    pass
                break

        time.sleep(1)
        self.uut.send_ctrl_c([self.u_boot_prompt], 600)

    def check_chassis_info(self):
        # if self.mapping.group in [df.GROUP_2, df.GROUP_3]:
        #     return helper.SKIP

        self.check_junos_version()
        self.check_chassis_hardware()

    def check_junos_version(self):
        self.uut.send_wise('show version | no-more', self.root_cli_pmt)
        # 检查 Model
        captured_model = re.search(r'Model: ([^\r\n]+)', self.uut.buffer)
        if captured_model is None:
            log.error(f'[Pass Criteria] Model capture: None, expect: {self.mapping.platform.lower()}, result: FAIL')
            raise Exception('not found Model!!')
        captured_model = captured_model.group(1).strip()
        if captured_model != self.mapping.platform.lower():
            log.error('model mismatch!!!')
            log.error(f'[Pass Criteria] Model capture: {captured_model}, expect: {self.mapping.platform.lower()}, result: FAIL')
            raise Exception('model mismatch!!!')
        log.debug('model match!!!')
        log.debug(f'[Pass Criteria] Model capture: {captured_model}, expect: {self.mapping.platform.lower()}, result: PASS')

        # 检查JUNOS version
        captured_junos_ver = re.search(r'Junos: ([^\r\n]+)', self.uut.buffer)
        if captured_junos_ver is None:
            log.error(f'[Pass Criteria] JUNOS version capture: None, expect: {self.mapping.junos_version}, result: FAIL')
            raise Exception('not found JUNOS version!!!')
        captured_junos_ver = captured_junos_ver.group(1)
        log.debug(f'Captured JUNOS version: {captured_junos_ver}')
        log.debug(f'Expected JUNOS version: {self.mapping.junos_version}')
        if captured_junos_ver != self.mapping.junos_version:
            log.error('JUNOS version mismatch!!')
            log.error(
                f'[Pass Criteria] JUNOS version capture: {captured_junos_ver}, expect: {self.mapping.junos_version}, result: FAIL')
            raise Exception('JUNOS version mismatch!!')
        log.debug('JUNOS version match!!')
        log.debug(
                f'[Pass Criteria] JUNOS version capture: {captured_junos_ver}, expect: {self.mapping.junos_version}, result: PASS')

    def check_chassis_hardware(self):
        # 检查 SFP 数量
        while True:
            self.uut.send_wise('show chassis hardware | no-more', self.root_cli_pmt)
            sfp = re.findall('Xcvr', self.uut.buffer)
            log.debug(f'count of SFP: {len(sfp)}')
            port_num = 2 if self.mapping.platform == "EX4000-8P" else 4
            if len(sfp) < port_num:
                if scanner.yes_or_enter_to_continue('Please plugin SFP\n请安装SFP\nCắm SFP') is False:
                    raise Exception(f'check SFP failed! found: {len(sfp)}')
                else:
                    self.sleep_time(20)
                    continue
            # 检查是否是sfp+
            # Xcvr 0       REV 01   740-030589   PMC8040593        SFP+-10G-LPBK
            sfp = re.findall(r'Xcvr (\d+)\s+REV\s+\d+\s+\S+\s+\S+\s+(\S+)', self.uut.buffer)
            for seq, name in sfp:
                log.debug(f'SFP {seq}: {name}')
                if 'SFP+' not in name:
                    log.error(f'SFP {seq} is not a SFP+ LPBK. FAIL!')
                    if scanner.yes_or_enter_to_continue(f'SFP {seq} is not a SFP+ LPBK! Please change another one\n'
                                                        f'SFP {seq} không phải là SFP+ LPBK! Vui lòng thay đổi một cái khác') is False:
                        raise Exception(f'SFP {seq} is not a SFP+ LPBK! FAILED!')
                    else:
                        self.sleep_time(20)
                        break
                log.debug(f'SFP {seq} is a SFP+ LPBK. PASS!')
            else:
                break

        chassis_sn = re.search(r'Chassis\s+(\S+)', self.uut.buffer)
        if chassis_sn is None:
            log.error(
                f'[Pass Criteria] Chassis sn capture: None, expect: {self.sernum}, result: FAIL')
            raise Exception('not found chassis SN!!')
        chassis_sn = chassis_sn.group(1).strip()
        if chassis_sn != self.sernum:
            log.error('Chassis SN mismatch!!')
            log.error(
                f'[Pass Criteria] Chassis sn capture: {chassis_sn}, expect: {self.sernum}, result: FAIL')
            raise Exception('Chassis SN mismatch!!')
        log.debug('Chassis SN match!!')
        log.debug(
                f'[Pass Criteria] Chassis sn capture: {chassis_sn}, expect: {self.sernum}, result: PASS')
        # check FPC REV
        fpc_rev = re.search(r'FPC 0\s+REV (\d+)', self.uut.buffer)
        if fpc_rev is None:
            log.error(
                f'[Pass Criteria] FPC rev capture: None, expect: {self.mapping.arev.r_val}, result: FAIL')
            raise Exception('not found FPC 0 REV!!')
        fpc_rev = fpc_rev.group(1).strip()
        if fpc_rev != self.mapping.arev.r_val:
            log.error('Chassis FPC 0 REV mismatch!!')
            log.error(
                f'[Pass Criteria] FPC rev capture: {fpc_rev}, expect: {self.mapping.arev.r_val}, result: FAIL')
            raise Exception('Chassis FPC 0 REV mismatch!!')
        log.debug('Chassis FPC 0 REV match!!')
        log.debug(
                f'[Pass Criteria] FPC rev capture: {fpc_rev}, expect: {self.mapping.arev.r_val}, result: PASS')

    def show_status(self):
        self.check_chassis_fpc()

        self.check_junos_version()

        self.check_chassis_hardware()

        self.check_chassis_mac_address()

        self.check_system_firmware()

        self.check_chassis_firmware()

        self.check_chassis_firmware_detail()

        self.check_system_storage_mmc_all_status()

        self.check_chassis_interface()

        self.check_system_storage()

        self.check_chassis_environment()

        self.check_chassis_hardware_extensive()

        self.save_system_configuration_rescue()

        self.check_system_alarms()

        self.check_system_memory()

        self.check_system_storage()

        self.check_chassis_power()

        self.check_system_alarms()

        self.check_poe_controller()

        self.check_chassis_alarms()

        self.check_chassis_routing_engine_memory_ecc_statistics()

        self.check_chassis_routing_engine_memory_ecc_statistics()

        self.check_system_core_dumps()

        # self.check_log()

    def check_system_core_dumps(self):
        self.uut.send_wise('show system core-dumps', self.root_cli_pmt)

    # def check_log(self):
    #     self.uut.send_wise('cat /var/log/messages', self.root_cli_pmt)

    def check_chassis_alarms(self):
        self.uut.send_wise('show chassis alarms', self.root_cli_pmt)
        if 'No alarms currently active' not in self.uut.buffer:
            allow_alarms = ['Minor  FPC 0 Fan 0 Spinning Underspeed',
                            'Minor  FPC 0 Fan 1 Spinning Underspeed',
                            'Minor  FPC 0 Fan 2 Spinning Underspeed']
            alarms_fail = list(filter(lambda z: z.split('UTC')[1].strip() not in allow_alarms, list(filter(lambda x: 'UTC' in x, self.uut.buffer.splitlines()))))
            alarms_allow = list(filter(lambda z: z.split('UTC')[1].strip() in allow_alarms, list(filter(lambda x: 'UTC' in x, self.uut.buffer.splitlines()))))

            if alarms_fail:
                raise Exception('found alarms!')
            if alarms_allow and self.ignore_fan_alarm:
                log.debug("FAN RPM > 2000")
                log.debug(f'Ignore {len(alarms_allow)} minor alarms of FAN')
                for j in alarms_allow:
                    log.debug(f'{j.strip()}')
                return
            else:
                raise Exception('found alarms!')
        log.debug('no alarms!')
        log.debug(f"Expected: 'No alarms currently active', Captured: 'No alarms currently active', PASS")

    def check_chassis_routing_engine_memory_ecc_statistics(self):
        self.uut.send_wise('show chassis routing-engine memory-ecc-statistics', self.root_cli_pmt)

    def check_chassis_power(self):
        self.uut.send_wise('show chassis power', self.root_cli_pmt)

    def check_system_memory(self):
        self.uut.send_wise('show system memory | no-more', self.root_cli_pmt, 90)

    def check_chassis_fan(self):
        if ("24" not in self.mapping.platform) and ("48" not in self.mapping.platform):
            return helper.SKIP
        self.uut.send_wise('show chassis fan', self.root_cli_pmt)
        rpm_values = re.findall(r'FPC 0 Fan Tray (\d) Fan 0\s+(\S+)\s+(\d{1,4})\s+Spinning', self.uut.buffer)
        if not rpm_values:
            raise Exception("Not found FAN RPM values")
        for status in rpm_values:
            if int(status[2]) > 2000 and status[1] == "OK":
                log.debug(
                    f'[Pass Criteria] show chassis fan {status[0]} capture: {status[1]}, {status[2]}, expect: OK, RPM>2000, result: PASS')
            else:
                log.error(
                    f'[Pass Criteria] show chassis fan {status[0]} capture: {status[1]}, {status[2]}, expect: OK, RPM>2000, result: FAIL')
                raise Exception(
                    f'[Pass Criteria] show chassis fan {status[0]} capture: {status[1]}, {status[2]}, expect: OK, RPM>2000, result: FAIL')
        self.ignore_fan_alarm = True

    def check_system_alarms(self):
        self.uut.send_wise('show system alarms', self.root_cli_pmt)
        if 'No alarms currently active' not in self.uut.buffer:
            allow_alarms = ['Minor  FPC 0 Fan 0 Spinning Underspeed',
                            'Minor  FPC 0 Fan 1 Spinning Underspeed',
                            'Minor  FPC 0 Fan 2 Spinning Underspeed']
            alarms_fail = list(filter(lambda z: z.split('UTC')[1].strip() not in allow_alarms, list(filter(lambda x: 'UTC' in x, self.uut.buffer.splitlines()))))
            alarms_allow = list(filter(lambda z: z.split('UTC')[1].strip() in allow_alarms, list(filter(lambda x: 'UTC' in x, self.uut.buffer.splitlines()))))

            if alarms_fail:
                raise Exception('found alarms!')
            if alarms_allow and self.ignore_fan_alarm:
                log.debug("FAN RPM > 2000")
                log.debug(f'Ignore {len(alarms_allow)} minor alarms of FAN')
                for j in alarms_allow:
                    log.debug(f'{j.strip()}')
                return
            else:
                raise Exception('found alarms!')
        log.debug('no alarms!')
        log.debug(
                f'[Pass Criteria] show system alarms capture: No alarms currently active, expect: No alarms currently active, result: PASS')

    def check_poe_controller(self):
        self.uut.send_wise('show poe controller', self.root_cli_pmt)

    def save_system_configuration_rescue(self):
        self.uut.send_wise('request system configuration rescue save', self.root_cli_pmt)

    def check_virtual_chassis_status(self):
        # todo 这个不知道要检查什么！
        self.uut.send_wise('show virtual-chassis status', self.root_cli_pmt)

    def check_chassis_hardware_extensive(self):
        # todo 这个不知道要检查什么！
        self.uut.send_wise('show chassis hardware extensive |no-more', self.root_cli_pmt)

    def check_chassis_environment(self):
        self.uut.send_wise('show chassis environment |no-more', self.root_cli_pmt)
        # check status
        check_list = self.mapping.check_list_env
        fail_list = []
        for item in check_list:
            item_status = re.search(r'%s\s+(\S+)' % item, self.uut.buffer)
            item_status = item_status.group(1).strip()
            if item_status != 'OK':
                log.error(f"{item} status is {item_status}, FAIL")
                fail_list.append([item, item_status])
            else:
                log.debug(f"{item} status is {item_status}, PASS")
        if fail_list:
            log.error(
                f'[Pass Criteria] show chassis environment capture: fail items {fail_list}, expect: all items are OK, result: FAIL')
            raise Exception('Check item status have some not OK')
        log.debug(
            f'[Pass Criteria] show chassis environment capture: all items are OK, expect: all items are OK, result: PASS')

    def check_system_storage(self):
        # todo 这个不知道要检查什么！
        self.uut.send_wise('show system storage |no-more', self.root_cli_pmt)

    def check_chassis_interface(self):
        while True:
            self.uut.send_wise('show interfaces terse |no-more', self.root_cli_pmt)
            down = re.findall('down', self.uut.buffer, flags=re.I)
            if len(down) != 0:
                if scanner.yes_or_enter_to_continue(
                        question=f'Found {len(down)} ports! Please ensure all network cable and SFP are installed!\n请确认所有的网线和SFP已安装'
                                 '\nVui lòng xác nhận tất cả các dây mạng và SFP đã được cài đặt.',
                        image='Edradour/images/traffic.png'
                ) is False:
                    log.error(
                        f'[Pass Criteria] show interfaces terse capture: {len(down)} ports down, expect: all ports are UP, result: FAIL')
                    raise Exception(f'found down ports: {len(down)}')
                self.sleep_time(20)
                continue

            log.debug('all ports are UP!')
            log.debug(
                f'[Pass Criteria] show interfaces terse capture: all ports are UP, expect: all ports are UP, result: PASS')

            # 检查RJ45和SFP是否全部都插了
            fail_port = []
            for p in range(self.mapping.rj45_ports):
                rs_buf = re.findall(rf'ge-0/0/{p}\s+up\s+up', self.uut.buffer)
                if not rs_buf:
                    fail_port.append(p)
            if fail_port:
                if scanner.yes_or_enter_to_continue(
                        question=f'Found {fail_port} ports fail! Please ensure all network cable and SFP are installed!\n请确认所有的网线和SFP已安装'
                                 '\nVui lòng xác nhận tất cả các dây mạng và SFP đã được cài đặt.',
                        image='Edradour/images/traffic.png'
                ) is False:
                    raise Exception(f'found down ports: {fail_port}')
                else:
                    self.sleep_time(20)
                    continue

            xe2 = re.findall(rf'xe-0/1/2\s+up\s+up', self.uut.buffer)
            xe3 = re.findall(rf'xe-0/1/3\s+up\s+up', self.uut.buffer)
            if (not xe2) or (not xe3):
                if scanner.yes_or_enter_to_continue(
                        question=f'Check SFP fail! Please ensure all network cable and SFP are installed!\n请确认所有的网线和SFP已安装'
                                 '\nVui lòng xác nhận tất cả các dây mạng và SFP đã được cài đặt.',
                        image='Edradour/images/traffic.png'
                ) is False:
                    raise Exception(f'found down ports')
                else:
                    self.sleep_time(20)
                    continue

            break

    def check_system_firmware(self):
        self.uut.send_wise('show system firmware', self.root_cli_pmt)
        # check POE ver
        if 'P' in self.mapping.platform:
            poe_ver = re.search(r'FPC 0\s+POE\s+(\S+)\s+(\S+)',  self.uut.buffer)
            if poe_ver is None:
                raise Exception('not found FPC 0 POE version!!')
            current_poe_ver = poe_ver.group(1).strip()
            available_poe_ver = poe_ver.group(2).strip()
            log.debug(f'Current POE version is: {current_poe_ver}')
            log.debug(f'Available POE version is: {available_poe_ver}')
            if current_poe_ver != available_poe_ver:
                log.debug(f'Current POE version not match Available POE version, Need Upgrade POE version')
                self.poe_fw_upgrade()
                return
            else:
                log.debug(f'[Pass Criteria] Current POE version match Available POE version, result: PASS')
                self.poe_version = available_poe_ver
        # check u_boot
        u_boot_ver = re.search(r'FPC 0\s+U-Boot\s+(\S+)',  self.uut.buffer)
        if u_boot_ver is None:
            raise Exception('not found FPC 0 U-Boot version!!')
        u_boot_ver = u_boot_ver.group(1).strip()
        if u_boot_ver != self.mapping.u_boot:
            log.error('FPC 0 U-Boot version mismatch!!')
            log.error(f'[Pass Criteria] U-Boot version capture: {u_boot_ver}, expect: {self.mapping.u_boot}, result: FAIL')
            raise Exception('FPC 0 U-Boot version mismatch!!')
        log.debug('FPC 0 U-Boot version match!!')
        log.debug(f'[Pass Criteria] U-Boot version capture: {u_boot_ver}, expect: {self.mapping.u_boot}, result: PASS')
        # check CPLD
        cpld_ver = re.search(r'FPC 0\s+CPLD\s+(\S+)',  self.uut.buffer)
        if cpld_ver is None:
            raise Exception('not found FPC 0 CPLD version!!')
        cpld_ver = cpld_ver.group(1).strip()
        log.debug(f'Captured FPC 0 CPLD version: {cpld_ver}')
        log.debug(f'Expected FPC 0 CPLD version: {self.mapping.cpld}')
        # todo update cpld in junos only support 48MP
        if cpld_ver not in [self.mapping.cpld, self.mapping.cpld_old]:
            log.error('FPC 0 CPLD version mismatch!!, Start update CPLD...')
            self.update_cpld_uboot()
            return
        log.debug('FPC 0 CPLD version match!!')
        log.debug(f'[Pass Criteria] CPLD version capture: {cpld_ver}, expect: {[self.mapping.cpld, self.mapping.cpld_old]}, result: PASS')

    def update_cpld_uboot(self):
        self.uut.send_wise('edit', self.root_pmt)
        # self.uut.send_wise('set system root-authentication plain-text-password', 'New password:')
        # self.uut.send_wise('Juniper123', 'Retype new password:')
        # self.uut.send_wise('Juniper123', self.root_pmt)
        self.uut.send_wise('delete interfaces vme', self.root_pmt)
        self.uut.send_wise(f"set interfaces me0 unit 0 family inet address {helper.config['uut_ip']}/24", self.root_pmt)
        self.uut.send_wise('commit', self.root_pmt)
        self.uut.send_wise('exit', self.root_cli_pmt)
        self.uut.send_wise('exit', self.root_re_pmt)
        self.sleep_time(20)
        self.uut.send_wise(f'scp genius@10.1.1.1:/tftpboot/edradour/{self.mapping.junos_cpld_filename} /var/tmp/', ["password", 'yes/no'])
        if 'yes/no' in self.uut.buffer:
            self.uut.send_wise('yes', 'password')
        self.uut.send_wise('genius', self.root_re_pmt)
        self.uut.send_wise('cli', self.root_cli_pmt)

        self.uut.send_wise('edit', self.root_pmt)
        self.uut.send_wise('delete interfaces me0', self.root_pmt)
        self.uut.send_wise(f"set interfaces vme unit 0 family inet address {helper.config['uut_ip']}/24", self.root_pmt)
        self.uut.send_wise('commit', self.root_pmt)
        self.uut.send_wise('exit', self.root_cli_pmt)

        self.uut.send_wise(f'request system software add /var/tmp/{self.mapping.junos_cpld_filename}', self.root_cli_pmt)
        self.uut.send_wise(f'request system firmware upgrade jfirmware cpld sys', self.root_cli_pmt)
        if 'not needed' not in self.uut.buffer:
            while True:
                self.uut.send_wise(f'request system firmware upgrade jfirmware cpld sys progress', self.root_cli_pmt)
                if 'complete' in self.uut.buffer:
                    break
                self.sleep_time(10)

        self.uut.send_wise(f'request system firmware upgrade jfirmware uboot', self.root_cli_pmt)
        if 'not needed' not in self.uut.buffer:
            while True:
                self.uut.send_wise(f'request system firmware upgrade jfirmware uboot progress', self.root_cli_pmt)
                if 'complete' in self.uut.buffer:
                    break
                self.sleep_time(10)
        # reboot
        self.uut.send_wise('request system reboot', '[yes,no] (no)')
        self.uut.send_wise('yes', 'login:', 10 * 60)
        self.sleep_time(60)
        self.login_junos()
        self.uut.send_wise('cli', self.root_cli_pmt)

        self.uut.send_wise('show system firmware', self.root_cli_pmt)
        # check POE ver
        if 'P' in self.mapping.platform:
            poe_ver = re.search(r'FPC 0\s+POE\s+(\S+)',  self.uut.buffer)
            if poe_ver is None:
                raise Exception('not found FPC 0 POE version!!')
            poe_ver = poe_ver.group(1).strip()
            if poe_ver != self.mapping.poe:
                log.error('FPC 0 POE version mismatch!!')
                log.error(
                    f'[Pass Criteria] POE version capture: {poe_ver}, expect: {self.mapping.poe}, result: FAIL')
                raise Exception('FPC 0 POE version mismatch!!')
            log.debug('FPC 0 POE version match!!')
            log.debug(
                f'[Pass Criteria] POE version capture: {poe_ver}, expect: {self.mapping.poe}, result: PASS')
        # check u_boot
        u_boot_ver = re.search(r'FPC 0\s+U-Boot\s+(\S+)',  self.uut.buffer)
        if u_boot_ver is None:
            raise Exception('not found FPC 0 U-Boot version!!')
        u_boot_ver = u_boot_ver.group(1).strip()
        if u_boot_ver != self.mapping.u_boot:
            log.error('FPC 0 U-Boot version mismatch!!')
            log.error(
                f'[Pass Criteria] FPC 0 U-Boot version capture: {u_boot_ver}, expect: {self.mapping.u_boot}, result: FAIL')
            raise Exception('FPC 0 U-Boot version mismatch!!')
        log.debug('FPC 0 U-Boot version match!!')
        log.debug(
                f'[Pass Criteria] FPC 0 U-Boot version capture: {u_boot_ver}, expect: {self.mapping.u_boot}, result: PASS')
        # check CPLD
        cpld_ver = re.search(r'FPC 0\s+CPLD\s+(\S+)',  self.uut.buffer)
        if cpld_ver is None:
            raise Exception('not found FPC 0 CPLD version!!')
        cpld_ver = cpld_ver.group(1).strip()
        log.debug(f'Captured FPC 0 CPLD version: {cpld_ver}')
        log.debug(f'Expected FPC 0 CPLD version: {self.mapping.cpld}')
        if cpld_ver != self.mapping.cpld:
            log.error('FPC 0 CPLD version mismatch!!')
            log.error(
                f'[Pass Criteria] CPLD version capture: {cpld_ver}, expect: {self.mapping.cpld}, result: FAIL')
            raise Exception('FPC 0 CPLD version mismatch!!')
        log.debug('FPC 0 CPLD version match!!')
        log.debug(
                f'[Pass Criteria] CPLD version capture: {cpld_ver}, expect: {self.mapping.cpld}, result: PASS')


    def check_chassis_firmware(self):
        self.uut.send_wise('show chassis firmware', self.root_cli_pmt)
        # check u_boot
        u_boot_ver = re.search(r'U-Boot\s+(\S+)',  self.uut.buffer)
        if u_boot_ver is None:
            raise Exception('not found FPC 0 U-Boot version!!')
        u_boot_ver = u_boot_ver.group(1).strip()
        if u_boot_ver != self.mapping.u_boot:
            log.error('FPC 0 U-Boot version mismatch!!')
            log.error(
                f'[Pass Criteria] U-Boot version capture: {u_boot_ver}, expect: {self.mapping.u_boot}, result: FAIL')
            raise Exception('FPC 0 U-Boot version mismatch!!')
        log.debug('FPC 0 U-Boot version match!!')
        log.debug(
                f'[Pass Criteria] U-Boot version capture: {u_boot_ver}, expect: {self.mapping.u_boot}, result: PASS')
        # check CPLD
        cpld_ver = re.search(r'CPLD\s+(\S+)',  self.uut.buffer)
        if cpld_ver is None:
            raise Exception('not found FPC 0 CPLD version!!')
        cpld_ver = cpld_ver.group(1).strip()
        if cpld_ver not in [self.mapping.cpld, self.mapping.cpld_old]:
            log.error('FPC 0 CPLD version mismatch!!')
            log.error(
                f'[Pass Criteria] CPLD version capture: {cpld_ver}, expect: {[self.mapping.cpld, self.mapping.cpld_old]}, result: FAIL')
            raise Exception('FPC 0 CPLD version mismatch!!')
        log.debug('FPC 0 CPLD version match!!')
        log.debug(
                f'[Pass Criteria] CPLD version capture: {cpld_ver}, expect: {[self.mapping.cpld, self.mapping.cpld_old]}, result: PASS')

    def check_chassis_firmware_detail(self):
        self.uut.send_wise('show chassis firmware detail', self.root_cli_pmt)
        # check POE ver
        if 'P' in self.mapping.platform:
            poe_ver = re.search(r'PoE firmware\s+(\S+)', self.uut.buffer)
            if poe_ver is None:
                raise Exception('not found FPC 0 POE version!!')
            poe_ver = poe_ver.group(1).strip()
            if poe_ver != self.poe_version:
                log.error('FPC 0 POE version mismatch!!')
                log.error(
                f'[Pass Criteria] POE version capture: {poe_ver}, expect: {self.poe_version}, result: FAIL')
                raise Exception('FPC 0 POE version mismatch!!')
            log.debug('FPC 0 POE version match!!')
            log.debug(
                f'[Pass Criteria] POE version capture: {poe_ver}, expect: {self.poe_version}, result: PASS')

        # check u_boot
        u_boot_ver = re.search(r'U-Boot\s+(\S+)',  self.uut.buffer)
        if u_boot_ver is None:
            raise Exception('not found FPC 0 U-Boot version!!')
        u_boot_ver = u_boot_ver.group(1).strip()
        if u_boot_ver != self.mapping.u_boot:
            log.error('FPC 0 U-Boot version mismatch!!')
            log.error(
                f'[Pass Criteria] U-Boot version capture: {u_boot_ver}, expect: {self.mapping.u_boot}, result: FAIL')
            raise Exception('FPC 0 U-Boot version mismatch!!')
        log.debug('FPC 0 U-Boot version match!!')
        log.debug(
                f'[Pass Criteria] U-Boot version capture: {u_boot_ver}, expect: {self.mapping.u_boot}, result: PASS')

    def check_system_storage_mmc_all_status(self):
        # todo 没有检查标准
        self.uut.send_wise('show system storage mmc all status', self.root_cli_pmt)

    def check_chassis_storage_mmc(self):
        # todo 没有检查标准
        self.uut.send_wise('show chassis storage mmc all status', self.root_cli_pmt)

    def check_chassis_mac_address(self):
        self.uut.send_wise('show chassis mac-addresses', self.root_cli_pmt)
        helper.check_item('Base address', self.mac_address.lower(), r'Base address\s+(\S+)', self.uut.buffer)
        helper.check_item('Count', str(self.mac_block_size), r'Count\s+(\d+)', self.uut.buffer)

    def check_mgmt_mac(self):
        self.uut.send_wise('show interfaces me0', self.root_cli_pmt)
        helper.check_item('Hardware address:', self.mac_address, r'Hardware address:\s+(\S+)', self.uut.buffer)
        hw_mac = self.mac_address.replace(':', '')

        if helper.mode == helper.PROD:
            current_time = helper.get_local_datetime()
            while True:
                try:
                    sfchelper.upload_mgmt_mac(sn=self.sernum, mac=hw_mac.upper(), current_time=current_time)
                    break
                except Exception as e:
                    if scanner.yes_or_enter_to_continue(question=f"Upload mgmt MAC fail: {e}") is False:
                        raise Exception(f"Upload mgmt MAC fail: {e}")


    def check_chassis_fpc(self):
        for i in range(5):
            self.uut.send_wise('show chassis fpc', self.root_cli_pmt)
            if ' 0  Online' not in self.uut.buffer:
                self.sleep_time(60)
                log.debug("fpc 0 is not online! retry...")
                continue
            log.debug('fpc 0 is online!')
            log.debug(
                f"[Pass Criteria] capture: ' 0  Online', expect:' 0  Online', result: PASS")
            self.uut.send_wise('show chassis fpc detail', self.root_cli_pmt)
            helper.check_item('State', 'Online', r'State\s+(\w+)', self.uut.buffer)
            break
        else:
            log.error(
                f"[Pass Criteria] capture: None, expect:' 0  Online', result: FAIL")
            raise Exception('fpc 0 is not online!')

    def system_zeroize(self):
        # if self.mapping.group in [df.GROUP_2, df.GROUP_3]:
        #     return helper.SKIP

        self.uut.send_wise('request system zeroize media', '[yes,no] (no)')
        self.uut.send_wise('yes', '')
        self.uut.waitfor('login:', 20 * 60)
        self.sleep_time(20)
        self.uut.send_wise('', 'login:')
        self.uut.send_wise('root', [self.root_re_pmt, 'Password:'])
        if 'Password:' in self.uut.buffer:
            raise Exception('system zeroize failed!')
        if self.root_re_pmt not in self.uut.buffer:
            raise Exception(f'not found {self.root_re_pmt}!!!')
        log.debug('system zeroize OK..')
        self.uut.send_wise('cli', self.root_cli_pmt)

    def request_system_halt(self):
        # if self.mapping.group in [df.GROUP_2, df.GROUP_3]:
        #     return helper.SKIP

        self.uut.send_wise('request system halt', '[yes,no] (no)')
        self.uut.send_wise('yes', '')
        self.uut.waitfor('System going down in 30 seconds', 120)
        self.uut.waitfor('Please press any key to reboot', 120)
        log.debug('system is down!')

    def power_off(self):
        self.pdu.power_off(helper.config['pdu_port'])

    def init_connections(self):
        self.uut = UUT(conn_str=helper.config['uut_conn_str'])
        self.pdu = APC(conn_str=helper.config['pdu_conn_str'])


    def close_all_connections(self):
        self.uut.do_disconnect()

    def first_step_of_pre_seq(self):
        self.check_latest_repo_version(self.product_name)
        super().first_step_of_pre_seq()

    def upload_test_records(self):
        self.update_test_status()
        helper.quick_set('Upload to Genius')
        super().add_genius_records(
            str1name='BASE_MAC',
            str1=self.mac_address,
            str2name='JNPR_Uboot_Version',
            str2=self.mapping.jnpr_uboot_version,
            str3name='JUNOS_Version',
            str3=self.mapping.junos_version,
            str4name='JUNOS_POE_Firmware_Version',
            str4=self.poe_version,
            str6name='Script_Version',
            str6=self.current_version,
        )
        helper.quick_set('Upload to MES')
        self.add_mes_records()

class FCA(FST):
    # 特殊工站，应该只有工站名不同
    area = 'FCA'
